# Prompt used to build Air Share (reusable)

Build a native Android feature (Kotlin + Jetpack Compose, no WebView) inside the existing "Air Flow" app that sends photos between two phones with hand gestures only, like Huawei Air Gestures.

1. Gesture: open palm hold = ready, fist = capture (photo shrinks into a glowing orb with an implode particle effect + haptic), open hand = release (shockwave ring, comet trail, orb flies away). Reuse the existing MediaPipe HandController / GestureEngine poses.
2. Receiving phone: the orb descends with a spring, lands, morphs back into the photo with a particle burst, saves to Pictures/AirFlow.
3. Show in the app, live: camera with hand skeleton, the pose being seen, step tracker with hold-progress bars, and plain-language corrections for each step. Include an animated demo of every step (sender phone -> receiver phone).
4. Connect by 6-digit code and QR (generate with ZXing, scan with Google code scanner). The code is also verified by both sides.
5. Two transports: (a) offline Google Nearby Connections, (b) online via Firebase Realtime DB (signal) + Supabase Storage (photo) over plain REST, configurable in-app.
6. Deliver as one ZIP the user uploads to GitHub; the existing GitHub Actions workflow builds the APK. Keep the premium Aurora/Pearl UI and spring animations.
