package com.airflow.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class HandsFreeTest {

    /** Feeds a blink: both eyes [l]/[r] for [ms], then open, at ~30 fps. Returns the clicks seen. */
    private fun blink(c: BlinkClassifier, start: Long, ms: Long, l: Float, r: Float): List<BlinkClassifier.Click> {
        val out = ArrayList<BlinkClassifier.Click>()
        var t = start
        while (t < start + ms) { out.add(c.update(l, r, t)); t += 33 }
        for (i in 0..3) { out.add(c.update(0f, 0f, t)); t += 33 }
        return out.filter { it != BlinkClassifier.Click.NONE }
    }

    @Test fun twentyNormalBlinksNeverClick() {
        val c = BlinkClassifier()
        var clicks = 0
        for (i in 0 until 20) clicks += blink(c, 1000L + i * 2000L, 130, 0.9f, 0.9f).size
        assertEquals(0, clicks)
    }

    @Test fun twentyWinksClick() {
        val c = BlinkClassifier()
        var clicks = 0
        for (i in 0 until 20) clicks += blink(c, 1000L + i * 2000L, 420, 0.9f, 0.1f).count { it == BlinkClassifier.Click.WINK }
        assertTrue(clicks >= 19)
    }

    @Test fun shortWinkDoesNotClick() {
        val c = BlinkClassifier()
        assertEquals(0, blink(c, 1000, 120, 0.9f, 0.1f).size)
    }

    @Test fun firmBlinkClicksAndBaselineRaisesTheBar() {
        val slow = BlinkClassifier(List(20) { 300L })   // this person blinks slowly
        assertTrue(slow.firmMinMs() >= 330L)
        val c = BlinkClassifier()
        assertEquals(1, blink(c, 1000, 600, 0.9f, 0.9f).count { it == BlinkClassifier.Click.FIRM })
    }

    @Test fun oneEuroSettlesAndFollowsFastMoves() {
        val f = OneEuroF()
        var v = 0f
        for (i in 0 until 60) v = f.filter(0.5f, 0.033f, 0.9f, 22f)
        assertEquals(0.5f, v, 0.001f)
        // a fast jump is followed quickly because beta opens the filter
        var after = 0f
        for (i in 0 until 5) after = f.filter(0.9f, 0.033f, 0.9f, 22f)
        assertTrue(after > 0.75f)
    }

    @Test fun zoomFastFlickBeatsSlowMove() {
        val slow = ZoomMath.step(0.02f, 0.6f, 1080f, 1f)
        val fast = ZoomMath.step(0.02f, 3.0f, 1080f, 1f)
        assertTrue(fast > slow * 2f)
        assertTrue(ZoomMath.step(0.05f, 1f, 1080f, 1f) > 0f)   // spreading zooms in
        assertTrue(ZoomMath.step(-0.05f, 1f, 1080f, 1f) < 0f)  // closing zooms out
        assertEquals(0.5f, ZoomMath.level(1f, 100f), 0.001f)
        assertEquals(8f, ZoomMath.level(10000f, 100f), 0.001f)
    }
}
