package com.airflow.app

import android.app.Activity
import android.app.PendingIntent
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.service.quicksettings.Tile
import android.service.quicksettings.TileService
import android.widget.Toast
import androidx.core.content.ContextCompat
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

/**
 * Quick Drop: a link, a piece of text, a YouTube video or whatever is on the clipboard, sent in one tiny
 * message (no file offer, nothing to wait for), so it lands on the other phone almost instantly.
 * [kind] is "link", "text" or "yt".
 */
class QuickItem(
    val kind: String,
    val text: String,
    val title: String = "",
    val thumb: Bitmap? = null,
    val thumbBytes: ByteArray? = null
) {
    val isYoutube: Boolean get() = kind == "yt"
    val isLink: Boolean get() = kind == "link" || kind == "yt"

    /** What to show as the headline: the title when there is one, otherwise the text itself. */
    val shown: String get() = if (title.isNotBlank()) title else text
}

object QuickParser {
    private val urlRe = Regex("https?://\\S+")

    /** Turns shared or clipboard text into an item: a link (YouTube gets its own kind) or plain text. */
    fun parse(raw: String?): QuickItem? {
        val t = raw?.trim() ?: return null
        if (t.isEmpty()) return null
        val m = urlRe.find(t)
        if (m != null) {
            val url = m.value.trimEnd('.', ',', ')', ']', '"')
            val extra = t.replace(m.value, "").trim().take(160)
            return QuickItem(if (ytId(url) != null) "yt" else "link", url, extra)
        }
        return QuickItem("text", t.take(2000))
    }

    fun ytId(url: String): String? {
        val u = try { Uri.parse(url) } catch (e: Exception) { return null }
        val host = (u.host ?: "").lowercase()
        val id: String? = when {
            host.endsWith("youtu.be") -> u.lastPathSegment
            host.contains("youtube.com") -> u.getQueryParameter("v") ?: u.pathSegments.let { seg ->
                if (seg.size >= 2 && (seg[0] == "shorts" || seg[0] == "embed" || seg[0] == "live")) seg[1] else null
            }
            else -> null
        }
        return id?.takeIf { it.length in 6..20 }
    }
}

/** Fetches a title (and, for YouTube, the thumbnail) so the receiver sees a ready card even offline. Blocking: call off the main thread. */
object QuickFetch {

    private fun get(url: String, maxBytes: Int): ByteArray? {
        var con: HttpURLConnection? = null
        return try {
            con = URL(url).openConnection() as HttpURLConnection
            con.connectTimeout = 2500
            con.readTimeout = 2500
            con.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android) AirFlow")
            if (con.responseCode !in 200..299) null
            else {
                val out = ByteArrayOutputStream()
                val buf = ByteArray(8192)
                con.inputStream.use { i ->
                    while (out.size() < maxBytes) {
                        val n = i.read(buf)
                        if (n <= 0) break
                        out.write(buf, 0, n)
                    }
                }
                out.toByteArray()
            }
        } catch (e: Exception) {
            null
        } finally {
            try { con?.disconnect() } catch (_: Exception) {}
        }
    }

    private fun shrink(src: ByteArray): Pair<Bitmap, ByteArray>? {
        val b = try { BitmapFactory.decodeByteArray(src, 0, src.size) } catch (e: Exception) { null } ?: return null
        val scaled = if (b.width > 320) Bitmap.createScaledBitmap(b, 320, (b.height * 320f / b.width).toInt().coerceAtLeast(1), true) else b
        var q = 62
        var out: ByteArray
        do {
            val bo = ByteArrayOutputStream()
            scaled.compress(Bitmap.CompressFormat.JPEG, q, bo)
            out = bo.toByteArray()
            q -= 12
        } while (out.size > 13500 && q > 20)
        return if (out.size <= 14000) Pair(scaled, out) else null
    }

    fun enrich(item: QuickItem): QuickItem {
        if (!item.isLink) return item
        try {
            if (item.isYoutube) {
                val id = QuickParser.ytId(item.text)
                var title = item.title
                val meta = get("https://www.youtube.com/oembed?format=json&url=" + URLEncoder.encode(item.text, "UTF-8"), 20000)
                if (meta != null) {
                    val t = try { JSONObject(String(meta)).optString("title", "") } catch (e: Exception) { "" }
                    if (t.isNotBlank()) title = t
                }
                var th: Pair<Bitmap, ByteArray>? = null
                if (id != null) {
                    val raw = get("https://i.ytimg.com/vi/$id/mqdefault.jpg", 120000)
                    if (raw != null) th = shrink(raw)
                }
                return QuickItem("yt", item.text, title, th?.first, th?.second)
            }
            val page = get(item.text, 40000)
            if (page != null && item.title.isBlank()) {
                val m = Regex("<title[^>]*>([^<]{1,200})</title>", RegexOption.IGNORE_CASE).find(String(page))
                val t = m?.groupValues?.get(1)?.trim()?.replace(Regex("\\s+"), " ") ?: ""
                if (t.isNotBlank()) return QuickItem("link", item.text, t.take(160))
            }
        } catch (_: Exception) {
        }
        return item
    }
}

object QuickActions {
    fun open(ctx: Context, item: QuickItem) {
        if (!item.isLink) { copy(ctx, item); return }
        try {
            ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(item.text)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (_: Exception) {
        }
    }

    /** Opens a YouTube link in the YouTube app when it is installed (the link keeps its timestamp). */
    fun play(ctx: Context, item: QuickItem) {
        try {
            ctx.startActivity(
                Intent(Intent.ACTION_VIEW, Uri.parse(item.text)).setPackage("com.google.android.youtube")
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
        } catch (e: Exception) {
            open(ctx, item)
        }
    }

    fun copy(ctx: Context, item: QuickItem) {
        try {
            val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            cm.setPrimaryClip(ClipData.newPlainText("Air Flow", item.text))
        } catch (_: Exception) {
        }
    }
}

/** The last few things received by Quick Drop, kept on this phone so nothing is lost if the animation is missed. */
object QuickHistory {
    fun add(item: QuickItem) {
        try {
            val old = JSONArray(Prefs.quickHistory)
            val arr = JSONArray()
            arr.put(JSONObject().put("k", item.kind).put("t", item.text).put("ti", item.title).put("ts", System.currentTimeMillis()))
            for (i in 0 until minOf(old.length(), 9)) arr.put(old.getJSONObject(i))
            Prefs.quickHistory = arr.toString()
        } catch (_: Exception) {
        }
    }

    fun list(): List<QuickItem> {
        val out = ArrayList<QuickItem>()
        try {
            val arr = JSONArray(Prefs.quickHistory)
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                out.add(QuickItem(o.optString("k", "text"), o.optString("t"), o.optString("ti")))
            }
        } catch (_: Exception) {
        }
        return out
    }

    fun clear() { Prefs.quickHistory = "[]" }
}

/** Quick Settings tile: send whatever is on the clipboard to the phone you touch. */
class ClipboardTileService : TileService() {
    override fun onStartListening() {
        val t = qsTile ?: return
        t.state = Tile.STATE_INACTIVE
        t.label = "Send clipboard"
        if (Build.VERSION.SDK_INT >= 29) t.subtitle = "Quick Drop"
        t.updateTile()
    }

    @Suppress("DEPRECATION")
    override fun onClick() {
        val i = Intent(this, QuickClipActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        if (Build.VERSION.SDK_INT >= 34) {
            startActivityAndCollapse(PendingIntent.getActivity(this, 41, i, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT))
        } else {
            startActivityAndCollapse(i)
        }
    }
}

/**
 * See-through screen the clipboard tile opens. Android only lets an app read the clipboard while it has focus,
 * so this reads it the moment it is in front, then hands it to Air Share and closes.
 */
class QuickClipActivity : Activity() {
    private var done = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Prefs.init(this)
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (!hasFocus || done) return
        done = true
        val text = try {
            val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            cm.primaryClip?.takeIf { it.itemCount > 0 }?.getItemAt(0)?.coerceToText(this)?.toString()
        } catch (e: Exception) { null }
        val item = QuickParser.parse(text)
        if (item == null) {
            Toast.makeText(this, "The clipboard is empty", Toast.LENGTH_SHORT).show()
            finish()
            return
        }
        QuickSender.start(this, item)
        finish()
    }
}

/** Shared by the share sheet, the clipboard tile and the in-app button. */
object QuickSender {
    /** Arms the item, makes sure Air Share / Tap Share is running, and adds the title and thumbnail in the background. */
    fun start(ctx: Context, item: QuickItem) {
        val app = ctx.applicationContext
        if (Perms.missing(app).isNotEmpty()) {
            Toast.makeText(app, "Open Air Flow once and allow Nearby devices and Location", Toast.LENGTH_LONG).show()
            return
        }
        AirShareHub.armQuick(app, item)
        if (!AirShareHub.active.value) {
            try {
                ContextCompat.startForegroundService(app, Intent(app, AirFlowService::class.java).setAction(AirFlowService.ACTION_TAP))
            } catch (e: Exception) {
                Toast.makeText(app, "Could not start Tap Share: ${e.message}", Toast.LENGTH_LONG).show()
            }
        }
        Toast.makeText(app, "Touch the phones together to send", Toast.LENGTH_SHORT).show()
        if (item.isLink) {
            Thread {
                val rich = QuickFetch.enrich(item)
                AirShareHub.updateQuick(item, rich)
            }.start()
        }
    }
}
