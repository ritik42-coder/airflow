package com.airflow.app

import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.layout.boundsInRoot
import androidx.compose.ui.layout.onGloballyPositioned

/**
 * Remembers where the buttons are, so a fingertip can press them without touching the glass.
 * Every air screen shares this.
 */
class AirReg {
    val rects = HashMap<String, Rect>()
    val actions = HashMap<String, () -> Unit>()

    fun hit(x: Float, y: Float): String? {
        for (key in rects.keys) {
            val r = rects[key] ?: continue
            if (x >= r.left && x <= r.right && y >= r.top && y <= r.bottom) return key
        }
        return null
    }
}

@Composable
fun Modifier.airTarget(reg: AirReg, id: String, onClick: () -> Unit): Modifier = composed {
    SideEffect { reg.actions[id] = onClick }
    onGloballyPositioned { co -> reg.rects[id] = co.boundsInRoot() }
}
