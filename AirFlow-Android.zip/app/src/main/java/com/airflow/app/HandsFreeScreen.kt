package com.airflow.app

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.clickable
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver

/**
 * Hands-free: head moves the cursor, a wink or dwell clicks, spread your fingers to zoom, face gestures
 * for the rest. The camera work is in AirFlowService + HandsFree.kt; this is the control panel and a practice area.
 */
@Composable
fun HandsFreeScreen() {
    val ctx = LocalContext.current
    val owner = LocalLifecycleOwner.current
    val c = Air.c
    var tick by remember { mutableIntStateOf(0) }
    DisposableEffect(owner) {
        val obs = LifecycleEventObserver { _, e -> if (e == Lifecycle.Event.ON_RESUME) tick++ }
        owner.lifecycle.addObserver(obs)
        onDispose { owner.lifecycle.removeObserver(obs) }
    }
    val running by AirFlowState.running.collectAsState()
    val error by AirFlowState.error.collectAsState()
    val camOk = remember(tick) { ContextCompat.checkSelfPermission(ctx, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED }
    val accOk = remember(tick) { AirFlowAccessibilityService.instance != null }
    val modelOk = remember { try { ctx.assets.list("")?.contains("face_landmarker.task") == true } catch (e: Exception) { false } }

    var on by remember { mutableStateOf(Prefs.handsFree) }
    var head by remember { mutableStateOf(Prefs.hfHead) }
    var click by remember { mutableStateOf(Prefs.hfClick) }
    var sens by remember { mutableFloatStateOf(Prefs.hfSens) }
    var zoom by remember { mutableStateOf(Prefs.hfZoom) }
    var zoomSpeed by remember { mutableFloatStateOf(Prefs.hfZoomSpeed) }
    var face by remember { mutableStateOf(Prefs.hfFace) }
    var edge by remember { mutableStateOf(Prefs.hfEdgeScroll) }
    var perf by remember { mutableIntStateOf(Prefs.hfPerf) }
    var preset by remember { mutableStateOf("") }

    val camLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        tick++
        if (ok && on && !AirFlowState.running.value) ContextCompat.startForegroundService(ctx, Intent(ctx, AirFlowService::class.java))
    }

    fun setOn(v: Boolean) {
        on = v
        Prefs.handsFree = v
        if (v) {
            if (!camOk) camLauncher.launch(Manifest.permission.CAMERA)
            else if (!running) ContextCompat.startForegroundService(ctx, Intent(ctx, AirFlowService::class.java))
        }
    }

    fun apply(h: Boolean, m: String, s: Float) {
        head = h; Prefs.hfHead = h
        click = m; Prefs.hfClick = m
        sens = s; Prefs.hfSens = s
    }

    AirScroll {
        ScreenHeader("Hands-free", "Head, eyes and hand control the whole phone. No touch.")

        SectionCard(if (on) "Hands-free is ON" else "Hands-free is OFF") {
            Text(
                if (on && running) "Move your head to point. Wink to click. Spread two fingers to zoom."
                else "Turn it on, then use any app. The camera stays on this phone, no video is saved or sent.",
                style = MaterialTheme.typography.bodySmall, color = if (on && running) c.ok else c.dim
            )
            AirButton(
                if (on) "Turn off" else "Turn on Hands-free",
                { setOn(!on) }, Modifier.fillMaxWidth(), icon = IconKind.BOLT
            )
            if (!camOk) Text("Camera permission is needed.", style = MaterialTheme.typography.bodySmall, color = c.a2)
            if (!accOk) Text("Switch on the Air Flow Accessibility service (Home tab): it does the tapping, scrolling and zoom for you.", style = MaterialTheme.typography.bodySmall, color = c.a2)
            if (!modelOk) Text("The face model is missing from this build. The GitHub workflow downloads it; use the workflow in this ZIP.", style = MaterialTheme.typography.bodySmall, color = c.a2)
            if (error != null) Text(error ?: "", style = MaterialTheme.typography.bodySmall, color = c.a2)
        }

        SectionCard("Easy start: pick one") {
            Text("One tap sets pointer, click and speed for you. You can fine-tune below.", style = MaterialTheme.typography.bodySmall, color = c.dim)
            AirButton("Easiest: head + hold still to click", { apply(true, "dwell", 1.0f); preset = "easy" }, Modifier.fillMaxWidth(), filled = preset == "easy")
            AirButton("Fast: head + wink to click", { apply(true, "wink", 1.2f); preset = "fast" }, Modifier.fillMaxWidth(), filled = preset == "fast")
            AirButton("Hands only: no head cursor", { apply(false, "wink", 1.0f); preset = "hands" }, Modifier.fillMaxWidth(), filled = preset == "hands")
        }

        SectionCard("Pointer") {
            AirButton(if (head) "Head moves the cursor: ON" else "Head moves the cursor: OFF", { head = !head; Prefs.hfHead = head }, Modifier.fillMaxWidth(), filled = head)
            Text("Reach: how far the cursor goes for a small head move", style = MaterialTheme.typography.bodySmall, color = c.dim)
            AirSlider(sens, { sens = it; Prefs.hfSens = it }, 0.5f..2.5f, Modifier.fillMaxWidth())
            AirButton("Recenter (look at the middle, then tap)", { HandsFree.recenter() }, Modifier.fillMaxWidth(), filled = false)
            AirButton(if (edge) "Edge scroll: ON (rest at top or bottom edge)" else "Edge scroll: OFF", { edge = !edge; Prefs.hfEdgeScroll = edge }, Modifier.fillMaxWidth(), filled = edge)
        }

        SectionCard("Click") {
            Text("A normal blink never clicks. Pick how you want to click:", style = MaterialTheme.typography.bodySmall, color = c.dim)
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                AirButton("Wink", { click = "wink"; Prefs.hfClick = "wink" }, Modifier.weight(1f), filled = click == "wink")
                AirButton("Hold still", { click = "dwell"; Prefs.hfClick = "dwell" }, Modifier.weight(1f), filled = click == "dwell")
                AirButton("Smile", { click = "smile"; Prefs.hfClick = "smile" }, Modifier.weight(1f), filled = click == "smile")
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                AirButton("Firm blink", { click = "firm"; Prefs.hfClick = "firm" }, Modifier.weight(1f), filled = click == "firm")
                AirButton("Double blink", { click = "double"; Prefs.hfClick = "double" }, Modifier.weight(1f), filled = click == "double")
            }
            Text(
                "Wink: close one eye for about half a second. Firm blink: close both eyes a little longer than a normal blink (it learns how long YOURS are). " +
                    "Hold still: keep the cursor still for 1 second. The click lands where the cursor was just before your eye closed.",
                style = MaterialTheme.typography.bodySmall, color = c.dim
            )
        }

        SectionCard("Zoom like a screen") {
            AirButton(if (zoom) "Thumb-index zoom: ON" else "Thumb-index zoom: OFF", { zoom = !zoom; Prefs.hfZoom = zoom }, Modifier.fillMaxWidth(), filled = zoom, icon = IconKind.SHARE)
            Text("Hold your open hand up, then spread thumb and index apart to zoom in, bring them together to zoom out. A fast flick zooms more than a slow move.", style = MaterialTheme.typography.bodySmall, color = c.dim)
            AirSlider(zoomSpeed, { zoomSpeed = it; Prefs.hfZoomSpeed = it }, 0.5f..2.5f, Modifier.fillMaxWidth())
        }

        SectionCard("Face gestures") {
            AirButton(if (face) "Face gestures: ON" else "Face gestures: OFF", { face = !face; Prefs.hfFace = face }, Modifier.fillMaxWidth(), filled = face)
            Text(
                "Eyebrows up: Back.   Head tilt: previous or next.   Mouth open for 0.7 s: pause or resume everything.   " +
                    "Smile for 0.7 s: recenter the cursor.   Without a head cursor, nod down or up scrolls.",
                style = MaterialTheme.typography.bodySmall, color = c.dim
            )
            Text("Speed and battery", style = MaterialTheme.typography.bodySmall, color = c.dim)
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                AirButton("Quality", { perf = 0; Prefs.hfPerf = 0 }, Modifier.weight(1f), filled = perf == 0)
                AirButton("Balanced", { perf = 1; Prefs.hfPerf = 1 }, Modifier.weight(1f), filled = perf == 1)
                AirButton("Battery", { perf = 2; Prefs.hfPerf = 2 }, Modifier.weight(1f), filled = perf == 2)
            }
        }

        PracticeArea()

        SectionCard("Good to know") {
            Text(
                "While Hands-free zoom is running, the normal pinch gestures pause so they do not fight it. In Cursor mode (hand mouse) the head cursor steps aside. " +
                    "Protected screens (banking, lock screen PIN) block taps from any accessibility service. Eye-gaze pointing is not in this version: " +
                    "the head cursor is more reliable on phones.",
                style = MaterialTheme.typography.bodySmall, color = c.dim
            )
        }
    }
}

@Composable
private fun PracticeArea() {
    val c = Air.c
    var hits by remember { mutableIntStateOf(0) }
    var last by remember { mutableIntStateOf(-1) }
    var scale by remember { mutableFloatStateOf(1f) }
    var off by remember { mutableStateOf(Offset.Zero) }
    SectionCard("Practice") {
        Text("Turn Hands-free on, then point at a button and click it. Clicks: $hits", style = MaterialTheme.typography.bodySmall, color = c.dim)
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            for (i in 0..2) {
                Box(
                    Modifier
                        .weight(1f)
                        .height(72.dp)
                        .clip(RoundedCornerShape(18.dp))
                        .background(if (last == i) c.a2 else c.glassHi)
                        .border(1.dp, c.stroke, RoundedCornerShape(18.dp))
                        .clickable { hits++; last = i },
                    contentAlignment = Alignment.Center
                ) { Text("${i + 1}", color = c.text, fontWeight = FontWeight.Black, fontSize = 22.sp, textAlign = TextAlign.Center) }
            }
        }
        Text("Zoom practice: spread two fingers in the air over this picture.", style = MaterialTheme.typography.bodySmall, color = c.dim)
        Box(
            Modifier
                .fillMaxWidth()
                .height(200.dp)
                .clip(RoundedCornerShape(18.dp))
                .border(1.dp, c.stroke, RoundedCornerShape(18.dp))
                .pointerInput(Unit) {
                    detectTransformGestures { _, pan, z, _ ->
                        scale = (scale * z).coerceIn(0.5f, 8f)
                        off += pan
                    }
                }
        ) {
            Canvas(
                Modifier
                    .fillMaxWidth()
                    .height(200.dp)
                    .graphicsLayer { scaleX = scale; scaleY = scale; translationX = off.x; translationY = off.y }
            ) {
                drawRect(Brush.linearGradient(listOf(Color(0xFF1B1F6B), Color(0xFF7B2FF7), Color(0xFFFF4D8D))))
                for (i in 0..8) {
                    drawCircle(Color.White.copy(alpha = 0.18f), radius = size.minDimension * (0.05f + 0.045f * i), center = Offset(size.width * 0.5f, size.height * 0.5f))
                }
                drawCircle(Color.White, radius = 6f, center = Offset(size.width * 0.5f, size.height * 0.5f))
            }
        }
        Text("Zoom: ${(scale * 100).toInt()}%", style = MaterialTheme.typography.bodySmall, color = c.a2)
    }
}
