package com.airflow.app

import android.app.PendingIntent
import android.content.Intent
import android.os.Build
import android.service.quicksettings.Tile
import android.service.quicksettings.TileService

/** Quick Settings tile: Air Share (hand gestures + touch). Swipe down, tap it, no need to open the app. */
class AirShareTileService : TileService() {
    override fun onStartListening() { ShareTiles.refresh(qsTile, true) }
    override fun onClick() {
        ShareTiles.click(this, "air")
        ShareTiles.refresh(qsTile, true)
    }
}

/** Quick Settings tile: Tap Share only (touch two phones; uses no camera). */
class TapShareTileService : TileService() {
    override fun onStartListening() { ShareTiles.refresh(qsTile, false) }
    override fun onClick() {
        ShareTiles.click(this, "tap")
        ShareTiles.refresh(qsTile, false)
    }
}

internal object ShareTiles {

    fun isOn(air: Boolean): Boolean = AirShareHub.active.value && (!air || AirShareHub.airMode)

    fun refresh(tile: Tile?, air: Boolean) {
        if (tile == null) return
        val on = isOn(air)
        tile.state = if (on) Tile.STATE_ACTIVE else Tile.STATE_INACTIVE
        tile.label = if (air) "Air Share" else "Tap Share"
        if (Build.VERSION.SDK_INT >= 29) tile.subtitle = if (on) "On" else "Off"
        tile.updateTile()
    }

    /**
     * Turning OFF is instant. Turning ON goes through a see-through activity, because Android only lets an
     * app start a camera or device service while it has something on screen.
     */
    @Suppress("DEPRECATION")
    fun click(svc: TileService, mode: String) {
        val air = mode == "air"
        if (isOn(air)) {
            svc.stopService(Intent(svc, AirFlowService::class.java))
            return
        }
        val i = Intent(svc, ShareToggleActivity::class.java)
            .putExtra("mode", mode)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        if (Build.VERSION.SDK_INT >= 34) {
            svc.startActivityAndCollapse(
                PendingIntent.getActivity(
                    svc, if (air) 31 else 32, i,
                    PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
                )
            )
        } else {
            svc.startActivityAndCollapse(i)
        }
    }
}
