package com.airflow.app

import android.Manifest
import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color as AColor
import android.graphics.Matrix
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.util.Base64
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.exifinterface.media.ExifInterface
import com.google.android.gms.nearby.Nearby
import com.google.android.gms.nearby.connection.AdvertisingOptions
import com.google.android.gms.nearby.connection.ConnectionInfo
import com.google.android.gms.nearby.connection.ConnectionLifecycleCallback
import com.google.android.gms.nearby.connection.ConnectionResolution
import com.google.android.gms.nearby.connection.DiscoveredEndpointInfo
import com.google.android.gms.nearby.connection.DiscoveryOptions
import com.google.android.gms.nearby.connection.EndpointDiscoveryCallback
import com.google.android.gms.nearby.connection.Payload
import com.google.android.gms.nearby.connection.PayloadCallback
import com.google.android.gms.nearby.connection.PayloadTransferUpdate
import com.google.android.gms.nearby.connection.Strategy
import com.google.zxing.BarcodeFormat
import com.google.zxing.EncodeHintType
import com.google.zxing.qrcode.QRCodeWriter
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.security.SecureRandom

// ---------------------------------------------------------------------------------------------
// Photos
// ---------------------------------------------------------------------------------------------

object PhotoStore {
    /** Loads a picked photo, fixes its rotation and limits it to [maxSide] pixels. */
    fun load(ctx: Context, uri: Uri, maxSide: Int = 2048): Bitmap? = try {
        val cr = ctx.contentResolver
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        cr.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
        var sample = 1
        while (maxOf(bounds.outWidth, bounds.outHeight) / sample > maxSide * 2) sample *= 2
        val opts = BitmapFactory.Options().apply { inSampleSize = sample }
        val raw = cr.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }
        if (raw == null) null else {
            val rot = cr.openInputStream(uri)?.use {
                when (ExifInterface(it).getAttributeInt(ExifInterface.TAG_ORIENTATION, 1)) {
                    6 -> 90f; 3 -> 180f; 8 -> 270f; else -> 0f
                }
            } ?: 0f
            val scale = minOf(1f, maxSide.toFloat() / maxOf(raw.width, raw.height))
            val m = Matrix().apply { postRotate(rot); postScale(scale, scale) }
            Bitmap.createBitmap(raw, 0, 0, raw.width, raw.height, m, true)
        }
    } catch (e: Exception) { null }

    fun decodeFile(f: File, maxSide: Int = 1600): Bitmap? = try {
        val b = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(f.path, b)
        var s = 1
        while (maxOf(b.outWidth, b.outHeight) / s > maxSide * 2) s *= 2
        BitmapFactory.decodeFile(f.path, BitmapFactory.Options().apply { inSampleSize = s })
    } catch (e: Exception) { null }

    fun toJpeg(ctx: Context, bmp: Bitmap, quality: Int = 92): File {
        val f = File(ctx.cacheDir, "air_send.jpg")
        FileOutputStream(f).use { bmp.compress(Bitmap.CompressFormat.JPEG, quality, it) }
        return f
    }

    fun saveToGallery(ctx: Context, file: File): Boolean = try {
        val name = "AirFlow_${System.currentTimeMillis()}.jpg"
        if (Build.VERSION.SDK_INT >= 29) {
            val v = ContentValues().apply {
                put(MediaStore.Images.Media.DISPLAY_NAME, name)
                put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
                put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/AirFlow")
                put(MediaStore.Images.Media.IS_PENDING, 1)
            }
            val uri = ctx.contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, v)!!
            ctx.contentResolver.openOutputStream(uri)?.use { out -> file.inputStream().use { it.copyTo(out) } }
            v.clear()
            v.put(MediaStore.Images.Media.IS_PENDING, 0)
            ctx.contentResolver.update(uri, v, null, null)
        } else {
            val dir = ctx.getExternalFilesDir(Environment.DIRECTORY_PICTURES) ?: ctx.filesDir
            file.copyTo(File(dir, name), true)
        }
        true
    } catch (e: Exception) { false }
}

// ---------------------------------------------------------------------------------------------
// Pairing: 6-digit code + QR
// ---------------------------------------------------------------------------------------------

object Pairing {
    fun newCode(): String = (100000 + SecureRandom().nextInt(900000)).toString()
    fun payload(code: String) = "airflow://pair?c=$code"

    /** Accepts a scanned QR text or a typed 6-digit code. */
    fun parse(raw: String?): String? {
        val s = raw?.trim() ?: return null
        Regex("^\\d{6}$").find(s)?.let { return it.value }
        return Regex("airflow://pair\\?c=(\\d{6})").find(s)?.groupValues?.get(1)
    }

    fun qr(text: String, px: Int = 720): Bitmap {
        val hints = mapOf<EncodeHintType, Any>(EncodeHintType.MARGIN to 1)
        val m = QRCodeWriter().encode(text, BarcodeFormat.QR_CODE, px, px, hints)
        val pixels = IntArray(px * px)
        for (y in 0 until px) for (x in 0 until px) {
            pixels[y * px + x] = if (m.get(x, y)) AColor.rgb(8, 10, 30) else AColor.WHITE
        }
        return Bitmap.createBitmap(pixels, px, px, Bitmap.Config.ARGB_8888)
    }

    fun nearbyPermissions(): List<String> = buildList {
        if (Build.VERSION.SDK_INT >= 31) {
            add(Manifest.permission.BLUETOOTH_ADVERTISE)
            add(Manifest.permission.BLUETOOTH_CONNECT)
            add(Manifest.permission.BLUETOOTH_SCAN)
        }
        if (Build.VERSION.SDK_INT <= 32) add(Manifest.permission.ACCESS_FINE_LOCATION)
        if (Build.VERSION.SDK_INT >= 33) add(Manifest.permission.NEARBY_WIFI_DEVICES)
    }
}

// ---------------------------------------------------------------------------------------------
// Online relay: Firebase Realtime Database (signal) + Supabase Storage (full-quality photo)
// Plain REST, so no google-services.json is needed. Only Firebase is required.
// ---------------------------------------------------------------------------------------------

class Relay(fbUrl: String, sbUrl: String, private val sbKey: String, private val bucket: String) {
    private val fb = fbUrl.trim().trimEnd('/')
    private val sb = sbUrl.trim().trimEnd('/')
    val ready: Boolean get() = fb.startsWith("https://")
    private val sbReady: Boolean get() = sb.startsWith("https://") && sbKey.isNotBlank()

    private fun http(method: String, url: String, body: ByteArray? = null, headers: Map<String, String> = emptyMap()): Pair<Int, ByteArray> {
        val c = URL(url).openConnection() as HttpURLConnection
        try {
            c.requestMethod = method
            c.connectTimeout = 8000
            c.readTimeout = 25000
            headers.forEach { (k, v) -> c.setRequestProperty(k, v) }
            if (body != null) {
                c.doOutput = true
                c.setFixedLengthStreamingMode(body.size)
                c.outputStream.use { it.write(body) }
            }
            val code = c.responseCode
            val st = if (code in 200..299) c.inputStream else c.errorStream
            return code to (st?.use { it.readBytes() } ?: ByteArray(0))
        } finally { c.disconnect() }
    }

    private fun node(room: String, path: String) = "$fb/airflow/$room/$path.json"

    fun join(room: String, me: String) { http("PUT", node(room, "peers/$me"), "true".toByteArray()) }
    fun leave(room: String, me: String) { http("DELETE", node(room, "peers/$me")) }

    /** -1 means the relay could not be reached. */
    fun peerCount(room: String): Int {
        val (code, b) = http("GET", node(room, "peers"))
        if (code !in 200..299) return -1
        val s = String(b).trim()
        return if (s == "null" || s.isEmpty()) 0 else JSONObject(s).length()
    }

    fun latestId(room: String): String {
        val (code, b) = http("GET", node(room, "msg"))
        val s = String(b).trim()
        if (code !in 200..299 || s == "null") return ""
        return JSONObject(s).optString("id")
    }

    fun push(room: String, me: String, file: File, progress: (Float) -> Unit): Boolean {
        val id = java.lang.Long.toHexString(System.nanoTime())
        val msg = JSONObject().put("id", id).put("from", me)
        progress(0.12f)
        if (sbReady) {
            val path = "$room/$id.jpg"
            val (c, _) = http(
                "POST", "$sb/storage/v1/object/$bucket/$path", file.readBytes(),
                mapOf("apikey" to sbKey, "Authorization" to "Bearer $sbKey", "Content-Type" to "image/jpeg", "x-upsert" to "true")
            )
            if (c !in 200..299) return false
            msg.put("url", "$sb/storage/v1/object/public/$bucket/$path")
        } else {
            // Firebase only: send a 1280 px JPEG inside the database itself.
            val bmp = PhotoStore.decodeFile(file, 1280) ?: return false
            val out = java.io.ByteArrayOutputStream()
            bmp.compress(Bitmap.CompressFormat.JPEG, 78, out)
            msg.put("b64", Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP))
        }
        progress(0.8f)
        val (c2, _) = http("PUT", node(room, "msg"), msg.toString().toByteArray())
        progress(1f)
        return c2 in 200..299
    }

    /** Returns (id, jpeg bytes) for a new photo from the other phone, or null. */
    fun poll(room: String, me: String, lastId: String): Pair<String, ByteArray>? {
        val (code, b) = http("GET", node(room, "msg"))
        val s = String(b).trim()
        if (code !in 200..299 || s == "null" || s.isEmpty()) return null
        val j = JSONObject(s)
        val id = j.optString("id")
        if (id.isEmpty() || id == lastId || j.optString("from") == me) return null
        val bytes = if (j.has("url")) http("GET", j.getString("url")).second
        else Base64.decode(j.optString("b64"), Base64.DEFAULT)
        return if (bytes.isEmpty()) null else id to bytes
    }
}

// ---------------------------------------------------------------------------------------------
// Offline link: Google Nearby Connections (Bluetooth + Wi-Fi Direct, no internet needed)
// ---------------------------------------------------------------------------------------------

class NearbyLink(ctx: Context, private val code: String, private val host: Boolean, private val cb: Callbacks) {
    interface Callbacks {
        fun connected()
        fun lost()
        fun failed(msg: String)
        fun progress(p: Float)
        fun sent(ok: Boolean)
        fun file(f: File)
    }

    private val app = ctx.applicationContext
    private val client = Nearby.getConnectionsClient(app)
    private val hostName = "AFH$code"
    private val guestName = "AFG$code"
    private val strategy = Strategy.P2P_POINT_TO_POINT
    private var peer: String? = null
    private var outId = -1L
    private val incoming = HashMap<Long, Payload>()

    private val payloadCb = object : PayloadCallback() {
        override fun onPayloadReceived(endpointId: String, payload: Payload) {
            if (payload.type == Payload.Type.FILE) incoming[payload.id] = payload
        }

        override fun onPayloadTransferUpdate(endpointId: String, u: PayloadTransferUpdate) {
            val total = u.totalBytes.coerceAtLeast(1L)
            cb.progress((u.bytesTransferred.toFloat() / total).coerceIn(0f, 1f))
            when (u.status) {
                PayloadTransferUpdate.Status.SUCCESS -> {
                    if (u.payloadId == outId) { outId = -1L; cb.sent(true) }
                    else incoming.remove(u.payloadId)?.let { copyIncoming(it) }
                }
                PayloadTransferUpdate.Status.FAILURE, PayloadTransferUpdate.Status.CANCELED -> {
                    if (u.payloadId == outId) { outId = -1L; cb.sent(false) }
                    incoming.remove(u.payloadId)
                }
                else -> {}
            }
        }
    }

    private fun copyIncoming(p: Payload) {
        try {
            val f = p.asFile() ?: return
            val out = File(app.cacheDir, "air_recv.jpg")
            val uri = f.asUri()
            val input = if (uri != null) app.contentResolver.openInputStream(uri)
            else f.asJavaFile()?.inputStream()
            input?.use { i -> out.outputStream().use { o -> i.copyTo(o) } }
            if (out.length() > 0) cb.file(out)
        } catch (e: Exception) { cb.failed("Could not read the received photo") }
    }

    private val connCb = object : ConnectionLifecycleCallback() {
        override fun onConnectionInitiated(id: String, info: ConnectionInfo) {
            // Both phones must know the same code, otherwise the connection is refused.
            val expected = if (host) guestName else hostName
            if (info.endpointName == expected) client.acceptConnection(id, payloadCb) else client.rejectConnection(id)
        }

        override fun onConnectionResult(id: String, r: ConnectionResolution) {
            if (r.status.isSuccess) {
                peer = id
                client.stopAdvertising()
                client.stopDiscovery()
                cb.connected()
            } else cb.failed("Connection was refused. Check the code.")
        }

        override fun onDisconnected(id: String) { peer = null; cb.lost() }
    }

    fun start() {
        if (host) {
            client.startAdvertising(hostName, SERVICE, connCb, AdvertisingOptions.Builder().setStrategy(strategy).build())
                .addOnFailureListener { cb.failed(it.message ?: "Could not start Nearby") }
        } else {
            val disc = object : EndpointDiscoveryCallback() {
                override fun onEndpointFound(id: String, info: DiscoveredEndpointInfo) {
                    if (info.endpointName == hostName) {
                        client.requestConnection(guestName, id, connCb)
                            .addOnFailureListener { cb.failed(it.message ?: "Could not connect") }
                    }
                }
                override fun onEndpointLost(id: String) {}
            }
            client.startDiscovery(SERVICE, disc, DiscoveryOptions.Builder().setStrategy(strategy).build())
                .addOnFailureListener { cb.failed(it.message ?: "Could not start Nearby") }
        }
    }

    fun send(file: File): Boolean {
        val id = peer ?: return false
        return try {
            val p = Payload.fromFile(file)
            outId = p.id
            client.sendPayload(id, p)
            true
        } catch (e: Exception) { false }
    }

    fun stop() {
        try { client.stopAdvertising(); client.stopDiscovery(); client.stopAllEndpoints() } catch (_: Exception) {}
    }

    private companion object { const val SERVICE = "com.airflow.app.share" }
}

// ---------------------------------------------------------------------------------------------
// Controller: one object the screen talks to
// ---------------------------------------------------------------------------------------------

enum class TMode { NEARBY, ONLINE }
enum class LinkState { IDLE, WAITING, CONNECTED, FAILED }

class TransferController(ctx: Context) : NearbyLink.Callbacks {
    private val app = ctx.applicationContext
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private val me = java.lang.Long.toHexString(System.nanoTime()).takeLast(8)

    var mode by mutableStateOf(TMode.NEARBY)
    var link by mutableStateOf(LinkState.IDLE)
    var code by mutableStateOf("")
    var hosting by mutableStateOf(false)
    var status by mutableStateOf("Not connected")
    var progress by mutableFloatStateOf(0f)
    var photo by mutableStateOf<Bitmap?>(null)
    var received by mutableStateOf<Bitmap?>(null)
    var receivedTick by mutableIntStateOf(0)

    private var sendFile: File? = null
    private var nearby: NearbyLink? = null
    private var relay: Relay? = null
    private var relayJob: Job? = null
    private var lastRelayId = ""
    private var pendingDone: ((Boolean) -> Unit)? = null

    fun pick(uri: Uri) {
        scope.launch {
            val bmp = withContext(Dispatchers.IO) { PhotoStore.load(app, uri) }
            if (bmp == null) { status = "Could not open that photo"; return@launch }
            sendFile = withContext(Dispatchers.IO) { PhotoStore.toJpeg(app, bmp) }
            photo = bmp
            status = "Photo ready. Do the gesture: open palm, fist, open."
        }
    }

    fun host() { code = Pairing.newCode(); hosting = true; startLink() }
    fun join(c: String) { code = c; hosting = false; startLink() }

    private fun startLink() {
        stopLink()
        link = LinkState.WAITING
        status = if (hosting) "Waiting for the other phone to scan…" else "Looking for the other phone…"
        if (mode == TMode.NEARBY) {
            nearby = NearbyLink(app, code, hosting, this).also { it.start() }
        } else {
            val r = Relay(Prefs.fbUrl, Prefs.sbUrl, Prefs.sbKey, Prefs.sbBucket)
            if (!r.ready) {
                link = LinkState.FAILED
                status = "Add your Firebase URL in Online setup first"
                return
            }
            relay = r
            relayJob = scope.launch { runRelay(r) }
        }
    }

    private suspend fun runRelay(r: Relay) {
        withContext(Dispatchers.IO) {
            runCatching { r.join(code, me); lastRelayId = r.latestId(code) }
        }
        while (scope.isActive) {
            val n = withContext(Dispatchers.IO) { runCatching { r.peerCount(code) }.getOrDefault(-1) }
            when {
                n < 0 -> { link = LinkState.FAILED; status = "Cannot reach Firebase. Check Online setup and rules." }
                n >= 2 -> { if (link != LinkState.CONNECTED) status = "Connected (online)"; link = LinkState.CONNECTED }
                else -> { link = LinkState.WAITING; status = "Waiting for the other phone…" }
            }
            if (link == LinkState.CONNECTED) {
                val msg = withContext(Dispatchers.IO) { runCatching { r.poll(code, me, lastRelayId) }.getOrNull() }
                if (msg != null) {
                    lastRelayId = msg.first
                    val f = File(app.cacheDir, "air_recv.jpg")
                    withContext(Dispatchers.IO) { f.writeBytes(msg.second) }
                    file(f)
                }
            }
            delay(450)
        }
    }

    /** Sends the picked photo. [done] is called on the main thread. */
    fun send(done: (Boolean) -> Unit) {
        val f = sendFile
        if (f == null || photo == null) { status = "Pick a photo first"; done(false); return }
        if (link != LinkState.CONNECTED) { status = "Connect the other phone first"; done(false); return }
        progress = 0.04f
        status = "Sending…"
        if (mode == TMode.NEARBY) {
            pendingDone = done
            if (nearby?.send(f) != true) { pendingDone = null; status = "Send failed"; done(false) }
        } else {
            val r = relay
            if (r == null) { done(false); return }
            scope.launch {
                val ok = withContext(Dispatchers.IO) {
                    runCatching { r.push(code, me, f) { progress = it } }.getOrDefault(false)
                }
                status = if (ok) "Sent ✓" else "Send failed. Check Online setup."
                done(ok)
            }
        }
    }

    private fun stopLink() {
        nearby?.stop(); nearby = null
        relayJob?.cancel(); relayJob = null
        val r = relay; val c = code
        relay = null
        if (r != null && c.isNotEmpty()) Thread { runCatching { r.leave(c, me) } }.start()
    }

    fun disconnect() {
        stopLink()
        link = LinkState.IDLE
        hosting = false
        code = ""
        status = "Not connected"
    }

    fun close() { stopLink(); scope.cancel() }

    // ---- Nearby callbacks (main thread) ----
    override fun connected() { link = LinkState.CONNECTED; status = "Connected (Nearby, no internet needed)" }
    override fun lost() { link = LinkState.WAITING; status = "Connection lost. Scan again." }
    override fun failed(msg: String) { link = LinkState.FAILED; status = msg }
    override fun progress(p: Float) { progress = p }
    override fun sent(ok: Boolean) {
        status = if (ok) "Sent ✓" else "Send failed"
        pendingDone?.invoke(ok); pendingDone = null
    }

    override fun file(f: File) {
        scope.launch {
            val bmp = withContext(Dispatchers.IO) {
                PhotoStore.saveToGallery(app, f)
                PhotoStore.decodeFile(f)
            }
            if (bmp != null) {
                received = bmp
                receivedTick++
                status = "Received ✓ saved to Gallery > AirFlow"
            }
        }
    }
}

// ---------------------------------------------------------------------------------------------
// Gesture state machine: open palm -> fist (capture) -> open hand (release)
// ---------------------------------------------------------------------------------------------

class AirGrabTracker {
    enum class Ev { NONE, READY, GRAB, RELEASE, RESET }

    /** 0 = waiting for open palm, 1 = waiting for fist, 2 = waiting for open hand. */
    var step by mutableIntStateOf(0)
    var hold by mutableFloatStateOf(0f)

    private var last = GestureEngine.Pose.NONE
    private var since = 0L
    private var lostSince = 0L
    private var stepAt = 0L
    private var cool = 0L

    fun reset() { step = 0; hold = 0f; last = GestureEngine.Pose.NONE }

    fun update(pose: GestureEngine.Pose, now: Long): Ev {
        if (now < cool) return Ev.NONE
        if (pose != last) { last = pose; since = now }
        val held = now - since
        lostSince = if (pose == GestureEngine.Pose.NONE) (if (lostSince == 0L) now else lostSince) else 0L
        when (step) {
            0 -> {
                hold = if (pose == GestureEngine.Pose.OPEN) (held / PALM_MS.toFloat()).coerceAtMost(1f) else 0f
                if (pose == GestureEngine.Pose.OPEN && held >= PALM_MS) { step = 1; stepAt = now; hold = 0f; return Ev.READY }
            }
            1 -> {
                hold = if (pose == GestureEngine.Pose.FIST) (held / FIST_MS.toFloat()).coerceAtMost(1f) else 0f
                if (pose == GestureEngine.Pose.FIST && held >= FIST_MS) { step = 2; stepAt = now; hold = 0f; return Ev.GRAB }
                if (now - stepAt > 12000 || (lostSince != 0L && now - lostSince > 3000)) { reset(); return Ev.RESET }
            }
            else -> {
                hold = if (pose == GestureEngine.Pose.OPEN) (held / OPEN_MS.toFloat()).coerceAtMost(1f) else 0f
                if (pose == GestureEngine.Pose.OPEN && held >= OPEN_MS) { reset(); cool = now + 1800; return Ev.RELEASE }
                if (now - stepAt > 15000) { reset(); return Ev.RESET }
            }
        }
        return Ev.NONE
    }

    private companion object {
        const val PALM_MS = 450L
        const val FIST_MS = 250L
        const val OPEN_MS = 220L
    }
}

// ---------------------------------------------------------------------------------------------
// Receiver side: a fist, then an open palm, brings a waiting photo down.
// Nothing lands on this phone until that gesture is made.
// ---------------------------------------------------------------------------------------------

class AirReceiveTracker {
    enum class Ev { NONE, ARM, ACCEPT, RESET }

    /** 0 = waiting for a fist, 1 = waiting for the open palm. */
    var step by mutableIntStateOf(0)
    var hold by mutableFloatStateOf(0f)

    private var last = GestureEngine.Pose.NONE
    private var since = 0L
    private var stepAt = 0L
    private var cool = 0L

    fun reset() {
        step = 0
        hold = 0f
        last = GestureEngine.Pose.NONE
    }

    fun update(pose: GestureEngine.Pose, now: Long): Ev {
        if (now < cool) return Ev.NONE
        if (pose != last) { last = pose; since = now }
        val held = now - since
        if (step == 0) {
            hold = if (pose == GestureEngine.Pose.FIST) (held / FIST_MS.toFloat()).coerceAtMost(1f) else 0f
            if (pose == GestureEngine.Pose.FIST && held >= FIST_MS) {
                step = 1
                stepAt = now
                hold = 0f
                return Ev.ARM
            }
        } else {
            hold = if (pose == GestureEngine.Pose.OPEN) (held / OPEN_MS.toFloat()).coerceAtMost(1f) else 0f
            if (pose == GestureEngine.Pose.OPEN && held >= OPEN_MS) {
                reset()
                cool = now + 1500
                return Ev.ACCEPT
            }
            if (now - stepAt > 12000) { reset(); return Ev.RESET }
        }
        return Ev.NONE
    }

    private companion object {
        const val FIST_MS = 220L
        const val OPEN_MS = 200L
    }
}
