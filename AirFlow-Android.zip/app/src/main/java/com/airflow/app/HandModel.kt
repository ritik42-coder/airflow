package com.airflow.app

import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.lerp as lerpColor
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

// ---------------------------------------------------------------------------------------------
// Tiny math helpers shared by every animation in the app
// ---------------------------------------------------------------------------------------------

fun lerpF(a: Float, b: Float, t: Float): Float = a + (b - a) * t

fun clamp01(x: Float): Float = if (x < 0f) 0f else if (x > 1f) 1f else x

/** 0..1 progress of [x] between [a] and [b]. */
fun seg(x: Float, a: Float, b: Float): Float = clamp01((x - a) / (b - a))

fun smooth(x: Float): Float {
    val t = clamp01(x)
    return t * t * (3f - 2f * t)
}

fun easeOut(x: Float): Float {
    val t = 1f - clamp01(x)
    return 1f - t * t * t
}

fun easeInOut(x: Float): Float {
    val t = clamp01(x)
    return if (t < 0.5f) 4f * t * t * t else 1f - Math.pow((-2.0 * t + 2.0), 3.0).toFloat() / 2f
}

/** Overshoots slightly before settling: great for pop-ins. */
fun backOut(x: Float): Float {
    val t = clamp01(x) - 1f
    val c1 = 1.70158f
    val c3 = c1 + 1f
    return 1f + c3 * t * t * t + c1 * t * t
}

fun lerpO(a: Offset, b: Offset, t: Float): Offset = Offset(lerpF(a.x, b.x, t), lerpF(a.y, b.y, t))

// ---------------------------------------------------------------------------------------------
// Procedural hand skeleton (same 21-point layout as MediaPipe, so it matches what the camera sees)
// ---------------------------------------------------------------------------------------------

/** Finger curls are 0 (straight) .. 1 (fully curled). [rot] turns the whole hand (degrees, clockwise). */
class HandPose(
    val thumb: Float,
    val index: Float,
    val middle: Float,
    val ring: Float,
    val pinky: Float,
    val pinch: Float = 0f,
    val rot: Float = 0f,
    val spread: Float = 1f
)

fun lerpPose(a: HandPose, b: HandPose, t: Float): HandPose = HandPose(
    lerpF(a.thumb, b.thumb, t), lerpF(a.index, b.index, t), lerpF(a.middle, b.middle, t),
    lerpF(a.ring, b.ring, t), lerpF(a.pinky, b.pinky, t),
    lerpF(a.pinch, b.pinch, t), lerpF(a.rot, b.rot, t), lerpF(a.spread, b.spread, t)
)

object Poses {
    val OPEN = HandPose(0f, 0f, 0f, 0f, 0f)
    val POINT = HandPose(0.85f, 0f, 1f, 1f, 1f)
    val PINCH = HandPose(0.3f, 0.42f, 0f, 0f, 0f, pinch = 1f)
    val PINCH_POINT = HandPose(0.3f, 0.4f, 1f, 1f, 1f, pinch = 1f)
    val FIST = HandPose(1f, 1f, 1f, 1f, 1f)
    val THUMB_UP = HandPose(0f, 1f, 1f, 1f, 1f, rot = 40f)
    val THUMB_DOWN = HandPose(0f, 1f, 1f, 1f, 1f, rot = 220f)
    val PEACE = HandPose(0.9f, 0f, 0f, 1f, 1f, spread = 1.7f)
    val ROCK = HandPose(0.9f, 0f, 1f, 1f, 0f, spread = 1.5f)
    val THREE = HandPose(0.9f, 0f, 0f, 0f, 1f)
    val CALL = HandPose(0f, 1f, 1f, 1f, 0f, spread = 1.4f)

    fun forGesture(g: Gesture): HandPose = when (g) {
        Gesture.PINCH -> PINCH
        Gesture.FIST_HOLD, Gesture.FIST_SWIPE_UP, Gesture.FIST_SWIPE_DOWN,
        Gesture.FIST_SWIPE_LEFT, Gesture.FIST_SWIPE_RIGHT -> FIST
        Gesture.THUMB_UP_HOLD -> THUMB_UP
        Gesture.THUMB_DOWN_HOLD -> THUMB_DOWN
        Gesture.PEACE_HOLD -> PEACE
        Gesture.POINT_HOLD -> POINT
        Gesture.THREE_HOLD -> THREE
        Gesture.ROCK_HOLD -> ROCK
        Gesture.CALL_HOLD -> CALL
        else -> OPEN
    }
}

private val MCP = arrayOf(Offset(-0.22f, -0.50f), Offset(0f, -0.56f), Offset(0.21f, -0.50f), Offset(0.40f, -0.38f))
private val FINGER_ANGLE = floatArrayOf(-8f, 0f, 8f, 16f)
private val FINGER_LEN = arrayOf(
    floatArrayOf(0.26f, 0.17f, 0.15f),
    floatArrayOf(0.29f, 0.19f, 0.16f),
    floatArrayOf(0.26f, 0.18f, 0.15f),
    floatArrayOf(0.20f, 0.13f, 0.12f)
)
private val PHI = floatArrayOf(55f, 105f, 130f)

private fun rad(deg: Float): Float = (deg * PI / 180.0).toFloat()

/** 21 points, wrist at (0,0), fingers pointing to negative y, hand roughly 1.2 units tall. */
fun computeHand(p: HandPose): Array<Offset> {
    val out = Array(21) { Offset.Zero }
    val curls = floatArrayOf(p.index, p.middle, p.ring, p.pinky)
    for (i in 0 until 4) {
        val c = curls[i]
        val base = 5 + 4 * i
        var x = MCP[i].x * (1f - 0.25f * c)
        var y = MCP[i].y
        out[base] = Offset(x, y)
        val a = rad(FINGER_ANGLE[i] * p.spread)
        val dx = sin(a)
        val dy = -cos(a)
        for (j in 0 until 3) {
            val l = FINGER_LEN[i][j] * cos(rad(PHI[j] * c))
            x += dx * l
            y += dy * l
            out[base + 1 + j] = Offset(x, y + 0.12f * c * (j + 1) / 3f)
        }
    }
    // thumb
    val tc = p.thumb
    var tx = -0.17f
    var ty = -0.09f
    out[1] = Offset(tx, ty)
    var ang = lerpF(-58f, 72f, tc)
    val lens = floatArrayOf(0.17f, 0.17f, 0.15f)
    for (j in 0 until 3) {
        tx += sin(rad(ang)) * lens[j]
        ty += -cos(rad(ang)) * lens[j]
        out[2 + j] = Offset(tx, ty)
        ang += 14f * tc
    }
    if (p.pinch > 0f) {
        val tip = out[8]
        out[4] = lerpO(out[4], tip, p.pinch)
        val mid = Offset((out[3].x + tip.x) / 2f, (out[3].y + tip.y) / 2f)
        out[3] = lerpO(out[3], mid, p.pinch * 0.7f)
    }
    if (p.rot != 0f) {
        val cs = cos(rad(p.rot))
        val sn = sin(rad(p.rot))
        for (i in 0 until 21) {
            val o = out[i]
            out[i] = Offset(o.x * cs - o.y * sn, o.x * sn + o.y * cs)
        }
    }
    return out
}

val HAND_BONES = listOf(
    0 to 1, 1 to 2, 2 to 3, 3 to 4,
    0 to 5, 5 to 6, 6 to 7, 7 to 8,
    5 to 9, 9 to 10, 10 to 11, 11 to 12,
    9 to 13, 13 to 14, 14 to 15, 15 to 16,
    13 to 17, 17 to 18, 18 to 19, 19 to 20, 0 to 17
)

private val TIPS = setOf(4, 8, 12, 16, 20)

/**
 * Neon skeleton hand. [reveal] 0..1 draws the bones one after another (used by the intro).
 * [origin] is where the wrist goes, [scale] is the size of one hand unit in pixels.
 */
fun DrawScope.drawHand(
    pts: Array<Offset>,
    origin: Offset,
    scale: Float,
    c1: Color,
    c2: Color,
    alpha: Float = 1f,
    glow: Float = 1f,
    lineW: Float = 3f,
    dotR: Float = 4.5f,
    reveal: Float = 1f
) {
    if (alpha <= 0.005f || reveal <= 0f) return
    fun pt(i: Int) = Offset(origin.x + pts[i].x * scale, origin.y + pts[i].y * scale)
    val n = HAND_BONES.size
    val shown = reveal * n

    val palm = Path().apply {
        moveTo(pt(0).x, pt(0).y)
        for (i in intArrayOf(5, 9, 13, 17)) lineTo(pt(i).x, pt(i).y)
        close()
    }
    drawPath(palm, c1.copy(alpha = 0.08f * alpha * clamp01(reveal * 1.5f)))

    for ((k, b) in HAND_BONES.withIndex()) {
        val f = (shown - k).coerceIn(0f, 1f)
        if (f <= 0f) continue
        val a = pt(b.first)
        val e0 = pt(b.second)
        val e = Offset(a.x + (e0.x - a.x) * f, a.y + (e0.y - a.y) * f)
        val col = lerpColor(c1, c2, k / (n - 1f))
        if (glow > 0f) drawLine(col.copy(alpha = 0.17f * alpha * glow), a, e, strokeWidth = lineW * 3.4f, cap = StrokeCap.Round)
        drawLine(col.copy(alpha = 0.95f * alpha), a, e, strokeWidth = lineW, cap = StrokeCap.Round)
    }
    for (i in 0 until 21) {
        val appear = (reveal * 21f - i).coerceIn(0f, 1f)
        if (appear <= 0f) continue
        val big = if (i in TIPS) 1.35f else 1f
        val col = lerpColor(c1, c2, i / 20f)
        val r = dotR * big * (0.4f + 0.6f * backOut(appear))
        if (glow > 0f) drawCircle(col.copy(alpha = 0.22f * alpha * glow), r * 2.6f, pt(i))
        drawCircle(col.copy(alpha = alpha), r, pt(i))
        drawCircle(Color.White.copy(alpha = 0.85f * alpha), r * 0.42f, pt(i))
    }
}
