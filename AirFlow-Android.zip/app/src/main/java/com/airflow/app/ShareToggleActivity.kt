package com.airflow.app

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.widget.Toast
import androidx.core.content.ContextCompat

/** See-through activity the Quick Settings tiles open. It switches Air Share / Tap Share on and closes itself. */
class ShareToggleActivity : Activity() {

    private var mode = "tap"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Prefs.init(this)
        mode = intent.getStringExtra("mode") ?: "tap"
        if (Perms.missing(this).isNotEmpty()) {
            Toast.makeText(this, "Open Air Flow once and allow Nearby devices and Location", Toast.LENGTH_LONG).show()
            startActivity(Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            finish()
            return
        }
        if (mode == "air" && ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.CAMERA), 61)
            return
        }
        begin()
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 61 && grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) begin()
        else {
            Toast.makeText(this, "Air Share needs the camera to see your hand", Toast.LENGTH_LONG).show()
            finish()
        }
    }

    private fun begin() {
        try {
            ContextCompat.startForegroundService(
                this,
                Intent(this, AirFlowService::class.java)
                    .setAction(if (mode == "air") AirFlowService.ACTION_SHARE else AirFlowService.ACTION_TAP)
            )
            if (!Perms.locationServiceOn(this)) {
                Toast.makeText(this, "Turn Location ON in quick settings so phones can find each other", Toast.LENGTH_LONG).show()
            } else {
                Toast.makeText(this, if (mode == "air") "Air Share is on" else "Tap Share is on", Toast.LENGTH_SHORT).show()
            }
        } catch (e: Exception) {
            Toast.makeText(this, "Could not start: ${e.message}", Toast.LENGTH_LONG).show()
        }
        finish()
    }
}
