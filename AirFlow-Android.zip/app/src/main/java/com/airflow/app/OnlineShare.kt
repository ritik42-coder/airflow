package com.airflow.app

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Build
import android.os.Looper
import android.util.Base64
import androidx.exifinterface.media.ExifInterface
import kotlinx.coroutines.flow.MutableStateFlow
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.File
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.Executors
import java.util.concurrent.ScheduledExecutorService
import java.util.concurrent.TimeUnit
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min

// ---------------------------------------------------------------------------------------------
// Online Air Share: the same grab-and-release hand gesture, but to phones that are only NEARBY
// (by location), over the Firebase Realtime Database. No Firebase Storage and no SDK: plain REST
// plus the streaming (SSE) endpoint, so there is nothing extra to build.
//
// Layout in the database (everything under /air):
//   p/<cell>/<uid>   presence: name, lat, lon, server time. <cell> is a ~2 km square, so a phone only
//                    ever reads the 1 to 4 squares around it.
//   d/<id>           one drop: from, kind, text or photos (base64), expiry, and "to" = who may read it
//   in/<uid>/<id>    a tiny pointer in each receiver's inbox. The receiver listens to ONLY its inbox.
// Drop ids start with the time and the lifetime, so any phone can tell when a drop is past its time.
// ---------------------------------------------------------------------------------------------

/** One phone on the nearby map. [dx] metres east and [dy] metres north of you. */
class OnlineNode(
    val uid: String,
    val name: String,
    val la: Double,
    val lo: Double,
    val dx: Float,
    val dy: Float,
    val dist: Float,
    val color: Int
)

/** A drop that arrived. Nothing is shown or saved until the owner accepts. */
class OnlineDrop(
    val id: String,
    val fromUid: String,
    val fromName: String,
    /** "img", "text", "link" or "yt" */
    val kind: String,
    val text: String,
    val title: String,
    val images: List<Pair<String, ByteArray>>,
    val expMs: Long
)

interface OnlineCallbacks {
    fun incoming(d: OnlineDrop)
    fun nearbyChanged()
}

/** Keeps dots on the small map apart. Pure maths, so it is unit tested. */
object MapLayout {
    /**
     * Moves points ([xs], [ys] relative to the middle, any unit) until none are closer than [minD],
     * none sit on the middle (the "you" dot) and all stay inside [maxR]. Points keep their direction
     * as far as possible, so the map still reads like the real street.
     */
    fun spread(xs: FloatArray, ys: FloatArray, minD: Float, maxR: Float, keepOut: Float) {
        val n = xs.size
        for (i in 0 until n) {
            if (hypot(xs[i], ys[i]) < 0.01f) { // same spot as you: pick a stable direction
                val a = i * 2.39996f
                xs[i] = (kotlin.math.cos(a) * keepOut); ys[i] = (kotlin.math.sin(a) * keepOut)
            }
        }
        repeat(120) {
            var moved = false
            for (i in 0 until n) for (j in i + 1 until n) {
                var dx = xs[j] - xs[i]
                var dy = ys[j] - ys[i]
                var d = hypot(dx, dy)
                if (d < minD) {
                    if (d < 0.01f) { val a = (i * 31 + j) * 2.39996f; dx = kotlin.math.cos(a); dy = kotlin.math.sin(a); d = 1f }
                    val push = (minD - d) / 2f + 0.01f
                    val ux = dx / d; val uy = dy / d
                    xs[i] -= ux * push; ys[i] -= uy * push
                    xs[j] += ux * push; ys[j] += uy * push
                    moved = true
                }
            }
            for (i in 0 until n) {
                var d = hypot(xs[i], ys[i])
                if (d < keepOut) {
                    if (d < 0.01f) { xs[i] = keepOut; ys[i] = 0f } else { xs[i] *= keepOut / d; ys[i] *= keepOut / d }
                    moved = true
                }
                d = hypot(xs[i], ys[i])
                if (d > maxR) { xs[i] *= maxR / d; ys[i] *= maxR / d; moved = true }
            }
            if (!moved) return
        }
    }
}

object OnlineShare {
    private const val DB = "https://bharatchat-d37fa-default-rtdb.asia-southeast1.firebasedatabase.app"
    private const val API_KEY = "AIzaSyAOBY17jm7dg3KveDmSI6Y6Ui8RqbQ_7k8"
    private const val CELL = 0.02          // degrees, about 2.2 km
    private const val MAX_NEARBY_M = 2000f

    /** Phones around you, nearest first. */
    val nearby = MutableStateFlow<List<OnlineNode>>(emptyList())
    /** Phones the owner tapped on the map. Empty = everyone in range. */
    val selected = MutableStateFlow<Set<String>>(emptySet())
    val status = MutableStateFlow("")
    val accuracy = MutableStateFlow(-1f)
    val connected = MutableStateFlow(false)

    @Volatile private var running = false
    private var app: Context? = null
    private var cb: OnlineCallbacks? = null
    private var ex: ScheduledExecutorService? = null
    @Volatile private var sseConn: HttpURLConnection? = null

    // auth
    private var uid = ""
    private var idToken = ""
    private var tokenExp = 0L
    private var refresh = ""

    // location
    @Volatile private var loc: Location? = null
    private var lm: LocationManager? = null
    private var myCell = ""
    private var serverOffset = 0L

    private class Ptr(val e: Long, val fu: String)
    private val pointers = ConcurrentHashMap<String, Ptr>()
    private val seen = ConcurrentHashMap.newKeySet<String>()

    val myUid: String get() = uid
    fun myName(): String = Prefs.onlineName.ifBlank { (Build.MODEL ?: "Phone").take(20) }

    // ------------------------------------------------------------------ lifecycle

    @Synchronized
    fun start(ctx: Context, callbacks: OnlineCallbacks) {
        cb = callbacks
        if (running) return
        running = true
        app = ctx.applicationContext
        status.value = "Connecting..."
        seen.clear()
        for (s in Prefs.onlineSeen.split(",")) if (s.isNotBlank()) seen.add(s)
        val e = Executors.newScheduledThreadPool(3)
        ex = e
        startLocation()
        e.execute {
            ensureAuth()
            if (!running) return@execute
            e.scheduleWithFixedDelay({ safe { heartbeat() } }, 1, 7, TimeUnit.SECONDS)
            e.scheduleWithFixedDelay({ safe { poll() } }, 1, 3, TimeUnit.SECONDS)
            e.scheduleWithFixedDelay({ safe { sweep() } }, 20, 60, TimeUnit.SECONDS)
            Thread({ sseLoop() }, "airshare-inbox").also { it.isDaemon = true }.start()
        }
    }

    @Synchronized
    fun stop() {
        if (!running) return
        running = false
        try { sseConn?.disconnect() } catch (_: Throwable) {}
        stopLocation()
        val cell = myCell
        val id = uid
        val t = idToken
        ex?.shutdownNow()
        ex = null
        nearby.value = emptyList()
        selected.value = emptySet()
        connected.value = false
        status.value = ""
        // leave the map: best effort, on its own thread
        if (cell.isNotEmpty() && id.isNotEmpty()) {
            Thread { try { rawCall("DELETE", "air/p/$cell/$id", null, t) } catch (_: Throwable) {} }.start()
        }
        myCell = ""
        pointers.clear()
        Prefs.onlineSeen = seen.toList().takeLast(80).joinToString(",")
    }

    private inline fun safe(f: () -> Unit) { try { f() } catch (e: Throwable) { if (running) note(e) } }

    private fun note(e: Throwable) {
        val m = e.message ?: ""
        status.value = when {
            m.startsWith("HTTP 401") || m.startsWith("HTTP 403") ->
                "Firebase refused it. Paste the rules from AIR_SHARE_RULES.json into your Realtime Database rules."
            m.startsWith("HTTP 404") -> "Firebase database not found. Check the database URL."
            else -> "Offline, retrying..."
        }
    }

    // ------------------------------------------------------------------ auth (anonymous, over REST)

    @Synchronized
    private fun ensureAuth(): Boolean {
        val now = System.currentTimeMillis()
        if (uid.isEmpty()) uid = Prefs.onlineUid
        if (refresh.isEmpty()) refresh = Prefs.onlineRefresh
        if (idToken.isNotEmpty() && now < tokenExp - 60_000L) return true
        // 1) refresh the saved identity
        if (refresh.isNotEmpty()) {
            try {
                val r = form("https://securetoken.googleapis.com/v1/token?key=$API_KEY", "grant_type=refresh_token&refresh_token=" + java.net.URLEncoder.encode(refresh, "UTF-8"))
                val o = JSONObject(r)
                idToken = o.getString("id_token")
                refresh = o.optString("refresh_token", refresh)
                uid = o.optString("user_id", uid)
                tokenExp = now + o.optString("expires_in", "3600").toLong() * 1000L
                save(); return true
            } catch (_: Throwable) { refresh = "" }
        }
        // 2) a new anonymous identity
        try {
            val r = json("https://identitytoolkit.googleapis.com/v1/accounts:signUp?key=$API_KEY", "{\"returnSecureToken\":true}")
            val o = JSONObject(r)
            idToken = o.getString("idToken")
            refresh = o.getString("refreshToken")
            uid = o.getString("localId")
            tokenExp = now + o.optString("expiresIn", "3600").toLong() * 1000L
            save(); return true
        } catch (_: Throwable) { }
        // 3) no sign-in available: a random id, works only if the database rules are open
        if (uid.isEmpty()) uid = "u" + java.lang.Long.toString(System.nanoTime(), 36) + java.lang.Long.toString((Math.random() * 1e9).toLong(), 36)
        idToken = ""
        save()
        return false
    }

    private fun save() { Prefs.onlineUid = uid; Prefs.onlineRefresh = refresh }

    private fun form(url: String, body: String): String = post(url, body, "application/x-www-form-urlencoded")
    private fun json(url: String, body: String): String = post(url, body, "application/json")

    private fun post(url: String, body: String, type: String): String {
        val c = URL(url).openConnection() as HttpURLConnection
        c.requestMethod = "POST"
        c.connectTimeout = 12000; c.readTimeout = 15000
        c.doOutput = true
        c.setRequestProperty("Content-Type", type)
        c.outputStream.use { it.write(body.toByteArray()) }
        val code = c.responseCode
        val txt = (if (code in 200..299) c.inputStream else c.errorStream)?.bufferedReader()?.use { it.readText() } ?: ""
        if (code !in 200..299) throw java.io.IOException("HTTP $code $txt")
        return txt
    }

    // ------------------------------------------------------------------ database REST

    private fun authQuery(t: String): String = if (t.isNotEmpty()) "auth=" + java.net.URLEncoder.encode(t, "UTF-8") else ""

    /** One REST call. PATCH goes through POST with the method-override, because HttpURLConnection has no PATCH. */
    private fun rawCall(method: String, path: String, body: String?, token: String, query: String = "", onProgress: ((Float) -> Unit)? = null): String {
        val q = listOf(authQuery(token), query).filter { it.isNotEmpty() }.toMutableList()
        val real = if (method == "PATCH") { q.add("x-http-method-override=PATCH"); "POST" } else method
        val url = "$DB/$path.json" + if (q.isEmpty()) "" else "?" + q.joinToString("&")
        val c = URL(url).openConnection() as HttpURLConnection
        c.requestMethod = real
        c.connectTimeout = 12000; c.readTimeout = 30000
        if (method == "PATCH") c.setRequestProperty("X-HTTP-Method-Override", "PATCH")
        if (body != null) {
            val bytes = body.toByteArray()
            c.doOutput = true
            c.setRequestProperty("Content-Type", "application/json")
            c.setFixedLengthStreamingMode(bytes.size)
            c.outputStream.use { o ->
                var off = 0
                while (off < bytes.size) {
                    val n = min(16 * 1024, bytes.size - off)
                    o.write(bytes, off, n); off += n
                    onProgress?.invoke(off.toFloat() / bytes.size)
                }
            }
        }
        val code = c.responseCode
        val txt = (if (code in 200..299) c.inputStream else c.errorStream)?.bufferedReader()?.use { it.readText() } ?: ""
        if (code !in 200..299) throw java.io.IOException("HTTP $code $txt")
        return txt
    }

    private fun call(method: String, path: String, body: String? = null, query: String = "", onProgress: ((Float) -> Unit)? = null): String {
        ensureAuth()
        return try {
            rawCall(method, path, body, idToken, query, onProgress)
        } catch (e: java.io.IOException) {
            // an expired token: refresh once and try again
            if ((e.message ?: "").startsWith("HTTP 401")) { tokenExp = 0L; ensureAuth(); rawCall(method, path, body, idToken, query, onProgress) } else throw e
        }
    }

    // ------------------------------------------------------------------ location

    @SuppressLint("MissingPermission")
    private fun startLocation() {
        val ctx = app ?: return
        if (!Perms.locationOk(ctx)) { status.value = "Allow Location to see phones nearby."; return }
        try {
            val m = ctx.getSystemService(Context.LOCATION_SERVICE) as LocationManager
            lm = m
            for (p in listOf(LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER)) {
                try {
                    if (m.isProviderEnabled(p)) {
                        m.getLastKnownLocation(p)?.let { consider(it) }
                        m.requestLocationUpdates(p, 3000L, 2f, locListener, Looper.getMainLooper())
                    }
                } catch (_: Throwable) {}
            }
        } catch (_: Throwable) {}
    }

    private fun stopLocation() {
        try { lm?.removeUpdates(locListener) } catch (_: Throwable) {}
        lm = null
    }

    private val locListener = object : LocationListener {
        override fun onLocationChanged(l: Location) { consider(l) }
        @Deprecated("old API") override fun onStatusChanged(provider: String?, status: Int, extras: android.os.Bundle?) {}
        override fun onProviderEnabled(provider: String) {}
        override fun onProviderDisabled(provider: String) {}
    }

    private fun consider(l: Location) {
        val cur = loc
        // the better fix wins, but an old good one does not block a fresh decent one
        if (cur == null || l.accuracy <= cur.accuracy + 25f || l.time - cur.time > 20_000L) {
            loc = l
            accuracy.value = l.accuracy
        }
    }

    // ------------------------------------------------------------------ presence + nearby

    private fun cellOf(la: Double, lo: Double): String = "${floor(la / CELL).toLong()}_${floor(lo / CELL).toLong()}"

    private fun heartbeat() {
        val l = loc ?: run { if (status.value.isEmpty() || status.value == "Connecting...") status.value = "Waiting for your location..."; return }
        val cell = cellOf(l.latitude, l.longitude)
        if (myCell.isNotEmpty() && myCell != cell) { try { call("DELETE", "air/p/$myCell/$uid") } catch (_: Throwable) {} }
        myCell = cell
        if (!Prefs.onlineVisible) {
            // hidden: leave the map but keep receiving
            try { call("DELETE", "air/p/$cell/$uid") } catch (_: Throwable) {}
            return
        }
        val o = JSONObject().put("n", myName()).put("la", round5(l.latitude)).put("lo", round5(l.longitude))
            .put("a", l.accuracy.toInt()).put("t", JSONObject().put(".sv", "timestamp"))
        call("PUT", "air/p/$cell/$uid", o.toString())
        connected.value = true
    }

    private fun round5(v: Double): Double = Math.round(v * 1e5) / 1e5

    private fun poll() {
        val l = loc ?: return
        val radiusDeg = MAX_NEARBY_M / 111_320.0
        val lonDeg = radiusDeg / max(0.2, cos(Math.toRadians(l.latitude)))
        val la0 = floor((l.latitude - radiusDeg) / CELL).toLong(); val la1 = floor((l.latitude + radiusDeg) / CELL).toLong()
        val lo0 = floor((l.longitude - lonDeg) / CELL).toLong(); val lo1 = floor((l.longitude + lonDeg) / CELL).toLong()
        val now = System.currentTimeMillis()
        val out = ArrayList<OnlineNode>()
        val kmx = 111_320.0 * cos(Math.toRadians(l.latitude))
        for (a in la0..la1) for (b in lo0..lo1) {
            val cell = "${a}_$b"
            val txt = call("GET", "air/p/$cell")
            if (txt == "null" || txt.isBlank()) continue
            val o = JSONObject(txt)
            for (k in o.keys()) {
                val v = o.optJSONObject(k) ?: continue
                val t = v.optLong("t", 0L)
                if (k == uid) { if (t > 0) serverOffset = t - now; continue }
                val age = now + serverOffset - t
                if (age > 180_000L) { try { call("DELETE", "air/p/$cell/$k") } catch (_: Throwable) {}; continue }
                if (age > 40_000L) continue
                val la = v.optDouble("la"); val lo = v.optDouble("lo")
                val dx = ((lo - l.longitude) * kmx).toFloat()
                val dy = ((la - l.latitude) * 110_540.0).toFloat()
                val dist = hypot(dx, dy)
                if (dist > MAX_NEARBY_M) continue
                out.add(OnlineNode(k, v.optString("n", "Phone").take(20), la, lo, dx, dy, dist, colorOf(k)))
            }
        }
        out.sortBy { it.dist }
        nearby.value = out
        selected.value = selected.value.filter { s -> out.any { it.uid == s } }.toSet()
        connected.value = true
        status.value = if (out.isEmpty()) "Online. No phones nearby yet." else "Online. ${out.size} phone${if (out.size == 1) "" else "s"} nearby."
        cb?.nearbyChanged()
    }

    private fun colorOf(uid: String): Int {
        val palette = intArrayOf(0xFF7B2FF7.toInt(), 0xFF00B3FF.toInt(), 0xFFFF4D8D.toInt(), 0xFFFFB020.toInt(), 0xFF00D68F.toInt(), 0xFFFF6A3D.toInt())
        return palette[abs(uid.hashCode()) % palette.size]
    }

    /** Who a drop goes to right now: the tapped phones, or everyone inside the chosen range. */
    fun targets(): List<OnlineNode> {
        val r = Prefs.onlineRadius.toFloat()
        val inRange = nearby.value.filter { it.dist <= r }
        val sel = selected.value
        return if (sel.isEmpty()) inRange else inRange.filter { it.uid in sel }
    }

    fun toggle(uid: String) {
        val s = selected.value
        selected.value = if (uid in s) s - uid else s + uid
    }

    // ------------------------------------------------------------------ receiving

    private fun sseLoop() {
        var backoff = 1000L
        while (running) {
            try {
                ensureAuth()
                val url = "$DB/air/in/$uid.json" + (if (idToken.isNotEmpty()) "?" + authQuery(idToken) else "")
                val c = URL(url).openConnection() as HttpURLConnection
                sseConn = c
                c.setRequestProperty("Accept", "text/event-stream")
                c.connectTimeout = 15000
                c.readTimeout = 75000
                val code = c.responseCode
                if (code !in 200..299) throw java.io.IOException("HTTP $code")
                backoff = 1000L
                val r = BufferedReader(InputStreamReader(c.inputStream))
                var ev = ""
                while (running) {
                    val line = r.readLine() ?: break
                    if (line.startsWith("event:")) ev = line.substring(6).trim()
                    else if (line.startsWith("data:")) {
                        val data = line.substring(5).trim()
                        if (ev == "auth_revoked" || ev == "cancel") { tokenExp = 0L; break }
                        if (ev == "put" || ev == "patch") handleEvent(ev, data)
                    }
                }
            } catch (e: Throwable) {
                if (running) note(e)
            }
            if (!running) return
            try { Thread.sleep(backoff) } catch (_: InterruptedException) { return }
            backoff = min(backoff * 2, 15_000L)
        }
    }

    private fun handleEvent(ev: String, data: String) {
        val o = try { JSONObject(data) } catch (e: Exception) { return }
        val path = o.optString("path", "/")
        val d = o.opt("data")
        if (path == "/") {
            if (d is JSONObject) for (k in d.keys()) pointer(k, d.opt(k))
        } else {
            pointer(path.trim('/').substringBefore('/'), if (path.trim('/').contains('/')) null else d)
        }
    }

    private fun pointer(id: String, v: Any?) {
        if (v !is JSONObject) { pointers.remove(id); return }
        if (id in seen || pointers.containsKey(id)) return
        val e = v.optLong("e", 0L)
        val fu = v.optString("fu", "")
        if (e in 1 until System.currentTimeMillis()) { expire(id, fu); return }
        pointers[id] = Ptr(e, fu)
        ex?.execute { safe { fetchDrop(id) } }
        // drops are deleted when their time is up, even if nobody opens the app again
        val left = e - System.currentTimeMillis()
        if (left > 0) ex?.schedule({ safe { expire(id, fu) } }, left + 2000L, TimeUnit.MILLISECONDS)
    }

    private fun fetchDrop(id: String) {
        val txt = call("GET", "air/d/$id")
        if (txt == "null" || txt.isBlank()) { try { call("DELETE", "air/in/$uid/$id") } catch (_: Throwable) {}; pointers.remove(id); return }
        val o = JSONObject(txt)
        val imgs = ArrayList<Pair<String, ByteArray>>()
        val arr = o.optJSONArray("im") ?: JSONArray()
        for (i in 0 until arr.length()) {
            val it = arr.optJSONObject(i) ?: continue
            try { imgs.add(it.optString("n", "photo_$i.jpg") to Base64.decode(it.getString("d"), Base64.NO_WRAP)) } catch (_: Throwable) {}
        }
        val kind = o.optString("k", "img")
        if (kind == "img" && imgs.isEmpty()) return
        seen.add(id)
        Prefs.onlineSeen = seen.toList().takeLast(80).joinToString(",")
        cb?.incoming(OnlineDrop(id, o.optString("fu"), o.optString("fn", "Someone").take(20), kind, o.optString("x"), o.optString("ti"), imgs, o.optLong("e")))
    }

    /** Deletes a finished drop and this phone's pointer to it. */
    private fun expire(id: String, fromUid: String) {
        try { call("DELETE", "air/d/$id") } catch (_: Throwable) {}
        try { call("DELETE", "air/in/$uid/$id") } catch (_: Throwable) {}
        pointers.remove(id)
    }

    private fun sweep() {
        val now = System.currentTimeMillis()
        for ((id, p) in pointers.entries.toList()) if (p.e in 1 until now) expire(id, p.fu)
    }

    // ------------------------------------------------------------------ sending

    private fun newId(ttlMin: Int): String {
        val ts = java.lang.Long.toString(System.currentTimeMillis(), 36).padStart(9, '0')
        val ttl = java.lang.Integer.toString(ttlMin.coerceIn(1, 1295), 36).padStart(2, '0')
        val rnd = java.lang.Integer.toString((Math.random() * 46656).toInt(), 36).padStart(3, '0')
        return ts + ttl + rnd
    }

    /** A photo as a small JPEG so it fits the Realtime Database: long edge 1280, shrunk until under [maxBytes]. */
    fun jpegFor(file: File, maxBytes: Int): ByteArray? {
        try {
            val bo = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeFile(file.absolutePath, bo)
            var sample = 1
            while (max(bo.outWidth, bo.outHeight) / sample > 2600) sample *= 2
            val src = BitmapFactory.decodeFile(file.absolutePath, BitmapFactory.Options().apply { inSampleSize = sample }) ?: return null
            val rot = when (ExifInterface(file.absolutePath).getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)) {
                ExifInterface.ORIENTATION_ROTATE_90 -> 90f
                ExifInterface.ORIENTATION_ROTATE_180 -> 180f
                ExifInterface.ORIENTATION_ROTATE_270 -> 270f
                else -> 0f
            }
            var bmp = if (rot != 0f) Bitmap.createBitmap(src, 0, 0, src.width, src.height, Matrix().apply { postRotate(rot) }, true) else src
            var edge = 1280
            var q = 76
            while (true) {
                val k = min(1f, edge.toFloat() / max(bmp.width, bmp.height))
                val s = if (k < 1f) Bitmap.createScaledBitmap(bmp, (bmp.width * k).toInt().coerceAtLeast(1), (bmp.height * k).toInt().coerceAtLeast(1), true) else bmp
                val o = java.io.ByteArrayOutputStream()
                s.compress(Bitmap.CompressFormat.JPEG, q, o)
                val b = o.toByteArray()
                if (b.size <= maxBytes || (q <= 42 && edge <= 480)) return b
                if (q > 46) q -= 10 else { edge = (edge * 0.8f).toInt(); q = 60 }
            }
        } catch (e: Throwable) {
            return null
        }
    }

    /**
     * Drops [files] (photos) or [item] (text or link) to [targets]. [progress] runs 0..1, [done] reports once.
     * Photos are compressed here, one drop holds up to 4 of them. The drop is deleted again after [ttlMin].
     */
    fun send(
        files: List<Pair<File, String>>,
        item: QuickItem?,
        ttlMin: Int,
        targets: List<OnlineNode>,
        progress: (Float) -> Unit,
        done: (delivered: Int, total: Int, error: String?) -> Unit
    ) {
        val e = ex
        if (!running || e == null) { done(0, targets.size, "Online Air Share is off."); return }
        e.execute {
            try {
                if (targets.isEmpty()) { done(0, 0, "Nobody is in range."); return@execute }
                ensureAuth()
                val id = newId(ttlMin)
                val exp = System.currentTimeMillis() + ttlMin * 60_000L
                val to = JSONObject(); for (t in targets) to.put(t.uid, true)
                val o = JSONObject().put("fu", uid).put("fn", myName()).put("e", exp).put("to", to)
                if (item != null) {
                    o.put("k", item.kind).put("x", item.text.take(2000)).put("ti", item.title.take(200))
                } else {
                    val use = files.take(4)
                    if (use.isEmpty()) { done(0, targets.size, "Nothing to send."); return@execute }
                    val per = 900_000 / use.size
                    val arr = JSONArray()
                    use.forEachIndexed { i, (f, name) ->
                        val b = jpegFor(f, per)
                        if (b == null) { done(0, targets.size, "Online drops carry photos, text and links. \"$name\" could not be read as a photo."); return@execute }
                        val n = name.substringBeforeLast('.', name).take(40) + ".jpg"
                        arr.put(JSONObject().put("n", n).put("d", Base64.encodeToString(b, Base64.NO_WRAP)))
                        progress(0.35f * (i + 1) / use.size)
                    }
                    o.put("k", "img").put("im", arr)
                }
                call("PUT", "air/d/$id", o.toString(), "", { p -> progress(0.35f + 0.55f * p) })
                // the pointers go in last, all at once, so every phone hears about it together
                val inbox = JSONObject()
                val ptr = { JSONObject().put("e", exp).put("fu", uid).put("f", myName()).put("k", item?.kind ?: "img") }
                for (t in targets) inbox.put("${t.uid}/$id", ptr())
                call("PATCH", "air/in", inbox.toString())
                progress(1f)
                done(targets.size, targets.size, null)
                // delete it again when its time is up, even if the phones never answered
                e.schedule({
                    safe {
                        call("DELETE", "air/d/$id")
                        val gone = JSONObject(); for (t in targets) gone.put("${t.uid}/$id", JSONObject.NULL)
                        call("PATCH", "air/in", gone.toString())
                    }
                }, ttlMin.toLong(), TimeUnit.MINUTES)
            } catch (ex2: Throwable) {
                val m = ex2.message ?: ""
                done(
                    0, targets.size,
                    when {
                        m.startsWith("HTTP 401") || m.startsWith("HTTP 403") -> "Firebase refused it. Paste the rules from AIR_SHARE_RULES.json into your Realtime Database rules."
                        else -> "Could not reach Firebase. Check the internet."
                    }
                )
            }
        }
    }
}
