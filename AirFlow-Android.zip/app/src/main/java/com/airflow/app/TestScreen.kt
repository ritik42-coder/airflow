package com.airflow.app

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.PointF
import android.os.Handler
import android.os.Looper
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val HAND_LINES = listOf(
    0 to 1, 1 to 2, 2 to 3, 3 to 4,
    0 to 5, 5 to 6, 6 to 7, 7 to 8,
    5 to 9, 9 to 10, 10 to 11, 11 to 12,
    9 to 13, 13 to 14, 14 to 15, 15 to 16,
    13 to 17, 17 to 18, 18 to 19, 19 to 20, 0 to 17
)

@Composable
fun TestScreen() {
    val ctx = LocalContext.current
    var camOk by remember {
        mutableStateOf(ContextCompat.checkSelfPermission(ctx, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED)
    }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { camOk = it }
    if (camOk) {
        LiveTest()
    } else {
        Column(
            Modifier.fillMaxSize().padding(24.dp),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text("Camera permission is needed for the live test.")
            Spacer(Modifier.height(12.dp))
            Button(onClick = { launcher.launch(Manifest.permission.CAMERA) }) { Text("Allow camera") }
        }
    }
}

@Composable
private fun LiveTest() {
    val ctx = LocalContext.current
    val owner = LocalLifecycleOwner.current
    var frame by remember { mutableStateOf<Bitmap?>(null) }
    var lms by remember { mutableStateOf<List<PointF>?>(null) }
    var pose by remember { mutableStateOf(GestureEngine.Pose.NONE) }
    var feedIdx by remember { mutableIntStateOf(0) }
    var direction by remember { mutableIntStateOf(1) }
    var paused by remember { mutableStateOf(false) }
    var likes by remember { mutableStateOf(setOf<Int>()) }
    val done = remember { mutableStateListOf<Gesture>() }
    val log = remember { mutableStateListOf<String>() }
    val error by AirFlowState.error.collectAsState()

    DisposableEffect(owner) {
        // The in-app test needs the camera, so pause the background service meanwhile.
        ctx.stopService(Intent(ctx, AirFlowService::class.java))
        val main = Handler(Looper.getMainLooper())
        val controller = HandController(ctx, owner) { r ->
            main.post {
                frame = r.bitmap
                lms = r.landmarks
                pose = r.pose
                r.gesture?.let { g ->
                    if (g !in done) done.add(g)
                    val time = SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date())
                    log.add(0, "$time  ${g.title} → ${g.action}")
                    if (log.size > 8) log.removeAt(log.lastIndex)
                    when (g) {
                        Gesture.SWIPE_UP -> { direction = 1; feedIdx++ }
                        Gesture.SWIPE_DOWN -> { direction = -1; if (feedIdx > 0) feedIdx-- }
                        Gesture.PALM_HOLD -> paused = !paused
                        Gesture.PINCH -> likes = likes + feedIdx
                        else -> {}
                    }
                }
            }
        }
        controller.start()
        onDispose { controller.stop() }
    }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("Live test", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
        Text(
            "The camera runs only inside the app. Do the gestures: the right panel is a fake Shorts feed that reacts " +
                "exactly like the real thing. The background service is paused while you are on this tab.",
            style = MaterialTheme.typography.bodySmall
        )
        error?.let { Text(it, color = MaterialTheme.colorScheme.error) }

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Box(
                Modifier.weight(1f).aspectRatio(0.75f).clip(RoundedCornerShape(12.dp)).background(Color.Black)
            ) {
                val f = frame
                if (f != null) {
                    val img = remember(f) { f.asImageBitmap() }
                    Image(img, null, Modifier.fillMaxSize(), contentScale = ContentScale.FillBounds)
                } else {
                    Text("Starting camera…", Modifier.align(Alignment.Center), color = Color.White)
                }
                Canvas(Modifier.fillMaxSize()) {
                    val pts = lms ?: return@Canvas
                    HAND_LINES.forEach { (a, b) ->
                        drawLine(
                            Color.White.copy(alpha = 0.8f),
                            Offset(pts[a].x * size.width, pts[a].y * size.height),
                            Offset(pts[b].x * size.width, pts[b].y * size.height),
                            strokeWidth = 3f
                        )
                    }
                    pts.forEach {
                        drawCircle(Color(0xFF4FC3F7), 6f, Offset(it.x * size.width, it.y * size.height))
                    }
                }
                Text(
                    if (lms == null) "No hand" else "Pose: ${pose.name}",
                    Modifier.align(Alignment.BottomStart).padding(6.dp)
                        .background(Color(0xAA000000), RoundedCornerShape(8.dp)).padding(horizontal = 8.dp, vertical = 2.dp),
                    color = Color.White, fontSize = 12.sp
                )
            }

            Box(Modifier.weight(1f).aspectRatio(0.75f).clip(RoundedCornerShape(12.dp))) {
                AnimatedContent(
                    targetState = feedIdx,
                    transitionSpec = {
                        if (direction > 0)
                            (slideInVertically { it } + fadeIn()) togetherWith (slideOutVertically { -it } + fadeOut())
                        else
                            (slideInVertically { -it } + fadeIn()) togetherWith (slideOutVertically { it } + fadeOut())
                    },
                    label = "feed"
                ) { i -> ShortCard(i, paused, i in likes) }
            }
        }

        val total = Gesture.values().size
        SectionCard("Checklist  ${done.size}/$total") {
            Gesture.values().forEach { g ->
                Row(verticalAlignment = Alignment.Top) {
                    Text(if (g in done) "✅" else "⬜", Modifier.padding(end = 8.dp))
                    Column {
                        Text("${g.title} → ${g.action}", fontWeight = FontWeight.SemiBold)
                        if (g !in done) Text(g.how, style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
            if (done.size == total) Text("🎉 All gestures work! Go to Home and press Start.")
            OutlinedButton(onClick = { done.clear(); log.clear(); feedIdx = 0; paused = false; likes = emptySet() }) {
                Text("Reset test")
            }
        }

        SectionCard("Event log") {
            if (log.isEmpty()) Text("Nothing detected yet.", style = MaterialTheme.typography.bodySmall)
            log.forEach { Text(it, style = MaterialTheme.typography.bodySmall) }
        }
    }
}

@Composable
private fun ShortCard(i: Int, paused: Boolean, liked: Boolean) {
    val colors = listOf(Color(0xFF7C4DFF), Color(0xFFFF5252), Color(0xFF00BFA5), Color(0xFFFFAB00), Color(0xFF2979FF))
    Box(Modifier.fillMaxSize().background(colors[i % colors.size]), contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text("Short #${i + 1}", fontSize = 22.sp, fontWeight = FontWeight.Bold, color = Color.White)
            if (paused) Text("⏸ Paused", color = Color.White)
            if (liked) Text("❤️ Liked", color = Color.White)
        }
    }
}
