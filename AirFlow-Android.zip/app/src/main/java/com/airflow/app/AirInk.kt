package com.airflow.app

import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BlurMaskFilter
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import android.os.Build
import android.provider.MediaStore
import java.io.File
import java.io.FileOutputStream
import java.util.Random
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.sin

// ---------------------------------------------------------------------------------------------
// Air Draw: the ink. Strokes are painted into one offscreen layer, so a thousand of them stay
// smooth; the live stroke is painted straight into that same layer as the fingertip moves.
// ---------------------------------------------------------------------------------------------

enum class Brush(val label: String) {
    NEON("Neon"), MARKER("Marker"), RAINBOW("Rainbow"), SPRAY("Spray"), ERASER("Eraser"), CHALK("Chalk")
}

object InkPalette {
    val colors = intArrayOf(
        0xFF22D3EE.toInt(), 0xFF8B5CFF.toInt(), 0xFFFF4FD8.toInt(), 0xFF34F5A5.toInt(),
        0xFFFFA24A.toInt(), 0xFFFFE066.toInt(), 0xFF4F8BFF.toInt(), 0xFFFF5A5A.toInt(),
        0xFFF5F8FF.toInt(), 0xFF161B2E.toInt()
    )
    val names = arrayOf("Cyan", "Violet", "Pink", "Mint", "Orange", "Gold", "Blue", "Red", "White", "Ink")
}

private fun withAlpha(color: Int, alpha: Int): Int = (color and 0x00FFFFFF) or (alpha shl 24)

private fun rainbow(seg: Int, seed: Int): Int {
    val hue = ((seg * 5.5f + seed * 0.7f) % 360f + 360f) % 360f
    return Color.HSVToColor(floatArrayOf(hue, 0.80f, 1f))
}

class Stroke(val brush: Brush, val color: Int, val width: Float, val seed: Int) {
    /** Flat x,y pairs in layer pixels. */
    val pts = ArrayList<Float>()
}

class AirInk {

    var w = 0
    var h = 0
    var layer: Bitmap? = null
    private var cv: Canvas? = null

    val strokes = ArrayList<Stroke>()
    private val redoStack = ArrayList<Stroke>()
    var live: Stroke? = null
        private set

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val glowPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val path = Path()

    /** Returns true when the layer was actually rebuilt (so the UI can refresh its image). */
    fun resize(nw: Int, nh: Int): Boolean {
        if (nw <= 4 || nh <= 4) return false
        if (nw == w && nh == h && layer != null) return false
        w = nw
        h = nh
        val b = Bitmap.createBitmap(nw, nh, Bitmap.Config.ARGB_8888)
        layer = b
        cv = Canvas(b)
        replay()
        return true
    }

    fun isEmpty(): Boolean = strokes.isEmpty() && live == null

    // --------------------------------------------------------------------------------- strokes

    fun begin(x: Float, y: Float, brush: Brush, color: Int, width: Float) {
        redoStack.clear()
        val s = Stroke(brush, color, width, (Math.random() * 90000).toInt())
        s.pts.add(x)
        s.pts.add(y)
        live = s
        dot(s, x, y)
    }

    fun extend(x: Float, y: Float) {
        val s = live ?: return
        val n = s.pts.size
        if (n >= 2) {
            val lx = s.pts[n - 2]
            val ly = s.pts[n - 1]
            if (hypot(x - lx, y - ly) < 1.4f) return
        }
        s.pts.add(x)
        s.pts.add(y)
        val count = s.pts.size / 2
        if (count >= 3) segment(s, count - 2)
    }

    fun end() {
        val s = live ?: return
        live = null
        val count = s.pts.size / 2
        if (count >= 2) tail(s)
        strokes.add(s)
    }

    fun undo(): Boolean {
        if (live != null) end()
        if (strokes.isEmpty()) return false
        redoStack.add(strokes.removeAt(strokes.size - 1))
        replay()
        return true
    }

    fun redo(): Boolean {
        if (redoStack.isEmpty()) return false
        strokes.add(redoStack.removeAt(redoStack.size - 1))
        replay()
        return true
    }

    /** Swaps in another page's strokes and repaints the layer. */
    fun adopt(list: MutableList<Stroke>) {
        live = null
        strokes.clear()
        strokes.addAll(list)
        redoStack.clear()
        replay()
    }

    fun snapshot(): ArrayList<Stroke> = ArrayList(strokes)

    fun addStroke(s: Stroke) {
        strokes.add(s)
        full(s)
    }

    fun refresh() {
        replay()
    }

    fun clear() {
        live = null
        strokes.clear()
        redoStack.clear()
        replay()
    }

    // --------------------------------------------------------------------------------- painting

    private fun replay() {
        val c = cv ?: return
        c.drawColor(Color.TRANSPARENT, PorterDuff.Mode.CLEAR)
        for (s in strokes) full(s)
    }

    private fun full(s: Stroke) {
        val n = s.pts.size / 2
        if (n == 0) return
        if (n == 1) {
            dot(s, s.pts[0], s.pts[1])
            return
        }
        path.reset()
        path.moveTo(s.pts[0], s.pts[1])
        var i = 1
        while (i < n - 1) {
            val x1 = s.pts[i * 2]
            val y1 = s.pts[i * 2 + 1]
            val x2 = s.pts[(i + 1) * 2]
            val y2 = s.pts[(i + 1) * 2 + 1]
            path.quadTo(x1, y1, (x1 + x2) / 2f, (y1 + y2) / 2f)
            i++
        }
        path.lineTo(s.pts[(n - 1) * 2], s.pts[(n - 1) * 2 + 1])
        if (s.brush == Brush.SPRAY) spray(s, 0, n - 1) else paintPath(s, 0)
    }

    /** One quadratic segment through the middle point, painted the moment it is known. */
    private fun segment(s: Stroke, mid: Int) {
        if (mid < 1) return
        val x0 = s.pts[(mid - 1) * 2]
        val y0 = s.pts[(mid - 1) * 2 + 1]
        val x1 = s.pts[mid * 2]
        val y1 = s.pts[mid * 2 + 1]
        val x2 = s.pts[(mid + 1) * 2]
        val y2 = s.pts[(mid + 1) * 2 + 1]
        path.reset()
        path.moveTo((x0 + x1) / 2f, (y0 + y1) / 2f)
        path.quadTo(x1, y1, (x1 + x2) / 2f, (y1 + y2) / 2f)
        if (s.brush == Brush.SPRAY) spray(s, mid - 1, mid + 1) else paintPath(s, mid)
    }

    private fun tail(s: Stroke) {
        val n = s.pts.size / 2
        val x0 = s.pts[(n - 2) * 2]
        val y0 = s.pts[(n - 2) * 2 + 1]
        val x1 = s.pts[(n - 1) * 2]
        val y1 = s.pts[(n - 1) * 2 + 1]
        path.reset()
        path.moveTo((x0 + x1) / 2f, (y0 + y1) / 2f)
        path.lineTo(x1, y1)
        if (s.brush == Brush.SPRAY) spray(s, n - 2, n - 1) else paintPath(s, n)
    }

    /** Glow first (neon only), then the line itself. */
    private fun paintPath(s: Stroke, seg: Int) {
        val c = cv ?: return
        configure(s, seg)
        if (s.brush == Brush.NEON) c.drawPath(path, glowPaint)
        c.drawPath(path, paint)
    }

    private fun dot(s: Stroke, x: Float, y: Float) {
        val c = cv ?: return
        configure(s, 0)
        paint.style = Paint.Style.FILL
        paint.xfermode = if (s.brush == Brush.ERASER) PorterDuffXfermode(PorterDuff.Mode.CLEAR) else null
        paint.color = if (s.brush == Brush.ERASER) Color.TRANSPARENT else paint.color
        c.drawCircle(x, y, s.width / 2f, paint)
        paint.style = Paint.Style.STROKE
    }

    /** Sets [paint] (and, for neon, [glowPaint]) up for this brush and this segment. */
    private fun configure(s: Stroke, seg: Int) {
        val color = if (s.brush == Brush.RAINBOW) rainbow(seg, s.seed) else s.color
        paint.reset()
        paint.isAntiAlias = true
        paint.style = Paint.Style.STROKE
        paint.strokeCap = Paint.Cap.ROUND
        paint.strokeJoin = Paint.Join.ROUND
        paint.strokeWidth = s.width
        paint.color = color
        paint.maskFilter = null
        paint.xfermode = null

        when (s.brush) {
            Brush.NEON -> {
                paint.color = Color.WHITE
                paint.strokeWidth = (s.width * 0.6f).coerceAtLeast(1.6f)
                glowPaint.reset()
                glowPaint.isAntiAlias = true
                glowPaint.style = Paint.Style.STROKE
                glowPaint.strokeCap = Paint.Cap.ROUND
                glowPaint.strokeJoin = Paint.Join.ROUND
                glowPaint.strokeWidth = s.width * 1.4f
                glowPaint.color = color
                glowPaint.maskFilter = BlurMaskFilter(s.width * 1.2f + 7f, BlurMaskFilter.Blur.NORMAL)
            }
            Brush.MARKER -> {
                paint.color = withAlpha(color, 108)
                paint.strokeWidth = s.width * 2.3f
            }
            Brush.CHALK -> {
                paint.color = withAlpha(color, 185)
                paint.strokeWidth = s.width * 1.15f
                paint.strokeCap = Paint.Cap.BUTT
            }
            Brush.ERASER -> {
                paint.color = Color.TRANSPARENT
                paint.strokeWidth = s.width * 2.6f
                paint.xfermode = PorterDuffXfermode(PorterDuff.Mode.CLEAR)
            }
            else -> {
                paint.color = color
            }
        }
    }

    private fun spray(s: Stroke, from: Int, to: Int) {
        val c = cv ?: return
        val r = Random(s.seed * 131L + from * 17L)
        val spread = s.width * 1.6f
        paint.reset()
        paint.isAntiAlias = true
        paint.style = Paint.Style.FILL
        if (s.brush == Brush.ERASER) {
            paint.color = Color.TRANSPARENT
            paint.xfermode = PorterDuffXfermode(PorterDuff.Mode.CLEAR)
        } else {
            paint.color = withAlpha(s.color, 190)
        }
        val rDot = (s.width * 0.13f).coerceAtLeast(1.1f)
        var i = from
        while (i <= to && i < s.pts.size / 2) {
            val px = s.pts[i * 2]
            val py = s.pts[i * 2 + 1]
            var k = 0
            while (k < 7) {
                val a = r.nextFloat() * (2.0 * PI).toFloat()
                val d = r.nextFloat() * spread
                c.drawCircle(px + cos(a) * d, py + sin(a) * d, rDot, paint)
                k++
            }
            i++
        }
    }

    // --------------------------------------------------------------------------------- export

    /** Flattens the ink onto [paper] and writes a PNG into Pictures/AirFlow. */
    fun export(ctx: Context, paper: Int): Boolean {
        val src = layer ?: return false
        return try {
            val out = Bitmap.createBitmap(src.width, src.height, Bitmap.Config.ARGB_8888)
            val c = Canvas(out)
            c.drawColor(paper)
            c.drawBitmap(src, 0f, 0f, null)
            val name = "AirDraw_${System.currentTimeMillis()}.png"
            val file = File(ctx.cacheDir, name)
            FileOutputStream(file).use { out.compress(Bitmap.CompressFormat.PNG, 100, it) }
            if (Build.VERSION.SDK_INT >= 29) {
                val v = ContentValues().apply {
                    put(MediaStore.Images.Media.DISPLAY_NAME, name)
                    put(MediaStore.Images.Media.MIME_TYPE, "image/png")
                    put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/AirFlow")
                    put(MediaStore.Images.Media.IS_PENDING, 1)
                }
                val uri = ctx.contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, v)
                if (uri != null) {
                    ctx.contentResolver.openOutputStream(uri)?.use { o -> file.inputStream().use { it.copyTo(o) } }
                    v.clear()
                    v.put(MediaStore.Images.Media.IS_PENDING, 0)
                    ctx.contentResolver.update(uri, v, null, null)
                }
            } else {
                val dir = ctx.getExternalFilesDir(android.os.Environment.DIRECTORY_PICTURES) ?: ctx.filesDir
                file.copyTo(File(dir, name), true)
            }
            out.recycle()
            true
        } catch (e: Exception) {
            false
        }
    }
}

// ---------------------------------------------------------------------------------------------
// Sample outlines to trace: every shape is a list of normalised polylines (0..1)
// ---------------------------------------------------------------------------------------------

class Template(val name: String, val lines: List<FloatArray>)

object Outlines {

    private fun ellipse(cx: Float, cy: Float, rx: Float, ry: Float, n: Int = 64, from: Float = 0f, to: Float = 6.2832f): FloatArray {
        val out = FloatArray((n + 1) * 2)
        for (i in 0..n) {
            val t = from + (to - from) * i / n
            out[i * 2] = cx + cos(t) * rx
            out[i * 2 + 1] = cy + sin(t) * ry
        }
        return out
    }

    private fun line(vararg xy: Float): FloatArray = xy

    private fun heart(): Template {
        val n = 120
        val a = FloatArray((n + 1) * 2)
        for (i in 0..n) {
            val t = 6.2832f * i / n
            val x = 16f * sin(t) * sin(t) * sin(t)
            val y = 13f * cos(t) - 5f * cos(2 * t) - 2f * cos(3 * t) - cos(4 * t)
            a[i * 2] = 0.5f + x * 0.0245f
            a[i * 2 + 1] = 0.5f - y * 0.0245f
        }
        return Template("Heart", listOf(a))
    }

    private fun star(): Template {
        val out = ArrayList<Float>()
        for (i in 0..10) {
            val r = if (i % 2 == 0) 0.36f else 0.155f
            val t = -PI / 2 + i * PI / 5
            out.add(0.5f + (cos(t) * r).toFloat())
            out.add(0.5f + (sin(t) * r).toFloat())
        }
        return Template("Star", listOf(out.toFloatArray()))
    }

    private fun house(): Template = Template(
        "House",
        listOf(
            line(0.22f, 0.52f, 0.78f, 0.52f, 0.78f, 0.86f, 0.22f, 0.86f, 0.22f, 0.52f),
            line(0.14f, 0.53f, 0.5f, 0.2f, 0.86f, 0.53f),
            line(0.42f, 0.86f, 0.42f, 0.66f, 0.58f, 0.66f, 0.58f, 0.86f),
            line(0.62f, 0.32f, 0.62f, 0.16f, 0.72f, 0.16f, 0.72f, 0.40f)
        )
    )

    private fun cat(): Template = Template(
        "Cat",
        listOf(
            ellipse(0.5f, 0.56f, 0.26f, 0.24f),
            line(0.29f, 0.40f, 0.26f, 0.20f, 0.42f, 0.31f),
            line(0.71f, 0.40f, 0.74f, 0.20f, 0.58f, 0.31f),
            ellipse(0.41f, 0.52f, 0.035f, 0.05f, 20),
            ellipse(0.59f, 0.52f, 0.035f, 0.05f, 20),
            line(0.47f, 0.63f, 0.5f, 0.66f, 0.53f, 0.63f),
            line(0.5f, 0.66f, 0.5f, 0.69f),
            line(0.24f, 0.60f, 0.38f, 0.63f),
            line(0.24f, 0.68f, 0.38f, 0.66f),
            line(0.76f, 0.60f, 0.62f, 0.63f),
            line(0.76f, 0.68f, 0.62f, 0.66f)
        )
    )

    private fun flower(): Template {
        val lines = ArrayList<FloatArray>()
        for (k in 0 until 5) {
            val a = -PI / 2 + k * 2 * PI / 5
            lines.add(ellipse(0.5f + (cos(a) * 0.14).toFloat(), 0.42f + (sin(a) * 0.14).toFloat(), 0.115f, 0.115f, 32))
        }
        lines.add(ellipse(0.5f, 0.42f, 0.05f, 0.05f, 24))
        lines.add(line(0.5f, 0.56f, 0.5f, 0.86f))
        lines.add(ellipse(0.60f, 0.70f, 0.09f, 0.05f, 32))
        return Template("Flower", lines)
    }

    private fun butterfly(): Template = Template(
        "Butterfly",
        listOf(
            ellipse(0.33f, 0.40f, 0.17f, 0.13f),
            ellipse(0.67f, 0.40f, 0.17f, 0.13f),
            ellipse(0.36f, 0.66f, 0.13f, 0.11f),
            ellipse(0.64f, 0.66f, 0.13f, 0.11f),
            line(0.5f, 0.28f, 0.5f, 0.78f),
            line(0.5f, 0.28f, 0.42f, 0.16f),
            line(0.5f, 0.28f, 0.58f, 0.16f)
        )
    )

    private fun tree(): Template = Template(
        "Tree",
        listOf(
            ellipse(0.5f, 0.38f, 0.24f, 0.20f),
            ellipse(0.34f, 0.48f, 0.15f, 0.13f),
            ellipse(0.66f, 0.48f, 0.15f, 0.13f),
            line(0.45f, 0.62f, 0.45f, 0.88f),
            line(0.55f, 0.62f, 0.55f, 0.88f),
            line(0.45f, 0.88f, 0.55f, 0.88f)
        )
    )

    private fun rocket(): Template = Template(
        "Rocket",
        listOf(
            line(0.5f, 0.14f, 0.62f, 0.36f, 0.62f, 0.68f, 0.38f, 0.68f, 0.38f, 0.36f, 0.5f, 0.14f),
            ellipse(0.5f, 0.38f, 0.06f, 0.06f, 24),
            line(0.38f, 0.52f, 0.26f, 0.70f, 0.38f, 0.68f),
            line(0.62f, 0.52f, 0.74f, 0.70f, 0.62f, 0.68f),
            line(0.44f, 0.68f, 0.44f, 0.80f, 0.5f, 0.74f, 0.56f, 0.80f, 0.56f, 0.68f)
        )
    )

    private fun apple(): Template = Template(
        "Apple",
        listOf(
            ellipse(0.5f, 0.60f, 0.24f, 0.24f),
            line(0.5f, 0.36f, 0.52f, 0.22f),
            ellipse(0.60f, 0.24f, 0.08f, 0.04f, 24)
        )
    )

    private fun cloud(): Template {
        val a = ArrayList<Float>()
        val n = 90
        for (i in 0..n) {
            val t = 6.2832f * i / n
            val r = 0.10f + 0.045f * sin(t * 3f)
            a.add(0.5f + (cos(t) * (r + 0.12f)).toFloat())
            a.add(0.55f + (sin(t) * r).toFloat())
        }
        return Template("Cloud", listOf(a.toFloatArray()))
    }

    private fun sun(): Template {
        val lines = ArrayList<FloatArray>()
        lines.add(ellipse(0.5f, 0.5f, 0.18f, 0.18f, 48))
        for (k in 0 until 8) {
            val a = k * PI / 4
            val c = cos(a).toFloat()
            val s = sin(a).toFloat()
            lines.add(line(0.5f + c * 0.24f, 0.5f + s * 0.24f, 0.5f + c * 0.36f, 0.5f + s * 0.36f))
        }
        return Template("Sun", lines)
    }

    private fun fish(): Template = Template(
        "Fish",
        listOf(
            ellipse(0.46f, 0.5f, 0.26f, 0.17f),
            line(0.72f, 0.5f, 0.88f, 0.34f, 0.88f, 0.66f, 0.72f, 0.5f),
            ellipse(0.32f, 0.46f, 0.022f, 0.022f, 16)
        )
    )

    private fun umbrella(): Template = Template(
        "Umbrella",
        listOf(
            ellipse(0.5f, 0.52f, 0.34f, 0.28f, 60, 3.1416f, 6.2832f),
            line(0.16f, 0.52f, 0.84f, 0.52f),
            line(0.5f, 0.14f, 0.5f, 0.52f),
            line(0.5f, 0.52f, 0.5f, 0.80f, 0.58f, 0.86f, 0.64f, 0.80f)
        )
    )

    val all: List<Template> = listOf(
        heart(), star(), house(), cat(), flower(), butterfly(), tree(), rocket(), apple(), cloud(), sun(), fish(), umbrella()
    )
}

/** Samples a template into points and tracks how much of it the fingertip has covered. */
class Tracer(template: Template, spacing: Float = 0.011f) {

    val xs: FloatArray
    val ys: FloatArray
    private val hit: BooleanArray
    private var count = 0

    init {
        val px = ArrayList<Float>()
        val py = ArrayList<Float>()
        for (l in template.lines) {
            var i = 0
            while (i + 3 < l.size) {
                val x0 = l[i]
                val y0 = l[i + 1]
                val x1 = l[i + 2]
                val y1 = l[i + 3]
                val d = hypot(x1 - x0, y1 - y0)
                val steps = (d / spacing).toInt().coerceIn(1, 400)
                for (k in 0..steps) {
                    val t = k.toFloat() / steps
                    px.add(x0 + (x1 - x0) * t)
                    py.add(y0 + (y1 - y0) * t)
                }
                i += 2
            }
        }
        xs = px.toFloatArray()
        ys = py.toFloatArray()
        hit = BooleanArray(xs.size)
    }

    fun touch(x: Float, y: Float, r: Float): Boolean {
        var added = false
        val r2 = r * r
        for (i in xs.indices) {
            if (hit[i]) continue
            val dx = xs[i] - x
            val dy = ys[i] - y
            if (dx * dx + dy * dy <= r2) {
                hit[i] = true
                count++
                added = true
            }
        }
        return added
    }

    val progress: Float
        get() = if (xs.isEmpty()) 0f else count.toFloat() / xs.size

    fun reset() {
        java.util.Arrays.fill(hit, false)
        count = 0
    }
}
