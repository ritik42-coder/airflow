package com.airflow.app

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.PointF
import android.os.Handler
import android.os.Looper
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.State
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush as BrushG
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.PointMode
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.boundsInRoot
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.layout.positionInRoot
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import kotlin.math.cos
import kotlin.math.exp
import kotlin.math.hypot
import kotlin.math.sin
import kotlinx.coroutines.delay

// ---------------------------------------------------------------------------------------------
// Air Draw: paint in the air. Pinch to put the pen down, open your fingers to lift it.
// ---------------------------------------------------------------------------------------------

private val TIP_INDEX = 8
private val TIP_THUMB = 4

/** Where the buttons are on screen, so a fingertip can press them without touching anything. */
private class AirReg {
    val rects = HashMap<String, Rect>()
    val actions = HashMap<String, () -> Unit>()

    fun hit(x: Float, y: Float): String? {
        for (key in rects.keys) {
            val r = rects[key] ?: continue
            if (x >= r.left && x <= r.right && y >= r.top && y <= r.bottom) return key
        }
        return null
    }
}

@Composable
private fun Modifier.airTarget(reg: AirReg, id: String, onClick: () -> Unit): Modifier = composed {
    SideEffect { reg.actions[id] = onClick }
    onGloballyPositioned { co -> reg.rects[id] = co.boundsInRoot() }
}

private class Spark2(var x: Float, var y: Float, var vx: Float, var vy: Float, var life: Float, var max: Float)

/**
 * All the live state of the studio: where the fingertip is, whether the pen is down, sparks.
 * Plain Kotlin so the 30 FPS camera never triggers a recomposition.
 */
private class DrawState(private val ink: AirInk) {

    var brush: Brush = Brush.NEON
    var color: Int = InkPalette.colors[0]
    var width: Float = 22f
    var pinchMode: Boolean = true
    var tracer: Tracer? = null
    var reg: AirReg? = null
    var onProgress: ((Float) -> Unit)? = null
    var onDone: (() -> Unit)? = null

    /** The whole play area (canvas + toolbar) in field pixels. */
    var fieldW = 0f
    var fieldH = 0f
    var colX = 0f
    var colY = 0f
    /** The drawing canvas, in root pixels and in size. */
    var canvasRootX = 0f
    var canvasRootY = 0f
    var canvasW = 0f
    var canvasH = 0f

    var cursorX = 0f
    var cursorY = 0f
    var visible = false
    var inCanvas = false
    var penDown = false
    private var suppressed = false
    private var sx = 0f
    private var sy = 0f
    private var lastProgress = 0f

    val sparks = ArrayList<Spark2>()
    var time = 0f
    var lastDir = 0f

    fun resetPen() {
        if (penDown) ink.end()
        penDown = false
        suppressed = false
        visible = false
    }

    fun onHands(lms: List<PointF>?) {
        if (lms == null || lms.size < 21 || fieldW < 8f || fieldH < 8f) {
            resetPen()
            return
        }
        val tip = lms[TIP_INDEX]
        val thumb = lms[TIP_THUMB]
        val d = hypot(tip.x - thumb.x, tip.y - thumb.y)

        val down = if (pinchMode) {
            d < (if (penDown) 0.078f else 0.050f)
        } else {
            tip.y < lms[6].y + 0.015f
        }

        // a little gain so the whole area is reachable without leaving the frame
        val nx = ((tip.x - 0.10f) / 0.80f).coerceIn(0f, 1f)
        val ny = ((tip.y - 0.10f) / 0.80f).coerceIn(0f, 1f)
        val left = canvasRootX - colX
        val top = canvasRootY - colY

        val tx = nx * fieldW
        // the upper part of the frame maps onto the canvas, the bottom band reaches the toolbar
        val ty = if (ny <= 0.78f) {
            top + ((ny - 0.10f) / 0.68f).coerceIn(0f, 1f) * canvasH
        } else {
            top + canvasH + ((ny - 0.78f) / 0.22f).coerceIn(0f, 1f) * (fieldH - top - canvasH).coerceAtLeast(0f)
        }

        if (!visible) {
            sx = tx
            sy = ty
            visible = true
        }
        sx += (tx - sx) * 0.42f
        sy += (ty - sy) * 0.42f
        cursorX = sx
        cursorY = sy
        inCanvas = sx >= left && sx <= left + canvasW && sy >= top && sy <= top + canvasH
        lastDir = tx - sx

        if (down && !penDown) {
            val hit = reg?.hit(colX + sx, colY + sy)
            if (hit != null) {
                reg?.actions?.get(hit)?.invoke()
                suppressed = true
            } else if (inCanvas) {
                suppressed = false
                ink.begin(sx - left, sy - top, brush, color, width)
                penDown = true
                burst(sx, sy)
            }
        } else if (down && penDown) {
            if (!suppressed) {
                ink.extend(sx - left, sy - top)
                trace()
            }
        } else if (!down && penDown) {
            if (!suppressed) ink.end()
            penDown = false
            suppressed = false
        }
    }

    private fun trace() {
        val t = tracer ?: return
        if (canvasW < 8f || canvasH < 8f) return
        val left = canvasRootX - colX
        val top = canvasRootY - colY
        t.touch((sx - left) / canvasW, (sy - top) / canvasH, 0.030f)
        val p = t.progress
        if (p - lastProgress > 0.01f) {
            lastProgress = p
            onProgress?.invoke(p)
            if (p >= 0.92f && lastProgress < 1f) {
                lastProgress = 1f
                onDone?.invoke()
            }
        }
    }

    fun newTemplate() {
        lastProgress = 0f
        onProgress?.invoke(0f)
    }

    fun burst(x: Float, y: Float) {
        var i = 0
        while (i < 10) {
            val a = (Math.random() * 6.2832).toFloat()
            val sp = 60f + 210f * Math.random().toFloat()
            sparks.add(Spark2(x, y, cos(a) * sp, sin(a) * sp, 0.45f + 0.35f * Math.random().toFloat(), 0.8f))
            i++
        }
        while (sparks.size > 80) sparks.removeAt(0)
    }

    fun frame(dt: Float) {
        time += dt
        var i = 0
        while (i < sparks.size) {
            val s = sparks[i]
            s.life -= dt
            if (s.life <= 0f) {
                sparks.removeAt(i)
            } else {
                s.x += s.vx * dt
                s.y += s.vy * dt
                s.vy += 320f * dt
                s.vx *= 0.96f
                i++
            }
        }
    }
}

// ---------------------------------------------------------------------------------------------
// Screen
// ---------------------------------------------------------------------------------------------

@Composable
fun AirDrawScreen() {
    val ctx = LocalContext.current
    var camOk by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED
        )
    }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { camOk = it }
    if (camOk) {
        DrawStudio()
    } else {
        AirScroll {
            ScreenHeader("Air Draw", "Paint in the air with your fingertip")
            SectionCard("Camera needed") {
                Text(
                    "Air Draw follows your fingertip. Nothing is recorded and the video never leaves your phone.",
                    color = Air.c.dim
                )
                AirButton(
                    "Allow camera", { launcher.launch(Manifest.permission.CAMERA) },
                    Modifier.fillMaxWidth(), icon = IconKind.SCAN
                )
            }
            SectionCard("How it works") {
                Text(
                    "Pinch your thumb and index finger to put the pen down, move to draw, open your fingers to lift it. " +
                        "Pick a colour, a brush or a sample outline by pinching over it — you never have to touch the screen.",
                    style = MaterialTheme.typography.bodySmall, color = Air.c.dim
                )
            }
        }
    }
}

@Composable
private fun DrawStudio() {
    val ctx = LocalContext.current
    val owner = LocalLifecycleOwner.current
    val c = Air.c
    val density = LocalDensity.current.density

    val ink = remember { AirInk() }
    val reg = remember { AirReg() }
    val st = remember { DrawState(ink) }

    var brush by remember { mutableStateOf(Brush.NEON) }
    var color by remember { mutableIntStateOf(InkPalette.colors[0]) }
    var sizeIdx by remember { mutableIntStateOf(1) }
    var night by remember { mutableStateOf(true) }
    var templateIdx by remember { mutableIntStateOf(-1) }
    var panel by remember { mutableStateOf(false) }
    var progress by remember { mutableFloatStateOf(0f) }
    var toast by remember { mutableStateOf<String?>(null) }
    var layerVersion by remember { mutableIntStateOf(0) }
    var pinchMode by remember { mutableStateOf(true) }
    var showCam by remember { mutableStateOf(true) }
    var hands by remember { mutableIntStateOf(0) }
    var canvasPx by remember { mutableStateOf(IntSize.Zero) }
    val clock = remember { mutableFloatStateOf(0f) }

    val frameState = remember { mutableStateOf<Bitmap?>(null) }
    val lmsState = remember { mutableStateOf<List<PointF>?>(null) }

    val paper = if (night) Color(0xFF0A0D18) else Color(0xFFFDFCFF)
    val paperArgb = if (night) 0xFF0A0D18.toInt() else 0xFFFDFCFF.toInt()

    val tracer = remember(templateIdx) {
        if (templateIdx >= 0) Tracer(Outlines.all[templateIdx]) else null
    }

    // ---- keep the engine in step with the UI ------------------------------------------------
    SideEffect {
        st.brush = brush
        st.color = color
        st.width = floatArrayOf(6f, 13f, 24f)[sizeIdx] * density
        st.pinchMode = pinchMode
        st.tracer = tracer
        st.reg = reg
        st.onProgress = { p -> progress = p }
        st.onDone = { toast = "Outline complete. Beautiful." }
    }
    LaunchedEffect(templateIdx) {
        progress = 0f
        st.newTemplate()
    }
    LaunchedEffect(toast) {
        if (toast != null) {
            delay(1800)
            toast = null
        }
    }

    // ---- camera -----------------------------------------------------------------------------
    DisposableEffect(owner) {
        ctx.stopService(Intent(ctx, AirFlowService::class.java))
        val main = Handler(Looper.getMainLooper())
        val controller = HandController(ctx, owner, needBitmap = true, maxHands = 1, minFps = 30) { r ->
            main.post {
                frameState.value = r.bitmap
                lmsState.value = r.landmarks
                val h = if (r.landmarks != null) 1 else 0
                if (h != hands) hands = h
                st.onHands(r.landmarks)
            }
        }
        controller.start()
        onDispose {
            controller.stop()
            st.resetPen()
        }
    }
    DisposableEffect(owner) {
        val obs = LifecycleEventObserver { _, e -> if (e == Lifecycle.Event.ON_PAUSE) st.resetPen() }
        owner.lifecycle.addObserver(obs)
        onDispose { owner.lifecycle.removeObserver(obs) }
    }

    // ---- frame clock ------------------------------------------------------------------------
    LaunchedEffect(Unit) {
        var last = 0L
        while (true) {
            withFrameNanos { now ->
                val dt = if (last == 0L) 0.016f else ((now - last) / 1000000000.0).toFloat().coerceIn(0.001f, 0.05f)
                last = now
                st.frame(dt)
                clock.floatValue += dt
            }
        }
    }

    val layerImg = remember(layerVersion) { ink.layer?.asImageBitmap() }
    // built once per canvas size: the paper dots and the sample outline never change shape
    val grid = remember(canvasPx) { paperDots(canvasPx.width, canvasPx.height) }
    val outlinePath = remember(templateIdx, canvasPx) {
        if (templateIdx >= 0) outlinePathOf(Outlines.all[templateIdx], canvasPx.width.toFloat(), canvasPx.height.toFloat())
        else null
    }

    // ---- layout -----------------------------------------------------------------------------
    Box(Modifier.fillMaxSize()) {
        Column(Modifier.fillMaxSize().padding(top = 56.dp, bottom = 84.dp)) {

            Box(
                Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .padding(horizontal = 10.dp)
                    .clip(RoundedCornerShape(26.dp))
                    .background(paper)
                    .border(
                        1.dp,
                        BrushG.linearGradient(
                            listOf(c.a2.copy(alpha = 0.45f), c.a1.copy(alpha = 0.18f), c.a3.copy(alpha = 0.45f))
                        ),
                        RoundedCornerShape(26.dp)
                    )
            ) {
                Canvas(
                    Modifier
                        .fillMaxSize()
                        .onSizeChanged { sz ->
                            canvasPx = sz
                            if (ink.resize(sz.width, sz.height)) layerVersion++
                        }
                        .onGloballyPositioned { co ->
                            st.canvasRootX = co.positionInRoot().x
                            st.canvasRootY = co.positionInRoot().y
                            st.canvasW = co.size.width.toFloat()
                            st.canvasH = co.size.height.toFloat()
                        }
                ) {
                    drawPaper(night, c, grid)
                    outlinePath?.let { drawOutline(it, c, clock.floatValue) }
                    layerImg?.let { drawImage(it, Offset.Zero) }
                }

                // camera inset ---------------------------------------------------------------
                if (showCam) {
                    Box(
                        Modifier
                            .align(Alignment.TopEnd)
                            .padding(8.dp)
                            .size(width = 92.dp, height = 118.dp)
                            .clip(RoundedCornerShape(18.dp))
                            .background(Color(0xFF05060C))
                            .border(1.dp, c.stroke, RoundedCornerShape(18.dp))
                            .pressClick(scaleTo = 0.94f) { showCam = false }
                    ) {
                        CameraInset(frameState, lmsState, c)
                        Box(
                            Modifier
                                .align(Alignment.BottomCenter)
                                .padding(4.dp)
                                .clip(RoundedCornerShape(50))
                                .background(Color(0xAA000000))
                                .padding(horizontal = 7.dp, vertical = 2.dp)
                        ) {
                            Text(
                                if (hands > 0) "HAND" else "SHOW HAND",
                                color = if (hands > 0) c.ok else c.warn,
                                fontSize = 8.sp, fontWeight = FontWeight.Black, letterSpacing = 1.sp
                            )
                        }
                    }
                } else {
                    Box(
                        Modifier
                            .align(Alignment.TopEnd)
                            .padding(8.dp)
                            .size(38.dp)
                            .clip(CircleShape)
                            .background(c.glass)
                            .border(1.dp, c.stroke, CircleShape)
                            .pressClick { showCam = true },
                        contentAlignment = Alignment.Center
                    ) { AirIcon(IconKind.SCAN, c.text, Modifier.size(17.dp)) }
                }

                // top-left status ------------------------------------------------------------
                Row(Modifier.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        Modifier
                            .clip(RoundedCornerShape(50))
                            .background(if (night) Color(0x66000000) else Color(0x14FFFFFF))
                            .border(1.dp, c.stroke, RoundedCornerShape(50))
                            .padding(horizontal = 10.dp, vertical = 5.dp)
                    ) {
                        Text(
                            "AIR DRAW", color = if (night) Color.White else c.text, fontSize = 10.sp,
                            fontWeight = FontWeight.Black, letterSpacing = 2.sp
                        )
                    }
                    if (tracer != null) {
                        Spacer(Modifier.width(8.dp))
                        Box(
                            Modifier
                                .clip(RoundedCornerShape(50))
                                .background(c.glassHi)
                                .padding(horizontal = 9.dp, vertical = 4.dp)
                        ) {
                            Text(
                                "${(progress * 100).toInt()}%",
                                color = c.a2, fontSize = 10.sp, fontWeight = FontWeight.Black
                            )
                        }
                    }
                }

                toast?.let {
                    Box(
                        Modifier
                            .align(Alignment.BottomCenter)
                            .padding(bottom = 14.dp)
                            .clip(RoundedCornerShape(50))
                            .background(BrushG.horizontalGradient(listOf(c.a1, c.a2)))
                            .padding(horizontal = 18.dp, vertical = 8.dp)
                    ) {
                        Text(it, color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }

            // toolbar -----------------------------------------------------------------------
            Column(Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 6.dp)) {
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Brush.values().forEach { b ->
                        val sel = b == brush
                        Box(
                            Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(50))
                                .background(if (sel) BrushG.horizontalGradient(listOf(c.a1, c.a2)) else SolidColor(c.glass))
                                .border(1.dp, if (sel) Color.Transparent else c.stroke, RoundedCornerShape(50))
                                .airTarget(reg, "brush_${b.name}") { brush = b }
                                .pressClick(scaleTo = 0.95f) { brush = b }
                                .padding(vertical = 6.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                b.label,
                                color = if (sel) Color.White else c.dim,
                                fontSize = 10.sp, fontWeight = if (sel) FontWeight.Bold else FontWeight.Medium,
                                maxLines = 1
                            )
                        }
                    }
                }
                Spacer(Modifier.height(6.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                    InkPalette.colors.forEachIndexed { i, col ->
                        val sel = col == color
                        Box(
                            Modifier
                                .weight(1f)
                                .height(30.dp)
                                .clip(RoundedCornerShape(9.dp))
                                .background(SolidColor(Color(col)))
                                .border(
                                    if (sel) 2.5.dp else 1.dp,
                                    if (sel) Color.White else c.stroke,
                                    RoundedCornerShape(9.dp)
                                )
                                .airTarget(reg, "col_$i") { color = col }
                                .pressClick(scaleTo = 0.9f) { color = col }
                        )
                    }
                }
                Spacer(Modifier.height(8.dp))
                Row(
                    Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceEvenly,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    DrawBtn("Undo", IconKind.REPLAY, reg, "undo") {
                        if (!ink.undo()) toast = "Nothing to undo"
                    }
                    DrawBtn("Redo", IconKind.PLAY, reg, "redo") {
                        if (!ink.redo()) toast = "Nothing to redo"
                    }
                    DrawBtn("Size", IconKind.BOLT, reg, "size") {
                        sizeIdx = (sizeIdx + 1) % 3
                        toast = "Brush size " + (sizeIdx + 1)
                    }
                    DrawBtn("Sample", IconKind.DRAW, reg, "sample") { panel = !panel }
                    DrawBtn("Paper", IconKind.SUN, reg, "paper") { night = !night }
                    DrawBtn("Save", IconKind.SHARE, reg, "save") {
                        toast = if (ink.export(ctx, paperArgb)) "Saved to Pictures/AirFlow" else "Could not save"
                    }
                    DrawBtn("Clear", IconKind.CHECK, reg, "clear") {
                        ink.clear()
                        layerVersion++
                        tracer?.reset()
                        progress = 0f
                        toast = "Canvas cleared"
                    }
                }
            }
        }

        // cursor layer: it sits above the toolbar too, so a fingertip can press buttons ----
        Box(Modifier.fillMaxSize().padding(top = 56.dp, bottom = 84.dp)) {
            Canvas(
                Modifier
                    .fillMaxSize()
                    .onGloballyPositioned { co ->
                        st.colX = co.positionInRoot().x
                        st.colY = co.positionInRoot().y
                        st.fieldW = co.size.width.toFloat()
                        st.fieldH = co.size.height.toFloat()
                    }
            ) {
                drawLive(st, c, clock.floatValue, brush, color)
            }
        }

        // sample outlines ------------------------------------------------------------------
        AnimatedVisibility(
            visible = panel,
            enter = fadeIn(tween(180)),
            exit = fadeOut(tween(160)),
            modifier = Modifier.align(Alignment.BottomCenter).padding(horizontal = 12.dp, vertical = 210.dp)
        ) {
            GlassCard(Modifier.fillMaxWidth(), reveal = false) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Sample outlines", style = MaterialTheme.typography.titleMedium, color = c.text)
                    Spacer(Modifier.weight(1f))
                    Text(
                        "Close", color = c.a2, fontSize = 12.sp, fontWeight = FontWeight.Bold,
                        modifier = Modifier.pressClick { panel = false }
                    )
                }
                Column(
                    Modifier.fillMaxWidth().heightIn(max = 230.dp).verticalScroll(rememberScrollState())
                ) {
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .pressClick(scaleTo = 0.98f) {
                                templateIdx = -1
                                panel = false
                            }
                            .padding(vertical = 8.dp, horizontal = 6.dp)
                    ) {
                        Text("Blank canvas", color = if (templateIdx < 0) c.a2 else c.text, fontWeight = FontWeight.Bold)
                    }
                    Outlines.all.chunked(3).forEach { rowItems ->
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            rowItems.forEach { t ->
                                val i = Outlines.all.indexOf(t)
                                val sel = i == templateIdx
                                Box(
                                    Modifier
                                        .weight(1f)
                                        .clip(RoundedCornerShape(14.dp))
                                        .background(if (sel) c.glassHi else Color.Transparent)
                                        .border(1.dp, if (sel) c.a2 else c.stroke, RoundedCornerShape(14.dp))
                                        .pressClick(scaleTo = 0.94f) {
                                            templateIdx = i
                                            panel = false
                                        }
                                        .padding(vertical = 9.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        t.name, color = if (sel) c.a2 else c.text,
                                        fontSize = 12.sp, fontWeight = FontWeight.SemiBold
                                    )
                                }
                            }
                            repeat(3 - rowItems.size) { Spacer(Modifier.weight(1f)) }
                        }
                        Spacer(Modifier.height(6.dp))
                    }
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Pen", color = c.dim, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.width(10.dp))
                    AirSwitch(checked = pinchMode, onChange = { pinchMode = it })
                    Spacer(Modifier.width(8.dp))
                    Text(
                        if (pinchMode) "Pinch to draw" else "Always drawing",
                        color = c.dim, fontSize = 11.sp
                    )
                }
            }
        }
    }
}

@Composable
private fun DrawBtn(label: String, icon: IconKind, reg: AirReg, id: String, onClick: () -> Unit) {
    val c = Air.c
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier
            .airTarget(reg, id, onClick)
            .pressClick(scaleTo = 0.9f) { onClick() }
            .padding(horizontal = 1.dp)
    ) {
        Box(
            Modifier
                .size(40.dp)
                .clip(CircleShape)
                .background(c.glass)
                .border(1.dp, c.stroke, CircleShape),
            contentAlignment = Alignment.Center
        ) { AirIcon(icon, c.text, Modifier.size(18.dp)) }
        Spacer(Modifier.height(2.dp))
        Text(label, color = c.dim, fontSize = 8.sp, fontWeight = FontWeight.Medium, maxLines = 1)
    }
}

@Composable
private fun CameraInset(frame: State<Bitmap?>, lms: State<List<PointF>?>, c: AirColors) {
    val bmp = frame.value
    if (bmp != null) {
        val img = remember(bmp) { bmp.asImageBitmap() }
        Image(img, null, Modifier.fillMaxSize(), contentScale = ContentScale.FillBounds)
    }
    val pts = lms.value
    Canvas(Modifier.fillMaxSize()) {
        if (pts == null || pts.size < 21) return@Canvas
        for ((a, b) in HAND_BONES) {
            val p1 = Offset(pts[a].x * size.width, pts[a].y * size.height)
            val p2 = Offset(pts[b].x * size.width, pts[b].y * size.height)
            drawLine(c.a2.copy(alpha = 0.22f), p1, p2, strokeWidth = 4f, cap = StrokeCap.Round)
            drawLine(Color.White.copy(alpha = 0.75f), p1, p2, strokeWidth = 1.4f, cap = StrokeCap.Round)
        }
        val tip = Offset(pts[TIP_INDEX].x * size.width, pts[TIP_INDEX].y * size.height)
        drawCircle(c.a3.copy(alpha = 0.35f), 7f, tip)
        drawCircle(c.a3, 3f, tip)
    }
}

// ---------------------------------------------------------------------------------------------
// Painting the canvas
// ---------------------------------------------------------------------------------------------

private fun paperDots(w: Int, h: Int): List<Offset> {
    if (w <= 0 || h <= 0) return emptyList()
    val out = ArrayList<Offset>(900)
    val step = 34f
    var y = step
    while (y < h) {
        var x = step
        while (x < w) {
            out.add(Offset(x, y))
            x += step
        }
        y += step
    }
    return out
}

private fun outlinePathOf(t: Template, w: Float, h: Float): Path {
    val path = Path()
    for (line in t.lines) {
        var i = 0
        while (i + 1 < line.size) {
            val x = line[i] * w
            val y = line[i + 1] * h
            if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
            i += 2
        }
    }
    return path
}

private fun DrawScope.drawPaper(night: Boolean, c: AirColors, grid: List<Offset>) {
    val w = size.width
    val h = size.height
    drawRect(if (night) Color(0xFF0A0D18) else Color(0xFFFDFCFF))
    if (night) {
        drawRect(
            BrushG.radialGradient(
                listOf(c.a1.copy(alpha = 0.10f), Color.Transparent),
                Offset(w * 0.2f, h * 0.15f), w * 0.9f
            )
        )
        drawRect(
            BrushG.radialGradient(
                listOf(c.a2.copy(alpha = 0.08f), Color.Transparent),
                Offset(w * 0.85f, h * 0.8f), w * 0.8f
            )
        )
    }
    if (grid.isNotEmpty()) {
        val dot = if (night) Color.White.copy(alpha = 0.05f) else Color(0xFF14172B).copy(alpha = 0.055f)
        drawPoints(grid, PointMode.Points, dot, strokeWidth = 2.2f, cap = StrokeCap.Round)
    }
}

private fun DrawScope.drawOutline(path: Path, c: AirColors, time: Float) {
    drawPath(
        path,
        c.a2.copy(alpha = 0.32f),
        style = Stroke(
            width = 2f,
            pathEffect = PathEffect.dashPathEffect(floatArrayOf(7f, 9f), -time * 26f)
        )
    )
}

private fun DrawScope.drawLive(st: DrawState, c: AirColors, time: Float, brush: Brush, color: Int) {
    for (s in st.sparks) {
        val a = (s.life / s.max).coerceIn(0f, 1f)
        drawCircle(Color(color).copy(alpha = a * 0.7f), 2.6f, Offset(s.x, s.y))
    }
    if (!st.visible) return
    val o = Offset(st.cursorX, st.cursorY)
    val pulse = 0.5f + 0.5f * sin(time * 4.4f)
    val col = if (brush == Brush.ERASER) Color(0xFFFF6B7A) else Color(color)

    if (!st.inCanvas) {
        // over the toolbar: a small pointer, no brush preview
        drawCircle(col.copy(alpha = 0.25f), 13f + 3f * pulse, o)
        drawCircle(Color.White.copy(alpha = 0.9f), 3.4f, o)
        return
    }

    // brush preview ring, so you see the width before you paint
    val r = st.width / 2f
    drawCircle(col.copy(alpha = 0.10f + 0.10f * pulse), r, o)
    drawCircle(col.copy(alpha = 0.55f), r, o, style = Stroke(1.5f))

    if (st.penDown) {
        drawCircle(col.copy(alpha = 0.10f), r + 10f + 6f * pulse, o)
        drawCircle(col.copy(alpha = 0.55f), r + 10f + 6f * pulse, o, style = Stroke(2f))
        drawCircle(Color.White.copy(alpha = 0.9f), 4.5f, o)
    } else {
        drawCircle(Color.White.copy(alpha = 0.85f), 3.2f, o)
        drawCircle(col.copy(alpha = 0.6f), 8f + 3f * pulse, o, style = Stroke(1.5f))
    }
}
