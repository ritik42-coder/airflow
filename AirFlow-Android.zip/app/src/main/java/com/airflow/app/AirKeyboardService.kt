package com.airflow.app

import android.inputmethodservice.InputMethodService
import android.os.Handler
import android.os.Looper
import android.view.View
import android.view.inputmethod.EditorInfo
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleOwner
import androidx.lifecycle.LifecycleRegistry

/**
 * The system keyboard. Once the user turns "Air Keyboard" on in Android settings, every text field
 * in every app gets the air keyboard: the camera runs inside the keyboard, the fingertip moves a
 * cursor over the keys and a pinch presses the one under it. Touch typing works at the same time.
 */
class AirKeyboardService : InputMethodService(), LifecycleOwner {

    private val registry = LifecycleRegistry(this)
    override val lifecycle: Lifecycle get() = registry

    private var keyboard: AirKeyboardView? = null
    private var controller: HandController? = null
    private val main = Handler(Looper.getMainLooper())

    private val sink = object : TypeSink {
        override fun text(s: String) {
            currentInputConnection?.commitText(s, 1)
        }

        override fun del() {
            val ic = currentInputConnection ?: return
            val selected = ic.getSelectedText(0)
            if (selected.isNullOrEmpty()) ic.deleteSurroundingText(1, 0) else ic.commitText("", 1)
        }

        override fun enter() {
            val ic = currentInputConnection ?: return
            val action = currentInputEditorInfo?.imeOptions?.and(EditorInfo.IME_MASK_ACTION) ?: EditorInfo.IME_ACTION_NONE
            if (action != EditorInfo.IME_ACTION_NONE && action != EditorInfo.IME_ACTION_UNSPECIFIED) {
                ic.performEditorAction(action)
            } else {
                ic.commitText("\n", 1)
            }
        }
    }

    override fun onCreate() {
        super.onCreate()
        registry.currentState = Lifecycle.State.CREATED
    }

    override fun onCreateInputView(): View {
        val v = keyboard ?: AirKeyboardView(this, sink).also { keyboard = it }
        return v
    }

    override fun onStartInputView(info: EditorInfo?, restarting: Boolean) {
        super.onStartInputView(info, restarting)
        registry.currentState = Lifecycle.State.RESUMED
        startCamera()
        updateCaps()
    }

    override fun onFinishInputView(finishingInput: Boolean) {
        super.onFinishInputView(finishingInput)
        stopCamera()
        registry.currentState = Lifecycle.State.CREATED
    }

    override fun onUpdateSelection(
        oldSelStart: Int, oldSelEnd: Int,
        newSelStart: Int, newSelEnd: Int,
        candidatesStart: Int, candidatesEnd: Int
    ) {
        super.onUpdateSelection(oldSelStart, oldSelEnd, newSelStart, newSelEnd, candidatesStart, candidatesEnd)
        updateCaps()
    }

    override fun onEvaluateFullscreenMode(): Boolean = false

    override fun onDestroy() {
        stopCamera()
        registry.currentState = Lifecycle.State.DESTROYED
        super.onDestroy()
    }

    // ------------------------------------------------------------------------------ camera

    private fun startCamera() {
        if (controller != null) return
        val c = HandController(this, this, needBitmap = true, maxHands = 2, minFps = 30) { r ->
            main.post {
                keyboard?.onFrame(r.bitmap)
                keyboard?.onHands(r.hands)
            }
        }
        c.start()
        controller = c
    }

    private fun stopCamera() {
        controller?.stop()
        controller = null
        keyboard?.onFrame(null)
        keyboard?.onHands(emptyList())
    }

    private fun updateCaps() {
        val caps = try {
            currentInputConnection?.getCursorCapsMode(EditorInfo.TYPE_TEXT_FLAG_CAP_SENTENCES) ?: 0
        } catch (e: Exception) {
            0
        }
        keyboard?.setAutoShift(caps != 0)
    }
}
