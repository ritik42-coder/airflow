package com.airflow.app

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.ScrollState
import androidx.compose.foundation.selection.toggleable
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.MutableFloatState
import androidx.compose.runtime.State
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshotFlow
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.CompositingStrategy
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathOperation
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.lerp as lerpColor
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.layout.positionInParent
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay

// ---------------------------------------------------------------------------------------------
// Scroll context: lets every card react to how far the screen has been scrolled
// ---------------------------------------------------------------------------------------------

/** Scroll position of the current screen, read by the live background for parallax. */
val LocalScroll = staticCompositionLocalOf<MutableFloatState?> { null }

class ScrollCtx(val state: ScrollState, val viewport: MutableFloatState)

val LocalScrollCtx = staticCompositionLocalOf<ScrollCtx?> { null }

class Stagger { var n = 0 }

val LocalStagger = staticCompositionLocalOf { Stagger() }

/** The scrolling page used by every screen. Cards glide, tilt and fade as they enter and leave. */
@Composable
fun AirScroll(
    modifier: Modifier = Modifier,
    top: Dp = 66.dp,
    bottom: Dp = 104.dp,
    content: @Composable ColumnScope.() -> Unit
) {
    val topInset = WindowInsets.statusBars.asPaddingValues().calculateTopPadding()
    val bottomInset = WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding()
    val st = rememberScrollState()
    val vp = remember { mutableFloatStateOf(1000f) }
    val stagger = remember { Stagger() }
    val ctx = remember(st) { ScrollCtx(st, vp) }
    val sink = LocalScroll.current
    LaunchedEffect(st, sink) {
        snapshotFlow { st.value }.collect { sink?.floatValue = it.toFloat() }
    }
    CompositionLocalProvider(LocalScrollCtx provides ctx, LocalStagger provides stagger) {
        Column(
            modifier
                .fillMaxSize()
                .onSizeChanged { vp.floatValue = it.height.toFloat() }
                .verticalScroll(st)
                .padding(start = 16.dp, end = 16.dp, top = top + topInset, bottom = bottom + bottomInset),
            verticalArrangement = Arrangement.spacedBy(16.dp),
            content = content
        )
    }
}

/**
 * Premium reveal: springs in once, then keeps animating with scroll (tilts up from below,
 * scales and fades slightly as it leaves the top).
 */
fun Modifier.airReveal(delayMs: Int): Modifier = composed {
    val sc = LocalScrollCtx.current
    var top by remember { mutableFloatStateOf(0f) }
    var hgt by remember { mutableFloatStateOf(1f) }
    val enter = remember { Animatable(0f) }
    LaunchedEffect(Unit) {
        delay(delayMs.toLong())
        enter.animateTo(1f, spring(dampingRatio = 0.82f, stiffness = Spring.StiffnessLow))
    }
    this
        .onGloballyPositioned {
            top = it.positionInParent().y
            hgt = it.size.height.toFloat()
        }
        .graphicsLayer {
            val e = enter.value
            var a = e.coerceIn(0f, 1f)
            var sc2 = 0.94f + 0.06f * e
            var ty = (1f - e) * 44.dp.toPx()
            var rx = 0f
            if (sc != null) {
                val vy = top - sc.state.value
                val vh = sc.viewport.floatValue
                val inP = smooth((vh - vy) / (vh * 0.34f))
                val outP = smooth((vy + hgt) / (vh * 0.28f))
                a *= (0.12f + 0.88f * inP) * (0.35f + 0.65f * outP)
                sc2 *= (0.90f + 0.10f * inP) * (0.95f + 0.05f * outP)
                ty += (1f - inP) * 34.dp.toPx()
                rx = (1f - inP) * -12f
            }
            alpha = a
            scaleX = sc2
            scaleY = sc2
            translationY = ty
            rotationX = rx
            cameraDistance = 14f * density
        }
}

// ---------------------------------------------------------------------------------------------
// Press feedback
// ---------------------------------------------------------------------------------------------

@Composable
fun Modifier.pressClick(enabled: Boolean = true, scaleTo: Float = 0.96f, onClick: () -> Unit): Modifier {
    val src = remember { MutableInteractionSource() }
    val pressed by src.collectIsPressedAsState()
    val s = animateFloatAsState(
        if (pressed) scaleTo else 1f,
        spring(dampingRatio = 0.55f, stiffness = 600f),
        label = "press"
    )
    return this
        .graphicsLayer {
            scaleX = s.value
            scaleY = s.value
        }
        .clickable(interactionSource = src, indication = null, enabled = enabled, onClick = onClick)
}

// ---------------------------------------------------------------------------------------------
// Glass surfaces
// ---------------------------------------------------------------------------------------------

@Composable
fun GlassCard(
    modifier: Modifier = Modifier,
    corner: Dp = 26.dp,
    reveal: Boolean = true,
    onClick: (() -> Unit)? = null,
    content: @Composable ColumnScope.() -> Unit
) {
    val c = Air.c
    val st = LocalStagger.current
    val idx = remember { st.n++ }
    val shape = RoundedCornerShape(corner)
    var m = modifier
    if (reveal) m = m.airReveal(minOf(idx, 7) * 70)
    if (onClick != null) m = m.pressClick(onClick = onClick)
    if (!c.dark) {
        m = m.shadow(
            elevation = 14.dp, shape = shape,
            ambientColor = c.shadow.copy(alpha = 0.16f), spotColor = c.shadow.copy(alpha = 0.30f)
        )
    }
    val hi = if (c.dark) 0.08f else 0.55f
    m = m
        .clip(shape)
        .background(c.glass)
        .drawBehind {
            drawRect(
                Brush.verticalGradient(
                    listOf(Color.White.copy(alpha = hi), Color.Transparent),
                    endY = size.height * 0.55f
                )
            )
        }
        .border(
            1.dp,
            Brush.linearGradient(
                listOf(c.stroke.copy(alpha = (c.stroke.alpha * 2.2f).coerceAtMost(1f)), c.stroke.copy(alpha = c.stroke.alpha * 0.3f))
            ),
            shape
        )
    Box(m) {
        Column(
            Modifier.padding(18.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
            content = content
        )
    }
}

@Composable
fun SectionCard(title: String? = null, content: @Composable ColumnScope.() -> Unit) {
    val c = Air.c
    GlassCard(Modifier.fillMaxWidth()) {
        if (title != null) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    Modifier.width(4.dp).height(18.dp).clip(RoundedCornerShape(2.dp))
                        .background(Brush.verticalGradient(listOf(c.a2, c.a1)))
                )
                Spacer(Modifier.width(10.dp))
                Text(title, style = MaterialTheme.typography.titleMedium, color = c.text)
            }
        }
        content()
    }
}

@Composable
fun SwitchRow(title: String, subtitle: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    val c = Air.c
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f).padding(end = 12.dp)) {
            Text(title, fontWeight = FontWeight.SemiBold, color = c.text)
            Text(subtitle, style = MaterialTheme.typography.bodySmall, color = c.dim)
        }
        AirSwitch(checked, onChange)
    }
}

@Composable
fun AirSwitch(checked: Boolean, onChange: (Boolean) -> Unit, enabled: Boolean = true) {
    val c = Air.c
    val pos = animateFloatAsState(if (checked) 1f else 0f, spring(dampingRatio = 0.6f, stiffness = 500f), label = "sw")
    val haptic = LocalHapticFeedback.current
    Canvas(
        Modifier
            .size(width = 56.dp, height = 32.dp)
            .alpha(if (enabled) 1f else 0.4f)
            .toggleable(
                value = checked, enabled = enabled, role = Role.Switch,
                onValueChange = {
                    haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                    onChange(it)
                }
            )
    ) {
        val r = size.height / 2f
        val on = pos.value.coerceIn(0f, 1f)
        drawRoundRect(
            Brush.horizontalGradient(listOf(lerpColor(c.glassHi, c.a1, on), lerpColor(c.glassHi, c.a2, on))),
            cornerRadius = CornerRadius(r, r)
        )
        drawRoundRect(c.stroke, cornerRadius = CornerRadius(r, r), style = Stroke(1.dp.toPx()))
        val cx = r + (size.width - 2f * r) * pos.value
        drawCircle(Color.White.copy(alpha = 0.28f * on), r * 1.05f, Offset(cx, r))
        drawCircle(Color.White, r * 0.72f, Offset(cx, r))
    }
}

@Composable
fun AirSlider(value: Float, onChange: (Float) -> Unit, range: ClosedFloatingPointRange<Float>, modifier: Modifier = Modifier) {
    val c = Air.c
    Slider(
        value = value, onValueChange = onChange, valueRange = range,
        modifier = modifier.fillMaxWidth(),
        colors = SliderDefaults.colors(
            thumbColor = c.a2, activeTrackColor = c.a1, inactiveTrackColor = c.glassHi
        )
    )
}

@Composable
fun AirButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    filled: Boolean = true,
    icon: IconKind? = null
) {
    val c = Air.c
    val haptic = LocalHapticFeedback.current
    val inf = rememberInfiniteTransition(label = "btn")
    val sheen = inf.animateFloat(0f, 1f, infiniteRepeatable(tween(2800, easing = LinearEasing)), label = "sheen")
    val shape = RoundedCornerShape(28.dp)
    Box(
        modifier
            .height(56.dp)
            .alpha(if (enabled) 1f else 0.45f)
            .pressClick(enabled = enabled) {
                haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                onClick()
            }
            .clip(shape)
            .drawBehind {
                if (filled) {
                    drawRect(Brush.horizontalGradient(listOf(c.a1, c.a2)))
                    val x = (sheen.value * 2.4f - 0.7f) * size.width
                    drawRect(
                        Brush.horizontalGradient(
                            listOf(Color.Transparent, Color.White.copy(alpha = 0.30f), Color.Transparent),
                            startX = x - size.width * 0.25f, endX = x + size.width * 0.25f
                        )
                    )
                } else {
                    drawRect(c.glass)
                }
            }
            .border(1.dp, if (filled) Color.White.copy(alpha = 0.25f) else c.stroke, shape),
        contentAlignment = Alignment.Center
    ) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            if (icon != null) AirIcon(icon, if (filled) Color.White else c.text, Modifier.size(20.dp))
            Text(
                text, color = if (filled) Color.White else c.text,
                fontWeight = FontWeight.Bold, fontSize = 15.sp, letterSpacing = 0.5.sp
            )
        }
    }
}

/** Text filled with a gradient, optionally with a travelling highlight. */
@Composable
fun GradientText(
    text: String,
    style: TextStyle,
    colors: List<Color>,
    modifier: Modifier = Modifier,
    shimmer: State<Float>? = null
) {
    Text(
        text, style = style.copy(color = Color.White),
        modifier = modifier
            .graphicsLayer { compositingStrategy = CompositingStrategy.Offscreen }
            .drawWithContent {
                drawContent()
                drawRect(Brush.horizontalGradient(colors, startX = 0f, endX = size.width), blendMode = BlendMode.SrcAtop)
                if (shimmer != null) {
                    val x = (shimmer.value * 1.8f - 0.4f) * size.width
                    drawRect(
                        Brush.horizontalGradient(
                            listOf(Color.Transparent, Color.White.copy(alpha = 0.85f), Color.Transparent),
                            startX = x - size.width * 0.18f, endX = x + size.width * 0.18f
                        ),
                        blendMode = BlendMode.SrcAtop
                    )
                }
            }
    )
}

@Composable
fun ScreenHeader(title: String, subtitle: String) {
    val c = Air.c
    val inf = rememberInfiniteTransition(label = "hdr")
    val sh = inf.animateFloat(0f, 1f, infiniteRepeatable(tween(4200, easing = LinearEasing)), label = "sh")
    Column(Modifier.padding(top = 6.dp).airReveal(0), verticalArrangement = Arrangement.spacedBy(4.dp)) {
        GradientText(title, MaterialTheme.typography.headlineLarge, listOf(c.text, c.a2, c.a1, c.a3), shimmer = sh)
        Text(subtitle, style = MaterialTheme.typography.bodyMedium, color = c.dim)
    }
}

@Composable
fun PulseDot(color: Color, active: Boolean, modifier: Modifier = Modifier) {
    val inf = rememberInfiniteTransition(label = "dot")
    val t = inf.animateFloat(0f, 1f, infiniteRepeatable(tween(1400, easing = LinearEasing)), label = "t")
    Canvas(modifier.size(14.dp)) {
        val r = size.minDimension / 2f
        if (active) {
            drawCircle(color.copy(alpha = (1f - t.value) * 0.5f), r * (0.5f + 0.5f * t.value), center)
        }
        drawCircle(if (active) color else color.copy(alpha = 0.35f), r * 0.45f, center)
    }
}

@Composable
fun Pill(text: String, color: Color, modifier: Modifier = Modifier) {
    val c = Air.c
    Box(
        modifier.clip(RoundedCornerShape(50)).background(color.copy(alpha = 0.16f))
            .border(1.dp, color.copy(alpha = 0.35f), RoundedCornerShape(50))
            .padding(horizontal = 12.dp, vertical = 5.dp)
    ) { Text(text, color = if (c.dark) color else color, fontSize = 12.sp, fontWeight = FontWeight.Bold) }
}

// ---------------------------------------------------------------------------------------------
// Icons drawn from paths (no icon libraries, crisp at any size, tintable and animatable)
// ---------------------------------------------------------------------------------------------

enum class IconKind { HOME, PLAY, SCAN, SLIDERS, SUN, MOON, CURSOR, CHECK, BOLT, REPLAY, SHARE, MUSIC }

@Composable
fun AirIcon(kind: IconKind, tint: Color, modifier: Modifier = Modifier) {
    Canvas(modifier) {
        val s = size.minDimension / 24f
        val st = Stroke(width = 2f * s, cap = StrokeCap.Round, join = StrokeJoin.Round)
        fun poly(fill: Boolean, vararg xy: Float) {
            val p = Path()
            var i = 0
            while (i < xy.size) {
                if (i == 0) p.moveTo(xy[0] * s, xy[1] * s) else p.lineTo(xy[i] * s, xy[i + 1] * s)
                i += 2
            }
            if (fill) {
                p.close()
                drawPath(p, tint)
            } else {
                drawPath(p, tint, style = st)
            }
        }
        when (kind) {
            IconKind.HOME -> {
                poly(false, 3f, 11f, 12f, 3.2f, 21f, 11f)
                poly(false, 5.5f, 9.5f, 5.5f, 20f, 10f, 20f, 10f, 14f, 14f, 14f, 14f, 20f, 18.5f, 20f, 18.5f, 9.5f)
            }
            IconKind.PLAY -> {
                drawCircle(tint, 9.2f * s, Offset(12f * s, 12f * s), style = st)
                poly(true, 10.2f, 8.2f, 16f, 12f, 10.2f, 15.8f)
            }
            IconKind.SCAN -> {
                poly(false, 4f, 9f, 4f, 5f, 8f, 5f)
                poly(false, 16f, 5f, 20f, 5f, 20f, 9f)
                poly(false, 20f, 15f, 20f, 19f, 16f, 19f)
                poly(false, 8f, 19f, 4f, 19f, 4f, 15f)
                drawCircle(tint, 2.7f * s, Offset(12f * s, 12f * s))
                drawCircle(tint.copy(alpha = 0.5f), 5.4f * s, Offset(12f * s, 12f * s), style = Stroke(1.4f * s))
            }
            IconKind.SLIDERS -> {
                drawLine(tint, Offset(4f * s, 7f * s), Offset(20f * s, 7f * s), 2f * s, StrokeCap.Round)
                drawLine(tint, Offset(4f * s, 12f * s), Offset(20f * s, 12f * s), 2f * s, StrokeCap.Round)
                drawLine(tint, Offset(4f * s, 17f * s), Offset(20f * s, 17f * s), 2f * s, StrokeCap.Round)
                drawCircle(tint, 2.8f * s, Offset(9f * s, 7f * s))
                drawCircle(tint, 2.8f * s, Offset(16f * s, 12f * s))
                drawCircle(tint, 2.8f * s, Offset(8f * s, 17f * s))
            }
            IconKind.SUN -> {
                drawCircle(tint, 4.2f * s, Offset(12f * s, 12f * s))
                for (k in 0 until 8) {
                    val a = Math.toRadians(k * 45.0)
                    val dx = Math.cos(a).toFloat()
                    val dy = Math.sin(a).toFloat()
                    drawLine(
                        tint,
                        Offset((12f + dx * 7.2f) * s, (12f + dy * 7.2f) * s),
                        Offset((12f + dx * 9.6f) * s, (12f + dy * 9.6f) * s),
                        2f * s, StrokeCap.Round
                    )
                }
            }
            IconKind.MOON -> {
                val a = Path().apply { addOval(Rect(Offset(12f * s, 12f * s), 8.5f * s)) }
                val b = Path().apply { addOval(Rect(Offset(17f * s, 8f * s), 7.2f * s)) }
                drawPath(Path.combine(PathOperation.Difference, a, b), tint)
            }
            IconKind.CURSOR -> poly(true, 6f, 3f, 6f, 18f, 10f, 14.2f, 13f, 20.5f, 15.6f, 19.3f, 12.7f, 13f, 17.5f, 12.7f)
            IconKind.CHECK -> {
                val p = Path().apply {
                    moveTo(5f * s, 12.5f * s); lineTo(10f * s, 17.5f * s); lineTo(19f * s, 7f * s)
                }
                drawPath(p, tint, style = Stroke(2.6f * s, cap = StrokeCap.Round, join = StrokeJoin.Round))
            }
            IconKind.BOLT -> poly(true, 13f, 2f, 5f, 13.5f, 11f, 13.5f, 10f, 22f, 19f, 10f, 13f, 10f)
            IconKind.SHARE -> {
                drawLine(tint, Offset(12f * s, 15f * s), Offset(12f * s, 4f * s), 2f * s, StrokeCap.Round)
                poly(false, 7.5f, 8.5f, 12f, 4f, 16.5f, 8.5f)
                poly(false, 5f, 13f, 5f, 20f, 19f, 20f, 19f, 13f)
            }
            IconKind.MUSIC -> {
                drawCircle(tint, 3.1f * s, Offset(7.4f * s, 17.6f * s))
                drawCircle(tint, 3.1f * s, Offset(17.2f * s, 15.8f * s))
                drawLine(tint, Offset(10.2f * s, 17.6f * s), Offset(10.2f * s, 6.4f * s), 2.1f * s, StrokeCap.Round)
                drawLine(tint, Offset(20f * s, 15.8f * s), Offset(20f * s, 4.6f * s), 2.1f * s, StrokeCap.Round)
                drawLine(tint, Offset(10.2f * s, 6.4f * s), Offset(20f * s, 4.6f * s), 2.1f * s, StrokeCap.Round)
            }
            IconKind.REPLAY -> {
                drawArc(tint, -50f, 280f, false, Offset(4.5f * s, 4.5f * s), Size(15f * s, 15f * s), style = st)
                poly(true, 15f, 2.5f, 20.5f, 3.5f, 17f, 8.5f)
            }
        }
    }
}

// ---------------------------------------------------------------------------------------------
// The logo: a gradient badge with a glowing hand, an air swoosh and an orbiting signal
// The same geometry is used by res/drawable/ic_launcher_foreground.xml (108 x 108 units)
// ---------------------------------------------------------------------------------------------

fun DrawScope.drawAirMark(origin: Offset, box: Float, ink: Color, accent: Color, alpha: Float = 1f) {
    val s = box / 108f
    fun px(x: Float) = origin.x + x * s
    fun py(y: Float) = origin.y + y * s
    val w = 7f * s
    val fingers = arrayOf(
        floatArrayOf(45f, 68f, 35f, 56f),
        floatArrayOf(49f, 60f, 46f, 38f),
        floatArrayOf(54f, 58f, 54f, 32f),
        floatArrayOf(59f, 60f, 62f, 36f),
        floatArrayOf(64f, 63f, 71f, 44f)
    )
    for (f in fingers) {
        drawLine(ink.copy(alpha = alpha), Offset(px(f[0]), py(f[1])), Offset(px(f[2]), py(f[3])), strokeWidth = w, cap = StrokeCap.Round)
    }
    val palm = Path().apply {
        moveTo(px(44f), py(64f))
        cubicTo(px(44f), py(58f), px(64f), py(58f), px(66f), py(63f))
        cubicTo(px(68f), py(72f), px(62f), py(80f), px(54f), py(80f))
        cubicTo(px(46f), py(80f), px(42f), py(72f), px(44f), py(64f))
        close()
    }
    drawPath(palm, ink.copy(alpha = alpha))
    val sw = Path().apply {
        moveTo(px(30f), py(84f))
        cubicTo(px(42f), py(92f), px(66f), py(92f), px(78f), py(82f))
    }
    drawPath(sw, accent.copy(alpha = 0.9f * alpha), style = Stroke(3f * s, cap = StrokeCap.Round))
    drawCircle(accent.copy(alpha = 0.35f * alpha), 6.5f * s, Offset(px(54f), py(22.5f)))
    drawCircle(accent.copy(alpha = alpha), 3.4f * s, Offset(px(54f), py(22.5f)))
}

fun DrawScope.drawLogoBadge(
    center: Offset, size: Float, spin: Float,
    c1: Color, c2: Color, c3: Color,
    glow: Float = 1f, markAlpha: Float = 1f
) {
    val tl = Offset(center.x - size / 2f, center.y - size / 2f)
    val r = size * 0.30f
    drawCircle(
        Brush.radialGradient(listOf(c2.copy(alpha = 0.45f * glow), Color.Transparent), center, size * 0.95f),
        size * 0.95f, center
    )
    drawRoundRect(
        Brush.linearGradient(listOf(c1, c2), start = tl, end = Offset(tl.x + size, tl.y + size)),
        tl, Size(size, size), CornerRadius(r, r)
    )
    drawRoundRect(
        Brush.verticalGradient(listOf(Color.White.copy(alpha = 0.30f), Color.Transparent), startY = tl.y, endY = tl.y + size * 0.55f),
        tl, Size(size, size), CornerRadius(r, r)
    )
    drawRoundRect(Color.White.copy(alpha = 0.35f), tl, Size(size, size), CornerRadius(r, r), style = Stroke(size * 0.012f))
    val box = size
    drawAirMark(Offset(center.x - box / 2f, center.y - box / 2f - size * 0.03f), box, Color.White, Color(0xFFC9FBFF), markAlpha)
    rotate(spin, center) {
        val rr = size * 0.64f
        drawArc(
            c3.copy(alpha = 0.95f), -25f, 55f, false,
            Offset(center.x - rr, center.y - rr), Size(rr * 2f, rr * 2f),
            style = Stroke(size * 0.03f, cap = StrokeCap.Round)
        )
        drawCircle(Color.White, size * 0.035f, Offset(center.x + rr, center.y))
        drawArc(
            c2.copy(alpha = 0.6f), 150f, 40f, false,
            Offset(center.x - rr, center.y - rr), Size(rr * 2f, rr * 2f),
            style = Stroke(size * 0.02f, cap = StrokeCap.Round)
        )
    }
}

@Composable
fun AirLogo(size: Dp, modifier: Modifier = Modifier) {
    val c = Air.c
    val inf = rememberInfiniteTransition(label = "logo")
    val spin = inf.animateFloat(0f, 360f, infiniteRepeatable(tween(7000, easing = LinearEasing)), label = "spin")
    val glow = inf.animateFloat(
        0.6f, 1f, infiniteRepeatable(tween(2400, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "glow"
    )
    Canvas(modifier.size(size * 1.7f)) {
        val badge = this.size.minDimension / 1.7f
        drawLogoBadge(center, badge, spin.value, c.a1, c.a2, c.a3, glow.value)
    }
}
