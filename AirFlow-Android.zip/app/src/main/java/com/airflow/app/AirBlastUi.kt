package com.airflow.app

import android.content.ClipboardManager
import android.content.Context
import android.net.Uri
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/** Air Blast: send to the whole room, or listen for a blast. Shown inside the Air Share "Anywhere" tab. */
@Composable
fun AirBlastCard() {
    val ctx = LocalContext.current
    val c = Air.c
    val shareOn by AirShareHub.active.collectAsState()
    val members by AirShareHub.blastMembers.collectAsState()
    val prompt by AirShareHub.blastPrompt.collectAsState()
    val inRoom by AirShareHub.blastInRoom.collectAsState()
    val bStatus by AirShareHub.blastStatus.collectAsState()
    var listening by remember { mutableStateOf(Prefs.blastReceive) }
    var code by remember { mutableStateOf(Prefs.blastCode) }
    var msg by remember { mutableStateOf("") }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris: List<Uri> ->
        if (uris.isEmpty()) return@rememberLauncherForActivityResult
        val app = ctx.applicationContext
        msg = "Getting your files ready..."
        Thread {
            val files = ArrayList<QueuedFile>()
            for (u in uris.take(10)) {
                val info = TapFiles.describe(app, u)
                val f = TapFiles.materialise(app, info) ?: continue
                files.add(QueuedFile(f, info.name, info.mime.startsWith("image/") || FileStore.isImage(info.name)))
            }
            android.os.Handler(android.os.Looper.getMainLooper()).post {
                if (files.isEmpty()) msg = "Could not read that file."
                else { AirShareHub.armBlast(app, files); msg = "Armed. Flick your open hand upward, or palm, fist, open." }
            }
        }.start()
    }

    SectionCard("Air Blast: one flick to the whole room") {
        Text(
            "Send a photo, PDF or link to every nearby phone at once (the room holds up to ${BlastLink.MAX_ROOM}). Each phone is asked first and " +
                "only gets it after its owner taps Accept, then plays the receive animation. Both phones need Air Share or Tap Share ON; " +
                "the sender needs Air Share (hand + touch). While a blast room is open, Tap Share (touch) pauses.",
            style = MaterialTheme.typography.bodySmall, color = c.dim
        )

        Text("SEND TO THE ROOM", color = c.a2, fontWeight = FontWeight.Black, fontSize = 11.sp, letterSpacing = 2.sp)
        Text(
            if (members == 0) "No phones in the room yet. Students turn on 'Receive blasts' below." else "$members phone${if (members == 1) "" else "s"} in the room",
            style = MaterialTheme.typography.bodySmall, color = if (members > 0) c.ok else c.dim
        )
        AirButton(
            "Pick files to blast",
            { if (!shareOn) msg = "Turn on Air Share (hand + touch) first." else picker.launch(arrayOf("*/*")) },
            Modifier.fillMaxWidth(), icon = IconKind.BOLT
        )
        AirButton(
            "Blast the link I copied",
            {
                if (!shareOn) { msg = "Turn on Air Share (hand + touch) first." } else {
                    val text = try {
                        val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                        cm.primaryClip?.takeIf { it.itemCount > 0 }?.getItemAt(0)?.coerceToText(ctx)?.toString()
                    } catch (e: Exception) { null }
                    val item = QuickParser.parse(text)
                    if (item == null) msg = "The clipboard is empty. Copy a link first."
                    else { AirShareHub.armBlast(ctx.applicationContext, emptyList(), item); msg = "Armed. Flick your open hand upward, or palm, fist, open." }
                }
            },
            Modifier.fillMaxWidth(), filled = false, icon = IconKind.SHARE
        )
        AirButton("Close the room", { AirShareHub.closeBlast(); msg = "Room closed." }, Modifier.fillMaxWidth(), filled = false)
        if (msg.isNotEmpty()) Text(msg, style = MaterialTheme.typography.bodySmall, color = c.a2)

        Text("RECEIVE A BLAST", color = c.a2, fontWeight = FontWeight.Black, fontSize = 11.sp, letterSpacing = 2.sp)
        AirButton(
            if (listening) "Receive blasts: ON" else "Receive blasts: OFF",
            {
                listening = !listening
                AirShareHub.setBlastReceive(listening)
                if (listening && !shareOn) msg = "Also turn on Air Share or Tap Share above so this phone can listen."
            },
            Modifier.fillMaxWidth(), filled = listening
        )
        if (listening) {
            Text(
                if (inRoom) bStatus.ifEmpty { "In a room" } else bStatus.ifEmpty { "Turn on Air Share or Tap Share to start listening." },
                style = MaterialTheme.typography.bodySmall, color = if (inRoom) c.ok else c.dim
            )
        }
        val p = prompt
        if (p != null) {
            Text(
                "${p.host} wants to send you " + (if (p.kind == "qd") "a link or text" else if (p.count > 1) "${p.count} files" else "a file") + ": " + p.title,
                color = c.text, fontSize = 13.sp
            )
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                AirButton("Accept", { AirShareHub.answerBlast(p.id, true) }, Modifier.weight(1f), icon = IconKind.CHECK)
                AirButton("Decline", { AirShareHub.answerBlast(p.id, false) }, Modifier.weight(1f), filled = false)
            }
        }
        OutlinedTextField(
            value = code,
            onValueChange = { v -> code = v.filter { it.isLetterOrDigit() }.take(8); AirShareHub.setBlastCode(code) },
            label = { Text("Class code (same on every phone, empty = open room)") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )
        Text(
            "Offers also appear as a notification with Accept and Decline. If notifications are off, accept here. " +
                "How many phones really work at once depends on the phones and their radios; test with your class size first.",
            style = MaterialTheme.typography.bodySmall, color = c.dim
        )
    }
}

/** Air Grab: a held fist over any app captures the screen and puts it in your hand. */
@Composable
fun AirGrabCard() {
    val ctx = LocalContext.current
    val c = Air.c
    val shareOn by AirShareHub.active.collectAsState()
    var on by remember { mutableStateOf(Prefs.airGrab) }
    var mode by remember { mutableStateOf(Prefs.grabMode) }
    val accOn = AirFlowAccessibilityService.instance != null

    SectionCard("Air Grab: pick up your screen") {
        Text(
            "With Air Share (hand + touch) on, make a fist over any app and hold it still for half a second. Air Flow captures what is on screen " +
                "(a screenshot, or the text you are reading) and it becomes the glowing orb in your hand. Open your hand toward the other phone " +
                "and it lands there as a picture or as a text card.",
            style = MaterialTheme.typography.bodySmall, color = c.dim
        )
        AirButton(
            if (on) "Air Grab: ON" else "Air Grab: OFF",
            { on = !on; Prefs.airGrab = on },
            Modifier.fillMaxWidth(), filled = on, icon = IconKind.BOLT
        )
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            AirButton("Screenshot", { mode = "shot"; Prefs.grabMode = "shot" }, Modifier.weight(1f), filled = mode == "shot")
            AirButton("Text on screen", { mode = "text"; Prefs.grabMode = "text" }, Modifier.weight(1f), filled = mode == "text")
        }
        if (!accOn) {
            Text("Needs the Air Flow Accessibility service (Home tab). After updating the app, switch it off and on once so Android grants screenshots.",
                style = MaterialTheme.typography.bodySmall, color = c.a2)
        }
        if (Build.VERSION.SDK_INT < 30 && mode == "shot") {
            Text("Screenshots need Android 11 or newer on this phone. Use Text on screen.", style = MaterialTheme.typography.bodySmall, color = c.a2)
        }
        if (!shareOn) {
            Text("Turn on Air Share (hand + touch) above for the fist to be watched.", style = MaterialTheme.typography.bodySmall, color = c.dim)
        }
        Text(
            "While Air Grab is on, a still fist grabs instead of pressing Back (fist swipes still work). Banking and other protected screens block " +
                "screenshots, and password fields are never read in Text mode. The other phone needs Air Share or Tap Share ON.",
            style = MaterialTheme.typography.bodySmall, color = c.dim
        )
    }
}
