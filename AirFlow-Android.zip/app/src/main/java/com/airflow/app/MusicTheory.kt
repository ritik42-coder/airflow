package com.airflow.app

import kotlin.math.abs

// ---------------------------------------------------------------------------------------------
// Notes
// ---------------------------------------------------------------------------------------------

val NOTE_NAMES = arrayOf("C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B")

private val WHITE_PC = booleanArrayOf(
    true, false, true, false, true, true, false, true, false, true, false, true
)

/** "C4", "F#5" ... */
fun noteName(midi: Int): String {
    val pc = ((midi % 12) + 12) % 12
    return NOTE_NAMES[pc] + (midi / 12 - 1)
}

fun isWhiteNote(midi: Int): Boolean = WHITE_PC[((midi % 12) + 12) % 12]

/**
 * The keyboard drawn at the bottom of the screen and used for hit testing.
 * x is always normalised: 0 at the left edge, 1 at the right edge of the keys.
 */
class Keys(val startMidi: Int, val whiteCount: Int) {

    val whites = IntArray(whiteCount)

    /** midi of the black key just after white key i, or -1 when there is none. */
    val blacks = IntArray(whiteCount) { -1 }

    val step = 1f / whiteCount
    val blackW = step * 0.52f

    init {
        var m = startMidi
        var i = 0
        while (i < whiteCount && m < 128) {
            if (isWhiteNote(m)) {
                whites[i] = m
                i++
            } else if (i > 0) {
                blacks[i - 1] = m
            }
            m++
        }
        // never leave a zero at the end (a range that starts on a black note)
        for (k in 0 until whiteCount) if (whites[k] == 0) whites[k] = startMidi + k
    }

    /** Key under [x]. Black keys win, exactly like a real keyboard. */
    fun keyAt(x: Float): Int {
        val xc = if (x < 0f) 0f else if (x > 0.9999f) 0.9999f else x
        val half = blackW / 2f
        for (i in 0 until whiteCount - 1) {
            val b = blacks[i]
            if (b < 0) continue
            if (abs(xc - (i + 1) * step) <= half) return b
        }
        val idx = (xc / step).toInt()
        return whites[if (idx < 0) 0 else if (idx >= whiteCount) whiteCount - 1 else idx]
    }

    /** Centre of a key in normalised x, or -1 when the key is not on this keyboard. */
    fun centerX(midi: Int): Float {
        for (i in 0 until whiteCount) {
            if (whites[i] == midi) return (i + 0.5f) * step
            if (blacks[i] == midi) return (i + 1) * step
        }
        return -1f
    }

    fun contains(midi: Int): Boolean = centerX(midi) >= 0f
}

// ---------------------------------------------------------------------------------------------
// Demo songs (traditional / public domain, plus one written for this app)
// ---------------------------------------------------------------------------------------------

/** hand 1 = right hand (melody), hand 0 = left hand (bass). */
class SongNote(val midi: Int, val start: Float, val len: Float, val hand: Int)

class Song(val title: String, val about: String, val tempo: Float, notes: List<SongNote>) {
    val notes: List<SongNote> = notes.sortedBy { it.start }
    val lengthBeats: Float = if (this.notes.isEmpty()) 1f else this.notes.maxOf { it.start + it.len }
    val melody: List<SongNote> = this.notes.filter { it.hand == 1 }
}

private class Builder(private val hand: Int) {
    val out = ArrayList<SongNote>()

    fun n(midi: Int, start: Float, len: Float) {
        out.add(SongNote(midi, start, len, hand))
    }

    /** Writes a run of notes, one every [step] beats. 0 = rest. Returns the next free beat. */
    fun run(start: Float, step: Float, vararg midis: Int): Float {
        var t = start
        for (m in midis) {
            if (m > 0) out.add(SongNote(m, t, step * 0.92f, hand))
            t += step
        }
        return t
    }

    /** Root notes on the beat, one per [every] beats, [len] beats long. */
    fun bass(start: Float, every: Float, len: Float, vararg midis: Int) {
        var t = start
        for (m in midis) {
            if (m > 0) out.add(SongNote(m, t, len, hand))
            t += every
        }
    }
}

private fun melody(block: Builder.() -> Unit): List<SongNote> {
    val b = Builder(1)
    b.block()
    return b.out
}

private fun bassLine(block: Builder.() -> Unit): List<SongNote> {
    val b = Builder(0)
    b.block()
    return b.out
}

object Songs {

    private fun furElise(): Song {
        val m = melody {
            run(0f, 0.5f, 76, 75, 76, 75, 76, 71, 74, 72)
            n(69, 4f, 1.6f)
            run(5.5f, 0.5f, 60, 64, 69, 71)
            n(76, 8.5f, 0.5f)
            n(75, 9f, 0.5f)
            n(76, 9.5f, 0.5f)
            n(75, 10f, 0.5f)
            n(76, 10.5f, 0.5f)
            n(71, 11f, 0.5f)
            n(74, 11.5f, 0.5f)
            n(72, 12f, 0.5f)
            n(69, 12.5f, 1.8f)
            run(14.5f, 0.5f, 60, 64, 69, 71)
            n(76, 17.5f, 0.5f)
            n(75, 18f, 0.5f)
            n(76, 18.5f, 0.5f)
            n(75, 19f, 0.5f)
            n(76, 19.5f, 0.5f)
            n(71, 20f, 0.5f)
            n(74, 20.5f, 0.5f)
            n(72, 21f, 0.5f)
            n(69, 21.5f, 2f)
        }
        val b = bassLine {
            n(45, 4f, 2.6f)
            n(40, 8.5f, 2.6f)
            n(45, 12.5f, 2.6f)
            n(40, 17.5f, 2.6f)
            n(45, 21.5f, 2.2f)
        }
        return Song("Für Elise", "Beethoven · the famous opening", 104f, m + b)
    }

    private fun odeToJoy(): Song {
        val m = melody {
            run(0f, 1f, 64, 64, 65, 67, 67, 65, 64, 62)
            run(8f, 1f, 60, 60, 62, 64, 64, 62, 62)
            n(64, 15f, 1f)
            n(64, 16f, 1f)
            n(65, 17f, 1f)
            n(67, 18f, 1f)
            run(19f, 1f, 67, 65, 64, 62)
            run(23f, 1f, 60, 60, 62, 64, 62, 60, 60)
        }
        val b = bassLine {
            bass(0f, 2f, 1.7f, 48, 43, 48, 43, 48, 43, 48, 43, 48, 43, 48, 43, 48, 43)
        }
        return Song("Ode to Joy", "Beethoven · Symphony No. 9", 112f, m + b)
    }

    private fun twinkle(): Song {
        val m = melody {
            run(0f, 1f, 60, 60, 67, 67, 69, 69)
            n(67, 6f, 2f)
            run(8f, 1f, 65, 65, 64, 64, 62, 62)
            n(60, 14f, 2f)
            run(16f, 1f, 67, 67, 65, 65, 64, 64)
            n(62, 22f, 2f)
            run(24f, 1f, 67, 67, 65, 65, 64, 64)
            n(62, 30f, 2f)
            run(32f, 1f, 60, 60, 67, 67, 69, 69)
            n(67, 38f, 2f)
            run(40f, 1f, 65, 65, 64, 64, 62, 62)
            n(60, 46f, 2f)
        }
        val b = bassLine {
            bass(0f, 4f, 3.4f, 48, 48, 41, 48, 48, 41, 48, 48, 41, 48, 48, 41)
        }
        return Song("Twinkle Twinkle", "the first tune everyone learns", 118f, m + b)
    }

    private fun jingleBells(): Song {
        val m = melody {
            run(0f, 0.5f, 64, 64, 64)
            n(64, 1.5f, 1f)
            run(2.5f, 0.5f, 64, 64, 64)
            n(64, 3.5f, 1f)
            run(4.5f, 0.5f, 64, 67, 60)
            n(62, 6f, 0.9f)
            n(64, 7f, 1.9f)
            run(9f, 0.5f, 65, 65, 65, 65, 65, 64, 64, 64, 64, 62, 62, 64)
            n(62, 15f, 1f)
            n(67, 16f, 2f)
        }
        val b = bassLine {
            bass(0f, 2f, 1.7f, 48, 43, 48, 43, 48, 43, 43, 48, 43)
        }
        return Song("Jingle Bells", "the sleigh tune, two hands", 132f, m + b)
    }

    private fun sargam(): Song {
        val m = melody {
            run(0f, 0.5f, 60, 62, 64, 65, 67, 69, 71, 72)
            run(4f, 0.5f, 72, 71, 69, 67, 65, 64, 62, 60)
            run(8f, 0.5f, 60, 64, 67, 72, 67, 64, 60)
            run(11.5f, 0.5f, 62, 65, 69, 74, 69, 65, 62)
        }
        val b = bassLine {
            bass(0f, 4f, 3.6f, 48, 43, 45, 41)
        }
        return Song("Sargam", "Sa Re Ga Ma · C major up and down", 100f, m + b)
    }

    private fun airFlowTheme(): Song {
        val m = melody {
            n(76, 0f, 1f)
            n(74, 1f, 0.5f)
            n(72, 1.5f, 0.5f)
            n(69, 2f, 1f)
            n(72, 3f, 1f)
            n(74, 4f, 1f)
            n(72, 5f, 0.5f)
            n(71, 5.5f, 0.5f)
            n(67, 6f, 2f)
            n(72, 8f, 1f)
            n(76, 9f, 1f)
            n(79, 10f, 2f)
            n(77, 12f, 1f)
            n(76, 13f, 0.5f)
            n(74, 13.5f, 0.5f)
            n(72, 14f, 2f)
        }
        val b = bassLine {
            n(45, 0f, 3.8f)
            n(41, 4f, 3.8f)
            n(48, 8f, 3.8f)
            n(43, 12f, 3.8f)
        }
        return Song("Air Flow", "the theme of this app, written for two hands", 96f, m + b)
    }

    val all: List<Song> = listOf(
        airFlowTheme(), furElise(), odeToJoy(), twinkle(), jingleBells(), sargam()
    )
}
