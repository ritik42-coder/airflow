package com.airflow.app

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.PointF
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.os.Build
import android.os.SystemClock
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import kotlin.math.exp
import kotlin.math.max
import kotlin.math.min

/**
 * A "dynamic island" for Air Flow: a small black pill at the top of the screen, over whatever app is open,
 * that lives on what the camera sees. It tucks into a dot, swells when a hand appears (hand emoji, pose name,
 * a ring that fills while you hold the pose, and a live mini skeleton of your hand), and pops open with
 * the gesture name and what it did when a gesture fires. It bounces like a spring, so it feels alive.
 */
class GestureIslandView(ctx: Context) : View(ctx) {

    private val d = resources.displayMetrics.density

    // ---- live data ------------------------------------------------------------------------
    private var handSeen = false
    private var pose = GestureEngine.Pose.NONE
    private var hold = 0f
    private var lm: List<PointF>? = null
    private var hint: String? = null
    private var lastHandAt = 0L
    private var lastSeenPose = GestureEngine.Pose.NONE

    private var firedAt = 0L
    private var firedEmoji = ""
    private var firedTitle = ""
    private var firedSub = ""

    // ---- spring state ---------------------------------------------------------------------
    private var w = 0f
    private var h = 0f
    private var vw = 0f
    private var vh = 0f
    private var vis = 0f
    private var lastT = 0L
    private var ring = 0f

    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.BLACK; style = Paint.Style.FILL }
    private val rim = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 1f * d }
    private val glow = Paint(Paint.ANTI_ALIAS_FLAG)
    private val txt = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE; typeface = Typeface.DEFAULT_BOLD }
    private val sub = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#B8C0D4") }
    private val emoji = Paint(Paint.ANTI_ALIAS_FLAG).apply { textAlign = Paint.Align.CENTER }
    private val arcP = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND }
    private val dot = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND }
    private val rect = RectF()
    private val arc = RectF()

    private val sbHeight: Float = run {
        val id = resources.getIdentifier("status_bar_height", "dimen", "android")
        if (id > 0) resources.getDimension(id) else 24f * d
    }

    fun feed(r: FrameResult, airHint: String?) {
        val seen = r.landmarks != null
        handSeen = seen
        pose = r.pose
        hold = r.hold
        lm = r.landmarks
        hint = airHint
        if (seen) {
            lastHandAt = SystemClock.uptimeMillis()
            if (r.pose != GestureEngine.Pose.NONE) lastSeenPose = r.pose
        }
        postInvalidateOnAnimation()
    }

    fun fired(g: Gesture, actionLabel: String) {
        firedAt = SystemClock.uptimeMillis()
        firedEmoji = g.emoji
        firedTitle = g.title
        firedSub = actionLabel
        ring = 0f
        postInvalidateOnAnimation()
    }

    private fun poseEmoji(p: GestureEngine.Pose): String = when (p) {
        GestureEngine.Pose.OPEN -> "🖐️"
        GestureEngine.Pose.FIST -> "✊"
        GestureEngine.Pose.PINCH -> "🤏"
        GestureEngine.Pose.THUMB_UP -> "👍"
        GestureEngine.Pose.THUMB_DOWN -> "👎"
        GestureEngine.Pose.PEACE -> "✌️"
        GestureEngine.Pose.POINT -> "☝️"
        GestureEngine.Pose.THREE -> "3️⃣"
        GestureEngine.Pose.ROCK -> "🤘"
        GestureEngine.Pose.CALL -> "🤙"
        else -> "✋"
    }

    private fun poseName(p: GestureEngine.Pose): String = when (p) {
        GestureEngine.Pose.OPEN -> "Open palm"
        GestureEngine.Pose.FIST -> "Fist"
        GestureEngine.Pose.PINCH -> "Pinch"
        GestureEngine.Pose.THUMB_UP -> "Thumb up"
        GestureEngine.Pose.THUMB_DOWN -> "Thumb down"
        GestureEngine.Pose.PEACE -> "Peace"
        GestureEngine.Pose.POINT -> "Point"
        GestureEngine.Pose.THREE -> "Three fingers"
        GestureEngine.Pose.ROCK -> "Rock"
        GestureEngine.Pose.CALL -> "Call me"
        GestureEngine.Pose.NONE -> "Looking..."
        else -> "Hand"
    }

    private fun fitText(p: Paint, s: String, maxW: Float, size: Float) {
        p.textSize = size
        while (p.measureText(s) > maxW && p.textSize > 8f * d) p.textSize -= 0.5f * d
    }

    override fun onDraw(c: Canvas) {
        super.onDraw(c)
        val t = SystemClock.uptimeMillis()
        val dt = ((t - lastT).coerceIn(1L, 40L)) / 1000f
        lastT = t
        val W = width.toFloat()
        if (W < 10f) { postInvalidateOnAnimation(); return }

        val sinceFire = t - firedAt
        val showFired = firedAt != 0L && sinceFire < 1250L
        val handRecent = handSeen || t - lastHandAt < 700L
        val hinted = hint != null
        val active = showFired || handRecent || hinted

        // what shape the pill wants to be
        val tw: Float
        val th: Float
        when {
            showFired -> { tw = 252f * d; th = 62f * d }
            hinted -> { tw = 236f * d; th = 54f * d }
            handRecent -> { tw = (196f + 14f * hold) * d; th = 46f * d }
            else -> { tw = 30f * d; th = 12f * d }
        }
        // spring, a little under-damped so it overshoots like a drop of liquid
        val k = 430f
        val cd = 25f
        vw += ((tw - w) * k - vw * cd) * dt
        vh += ((th - h) * k - vh * cd) * dt
        w = max(2f, w + vw * dt)
        h = max(2f, h + vh * dt)
        val targetVis = if (active) 1f else 0f
        vis += (targetVis - vis) * (1f - exp(-dt / (if (active) 0.06f else 0.22f)))

        if (vis < 0.01f && !active) {
            if (w < 40f * d && h < 16f * d) return // fully tucked away: stop redrawing until new data arrives
        }

        val cx = W / 2f
        val top = max(4f * d, (sbHeight - h) / 2f + 4f * d)
        val a = vis.coerceIn(0f, 1f)
        val acc = when {
            showFired -> Color.parseColor("#34F5A5")
            hold > 0.05f -> Color.parseColor("#FFD27A")
            else -> Color.parseColor("#22D3EE")
        }

        // soft glow around the pill, stronger right after a gesture fires
        val pulse = if (showFired) (1f - sinceFire / 1250f) else 0f
        val ga = (0.2f + 0.45f * pulse) * a
        glow.shader = RadialGradient(
            cx, top + h / 2f, max(w, h) * 0.85f,
            intArrayOf((acc and 0xFFFFFF) or ((255 * ga).toInt().coerceIn(0, 255) shl 24), acc and 0xFFFFFF),
            floatArrayOf(0.35f, 1f), Shader.TileMode.CLAMP
        )
        c.drawCircle(cx, top + h / 2f, max(w, h) * 0.85f, glow)

        // the black pill
        rect.set(cx - w / 2f, top, cx + w / 2f, top + h)
        val corner = min(h / 2f, 30f * d)
        fill.alpha = (255 * a).toInt().coerceIn(0, 255)
        c.drawRoundRect(rect, corner, corner, fill)
        rim.color = acc
        rim.alpha = (110 * a * (0.4f + 0.6f * pulse + 0.3f)).toInt().coerceIn(0, 255)
        c.drawRoundRect(rect, corner, corner, rim)

        // the ripple that leaves the pill when a gesture fires
        if (showFired) {
            ring = sinceFire / 700f
            if (ring in 0f..1f) {
                rim.alpha = (200 * (1f - ring)).toInt().coerceIn(0, 255)
                rim.strokeWidth = (2.2f * (1f - ring) + 0.6f) * d
                val grow = ring * 26f * d
                rect.set(cx - w / 2f - grow, top - grow * 0.6f, cx + w / 2f + grow, top + h + grow * 0.6f)
                c.drawRoundRect(rect, corner + grow, corner + grow, rim)
                rim.strokeWidth = 1f * d
            }
        }

        val contentA = ((w - 60f * d) / (120f * d)).coerceIn(0f, 1f) * a
        if (contentA > 0.05f) {
            c.save()
            c.clipRect(cx - w / 2f + 2f * d, top, cx + w / 2f - 2f * d, top + h)
            when {
                showFired -> drawFired(c, cx, top, contentA, acc)
                hinted -> drawHint(c, cx, top, contentA)
                else -> drawHand(c, cx, top, contentA, acc)
            }
            c.restore()
        } else if (a > 0.05f) {
            // tucked-in state: one live dot, like a camera light
            dot.color = Color.parseColor("#34F5A5")
            dot.alpha = (200 * a * (0.5f + 0.5f * kotlin.math.sin(t / 220f))).toInt().coerceIn(0, 255)
            c.drawCircle(cx, top + h / 2f, 2.6f * d, dot)
        }
        postInvalidateOnAnimation()
    }

    private fun drawHand(c: Canvas, cx: Float, top: Float, a: Float, acc: Int) {
        val left = cx - w / 2f
        val midY = top + h / 2f
        val er = h * 0.5f
        // emoji + the ring that fills while the pose is held
        emoji.textSize = h * 0.5f
        emoji.alpha = (255 * a).toInt().coerceIn(0, 255)
        val shown = if (pose == GestureEngine.Pose.NONE) lastSeenPose else pose
        c.drawText(poseEmoji(shown), left + h * 0.62f, midY + h * 0.18f, emoji)
        arc.set(left + h * 0.62f - er * 0.82f, midY - er * 0.82f, left + h * 0.62f + er * 0.82f, midY + er * 0.82f)
        arcP.strokeWidth = 2.4f * d
        arcP.color = Color.WHITE
        arcP.alpha = (40 * a).toInt().coerceIn(0, 255)
        c.drawArc(arc, 0f, 360f, false, arcP)
        if (hold > 0.02f) {
            arcP.color = acc
            arcP.alpha = (255 * a).toInt().coerceIn(0, 255)
            c.drawArc(arc, -90f, 360f * hold, false, arcP)
        }
        // pose name
        val name = poseName(pose)
        fitText(txt, name, w - h * 2.9f, 13.5f * d)
        txt.alpha = (255 * a).toInt().coerceIn(0, 255)
        c.drawText(name, left + h * 1.12f, midY + txt.textSize * 0.34f, txt)
        // live mini skeleton on the right
        drawSkeleton(c, cx + w / 2f - h * 0.85f, midY, h * 0.62f, a, acc)
    }

    private fun drawFired(c: Canvas, cx: Float, top: Float, a: Float, acc: Int) {
        val left = cx - w / 2f
        val midY = top + h / 2f
        emoji.textSize = h * 0.52f
        emoji.alpha = (255 * a).toInt().coerceIn(0, 255)
        c.drawText(firedEmoji, left + h * 0.7f, midY + h * 0.19f, emoji)
        fitText(txt, firedTitle, w - h * 1.5f, 15f * d)
        txt.alpha = (255 * a).toInt().coerceIn(0, 255)
        c.drawText(firedTitle, left + h * 1.25f, midY - 2f * d, txt)
        fitText(sub, firedSub, w - h * 1.5f, 11.5f * d)
        sub.color = acc
        sub.alpha = (230 * a).toInt().coerceIn(0, 255)
        c.drawText(firedSub, left + h * 1.25f, midY + 15f * d, sub)
    }

    private fun drawHint(c: Canvas, cx: Float, top: Float, a: Float) {
        val left = cx - w / 2f
        val midY = top + h / 2f
        emoji.textSize = h * 0.5f
        emoji.alpha = (255 * a).toInt().coerceIn(0, 255)
        val shown = if (pose == GestureEngine.Pose.NONE) lastSeenPose else pose
        c.drawText(poseEmoji(shown), left + h * 0.62f, midY + h * 0.18f, emoji)
        val s = hint ?: ""
        fitText(txt, s, w - h * 1.5f, 13f * d)
        txt.alpha = (255 * a).toInt().coerceIn(0, 255)
        c.drawText(s, left + h * 1.12f, midY - 1f * d, txt)
        fitText(sub, "Air Share", w - h * 1.5f, 11f * d)
        sub.color = Color.parseColor("#B8C0D4")
        sub.alpha = (210 * a).toInt().coerceIn(0, 255)
        c.drawText("Air Share", left + h * 1.12f, midY + 14f * d, sub)
        drawSkeleton(c, cx + w / 2f - h * 0.8f, midY, h * 0.56f, a, Color.parseColor("#22D3EE"))
    }

    /** The 21 hand points, drawn small and fitted into a square: you see your hand being tracked in real time. */
    private fun drawSkeleton(c: Canvas, ccx: Float, ccy: Float, size: Float, a: Float, acc: Int) {
        val pts = lm ?: return
        if (pts.size < 21) return
        var minX = 1f; var maxX = 0f; var minY = 1f; var maxY = 0f
        for (p in pts) { minX = min(minX, p.x); maxX = max(maxX, p.x); minY = min(minY, p.y); maxY = max(maxY, p.y) }
        val span = max(max(maxX - minX, maxY - minY), 0.05f)
        val sc = size / span
        val ox = ccx - (minX + maxX) / 2f * sc
        val oy = ccy - (minY + maxY) / 2f * sc
        line.strokeWidth = 1.3f * d
        line.color = acc
        line.alpha = (170 * a).toInt().coerceIn(0, 255)
        for (i in CONN.indices step 2) {
            val p = pts[CONN[i]]
            val q = pts[CONN[i + 1]]
            c.drawLine(ox + p.x * sc, oy + p.y * sc, ox + q.x * sc, oy + q.y * sc, line)
        }
        dot.color = Color.WHITE
        dot.alpha = (240 * a).toInt().coerceIn(0, 255)
        for (p in pts) c.drawCircle(ox + p.x * sc, oy + p.y * sc, 1.5f * d, dot)
    }

    private companion object {
        val CONN = intArrayOf(
            0, 1, 1, 2, 2, 3, 3, 4, 0, 5, 5, 6, 6, 7, 7, 8, 5, 9, 9, 10, 10, 11, 11, 12,
            9, 13, 13, 14, 14, 15, 15, 16, 13, 17, 17, 18, 18, 19, 19, 20, 0, 17
        )
    }
}

/** Puts the island on screen while the Air Flow service runs, and feeds it every camera frame. */
object IslandHost {
    private var view: GestureIslandView? = null
    private var wm: WindowManager? = null

    fun show(ctx: Context) {
        if (view != null || !Prefs.island) return
        val app = ctx.applicationContext
        val acc = AirFlowAccessibilityService.instance
        val host: Context
        val type: Int
        if (acc != null) {
            host = acc
            type = WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY
        } else if (Settings.canDrawOverlays(app)) {
            host = app
            type = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else return
        try {
            val v = GestureIslandView(host)
            val h = (120f * host.resources.displayMetrics.density).toInt()
            val lp = WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT, h, type,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT
            )
            lp.gravity = Gravity.TOP
            if (Build.VERSION.SDK_INT >= 28) {
                lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            }
            val w = host.getSystemService(Context.WINDOW_SERVICE) as WindowManager
            w.addView(v, lp)
            view = v
            wm = w
        } catch (_: Exception) {
        }
    }

    fun hide() {
        val v = view ?: return
        try { wm?.removeView(v) } catch (_: Exception) {}
        view = null
        wm = null
    }

    /** Turns the island on or off straight away (the Anywhere tab switch). */
    fun setEnabled(ctx: Context, on: Boolean) {
        Prefs.island = on
        if (on && AirFlowState.running.value) show(ctx) else if (!on) hide()
    }

    fun onFrame(r: FrameResult, airHint: String?) { view?.feed(r, airHint) }

    fun fired(g: Gesture, a: Action) {
        val v = view ?: return
        val label = a.name.lowercase().replace('_', ' ').replaceFirstChar { it.uppercase() }
        v.post { v.fired(g, label) }
    }
}
