package com.airflow.app

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.PI
import kotlin.math.sin

@Composable
fun DemoScreen(goTest: () -> Unit) {
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("Gesture demo", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
        Text("Watch each animation, then try it in front of the camera on the Test tab.")

        SectionCard("Golden rules") {
            Text("• Face the phone, hand 40–60 cm away, fully inside the frame.")
            Text("• Good light on your palm. Avoid a bright window behind you.")
            Text("• Spread your fingers. Move fast and decisively (about 0.3 s).")
            Text("• After a gesture, lower your hand out of view to reset.")
            Text("• Gestures pause briefly after each trigger so your return motion is ignored.")
            Text("• Open-hand swipes are smart: they act differently in Shorts, YouTube videos, music apps and other apps.")
            Text("• Fist swipes control the whole phone. Thumb up / down change volume (hold to keep going).")
            Text("• Every gesture can be remapped or switched off in Settings.")
        }

        SectionCard("🖱 Cursor mode (hand mouse)") {
            Text("Show the rock sign 🤘 for 1 second (or press the Cursor button on Home) to turn it on.")
            Text("• Point with your index finger: the cursor follows your fingertip.")
            Text("• Quick pinch 🤏 = tap (open apps, press keys, buttons).")
            Text("• Pinch and hold still 0.6 s until the cursor turns orange, then release = long-press.")
            Text("• Pinch and move straight away = scroll or swipe. Orange hold, then move = drag and drop.")
            Text("• Fist hold ✊ or rock sign again = leave cursor mode. Fist swipes still do Home / Back / Recents.")
        }

        Gesture.values().forEach { g ->
            SectionCard(g.title) {
                Row(horizontalArrangement = Arrangement.spacedBy(16.dp), verticalAlignment = Alignment.CenterVertically) {
                    GestureAnim(g)
                    Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text("Action: ${g.action}", fontWeight = FontWeight.SemiBold)
                        Text(g.how, style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
        }

        Button(onClick = goTest, modifier = Modifier.fillMaxWidth()) { Text("Try it live →") }
    }
}

@Composable
private fun GestureAnim(g: Gesture) {
    val t = rememberInfiniteTransition(label = "demo")
    val p by t.animateFloat(
        initialValue = 0f, targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(1800, easing = FastOutSlowInEasing), RepeatMode.Restart),
        label = "p"
    )
    val fade = sin(PI * p).toFloat().coerceIn(0f, 1f)
    Box(
        Modifier.size(width = 110.dp, height = 130.dp).clip(RoundedCornerShape(16.dp)).background(Color(0xFF0B1020)),
        contentAlignment = Alignment.Center
    ) {
        val hand = Modifier
        when (g) {
            Gesture.SWIPE_UP, Gesture.FIST_SWIPE_UP ->
                Text(g.emoji, fontSize = 44.sp, modifier = hand.offset(y = (35 - 70 * p).dp).alpha(fade))
            Gesture.SWIPE_DOWN, Gesture.FIST_SWIPE_DOWN ->
                Text(g.emoji, fontSize = 44.sp, modifier = hand.offset(y = (-35 + 70 * p).dp).alpha(fade))
            Gesture.SWIPE_LEFT, Gesture.FIST_SWIPE_LEFT ->
                Text(g.emoji, fontSize = 44.sp, modifier = hand.offset(x = (35 - 70 * p).dp).alpha(fade))
            Gesture.SWIPE_RIGHT, Gesture.FIST_SWIPE_RIGHT ->
                Text(g.emoji, fontSize = 44.sp, modifier = hand.offset(x = (-35 + 70 * p).dp).alpha(fade))
            Gesture.PINCH -> Text(g.emoji, fontSize = 44.sp, modifier = Modifier.scale(0.8f + 0.4f * fade))
            else -> {
                // All "hold still" poses: a progress ring fills while the pose is held.
                CircularProgressIndicator(progress = { p }, modifier = Modifier.size(84.dp))
                Text(g.emoji, fontSize = 40.sp)
            }
        }
    }
}
