package com.airflow.app

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.RoundRect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipPath
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.launch
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.min
import kotlin.math.sin

// =============================================================================================
// Scene engine: every scene is a pure function of progress p in 0..1 that fills a Frame.
// =============================================================================================

private class Frame {
    var screen = 0            // 0 home, 1 shorts, 2 video, 3 browser, 4 keyboard
    var shortIdx = 0f
    var pose: HandPose = Poses.OPEN
    var hx = 0.5f; var hy = 0.6f; var ha = 1f
    var trailDx = 0f; var trailDy = 0f; var trailA = 0f
    var label = ""
    var ring = 0f
    var cursorA = 0f; var cx = 0.5f; var cy = 0.5f; var cmode = 0
    var ripple = 0f; var rx = 0.5f; var ry = 0.5f
    var toast = ""; var toastA = 0f
    var flash = 0f
    var shade = 0f; var recents = 0f
    var zoom = 0f; var zx = 0.4f; var zy = 0.2f
    var menu = 0f; var mx = 0.6f; var my = 0.34f
    var dragA = 0f; var dx = 0.16f; var dy = 0.34f
    var typed = ""; var pressedKey = ' '
    var liked = 0f; var pauseA = 0f
    var vid = 0.3f
    var scrollY = 0f

    fun reset() {
        screen = 0; shortIdx = 0f; pose = Poses.OPEN; hx = 0.5f; hy = 0.6f; ha = 1f
        trailDx = 0f; trailDy = 0f; trailA = 0f; label = ""; ring = 0f
        cursorA = 0f; cx = 0.5f; cy = 0.5f; cmode = 0; ripple = 0f
        toast = ""; toastA = 0f; flash = 0f; shade = 0f; recents = 0f; zoom = 0f
        menu = 0f; dragA = 0f; typed = ""; pressedKey = ' '; liked = 0f; pauseA = 0f
        vid = 0.3f; scrollY = 0f
    }
}

private class Scene(
    val cursor: Boolean,
    val title: String,
    val sub: String,
    val ms: Int,
    val steps: List<String>,
    val run: (Float, Frame) -> Unit
)

private fun mv(p: Float, a: Float, b: Float, from: Float, to: Float) = lerpF(from, to, easeInOut(seg(p, a, b)))
private fun pulse(p: Float, a: Float, b: Float) = smooth(seg(p, a, a + 0.08f)) * (1f - smooth(seg(p, b - 0.08f, b)))

private fun Frame.base(p: Float) {
    ha = smooth(seg(p, 0f, 0.08f)) * (1f - smooth(seg(p, 0.94f, 1f)))
}

private fun Frame.say(s: String, p: Float, a: Float) {
    if (p >= a) label = s
}

private fun Frame.toastIt(s: String, a: Float, b: Float, p: Float) {
    val v = pulse(p, a, b)
    if (v > 0f) { toast = s; toastA = v }
}

/** Cursor follows a point; the hand mirrors it in the camera panel. */
private fun Frame.point(x: Float, y: Float) {
    cx = x; cy = y
    hx = 0.3f + 0.4f * x
    hy = 0.5f + 0.3f * y
}

private fun iconX(col: Int) = 0.16f + 0.227f * col
private fun iconY(row: Int) = 0.2f + 0.14f * row

private fun keyPos(ch: Char): Offset {
    val rows = arrayOf("QWERTYUIOP", "ASDFGHJKL", "ZXCVBNM")
    for (r in rows.indices) {
        val i = rows[r].indexOf(ch)
        if (i >= 0) {
            val off = if (r == 0) 0f else if (r == 1) 0.5f else 1.5f
            return Offset((i + 0.5f + off) / 10f, 0.63f + 0.1f * r)
        }
    }
    return Offset(0.5f, 0.9f)
}

private val SCENES: List<Scene> = listOf(
    Scene(false, "Start Air Flow", "One tap on the orb and your front camera becomes a remote control.", 5200,
        listOf("Tap the glowing orb on the Home tab", "Prop your phone up, hand 40 to 60 cm away", "When you see Hand detected you are ready")) { p, f ->
        f.base(p); f.screen = 0; f.pose = Poses.OPEN
        f.hx = 0.5f; f.hy = 0.62f + 0.02f * sin(p * 12f)
        f.say("Hand detected", p, 0.2f)
        f.toastIt("Air Flow is live", 0.12f, 0.9f, p)
    },
    Scene(false, "Swipe up: next Short", "Flick your open hand upward, like flicking a real screen.", 5000,
        listOf("Show an open hand", "Flick it up, quick and clean", "The next Short slides in")) { p, f ->
        f.base(p); f.screen = 1; f.shortIdx = easeInOut(seg(p, 0.45f, 0.78f))
        f.hy = mv(p, 0.25f, 0.58f, 0.78f, 0.34f)
        val s = sin(PI.toFloat() * seg(p, 0.25f, 0.58f)); f.trailDy = 1f; f.trailA = s
        f.say("Swipe up  →  Next Short", p, 0.28f)
    },
    Scene(false, "Swipe down: previous", "Flick down to go back to the Short you just saw.", 5000,
        listOf("Open hand, held high", "Flick it down", "The previous Short returns")) { p, f ->
        f.base(p); f.screen = 1; f.shortIdx = 1f - easeInOut(seg(p, 0.45f, 0.78f))
        f.hy = mv(p, 0.25f, 0.58f, 0.34f, 0.78f)
        f.trailDy = -1f; f.trailA = sin(PI.toFloat() * seg(p, 0.25f, 0.58f))
        f.say("Swipe down  →  Previous", p, 0.28f)
    },
    Scene(false, "Pinch: next Short", "The fastest way to scroll Shorts: just pinch. No big arm movement.", 5200,
        listOf("Show your hand", "Touch thumb and index finger together", "Release. The next Short plays")) { p, f ->
        f.base(p); f.screen = 1; f.shortIdx = 2f + easeInOut(seg(p, 0.5f, 0.8f))
        f.pose = lerpPose(Poses.OPEN, Poses.PINCH, smooth(seg(p, 0.15f, 0.32f)) - smooth(seg(p, 0.55f, 0.7f)))
        f.rx = 0.5f; f.ry = 0.5f; f.ripple = seg(p, 0.45f, 0.75f)
        f.say("Pinch  →  Next Short", p, 0.3f)
    },
    Scene(false, "Open palm hold: pause", "Hold a flat palm still and the video pauses or plays.", 5200,
        listOf("Raise an open palm to the camera", "Hold still, the ring fills", "Video pauses. Do it again to resume")) { p, f ->
        f.base(p); f.screen = 1; f.shortIdx = 3f
        f.ring = if (p < 0.7f) seg(p, 0.15f, 0.7f) else 0f
        f.pauseA = pulse(p, 0.7f, 0.97f)
        f.say("Hold palm  →  Pause", p, 0.2f)
    },
    Scene(false, "Thumbs up: like", "Hold a thumbs up and the heart pops on the video you are watching.", 5200,
        listOf("Make a thumbs up", "Hold for a moment", "The heart pops, it is liked")) { p, f ->
        f.base(p); f.screen = 1; f.shortIdx = 3f
        f.pose = lerpPose(Poses.OPEN, Poses.THUMB_UP, smooth(seg(p, 0.1f, 0.28f)))
        f.ring = if (p < 0.62f) seg(p, 0.3f, 0.62f) else 0f
        f.liked = backOut(seg(p, 0.64f, 0.8f))
        f.say("Thumbs up  →  Like", p, 0.3f)
    },
    Scene(false, "Swipe left or right: seek", "In a video, sideways swipes jump back or forward 10 seconds.", 6000,
        listOf("Open hand, swipe right to skip ahead", "Swipe left to rewind", "Works in YouTube and most players")) { p, f ->
        f.base(p); f.screen = 2
        if (p < 0.5f) {
            f.hx = mv(p, 0.12f, 0.4f, 0.3f, 0.72f); f.trailDx = -1f; f.trailA = sin(PI.toFloat() * seg(p, 0.12f, 0.4f))
            f.vid = mv(p, 0.3f, 0.5f, 0.3f, 0.4f); f.say("Swipe right  →  +10 s", p, 0.15f)
            f.toastIt("+10 s", 0.3f, 0.5f, p)
        } else {
            f.hx = mv(p, 0.55f, 0.83f, 0.72f, 0.3f); f.trailDx = 1f; f.trailA = sin(PI.toFloat() * seg(p, 0.55f, 0.83f))
            f.vid = mv(p, 0.75f, 0.95f, 0.4f, 0.3f); f.say("Swipe left  →  -10 s", p, 0.56f)
            f.toastIt("-10 s", 0.75f, 0.97f, p)
        }
    },
    Scene(false, "Peace sign: screenshot", "Hold a V sign and Air Flow snaps a screenshot.", 5200,
        listOf("Make a peace sign", "Hold until the ring fills", "Flash. Screenshot saved")) { p, f ->
        f.base(p); f.screen = 1; f.shortIdx = 3f
        f.pose = lerpPose(Poses.OPEN, Poses.PEACE, smooth(seg(p, 0.1f, 0.28f)))
        f.ring = if (p < 0.62f) seg(p, 0.3f, 0.62f) else 0f
        f.flash = 1f - seg(p, 0.64f, 0.8f); if (p < 0.64f) f.flash = 0f
        f.toastIt("Screenshot saved", 0.66f, 0.98f, p)
        f.say("Peace sign  →  Screenshot", p, 0.3f)
    },
    Scene(false, "Fist swipes: phone control", "A closed fist swipes the whole phone: Notifications, Recents, Home and Back.", 7000,
        listOf("Close your hand into a fist", "Fist swipe down opens Notifications", "Fist swipe right opens Recents", "Fist up is Home, fist left is Back")) { p, f ->
        f.base(p); f.screen = 1; f.shortIdx = 3f; f.pose = Poses.FIST
        if (p < 0.5f) {
            f.hy = mv(p, 0.12f, 0.36f, 0.3f, 0.78f); f.trailDy = -1f; f.trailA = sin(PI.toFloat() * seg(p, 0.12f, 0.36f))
            f.shade = easeInOut(seg(p, 0.3f, 0.45f)) * (1f - easeInOut(seg(p, 0.46f, 0.5f)))
            f.say("Fist swipe down  →  Notifications", p, 0.14f)
        } else {
            f.hx = mv(p, 0.55f, 0.8f, 0.28f, 0.72f); f.trailDx = -1f; f.trailA = sin(PI.toFloat() * seg(p, 0.55f, 0.8f))
            f.recents = easeInOut(seg(p, 0.72f, 0.88f)) * (1f - easeInOut(seg(p, 0.93f, 1f)))
            f.say("Fist swipe right  →  Recents", p, 0.56f)
        }
    },
    // ----------------------------------------------------------------------------- cursor mode
    Scene(true, "Rock sign: cursor ON", "Hold the rock sign and your hand turns into a mouse for the whole phone.", 5600,
        listOf("Make the rock sign", "Hold until the ring fills", "A glowing cursor appears on screen")) { p, f ->
        f.base(p); f.screen = 0
        val k = smooth(seg(p, 0.08f, 0.24f)) - smooth(seg(p, 0.72f, 0.88f))
        f.pose = lerpPose(Poses.OPEN, Poses.ROCK, k)
        if (p > 0.72f) f.pose = lerpPose(Poses.ROCK, Poses.POINT, smooth(seg(p, 0.72f, 0.88f)))
        f.ring = if (p < 0.6f) seg(p, 0.25f, 0.6f) else 0f
        f.cursorA = smooth(seg(p, 0.6f, 0.72f))
        f.toastIt("Cursor mode ON", 0.62f, 0.98f, p)
        f.say("Rock sign  →  Cursor mode", p, 0.25f)
    },
    Scene(true, "Point to move", "Point with your index finger. The cursor glides smoothly wherever you aim.", 6000,
        listOf("Curl the other fingers, point", "Move your hand slowly", "The cursor follows with no lag")) { p, f ->
        f.base(p); f.screen = 0; f.pose = Poses.POINT; f.cursorA = 1f
        val a = (p * 2f * PI).toFloat()
        f.point(0.5f + 0.32f * sin(a), 0.45f + 0.3f * sin(a * 2f))
        f.say("Index finger  →  Move", p, 0.1f)
    },
    Scene(true, "Pinch to tap", "Pinch while pointing and whatever is under the cursor gets tapped.", 6000,
        listOf("Point at an app icon", "Pinch thumb and index together", "The app opens")) { p, f ->
        f.base(p); f.screen = 0; f.cursorA = 1f
        val tx = iconX(1); val ty = iconY(0)
        f.point(mv(p, 0.05f, 0.38f, 0.5f, tx), mv(p, 0.05f, 0.38f, 0.65f, ty))
        val pin = smooth(seg(p, 0.42f, 0.5f)) - smooth(seg(p, 0.6f, 0.68f))
        f.pose = lerpPose(Poses.POINT, Poses.PINCH_POINT, pin)
        f.cmode = if (pin > 0.5f) 1 else 0
        f.rx = tx; f.ry = ty; f.ripple = seg(p, 0.48f, 0.7f)
        f.zx = tx; f.zy = ty; f.zoom = easeOut(seg(p, 0.55f, 0.85f))
        f.say("Pinch  →  Tap", p, 0.42f)
    },
    Scene(true, "Pinch and hold: long-press", "Hold the pinch still until the cursor turns orange.", 6200,
        listOf("Point at an icon and pinch", "Keep holding still, cursor turns orange", "The long-press menu pops open")) { p, f ->
        f.base(p); f.screen = 0; f.cursorA = 1f
        val tx = iconX(2); val ty = iconY(1)
        f.point(mv(p, 0.04f, 0.2f, 0.5f, tx), mv(p, 0.04f, 0.2f, 0.7f, ty))
        val pin = smooth(seg(p, 0.22f, 0.3f)) - smooth(seg(p, 0.88f, 0.95f))
        f.pose = lerpPose(Poses.POINT, Poses.PINCH_POINT, pin)
        f.ring = if (p in 0.3f..0.58f) seg(p, 0.3f, 0.58f) else 0f
        f.cmode = if (p in 0.58f..0.9f) 2 else if (pin > 0.5f) 1 else 0
        f.mx = tx; f.my = ty; f.menu = backOut(seg(p, 0.6f, 0.72f)) * (1f - smooth(seg(p, 0.93f, 1f)))
        f.say("Pinch + hold  →  Long-press", p, 0.3f)
    },
    Scene(true, "Pinch and move: scroll", "Pinch and slide your hand: the page scrolls like a finger on glass.", 6200,
        listOf("Point at the page", "Pinch and move straight away", "Slide up to scroll down, slide down to go back")) { p, f ->
        f.base(p); f.screen = 3; f.cursorA = 1f
        val pin = smooth(seg(p, 0.1f, 0.18f)) - smooth(seg(p, 0.78f, 0.86f))
        f.pose = lerpPose(Poses.POINT, Poses.PINCH_POINT, pin)
        f.cmode = if (pin > 0.5f) 1 else 0
        val k = easeInOut(seg(p, 0.22f, 0.7f))
        f.point(0.5f, lerpF(0.75f, 0.3f, k))
        f.scrollY = k
        f.say("Pinch + move  →  Scroll", p, 0.2f)
    },
    Scene(true, "Drag and drop", "Pinch, hold, then move to carry an icon anywhere.", 6600,
        listOf("Pinch an icon and hold still", "Move your hand to carry it", "Release to drop it in the dock")) { p, f ->
        f.base(p); f.screen = 0; f.cursorA = 1f
        val sx = iconX(0); val sy = iconY(1)
        val px = if (p < 0.55f) mv(p, 0.04f, 0.2f, 0.6f, sx) else mv(p, 0.55f, 0.82f, sx, 0.4f)
        val py = if (p < 0.55f) mv(p, 0.04f, 0.2f, 0.7f, sy) else mv(p, 0.55f, 0.82f, sy, 0.9f)
        f.point(px, py)
        val pin = smooth(seg(p, 0.22f, 0.3f)) - smooth(seg(p, 0.86f, 0.93f))
        f.pose = lerpPose(Poses.POINT, Poses.PINCH_POINT, pin)
        f.ring = if (p in 0.3f..0.5f) seg(p, 0.3f, 0.5f) else 0f
        f.cmode = if (p in 0.5f..0.88f) 2 else if (pin > 0.5f) 1 else 0
        f.dragA = if (p in 0.5f..0.88f) 1f else 0f; f.dx = px; f.dy = py
        f.rx = 0.4f; f.ry = 0.9f; f.ripple = seg(p, 0.86f, 1f)
        f.say("Pinch + hold + move  →  Drag", p, 0.3f)
    },
    Scene(true, "Type with your hand", "Tap the keys with pinches to type on any on-screen keyboard.", 8200,
        listOf("Point at a key", "Pinch to press it", "Letter by letter, you are typing")) { p, f ->
        f.base(p); f.screen = 4; f.cursorA = 1f
        val word = "HELLO"
        val span = 0.17f
        val i = ((p - 0.08f) / span).toInt().coerceIn(0, 4)
        val q = ((p - 0.08f - span * i) / span).coerceIn(0f, 1f)
        val prev = if (i == 0) Offset(0.5f, 0.5f) else keyPos(word[i - 1])
        val tgt = keyPos(word[i])
        val pos = lerpO(prev, tgt, easeInOut(seg(q, 0f, 0.55f)))
        f.point(pos.x, pos.y)
        val tapped = q > 0.62f
        f.typed = word.substring(0, i + if (tapped) 1 else 0).let { if (p < 0.08f) "" else it }
        val pin = smooth(seg(q, 0.55f, 0.65f)) - smooth(seg(q, 0.8f, 0.95f))
        f.pose = lerpPose(Poses.POINT, Poses.PINCH_POINT, pin)
        f.cmode = if (pin > 0.5f) 1 else 0
        f.rx = tgt.x; f.ry = tgt.y; f.ripple = seg(q, 0.62f, 1f)
        if (q in 0.62f..0.95f) f.pressedKey = word[i]
        f.say("Pinch  →  Press key", p, 0.1f)
    },
    Scene(true, "Hover to tap", "Prefer no pinching? Hold the cursor still for a second and it taps.", 6000,
        listOf("Turn on Hover to tap in Settings", "Aim at an icon and hold still", "A ring fills, then it taps by itself")) { p, f ->
        f.base(p); f.screen = 0; f.pose = Poses.POINT; f.cursorA = 1f
        val tx = iconX(3); val ty = iconY(2)
        f.point(mv(p, 0.05f, 0.3f, 0.45f, tx) + 0.004f * sin(p * 60f), mv(p, 0.05f, 0.3f, 0.7f, ty))
        f.ring = if (p in 0.32f..0.7f) seg(p, 0.32f, 0.7f) else 0f
        f.rx = tx; f.ry = ty; f.ripple = seg(p, 0.7f, 0.92f)
        f.say("Hold still  →  Auto tap", p, 0.32f)
    },
    Scene(true, "Fist or rock: exit", "Make a fist or the rock sign again to put the cursor away.", 5200,
        listOf("Close your hand into a fist", "Hold until the ring fills", "The cursor disappears")) { p, f ->
        f.base(p); f.screen = 0
        f.pose = lerpPose(Poses.POINT, Poses.FIST, smooth(seg(p, 0.1f, 0.26f)))
        f.cursorA = 1f - smooth(seg(p, 0.62f, 0.74f))
        f.ring = if (p in 0.28f..0.62f) seg(p, 0.28f, 0.62f) else 0f
        f.toastIt("Cursor mode OFF", 0.64f, 0.98f, p)
        f.say("Fist hold  →  Exit cursor", p, 0.28f)
    }
)

// =============================================================================================
// Drawing
// =============================================================================================

private class Ink { val p = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG) }

private fun DrawScope.txt(
    ink: Ink, s: String, x: Float, y: Float, size: Float, color: Color,
    bold: Boolean = false, align: android.graphics.Paint.Align = android.graphics.Paint.Align.LEFT
) {
    drawIntoCanvas { cv ->
        ink.p.textSize = size
        ink.p.color = color.toArgb()
        ink.p.isFakeBoldText = bold
        ink.p.textAlign = align
        cv.nativeCanvas.drawText(s, x, y, ink.p)
    }
}

private val APP_COLORS = listOf(
    0xFFFF4D4D, 0xFF4D9BFF, 0xFF33D17A, 0xFFFFB020,
    0xFFB06BFF, 0xFF20D0E0, 0xFFFF6BB5, 0xFF7C8CFF,
    0xFFFF8A3D, 0xFF3DDC97, 0xFF5B6CFF, 0xFFE05AFF,
    0xFF4CC9F0, 0xFFF7B801, 0xFFFF5D8F, 0xFF6BE675
).map { Color(it) }

private val CARD_COLORS = listOf(
    Color(0xFF7C4DFF) to Color(0xFF1E1B4B), Color(0xFFFF5C7A) to Color(0xFF4A1230),
    Color(0xFF00C2A8) to Color(0xFF053B46), Color(0xFFFFB020) to Color(0xFF5A2A0B),
    Color(0xFF3B82F6) to Color(0xFF0B1B4D)
)

private fun DrawScope.drawStage(f: Frame, ink: Ink, dark: Color, a1: Color, a2: Color, a3: Color, warn: Color) {
    val w = size.width
    val h = size.height
    // ---- phone
    var ph = h * 0.97f
    var pw = ph * 0.49f
    if (pw > w * 0.5f) { pw = w * 0.5f; ph = pw / 0.49f }
    val px = w * 0.01f + (w * 0.5f - pw) / 2f
    val py = (h - ph) / 2f
    val body = RoundRect(px, py, px + pw, py + ph, CornerRadius(pw * 0.17f))
    drawRoundRect(Color(0xFF0B0D16), Offset(px, py), Size(pw, ph), CornerRadius(pw * 0.17f))
    drawRoundRect(
        Brush.linearGradient(listOf(a2, a1, a3), Offset(px, py), Offset(px + pw, py + ph)),
        Offset(px, py), Size(pw, ph), CornerRadius(pw * 0.17f), style = Stroke(2.2f)
    )
    val bez = pw * 0.035f
    val sx = px + bez; val sy = py + bez; val sw = pw - 2 * bez; val sh = ph - 2 * bez
    val sr = CornerRadius(pw * 0.145f)
    val screenPath = Path().apply { addRoundRect(RoundRect(sx, sy, sx + sw, sy + sh, sr)) }

    clipPath(screenPath) {
        drawScreen(f.screen, f, ink, sx, sy, sw, sh)
        if (f.zoom > 0f) {
            val z = f.zoom
            val cx = sx + f.zx * sw; val cy = sy + f.zy * sh
            val l = lerpF(cx - sw * 0.08f, sx, z); val t = lerpF(cy - sw * 0.08f, sy, z)
            val r = lerpF(cx + sw * 0.08f, sx + sw, z); val b = lerpF(cy + sw * 0.08f, sy + sh, z)
            val zp = Path().apply { addRoundRect(RoundRect(l, t, r, b, CornerRadius(lerpF(24f, 0f, z)))) }
            clipPath(zp) { drawScreen(3, f, ink, sx, sy, sw, sh) }
        }
        // notification shade
        if (f.shade > 0f) {
            val hh = sh * 0.72f * f.shade
            drawRect(Color(0xF0111426), Offset(sx, sy), Size(sw, hh))
            for (i in 0..3) {
                val yy = sy + hh - sh * (0.62f - 0.15f * i)
                if (yy > sy + sh * 0.05f && yy < sy + hh - 6f) {
                    drawRoundRect(Color.White.copy(alpha = 0.1f), Offset(sx + sw * 0.06f, yy), Size(sw * 0.88f, sh * 0.1f), CornerRadius(14f))
                    drawCircle(APP_COLORS[i * 3], sw * 0.04f, Offset(sx + sw * 0.13f, yy + sh * 0.05f))
                    drawRoundRect(Color.White.copy(alpha = 0.5f), Offset(sx + sw * 0.22f, yy + sh * 0.028f), Size(sw * 0.45f, 6f), CornerRadius(3f))
                    drawRoundRect(Color.White.copy(alpha = 0.25f), Offset(sx + sw * 0.22f, yy + sh * 0.06f), Size(sw * 0.3f, 5f), CornerRadius(3f))
                }
            }
        }
        // recents
        if (f.recents > 0f) {
            drawRect(Color.Black.copy(alpha = 0.55f * f.recents))
            for (k in -1..1) {
                val s = 0.56f * (0.85f + 0.15f * f.recents)
                val cw = sw * s; val ch = sh * 0.6f * (0.85f + 0.15f * f.recents)
                val ox = sx + sw / 2f + k * sw * 0.62f * f.recents - cw / 2f
                val oy = sy + sh * 0.2f
                val col = CARD_COLORS[(k + 3) % 5]
                drawRoundRect(Brush.verticalGradient(listOf(col.first, col.second), oy, oy + ch), Offset(ox, oy), Size(cw, ch), CornerRadius(22f), alpha = f.recents)
            }
        }
        // screenshot flash
        if (f.flash > 0f) drawRect(Color.White.copy(alpha = 0.85f * f.flash))
        // long-press menu
        if (f.menu > 0f) {
            val mx = sx + f.mx * sw; val my = sy + f.my * sh
            val mw = sw * 0.46f * f.menu; val mh = sh * 0.2f * f.menu
            val ox = (mx - mw * 0.6f).coerceIn(sx + 6f, sx + sw - mw - 6f)
            drawRoundRect(Color(0xF0222640), Offset(ox, my + 8f), Size(mw, mh), CornerRadius(18f))
            if (f.menu > 0.6f) {
                for (i in 0..2) drawRoundRect(Color.White.copy(alpha = 0.6f - 0.15f * i), Offset(ox + mw * 0.1f, my + 8f + mh * (0.15f + 0.3f * i)), Size(mw * (0.7f - 0.1f * i), 6f), CornerRadius(3f))
            }
        }
        // dragged icon
        if (f.dragA > 0f) {
            val s = sw * 0.17f
            drawRoundRect(APP_COLORS[4].copy(alpha = 0.95f), Offset(sx + f.dx * sw - s / 2f, sy + f.dy * sh - s / 2f), Size(s, s), CornerRadius(s * 0.28f))
        }
        // volume / toast
        if (f.toastA > 0f) {
            val tw = sw * 0.78f; val th = sh * 0.06f
            val ty = sy + sh * 0.07f - (1f - f.toastA) * 12f
            drawRoundRect(Color(0xEE000000).copy(alpha = 0.8f * f.toastA), Offset(sx + (sw - tw) / 2f, ty), Size(tw, th), CornerRadius(th / 2f))
            txt(ink, f.toast, sx + sw / 2f, ty + th * 0.68f, th * 0.5f, Color.White.copy(alpha = f.toastA), true, android.graphics.Paint.Align.CENTER)
        }
        // ripple
        if (f.ripple > 0f && f.ripple < 1f) {
            val c = Offset(sx + f.rx * sw, sy + f.ry * sh)
            drawCircle(a2.copy(alpha = (1f - f.ripple) * 0.7f), sw * (0.03f + 0.14f * f.ripple), c, style = Stroke(3f))
            drawCircle(a2.copy(alpha = (1f - f.ripple) * 0.25f), sw * (0.02f + 0.1f * f.ripple), c)
        }
        // cursor
        if (f.cursorA > 0.01f) {
            val c = Offset(sx + f.cx * sw, sy + f.cy * sh)
            val col = if (f.cmode == 2) warn else a2
            val r = sw * (if (f.cmode == 1) 0.028f else 0.04f)
            drawCircle(col.copy(alpha = 0.28f * f.cursorA), r * 2.1f, c)
            drawCircle(col.copy(alpha = f.cursorA), r, c)
            drawCircle(Color.White.copy(alpha = f.cursorA), r * 0.4f, c)
            if (f.ring > 0f) drawArc(Color.White.copy(alpha = f.cursorA), -90f, 360f * f.ring, false, Offset(c.x - r * 1.9f, c.y - r * 1.9f), Size(r * 3.8f, r * 3.8f), style = Stroke(3.5f, cap = StrokeCap.Round))
        }
    }
    // notch
    drawRoundRect(Color.Black, Offset(px + pw / 2f - pw * 0.13f, sy + 6f), Size(pw * 0.26f, pw * 0.05f), CornerRadius(20f))

    // ---- camera panel
    val cxL = px + pw + w * 0.035f
    val cw = w - cxL - w * 0.01f
    val chh = min(h * 0.8f, cw * 1.25f)
    val cyT = (h - chh) / 2f
    drawRoundRect(Brush.verticalGradient(listOf(Color(0xFF0B1226), Color(0xFF151B38)), cyT, cyT + chh), Offset(cxL, cyT), Size(cw, chh), CornerRadius(28f))
    for (g in 1..5) {
        val gx = cxL + cw * g / 6f
        drawLine(Color.White.copy(alpha = 0.04f), Offset(gx, cyT), Offset(gx, cyT + chh), 1f)
        val gy = cyT + chh * g / 6f
        drawLine(Color.White.copy(alpha = 0.04f), Offset(cxL, gy), Offset(cxL + cw, gy), 1f)
    }
    drawRoundRect(Brush.linearGradient(listOf(a2, a1, a3), Offset(cxL, cyT), Offset(cxL + cw, cyT + chh)), Offset(cxL, cyT), Size(cw, chh), CornerRadius(28f), style = Stroke(2f))
    drawCircle(Color(0xFFFF3B5C), 5f, Offset(cxL + 22f, cyT + 24f))
    txt(ink, "CAMERA", cxL + 34f, cyT + 29f, 22f, Color.White.copy(alpha = 0.7f), true)

    if (f.ha > 0.01f) {
        val pts = computeHand(f.pose)
        val sc = chh * 0.5f
        val o = Offset(cxL + f.hx * cw, cyT + (0.35f + f.hy * 0.62f) * chh)
        // swipe trail
        if (f.trailA > 0.02f) {
            val tip = Offset(o.x + pts[9].x * sc, o.y + pts[9].y * sc)
            val len = chh * 0.26f * f.trailA
            val d = Offset(f.trailDx, f.trailDy)
            val tail = Offset(tip.x + d.x * len, tip.y + d.y * len)
            drawLine(Brush.linearGradient(listOf(a2.copy(alpha = 0.85f * f.ha), Color.Transparent), tip, tail), tip, tail, strokeWidth = 14f, cap = StrokeCap.Round)
        }
        drawHand(pts, o, sc, a2, a3, alpha = f.ha, glow = 1f, lineW = 3.2f, dotR = 4.2f)
        if (f.ring > 0f) {
            val rc = Offset(o.x, o.y - sc * 0.62f)
            drawCircle(Color.White.copy(alpha = 0.12f), 30f, rc, style = Stroke(5f))
            drawArc(a3, -90f, 360f * f.ring, false, Offset(rc.x - 30f, rc.y - 30f), Size(60f, 60f), style = Stroke(5f, cap = StrokeCap.Round))
        }
    }
    if (f.label.isNotEmpty()) {
        val lw = cw * 0.9f
        drawRoundRect(Color.Black.copy(alpha = 0.6f), Offset(cxL + (cw - lw) / 2f, cyT + chh - 54f), Size(lw, 38f), CornerRadius(19f))
        txt(ink, f.label, cxL + cw / 2f, cyT + chh - 28f, 21f, Color.White, true, android.graphics.Paint.Align.CENTER)
    }
}

private fun DrawScope.drawScreen(kind: Int, f: Frame, ink: Ink, x: Float, y: Float, w: Float, h: Float) {
    when (kind) {
        0 -> { // home
            drawRect(Brush.verticalGradient(listOf(Color(0xFF2B1B6B), Color(0xFF0E2A5E), Color(0xFF0B1B3A)), y, y + h), Offset(x, y), Size(w, h))
            txt(ink, "9:41", x + w / 2f, y + h * 0.13f, w * 0.14f, Color.White, true, android.graphics.Paint.Align.CENTER)
            for (r in 0..3) for (c in 0..3) {
                val s = w * 0.17f
                val col = APP_COLORS[r * 4 + c]
                if (f.dragA > 0f && r == 1 && c == 0) continue
                drawRoundRect(col, Offset(x + w * iconX(c) - s / 2f, y + h * iconY(r + 0) + h * 0.07f - s / 2f + h * 0.0f), Size(s, s), CornerRadius(s * 0.28f))
            }
            drawRoundRect(Color.White.copy(alpha = 0.14f), Offset(x + w * 0.05f, y + h * 0.9f), Size(w * 0.9f, h * 0.085f), CornerRadius(30f))
            for (i in 0..3) {
                val s = w * 0.14f
                drawRoundRect(APP_COLORS[12 + i], Offset(x + w * (0.16f + 0.227f * i) - s / 2f, y + h * 0.9f + h * 0.0425f - s / 2f), Size(s, s), CornerRadius(s * 0.28f))
            }
        }
        1 -> { // shorts
            val base = Math.floor(f.shortIdx.toDouble()).toInt()
            val fr = f.shortIdx - base
            shortCard(base, -fr * h, f, ink, x, y, w, h, true)
            if (fr > 0.001f) shortCard(base + 1, (1f - fr) * h, f, ink, x, y, w, h, false)
            if (f.pauseA > 0f) {
                val c = Offset(x + w / 2f, y + h / 2f)
                drawCircle(Color.Black.copy(alpha = 0.5f * f.pauseA), w * 0.16f * (0.8f + 0.2f * f.pauseA), c)
                val bw = w * 0.035f
                drawRoundRect(Color.White.copy(alpha = f.pauseA), Offset(c.x - bw * 1.6f, c.y - w * 0.06f), Size(bw, w * 0.12f), CornerRadius(4f))
                drawRoundRect(Color.White.copy(alpha = f.pauseA), Offset(c.x + bw * 0.6f, c.y - w * 0.06f), Size(bw, w * 0.12f), CornerRadius(4f))
            }
        }
        2 -> { // video
            drawRect(Color(0xFF0F1220), Offset(x, y), Size(w, h))
            val vh = h * 0.3f
            val vy = y + h * 0.1f
            drawRect(Brush.linearGradient(listOf(Color(0xFF3B1E7A), Color(0xFF0E5A8A)), Offset(x, vy), Offset(x + w, vy + vh)), Offset(x, vy), Size(w, vh))
            val c = Offset(x + w / 2f, vy + vh / 2f)
            drawCircle(Color.Black.copy(alpha = 0.4f), w * 0.09f, c)
            val tri = Path().apply { moveTo(c.x - w * 0.025f, c.y - w * 0.04f); lineTo(c.x + w * 0.045f, c.y); lineTo(c.x - w * 0.025f, c.y + w * 0.04f); close() }
            drawPath(tri, Color.White)
            val by = vy + vh - 14f
            drawRect(Color.White.copy(alpha = 0.25f), Offset(x + w * 0.04f, by), Size(w * 0.92f, 5f))
            drawRect(Color(0xFFFF2D55), Offset(x + w * 0.04f, by), Size(w * 0.92f * f.vid, 5f))
            drawCircle(Color(0xFFFF2D55), 9f, Offset(x + w * 0.04f + w * 0.92f * f.vid, by + 2.5f))
            for (i in 0..3) {
                val yy = vy + vh + h * 0.04f + i * h * 0.12f
                drawRoundRect(Color.White.copy(alpha = 0.1f), Offset(x + w * 0.04f, yy), Size(w * 0.36f, h * 0.09f), CornerRadius(10f))
                drawRoundRect(Color.White.copy(alpha = 0.55f), Offset(x + w * 0.44f, yy + h * 0.01f), Size(w * 0.46f, 7f), CornerRadius(4f))
                drawRoundRect(Color.White.copy(alpha = 0.25f), Offset(x + w * 0.44f, yy + h * 0.045f), Size(w * 0.3f, 6f), CornerRadius(3f))
            }
        }
        3 -> { // browser
            drawRect(Color(0xFFF4F5FB), Offset(x, y), Size(w, h))
            val off = f.scrollY * h * 0.75f
            for (i in 0..7) {
                val yy = y + h * 0.16f + i * h * 0.26f - off
                val col = APP_COLORS[(i * 3) % 16]
                drawRoundRect(Brush.linearGradient(listOf(col, col.copy(alpha = 0.55f)), Offset(x, yy), Offset(x + w, yy + h * 0.16f)), Offset(x + w * 0.05f, yy), Size(w * 0.9f, h * 0.16f), CornerRadius(20f))
                drawRoundRect(Color(0xFF2A2F45), Offset(x + w * 0.05f, yy + h * 0.18f), Size(w * 0.6f, 8f), CornerRadius(4f))
                drawRoundRect(Color(0x552A2F45), Offset(x + w * 0.05f, yy + h * 0.21f), Size(w * 0.8f, 6f), CornerRadius(3f))
            }
            drawRect(Color.White, Offset(x, y), Size(w, h * 0.1f))
            drawRoundRect(Color(0xFFE4E7F5), Offset(x + w * 0.06f, y + h * 0.035f), Size(w * 0.88f, h * 0.045f), CornerRadius(30f))
            txt(ink, "airflow.app", x + w * 0.12f, y + h * 0.066f, w * 0.055f, Color(0xFF555B78))
        }
        else -> { // keyboard
            drawRect(Color(0xFF14172A), Offset(x, y), Size(w, h))
            drawRoundRect(Color.White.copy(alpha = 0.1f), Offset(x + w * 0.05f, y + h * 0.1f), Size(w * 0.9f, h * 0.08f), CornerRadius(30f))
            txt(ink, if (f.typed.isEmpty()) "Search..." else f.typed + "|", x + w * 0.1f, y + h * 0.152f, w * 0.075f,
                if (f.typed.isEmpty()) Color.White.copy(alpha = 0.4f) else Color.White, f.typed.isNotEmpty())
            drawRect(Color(0xFF1E2238), Offset(x, y + h * 0.56f), Size(w, h * 0.44f))
            val rows = arrayOf("QWERTYUIOP", "ASDFGHJKL", "ZXCVBNM")
            for (r in rows.indices) for (i in rows[r].indices) {
                val ch = rows[r][i]
                val kp = keyPos(ch)
                val kw = w * 0.085f; val kh = h * 0.07f
                val pressed = ch == f.pressedKey
                drawRoundRect(if (pressed) Color(0xFF22D3EE) else Color.White.copy(alpha = 0.16f), Offset(x + kp.x * w - kw / 2f, y + kp.y * h - kh / 2f), Size(kw, kh), CornerRadius(10f))
                txt(ink, ch.toString(), x + kp.x * w, y + kp.y * h + kh * 0.18f, kh * 0.5f, if (pressed) Color.Black else Color.White, false, android.graphics.Paint.Align.CENTER)
            }
        }
    }
}

private fun DrawScope.shortCard(idx: Int, dy: Float, f: Frame, ink: Ink, x: Float, y: Float, w: Float, h: Float, current: Boolean) {
    val col = CARD_COLORS[idx.mod(CARD_COLORS.size)]
    val top = y + dy
    drawRect(Brush.verticalGradient(listOf(col.first, col.second), top, top + h), Offset(x, top), Size(w, h))
    drawCircle(Color.White.copy(alpha = 0.14f), w * 0.3f, Offset(x + w * 0.45f, top + h * 0.38f))
    drawCircle(Color.White.copy(alpha = 0.2f), w * 0.16f, Offset(x + w * 0.45f, top + h * 0.38f))
    txt(ink, "SHORT ${idx + 1}", x + w * 0.45f, top + h * 0.395f, w * 0.07f, Color.White, true, android.graphics.Paint.Align.CENTER)
    drawRoundRect(Color.White.copy(alpha = 0.85f), Offset(x + w * 0.05f, top + h * 0.86f), Size(w * 0.5f, 8f), CornerRadius(4f))
    drawRoundRect(Color.White.copy(alpha = 0.45f), Offset(x + w * 0.05f, top + h * 0.9f), Size(w * 0.35f, 6f), CornerRadius(3f))
    // heart
    val hc = Offset(x + w * 0.9f, top + h * 0.6f)
    val like = if (current && idx == 3) f.liked else 0f
    val hs = w * 0.05f * (1f + 0.5f * like)
    val heart = Path().apply {
        moveTo(hc.x, hc.y + hs)
        cubicTo(hc.x - hs * 2f, hc.y - hs * 0.2f, hc.x - hs * 0.8f, hc.y - hs * 1.6f, hc.x, hc.y - hs * 0.6f)
        cubicTo(hc.x + hs * 0.8f, hc.y - hs * 1.6f, hc.x + hs * 2f, hc.y - hs * 0.2f, hc.x, hc.y + hs)
    }
    drawPath(heart, if (like > 0.3f) Color(0xFFFF2D55) else Color.White.copy(alpha = 0.9f))
    if (like > 0f && like < 1.1f && current && idx == 3) {
        drawCircle(Color(0xFFFF2D55).copy(alpha = (1f - like).coerceIn(0f, 1f)), w * 0.3f * like, Offset(x + w * 0.5f, top + h * 0.5f), style = Stroke(4f))
    }
    drawCircle(Color.White.copy(alpha = 0.5f), w * 0.04f, Offset(hc.x, top + h * 0.72f))
    drawCircle(Color.White.copy(alpha = 0.5f), w * 0.04f, Offset(hc.x, top + h * 0.8f))
}

// =============================================================================================
// Screen
// =============================================================================================

@Composable
fun DemoScreen(goTest: () -> Unit) {
    val c = Air.c
    val scope = rememberCoroutineScope()
    val prog = remember { Animatable(0f) }
    var idx by remember { mutableIntStateOf(0) }
    var playing by remember { mutableStateOf(true) }
    var nonce by remember { mutableIntStateOf(0) }
    val frame = remember { Frame() }
    val ink = remember { Ink() }
    val scene = SCENES[idx]

    LaunchedEffect(idx, playing, nonce) {
        if (playing) {
            val remain = ((1f - prog.value) * SCENES[idx].ms).toInt().coerceAtLeast(1)
            prog.animateTo(1f, tween(remain, easing = LinearEasing))
            prog.snapTo(0f)
            idx = (idx + 1) % SCENES.size
        }
    }

    fun jump(i: Int) {
        scope.launch { prog.snapTo(0f); idx = ((i % SCENES.size) + SCENES.size) % SCENES.size; nonce++ }
    }

    val step by remember(idx) { derivedStateOf { (prog.value * scene.steps.size).toInt().coerceIn(0, scene.steps.size - 1) } }
    val accent = if (scene.cursor) c.a3 else c.a2

    AirScroll {
        ScreenHeader("Interactive tour", "See exactly how every gesture works")

        // ---- stage
        Box(
            Modifier.fillMaxWidth().height(340.dp).airReveal(0)
                .clip(RoundedCornerShape(30.dp))
                .background(Brush.verticalGradient(listOf(Color(0xFF070914), Color(0xFF111633))))
                .border(1.dp, Brush.linearGradient(listOf(c.a2, c.a1, c.a3)), RoundedCornerShape(30.dp))
        ) {
            Canvas(Modifier.fillMaxWidth().height(340.dp).padding(10.dp)) {
                frame.reset()
                scene.run(prog.value.coerceIn(0f, 1f), frame)
                drawStage(frame, ink, Color.Black, c.a2.copy(alpha = 1f), c.a2, c.a3, c.warn)
            }
            Box(Modifier.padding(12.dp).align(Alignment.TopStart)) {
                Pill(if (scene.cursor) "CURSOR MODE" else "GESTURES", accent)
            }
        }

        // ---- title
        Column(Modifier.airReveal(0), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            AnimatedContent(
                targetState = idx,
                transitionSpec = { (slideInVertically { it / 2 } + fadeIn(tween(300))) togetherWith (slideOutVertically { -it / 2 } + fadeOut(tween(180))) },
                label = "title"
            ) { i ->
                Column {
                    Text("${i + 1} / ${SCENES.size}", color = accent, fontWeight = FontWeight.Black, fontSize = 12.sp, letterSpacing = 2.sp)
                    Text(SCENES[i].title, style = MaterialTheme.typography.titleLarge, color = c.text)
                    Text(SCENES[i].sub, style = MaterialTheme.typography.bodyMedium, color = c.dim)
                }
            }
        }

        // ---- player
        GlassCard(Modifier.fillMaxWidth()) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly, verticalAlignment = Alignment.CenterVertically) {
                RoundBtn("<", { jump(idx - 1) })
                Box(
                    Modifier.size(58.dp).clip(CircleShape).background(Brush.linearGradient(listOf(c.a1, c.a2)))
                        .pressClick { playing = !playing },
                    contentAlignment = Alignment.Center
                ) { PlayGlyph(playing) }
                RoundBtn(">", { jump(idx + 1) })
            }
            Box(
                Modifier.fillMaxWidth().height(22.dp).pointerInput(idx) {
                    detectTapGestures { o ->
                        scope.launch { prog.snapTo((o.x / size.width).coerceIn(0f, 0.98f)); nonce++ }
                    }
                }
            ) {
                Canvas(Modifier.fillMaxWidth().height(22.dp)) {
                    val y = size.height / 2f
                    drawLine(c.glassHi, Offset(0f, y), Offset(size.width, y), 8f, StrokeCap.Round)
                    val px = size.width * prog.value
                    drawLine(Brush.horizontalGradient(listOf(c.a2, accent)), Offset(0f, y), Offset(px.coerceAtLeast(1f), y), 8f, StrokeCap.Round)
                    drawCircle(accent.copy(alpha = 0.3f), 14f, Offset(px, y))
                    drawCircle(Color.White, 7f, Offset(px, y))
                }
            }
        }

        // ---- steps
        SectionCard("How to do it") {
            scene.steps.forEachIndexed { i, s ->
                val on = i == step
                val bg by animateColorAsState(if (on) accent else c.glassHi, tween(300), label = "stepbg")
                val sc by animateFloatAsState(if (on) 1.12f else 1f, tween(300), label = "stepsc")
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        Modifier.size(28.dp).clip(CircleShape).background(bg)
                            .then(Modifier),
                        contentAlignment = Alignment.Center
                    ) {
                        Text("${i + 1}", color = if (on) Color.White else c.dim, fontWeight = FontWeight.Black, fontSize = (13 * sc).sp)
                    }
                    Spacer(Modifier.width(12.dp))
                    Text(s, color = if (on) c.text else c.dim, fontWeight = if (on) FontWeight.Bold else FontWeight.Normal)
                }
            }
        }

        // ---- chapters
        Column(Modifier.airReveal(0), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("All lessons", style = MaterialTheme.typography.titleMedium, color = c.text)
            val ls = rememberLazyListState()
            LaunchedEffect(idx) { ls.animateScrollToItem((idx - 1).coerceAtLeast(0)) }
            LazyRow(state = ls, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                itemsIndexed(SCENES) { i, s ->
                    val on = i == idx
                    val col = if (s.cursor) c.a3 else c.a2
                    val bg by animateColorAsState(if (on) col else c.glassHi, tween(250), label = "chip")
                    Box(
                        Modifier.clip(RoundedCornerShape(50)).background(bg).pressClick { jump(i) }
                            .padding(horizontal = 14.dp, vertical = 9.dp)
                    ) { Text(s.title, color = if (on) Color.White else c.text, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, maxLines = 1) }
                }
            }
        }

        SectionCard("Golden rules") {
            Text("1. Keep your hand 40 to 60 cm from the camera, palm facing it.", color = c.text)
            Text("2. Use good light. Avoid a bright window behind you.", color = c.text)
            Text("3. Move smoothly, then pause. Hold poses for about half a second.", color = c.text)
            Text("4. Everything is processed on your phone. Nothing is uploaded.", color = c.text)
        }

        AirButton("Try it live with your camera", goTest, Modifier.fillMaxWidth(), icon = IconKind.SCAN)
    }
}

@Composable
private fun RoundBtn(label: String, onClick: () -> Unit) {
    val c = Air.c
    Box(
        Modifier.size(46.dp).clip(CircleShape).background(c.glassHi).pressClick(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Canvas(Modifier.size(18.dp)) {
            val left = label == "<"
            val p = Path().apply {
                if (left) { moveTo(size.width * 0.85f, 0f); lineTo(size.width * 0.15f, size.height / 2f); lineTo(size.width * 0.85f, size.height) }
                else { moveTo(size.width * 0.15f, 0f); lineTo(size.width * 0.85f, size.height / 2f); lineTo(size.width * 0.15f, size.height) }
            }
            drawPath(p, c.text, style = Stroke(4f, cap = StrokeCap.Round))
        }
    }
}

@Composable
private fun PlayGlyph(playing: Boolean) {
    Canvas(Modifier.size(22.dp)) {
        if (playing) {
            drawRoundRect(Color.White, Offset(size.width * 0.15f, 0f), Size(size.width * 0.27f, size.height), CornerRadius(4f))
            drawRoundRect(Color.White, Offset(size.width * 0.58f, 0f), Size(size.width * 0.27f, size.height), CornerRadius(4f))
        } else {
            val p = Path().apply { moveTo(size.width * 0.2f, 0f); lineTo(size.width, size.height / 2f); lineTo(size.width * 0.2f, size.height); close() }
            drawPath(p, Color.White)
        }
    }
}

// =============================================================================================
// Small looping hand used by gesture cards
// =============================================================================================

@Composable
fun MiniHand(g: Gesture, modifier: Modifier = Modifier) {
    val c = Air.c
    val inf = rememberInfiniteTransition(label = "mh")
    val t = inf.animateFloat(0f, 1f, infiniteRepeatable(tween(2600, easing = LinearEasing)), label = "t")
    Canvas(modifier) {
        val k = smooth(seg(t.value, 0.1f, 0.4f)) - smooth(seg(t.value, 0.8f, 0.95f))
        val name = g.name
        val swipe = g.isSwipe
        val pose = if (swipe) (if (name.startsWith("FIST")) Poses.FIST else Poses.OPEN) else lerpPose(Poses.OPEN, Poses.forGesture(g), k)
        var ox = 0f
        var oy = 0f
        if (swipe) {
            val m = easeInOut(seg(t.value, 0.15f, 0.75f)) - 0.5f
            val d = size.minDimension * 0.5f
            when {
                name.endsWith("UP") -> oy = -m * d
                name.endsWith("DOWN") -> oy = m * d
                name.endsWith("LEFT") -> ox = -m * d
                else -> ox = m * d
            }
        }
        val s = size.height * 0.62f
        val pts = computeHand(pose)
        drawHand(pts, Offset(size.width / 2f + ox, size.height * 0.92f + oy), s, c.a2, c.a3, alpha = 1f, glow = 1f, lineW = 2.6f, dotR = 3.2f)
    }
}
