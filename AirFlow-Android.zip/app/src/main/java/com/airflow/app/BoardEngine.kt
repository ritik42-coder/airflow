package com.airflow.app

import android.content.Context
import java.io.File
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

// ---------------------------------------------------------------------------------------------
// Air Board: the board itself. Scenes, pages, snapped shapes, a small 3D science library and a
// project file that survives closing the app.
// ---------------------------------------------------------------------------------------------

enum class BoardScene(val label: String) {
    CAMERA("Camera"), DARK("Board"), WHITE("White"), GRAPH("Graph"), CHALK("Chalk")
}

enum class ObjMode(val label: String) {
    BALL("Ball & stick"), WIRE("Wireframe"), SPACE("Space fill")
}

class Atom(val el: String, val x: Float, val y: Float, val z: Float)

class Bond(val a: Int, val b: Int, val order: Int)

class Molecule(val name: String, val about: String, val atoms: List<Atom>, val bonds: List<Bond>)

/** One atom after rotation, ready to project. */
class P3(val x: Float, val y: Float, val z: Float, val el: String)

object Elements {
    fun color(el: String): Long = when (el) {
        "H" -> 0xFFEFF4FF
        "C" -> 0xFF3E4658
        "O" -> 0xFFFF5F5F
        "N" -> 0xFF4F8BFF
        "Cl" -> 0xFF34F5A5
        "Na" -> 0xFFB07CFF
        "P" -> 0xFFFFA24A
        else -> 0xFF9AA7CB
    }

    fun radius(el: String): Float = when (el) {
        "H" -> 0.30f
        "C" -> 0.52f
        "O" -> 0.50f
        "N" -> 0.50f
        "Cl" -> 0.66f
        "Na" -> 0.72f
        else -> 0.50f
    }

    fun space(el: String): Float = when (el) {
        "H" -> 0.52f
        "C" -> 0.82f
        "O" -> 0.78f
        "N" -> 0.78f
        "Cl" -> 0.95f
        "Na" -> 1.05f
        else -> 0.80f
    }
}

object Molecules {

    private fun ring(cx: Float, cy: Float, r: Float, n: Int, z: Float = 0f): List<Atom> {
        val out = ArrayList<Atom>()
        for (i in 0 until n) {
            val t = 2 * PI * i / n
            out.add(Atom("C", cx + (cos(t) * r).toFloat(), cy + (sin(t) * r).toFloat(), z))
        }
        return out
    }

    private fun methane(): Molecule {
        val atoms = arrayListOf(Atom("C", 0f, 0f, 0f))
        val s = 0.63f
        atoms.add(Atom("H", s, s, s))
        atoms.add(Atom("H", s, -s, -s))
        atoms.add(Atom("H", -s, s, -s))
        atoms.add(Atom("H", -s, -s, s))
        val bonds = (1..4).map { Bond(0, it, 1) }
        return Molecule("Methane", "CH4 · tetrahedral, 109.5°", atoms, bonds)
    }

    private fun water(): Molecule = Molecule(
        "Water", "H2O · bent, 104.5°",
        listOf(
            Atom("O", 0f, 0f, 0f),
            Atom("H", 0.757f, 0.586f, 0f),
            Atom("H", -0.757f, 0.586f, 0f)
        ),
        listOf(Bond(0, 1, 1), Bond(0, 2, 1))
    )

    private fun co2(): Molecule = Molecule(
        "Carbon dioxide", "CO2 · linear, two double bonds",
        listOf(Atom("C", 0f, 0f, 0f), Atom("O", 1.16f, 0f, 0f), Atom("O", -1.16f, 0f, 0f)),
        listOf(Bond(0, 1, 2), Bond(0, 2, 2))
    )

    private fun ammonia(): Molecule = Molecule(
        "Ammonia", "NH3 · pyramidal, 107°",
        listOf(
            Atom("N", 0f, 0f, 0f),
            Atom("H", 0.94f, -0.33f, 0f),
            Atom("H", -0.47f, -0.33f, 0.81f),
            Atom("H", -0.47f, -0.33f, -0.81f)
        ),
        listOf(Bond(0, 1, 1), Bond(0, 2, 1), Bond(0, 3, 1))
    )

    private fun benzene(): Molecule {
        val atoms = ArrayList<Atom>()
        val bonds = ArrayList<Bond>()
        val r = 1.39f
        for (i in 0 until 6) {
            val t = 2 * PI * i / 6
            atoms.add(Atom("C", (cos(t) * r).toFloat(), (sin(t) * r).toFloat(), 0f))
        }
        for (i in 0 until 6) {
            val t = 2 * PI * i / 6
            atoms.add(Atom("H", (cos(t) * 2.48f).toFloat(), (sin(t) * 2.48f).toFloat(), 0f))
        }
        for (i in 0 until 6) {
            bonds.add(Bond(i, (i + 1) % 6, if (i % 2 == 0) 2 else 1))
            bonds.add(Bond(i, i + 6, 1))
        }
        return Molecule("Benzene", "C6H6 · aromatic ring", atoms, bonds)
    }

    private fun ethanol(): Molecule = Molecule(
        "Ethanol", "C2H5OH · the alcohol in drinks",
        listOf(
            Atom("C", -0.76f, 0f, 0f),
            Atom("C", 0.76f, 0f, 0f),
            Atom("O", 1.62f, 1.02f, 0f),
            Atom("H", -1.14f, 1.02f, 0f),
            Atom("H", -1.14f, -0.51f, 0.89f),
            Atom("H", -1.14f, -0.51f, -0.89f),
            Atom("H", 1.14f, -0.51f, 0.89f),
            Atom("H", 1.14f, -0.51f, -0.89f),
            Atom("H", 2.46f, 0.72f, 0f)
        ),
        listOf(
            Bond(0, 1, 1), Bond(1, 2, 1), Bond(0, 3, 1), Bond(0, 4, 1), Bond(0, 5, 1),
            Bond(1, 6, 1), Bond(1, 7, 1), Bond(2, 8, 1)
        )
    )

    private fun salt(): Molecule {
        val atoms = ArrayList<Atom>()
        val bonds = ArrayList<Bond>()
        var idx = 0
        for (x in -1..1) for (y in -1..1) for (z in -1..1) {
            val el = if ((x + y + z + 3) % 2 == 0) "Na" else "Cl"
            atoms.add(Atom(el, x * 1.1f, y * 1.1f, z * 1.1f))
            idx++
        }
        // bond each atom to its neighbour along x only, so the lattice stays readable
        for (xi in 0..1) for (yi in 0..2) for (zi in 0..2) {
            val a = xi * 9 + yi * 3 + zi
            bonds.add(Bond(a, a + 9, 1))
        }
        return Molecule("NaCl lattice", "rock salt · ionic crystal", atoms, bonds)
    }

    private fun diamond(): Molecule {
        val atoms = arrayListOf(Atom("C", 0f, 0f, 0f))
        val s = 0.9f
        atoms.add(Atom("C", s, s, s))
        atoms.add(Atom("C", s, -s, -s))
        atoms.add(Atom("C", -s, s, -s))
        atoms.add(Atom("C", -s, -s, s))
        val bonds = ArrayList<Bond>()
        for (i in 1..4) bonds.add(Bond(0, i, 1))
        bonds.add(Bond(1, 2, 1))
        bonds.add(Bond(3, 4, 1))
        return Molecule("Diamond", "carbon · tetrahedral network", atoms, bonds)
    }

    private fun graphite(): Molecule {
        val atoms = ArrayList<Atom>()
        val bonds = ArrayList<Bond>()
        val r = 0.78f
        for (layer in 0 until 2) {
            val base = atoms.size
            for (i in 0 until 6) {
                val t = 2 * PI * i / 6
                atoms.add(Atom("C", (cos(t) * r).toFloat(), layer * 1.7f - 0.85f, (sin(t) * r).toFloat()))
            }
            for (i in 0 until 6) bonds.add(Bond(base + i, base + (i + 1) % 6, 1))
        }
        return Molecule("Graphite", "carbon · soft layers", atoms, bonds)
    }

    private fun dna(): Molecule {
        val atoms = ArrayList<Atom>()
        val bonds = ArrayList<Bond>()
        val pairs = 11
        for (i in 0 until pairs) {
            val t = i * 0.62f
            val y = -2.9f + i * 0.58f
            atoms.add(Atom("P", (cos(t) * 1.15f).toFloat(), y, (sin(t) * 1.15f).toFloat()))
            atoms.add(Atom("P", (cos(t + PI) * 1.15f).toFloat(), y, (sin(t + PI) * 1.15f).toFloat()))
            val a = i * 2
            bonds.add(Bond(a, a + 1, 1))
            if (i > 0) {
                bonds.add(Bond(a - 2, a, 1))
                bonds.add(Bond(a - 1, a + 1, 1))
            }
        }
        return Molecule("DNA", "double helix · 11 base pairs", atoms, bonds)
    }

    private fun cyclohexane(): Molecule {
        val atoms = ArrayList<Atom>(ring(0f, 0f, 1.4f, 6))
        val bonds = ArrayList<Bond>()
        for (i in 0 until 6) bonds.add(Bond(i, (i + 1) % 6, 1))
        return Molecule("Cyclohexane", "C6H12 · chair ring", atoms, bonds)
    }

    val all: List<Molecule> = listOf(
        methane(), water(), co2(), ammonia(), benzene(), ethanol(), cyclohexane(),
        salt(), diamond(), graphite(), dna()
    )
}

/** Rotates a molecule and returns depth-sorted atoms. */
fun Molecule.project(ax: Float, ay: Float, explode: Float): List<P3> {
    val ca = cos(ax)
    val sa = sin(ax)
    val cb = cos(ay)
    val sb = sin(ay)
    val k = 1f + explode
    val out = ArrayList<P3>(atoms.size)
    for (a in atoms) {
        val x1 = a.x * cb + a.z * sb
        val z1 = -a.x * sb + a.z * cb
        val y1 = a.y * ca - z1 * sa
        val z2 = a.y * sa + z1 * ca
        out.add(P3(x1 * k, y1 * k, z2 * k, a.el))
    }
    return out
}

// ---------------------------------------------------------------------------------------------
// Shape snapping: hold still at the end of a stroke and it becomes a clean line, circle or box.
// ---------------------------------------------------------------------------------------------

object Shapes {

    fun snap(pts: ArrayList<Float>): ArrayList<Float>? {
        val n = pts.size / 2
        if (n < 5) return null
        var minX = Float.MAX_VALUE
        var minY = Float.MAX_VALUE
        var maxX = -Float.MAX_VALUE
        var maxY = -Float.MAX_VALUE
        var len = 0f
        var i = 0
        while (i < n) {
            val x = pts[i * 2]
            val y = pts[i * 2 + 1]
            if (x < minX) minX = x
            if (x > maxX) maxX = x
            if (y < minY) minY = y
            if (y > maxY) maxY = y
            if (i > 0) len += hypot(x - pts[(i - 1) * 2], y - pts[(i - 1) * 2 + 1])
            i++
        }
        val bw = maxX - minX
        val bh = maxY - minY
        val diag = hypot(bw, bh)
        if (diag < 30f || len < 40f) return null

        val sx = pts[0]
        val sy = pts[1]
        val ex = pts[(n - 1) * 2]
        val ey = pts[(n - 1) * 2 + 1]
        val chord = hypot(ex - sx, ey - sy)

        // a straight stroke?
        if (chord > diag * 0.72f) {
            var dev = 0f
            val ux = (ex - sx) / chord
            val uy = (ey - sy) / chord
            i = 0
            while (i < n) {
                val px = pts[i * 2] - sx
                val py = pts[i * 2 + 1] - sy
                val d = abs(px * uy - py * ux)
                if (d > dev) dev = d
                i++
            }
            if (dev < chord * 0.10f) return arrayListOf(sx, sy, ex, ey)
        }

        // closed: circle or rectangle
        if (chord < diag * 0.30f) {
            var area = 0f
            i = 0
            while (i < n) {
                val x1 = pts[i * 2]
                val y1 = pts[i * 2 + 1]
                val j = (i + 1) % n
                val x2 = pts[j * 2]
                val y2 = pts[j * 2 + 1]
                area += x1 * y2 - x2 * y1
                i++
            }
            area = abs(area) / 2f
            // a box fills more than the ellipse inside its own bounding box, a circle fills about the same
            val ellipse = PI.toFloat() * (bw / 2f) * (bh / 2f)
            val boxy = ellipse > 1f && area > ellipse * 1.12f
            if (!boxy) {
                val out = ArrayList<Float>()
                val cx = (minX + maxX) / 2f
                val cy = (minY + maxY) / 2f
                val rx = bw / 2f
                val ry = bh / 2f
                for (k in 0..64) {
                    val t = 2 * PI * k / 64
                    out.add(cx + (cos(t) * rx).toFloat())
                    out.add(cy + (sin(t) * ry).toFloat())
                }
                return out
            }
            if (bw > 30f && bh > 30f) {
                return arrayListOf(
                    minX, minY, maxX, minY, maxX, maxY, minX, maxY, minX, minY
                )
            }
        }
        return null
    }
}

// ---------------------------------------------------------------------------------------------
// Project file: every page, every stroke, the scene and the object. Plain text, easy to debug.
// ---------------------------------------------------------------------------------------------

class BoardSave(
    val pages: List<ArrayList<Stroke>>,
    val cur: Int,
    val scene: Int,
    val obj: Int
)

object BoardStore {

    private fun file(ctx: Context) = File(ctx.filesDir, "airboard.txt")

    fun save(ctx: Context, pages: List<ArrayList<Stroke>>, cur: Int, scene: Int, obj: Int): Boolean = try {
        file(ctx).writeText(encode(pages, cur, scene, obj))
        true
    } catch (e: Exception) {
        false
    }

    /** Pure text form of the board, so it can be tested and inspected. */
    fun encode(pages: List<ArrayList<Stroke>>, cur: Int, scene: Int, obj: Int): String {
        val sb = StringBuilder()
        sb.append("AIRBOARD2\n")
        sb.append("meta|").append(cur).append('|').append(scene).append('|').append(obj).append('\n')
        for (page in pages) {
            sb.append("page|").append(page.size).append('\n')
            for (s in page) {
                sb.append("s|").append(s.brush.name).append('|').append(s.color).append('|')
                    .append(s.width).append('|').append(s.seed).append('|').append(s.pts.size).append('|')
                var i = 0
                while (i < s.pts.size) {
                    if (i > 0) sb.append(';')
                    sb.append(s.pts[i].toInt()).append(',').append(s.pts[i + 1].toInt())
                    i += 2
                }
                sb.append('\n')
            }
        }
        return sb.toString()
    }

    fun load(ctx: Context): BoardSave? = try {
        val f = file(ctx)
        if (!f.exists()) null else decode(f.readText())
    } catch (e: Exception) {
        null
    }

    fun decode(text: String): BoardSave? = try {
        run {
            val pages = ArrayList<ArrayList<Stroke>>()
            var cur = 0
            var scene = 0
            var obj = -1
            var current: ArrayList<Stroke>? = null
            for (line in text.split("\n")) {
                when {
                    line.startsWith("meta|") -> {
                        val p = line.split("|")
                        cur = p.getOrNull(1)?.toIntOrNull() ?: 0
                        scene = p.getOrNull(2)?.toIntOrNull() ?: 0
                        obj = p.getOrNull(3)?.toIntOrNull() ?: -1
                    }
                    line.startsWith("page|") -> {
                        current = ArrayList()
                        pages.add(current)
                    }
                    line.startsWith("s|") -> {
                        val p = line.split("|")
                        if (p.size >= 7) {
                            val brush = try { Brush.valueOf(p[1]) } catch (e: Exception) { Brush.NEON }
                            val color = p[2].toIntOrNull() ?: 0xFF22D3EE.toInt()
                            val width = p[3].toFloatOrNull() ?: 8f
                            val seed = p[4].toIntOrNull() ?: 1
                            val s = Stroke(brush, color, width, seed)
                            for (pair in p[6].split(";")) {
                                val xy = pair.split(",")
                                if (xy.size == 2) {
                                    s.pts.add(xy[0].toFloatOrNull() ?: 0f)
                                    s.pts.add(xy[1].toFloatOrNull() ?: 0f)
                                }
                            }
                            current?.add(s)
                        }
                    }
                }
            }
            if (pages.isEmpty()) return null
            BoardSave(pages, cur.coerceIn(0, pages.size - 1), scene, obj)
        }
    } catch (e: Exception) {
        null
    }

    fun clear(ctx: Context) {
        try {
            file(ctx).delete()
        } catch (e: Exception) {
        }
    }
}
