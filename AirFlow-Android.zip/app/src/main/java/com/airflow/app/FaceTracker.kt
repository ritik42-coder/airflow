package com.airflow.app

import android.content.Context
import android.graphics.Bitmap
import android.util.Log
import com.google.mediapipe.framework.image.BitmapImageBuilder
import com.google.mediapipe.tasks.core.BaseOptions
import com.google.mediapipe.tasks.core.Delegate
import com.google.mediapipe.tasks.vision.core.RunningMode
import com.google.mediapipe.tasks.vision.facelandmarker.FaceLandmarker

/** What the face model saw in one frame. Everything is normalised 0..1 in the mirrored (selfie) picture. */
class FaceFrame(
    val noseX: Float,
    val noseY: Float,
    /** How far the nose sits to the side of the eye line, in eye widths (head turn left/right). */
    val yaw: Float,
    /** How far the nose sits below the eye line, in face heights (head up/down). */
    val pitch: Float,
    /** Head tilt in degrees (ear toward shoulder). */
    val rollDeg: Float,
    val blinkL: Float,
    val blinkR: Float,
    val jawOpen: Float,
    val smile: Float,
    val browUp: Float,
    /** Face width as a share of the picture: warns when the user is too far away. */
    val size: Float
)

/**
 * Face landmarks + blendshapes from MediaPipe, on the same camera frame the hand model uses.
 * Created lazily (only when Hands-free is on) and kept to one face: the biggest one.
 */
class FaceTracker(private val context: Context) {
    private var model: FaceLandmarker? = null
    private var gpu = false
    private var failed = false
    @Volatile var lastMs = 0f
        private set

    private fun build(useGpu: Boolean): FaceLandmarker {
        val b = BaseOptions.builder().setModelAssetPath("face_landmarker.task")
        if (useGpu) b.setDelegate(Delegate.GPU)
        val o = FaceLandmarker.FaceLandmarkerOptions.builder()
            .setBaseOptions(b.build())
            .setRunningMode(RunningMode.VIDEO)
            .setNumFaces(1)
            .setOutputFaceBlendshapes(true)
            .setMinFaceDetectionConfidence(0.5f)
            .setMinFacePresenceConfidence(0.5f)
            .setMinTrackingConfidence(0.5f)
            .build()
        return FaceLandmarker.createFromOptions(context, o)
    }

    private fun ensure(): FaceLandmarker? {
        model?.let { return it }
        if (failed) return null
        // the hand model already proved whether the GPU works here (Prefs.gpuState 2 = yes)
        if (Prefs.gpuHands && Prefs.gpuState == 2) {
            try { model = build(true); gpu = true; return model } catch (e: Throwable) { Log.w("AirFlow", "GPU face model unavailable", e) }
        }
        return try { model = build(false); model } catch (e: Throwable) {
            Log.e("AirFlow", "Face model failed to load", e)
            failed = true
            AirFlowState.error.value = "Could not start the face model: ${e.message}. Is face_landmarker.task in assets?"
            null
        }
    }

    /** Runs on the camera thread. Returns null when no face is seen. */
    fun detect(bmp: Bitmap, tsMs: Long): FaceFrame? {
        val m = ensure() ?: return null
        val t0 = System.nanoTime()
        val r = try {
            m.detectForVideo(BitmapImageBuilder(bmp).build(), tsMs)
        } catch (e: Throwable) {
            if (gpu) { // fall back to the CPU once
                try { m.close() } catch (_: Throwable) {}
                model = null; gpu = false
                try { model = build(false) } catch (_: Throwable) { failed = true }
            }
            return null
        }
        lastMs = (System.nanoTime() - t0) / 1_000_000f
        val faces = r.faceLandmarks()
        if (faces.isEmpty()) return null
        // the biggest face wins (nearest the camera)
        var best = 0
        var bestW = -1f
        for (i in faces.indices) {
            val f = faces[i]
            val w = Math.abs(f[263].x() - f[33].x())
            if (w > bestW) { bestW = w; best = i }
        }
        val f = faces[best]
        if (f.size < 400) return null
        val nose = f[1]
        val eyeLx = f[33].x(); val eyeLy = f[33].y()
        val eyeRx = f[263].x(); val eyeRy = f[263].y()
        val midX = (eyeLx + eyeRx) / 2f
        val midY = (eyeLy + eyeRy) / 2f
        val eyeW = Math.hypot((eyeRx - eyeLx).toDouble(), (eyeRy - eyeLy).toDouble()).toFloat().coerceAtLeast(0.01f)
        val faceH = Math.abs(f[152].y() - f[10].y()).coerceAtLeast(0.02f)
        val yaw = (nose.x() - midX) / eyeW
        val pitch = (nose.y() - midY) / faceH
        val roll = Math.toDegrees(Math.atan2((eyeRy - eyeLy).toDouble(), (eyeRx - eyeLx).toDouble())).toFloat()

        var bl = 0f; var br = 0f; var jaw = 0f; var sl = 0f; var sr = 0f; var brow = 0f
        val shapes = r.faceBlendshapes().orElse(null)?.getOrNull(best)
        if (shapes != null) {
            for (c in shapes) {
                when (c.categoryName()) {
                    "eyeBlinkLeft" -> bl = c.score()
                    "eyeBlinkRight" -> br = c.score()
                    "jawOpen" -> jaw = c.score()
                    "mouthSmileLeft" -> sl = c.score()
                    "mouthSmileRight" -> sr = c.score()
                    "browInnerUp" -> brow = c.score()
                }
            }
        }
        return FaceFrame(nose.x(), nose.y(), yaw, pitch, roll, bl, br, jaw, (sl + sr) / 2f, brow, bestW)
    }

    fun close() {
        try { model?.close() } catch (_: Throwable) {}
        model = null
    }
}
