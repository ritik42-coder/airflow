package com.airflow.app

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.LocalContentColor
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp

/** Every colour of the app. Two complete palettes with different personalities. */
@Immutable
data class AirColors(
    val dark: Boolean,
    val bg0: Color,
    val bg1: Color,
    val glass: Color,
    val glassHi: Color,
    val stroke: Color,
    val text: Color,
    val dim: Color,
    val a1: Color,
    val a2: Color,
    val a3: Color,
    val ok: Color,
    val warn: Color,
    val shadow: Color
)

/** "Aurora Night": deep space, neon aurora, star field and a glowing hand constellation. */
val DarkAir = AirColors(
    dark = true,
    bg0 = Color(0xFF04050D),
    bg1 = Color(0xFF0A0F26),
    glass = Color(0x14FFFFFF),
    glassHi = Color(0x26FFFFFF),
    stroke = Color(0x2EFFFFFF),
    text = Color(0xFFF3F6FF),
    dim = Color(0xFF9AA7CB),
    a1 = Color(0xFF8B5CFF),
    a2 = Color(0xFF22D3EE),
    a3 = Color(0xFFFF4FD8),
    ok = Color(0xFF34F5A5),
    warn = Color(0xFFFFA24A),
    shadow = Color(0xFF000000)
)

/** "Pearl Silk": bright pearl white, flowing silk ribbons, soft bokeh and pastel light. */
val LightAir = AirColors(
    dark = false,
    bg0 = Color(0xFFFBF8FF),
    bg1 = Color(0xFFEAF1FF),
    glass = Color(0xB8FFFFFF),
    glassHi = Color(0xE6FFFFFF),
    stroke = Color(0x2E6C4DFF),
    text = Color(0xFF14172B),
    dim = Color(0xFF5B6385),
    a1 = Color(0xFF6C4DFF),
    a2 = Color(0xFF0A9BE0),
    a3 = Color(0xFFFF5C9A),
    ok = Color(0xFF0FB77E),
    warn = Color(0xFFF0900B),
    shadow = Color(0xFF4A3FA8)
)

val LocalAir = staticCompositionLocalOf { DarkAir }

object Air {
    val c: AirColors
        @Composable get() = LocalAir.current
}

@Composable
private fun ac(c: Color): Color = animateColorAsState(c, tween(650), label = "airColor").value

/** Colours glide from one theme to the other instead of flipping. */
@Composable
private fun animatedAir(t: AirColors): AirColors = AirColors(
    dark = t.dark,
    bg0 = ac(t.bg0), bg1 = ac(t.bg1),
    glass = ac(t.glass), glassHi = ac(t.glassHi), stroke = ac(t.stroke),
    text = ac(t.text), dim = ac(t.dim),
    a1 = ac(t.a1), a2 = ac(t.a2), a3 = ac(t.a3),
    ok = ac(t.ok), warn = ac(t.warn), shadow = ac(t.shadow)
)

private val AirType: Typography = Typography().let { d ->
    d.copy(
        displayMedium = d.displayMedium.copy(fontWeight = FontWeight.Black, letterSpacing = (-1).sp),
        headlineLarge = d.headlineLarge.copy(fontWeight = FontWeight.Black, letterSpacing = (-0.5).sp),
        headlineMedium = d.headlineMedium.copy(fontWeight = FontWeight.ExtraBold, letterSpacing = (-0.3).sp),
        titleLarge = d.titleLarge.copy(fontWeight = FontWeight.Bold),
        titleMedium = d.titleMedium.copy(fontWeight = FontWeight.Bold, letterSpacing = 0.2.sp),
        labelLarge = d.labelLarge.copy(fontWeight = FontWeight.Bold, letterSpacing = 0.6.sp),
        bodyMedium = d.bodyMedium.copy(lineHeight = 21.sp),
        bodySmall = d.bodySmall.copy(lineHeight = 18.sp)
    )
}

@Composable
fun isAirDark(): Boolean {
    val mode by AirFlowState.themeMode.collectAsState()
    val sys = isSystemInDarkTheme()
    return when (mode) {
        1 -> false
        2 -> true
        else -> sys
    }
}

@Composable
fun AirTheme(content: @Composable () -> Unit) {
    val dark = isAirDark()
    val c = animatedAir(if (dark) DarkAir else LightAir)
    val scheme = if (dark) {
        darkColorScheme(
            primary = c.a2, onPrimary = Color(0xFF00131A),
            secondary = c.a1, tertiary = c.a3,
            background = c.bg0, onBackground = c.text,
            surface = c.bg1, onSurface = c.text,
            surfaceVariant = c.glassHi, onSurfaceVariant = c.dim,
            outline = c.stroke, error = Color(0xFFFF6B7A)
        )
    } else {
        lightColorScheme(
            primary = c.a1, onPrimary = Color.White,
            secondary = c.a2, tertiary = c.a3,
            background = c.bg0, onBackground = c.text,
            surface = Color.White, onSurface = c.text,
            surfaceVariant = Color(0xFFE6E9FA), onSurfaceVariant = c.dim,
            outline = c.stroke, error = Color(0xFFD93A4F)
        )
    }
    CompositionLocalProvider(LocalAir provides c, LocalContentColor provides c.text) {
        MaterialTheme(colorScheme = scheme, typography = AirType, content = content)
    }
}
