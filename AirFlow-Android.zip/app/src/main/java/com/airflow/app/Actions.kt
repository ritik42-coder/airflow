package com.airflow.app

/** Everything a gesture can do. AUTO means "pick the best action for the app that is open". */
enum class Action(val label: String) {
    AUTO("Auto (smart, changes per app)"),
    NONE("Off"),

    // Scrolling / paging
    NEXT("Next video / reel (big swipe up)"),
    PREVIOUS("Previous video / reel (big swipe down)"),
    PAGE_DOWN("Scroll page down (gentle)"),
    PAGE_UP("Scroll page up (gentle)"),
    SIDE_LEFT("Swipe left"),
    SIDE_RIGHT("Swipe right"),

    // Video controls
    TAP_CENTER("Tap screen centre (play / pause)"),
    LIKE("Like (double-tap / like button)"),
    SEEK_BACK("Rewind 10 s (double-tap left)"),
    SEEK_FORWARD("Forward 10 s (double-tap right)"),
    FULLSCREEN_ON("YouTube: enter fullscreen"),
    FULLSCREEN_OFF("YouTube: exit fullscreen"),

    // Any media app (Spotify, Netflix, podcasts, ...)
    MEDIA_PLAY_PAUSE("Media play / pause (any player)"),
    MEDIA_NEXT("Media next track"),
    MEDIA_PREVIOUS("Media previous track"),
    VOLUME_UP("Volume up"),
    VOLUME_DOWN("Volume down"),
    MUTE("Mute / unmute"),

    // Whole phone
    BACK("Back"),
    HOME("Home"),
    RECENTS("Recent apps"),
    NOTIFICATIONS("Open notifications"),
    QUICK_SETTINGS("Open quick settings"),
    SCREENSHOT("Take screenshot"),
    LOCK_SCREEN("Lock screen"),

    // Cursor mode and launching apps
    TOGGLE_CURSOR("Cursor mode on / off (hand mouse)"),
    OPEN_YOUTUBE("Open YouTube"),
    OPEN_CAMERA("Open camera"),
    OPEN_FAV_1("Open favorite app 1"),
    OPEN_FAV_2("Open favorite app 2"),
    OPEN_FAV_3("Open favorite app 3")
}

/** What kind of screen is in front of the user. */
enum class Ctx { FEED, YT_WATCH, PLAYER, MUSIC, GENERIC }

object Apps {
    val YOUTUBE = setOf(
        "com.google.android.youtube",
        "com.google.android.apps.youtube.mango"
    )

    /** Short-video / social feeds: big swipe = next item. */
    val FEED = setOf(
        "com.instagram.android",
        "com.facebook.katana",
        "com.facebook.lite",
        "com.zhiliaoapp.musically",
        "com.ss.android.ugc.trill",
        "com.snapchat.android",
        "in.mohalla.sharechat",
        "in.mohalla.video",
        "com.eterno.shortvideos",
        "com.twitter.android",
        "com.linkedin.android"
    )

    /** Long-form video players. */
    val PLAYER = setOf(
        "com.netflix.mediaclient",
        "com.mxtech.videoplayer.ad",
        "com.mxtech.videoplayer.pro",
        "org.videolan.vlc",
        "com.amazon.avod.thirdpartyclient",
        "in.startv.hotstar",
        "com.jio.media.ondemand",
        "tv.twitch.android.app",
        "com.google.android.videos"
    )

    val MUSIC = setOf(
        "com.spotify.music",
        "com.google.android.apps.youtube.music",
        "com.jio.media.jiobeats",
        "com.gaana",
        "com.bsbportal.music",
        "com.amazon.mp3",
        "deezer.android.app",
        "com.soundcloud.android",
        "com.apple.android.music",
        "com.google.android.apps.podcasts"
    )

    val VIDEO_ALL: Set<String> = YOUTUBE + FEED + PLAYER

    // YouTube view ids (resource names inside the YouTube package). If YouTube renames them the
    // app simply falls back to the "feed" behaviour, which is the original Shorts behaviour.
    val SHORTS_IDS = listOf("reel_recycler", "reel_player_page_container", "reel_watch_player")
    val WATCH_IDS = listOf("watch_player", "watch_while_layout", "player_view")
    val PLAYER_IDS = listOf("watch_player", "player_view")
}

/** The "Auto" brain: picks an action from the gesture and the app that is open. */
object AutoMap {
    fun resolve(g: Gesture, c: Ctx): Action = when (g) {
        Gesture.SWIPE_UP -> when (c) {
            Ctx.MUSIC, Ctx.PLAYER -> Action.VOLUME_UP
            Ctx.YT_WATCH -> Action.FULLSCREEN_ON
            Ctx.GENERIC -> Action.PAGE_DOWN
            Ctx.FEED -> Action.NEXT
        }
        Gesture.SWIPE_DOWN -> when (c) {
            Ctx.MUSIC, Ctx.PLAYER -> Action.VOLUME_DOWN
            Ctx.YT_WATCH -> Action.FULLSCREEN_OFF
            Ctx.GENERIC -> Action.PAGE_UP
            Ctx.FEED -> Action.PREVIOUS
        }
        Gesture.SWIPE_LEFT -> when (c) {
            Ctx.MUSIC -> Action.MEDIA_PREVIOUS
            Ctx.PLAYER, Ctx.YT_WATCH -> Action.SEEK_BACK
            else -> Action.SIDE_LEFT
        }
        Gesture.SWIPE_RIGHT -> when (c) {
            Ctx.MUSIC -> Action.MEDIA_NEXT
            Ctx.PLAYER, Ctx.YT_WATCH -> Action.SEEK_FORWARD
            else -> Action.SIDE_RIGHT
        }
        Gesture.PALM_HOLD -> when (c) {
            Ctx.FEED -> Action.TAP_CENTER
            else -> Action.MEDIA_PLAY_PAUSE
        }
        // Pinch = flick to the next Short / Reel (the original, fastest way to scroll Shorts).
        Gesture.PINCH -> when (c) {
            Ctx.FEED -> Action.NEXT
            Ctx.YT_WATCH -> Action.LIKE
            Ctx.MUSIC -> Action.MEDIA_NEXT
            else -> Action.NONE
        }
        // Thumb up = like in video feeds, volume up everywhere else.
        Gesture.THUMB_UP_HOLD -> when (c) {
            Ctx.FEED, Ctx.YT_WATCH -> Action.LIKE
            else -> Action.VOLUME_UP
        }
        else -> if (g.defaultAction == Action.AUTO) Action.NONE else g.defaultAction
    }
}
