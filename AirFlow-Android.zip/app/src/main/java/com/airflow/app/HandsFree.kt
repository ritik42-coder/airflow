package com.airflow.app

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.graphics.PointF
import android.os.SystemClock
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

// ---------------------------------------------------------------------------------------------
// Hands-free: face + hand control of the whole phone, from one camera frame.
//   head moves the cursor   | wink / firm blink / double blink / dwell / smile = click
//   thumb-index spread/close = real pinch zoom on the screen
//   face gestures (tilt, brows, mouth, smile) and edge-scroll for easy control
// Everything runs on the main thread, fed one frame at a time by AirFlowService.
// ---------------------------------------------------------------------------------------------

/** One-Euro filter (steady when still, almost no lag when fast). Pure Kotlin, so it is unit tested. */
class OneEuroF {
    private var xPrev = 0f
    private var dxPrev = 0f
    private var rawPrev = 0f
    private var has = false

    fun reset() { has = false }

    fun filter(v: Float, dt: Float, minCut: Float, beta: Float): Float {
        if (!has) { has = true; xPrev = v; rawPrev = v; dxPrev = 0f; return v }
        val d = dt.coerceAtLeast(1e-3f)
        val dx = (v - rawPrev) / d
        rawPrev = v
        dxPrev += alpha(1.0f, d) * (dx - dxPrev)
        xPrev += alpha(minCut + beta * abs(dxPrev), d) * (v - xPrev)
        return xPrev
    }

    private fun alpha(cutoff: Float, dt: Float): Float {
        val tau = 1f / (2f * PI.toFloat() * cutoff)
        return 1f / (1f + tau / dt)
    }
}

/**
 * Tells a deliberate click-blink from a normal one. Normal blinks are quick and both eyes close together,
 * so they never click. A wink (one eye) held 250..800 ms clicks; a firm two-eye close longer than THIS
 * person's own natural blinks (median + 2 sd, never under 350 ms) clicks; two firm-ish closes in 700 ms
 * make a double blink. The click is reported when the eye reopens.
 */
class BlinkClassifier(naturalMs: List<Long> = emptyList()) {
    enum class Click { NONE, WINK, FIRM, DOUBLE }

    private val natural = ArrayList<Long>(naturalMs)
    private var closeStart = 0L
    private var closeType = 0          // 1 = both eyes, 2 = one eye
    private var openFrames = 0
    private var lastFirmEnd = 0L
    private var lastClick = 0L

    /** True while an eye is closed (the cursor should hold still). */
    var closing = false
        private set

    /** When the current (or last finished) closure began, for "the cursor position from just before the blink". */
    var closeStartMs = 0L
        private set

    /** What the user's own natural blink length tells us: a close must be at least this long to be deliberate. */
    fun firmMinMs(): Long {
        if (natural.size < 8) return 350L
        val s = natural.sorted()
        val med = s[s.size / 2].toDouble()
        val mean = natural.average()
        val sd = sqrt(natural.sumOf { (it - mean) * (it - mean) } / natural.size)
        return (med + 2.0 * sd).toLong().coerceIn(330L, 600L)
    }

    fun naturalList(): List<Long> = natural.toList()

    fun update(blinkL: Float, blinkR: Float, now: Long): Click {
        val both = blinkL > 0.5f && blinkR > 0.5f
        val wink = (blinkL > 0.6f && blinkR < 0.3f) || (blinkR > 0.6f && blinkL < 0.3f)
        val type = if (both) 1 else if (wink) 2 else 0

        if (type != 0) {
            openFrames = 0
            if (!closing) { closing = true; closeStart = now; closeStartMs = now; closeType = type }
            else if (type == 1) closeType = 1      // one eye that turns into two eyes was just a blink
            return Click.NONE
        }
        if (!closing) return Click.NONE
        // tolerate one flickery open frame inside a closure
        openFrames++
        if (openFrames < 2) return Click.NONE
        closing = false
        val dur = now - closeStart
        val cooled = now - lastClick > 500L
        var out = Click.NONE
        if (closeType == 2) {
            if (dur in 250L..800L && cooled) out = Click.WINK
        } else {
            if (dur in 50L..380L) {
                natural.add(dur)
                while (natural.size > 40) natural.removeAt(0)
            }
            val firm = firmMinMs()
            if (dur in firm..1400L && cooled) {
                out = Click.FIRM
            } else if (dur in (firm * 7 / 10)..1400L && closeStart - lastFirmEnd in 0L..700L && lastFirmEnd != 0L && cooled) {
                out = Click.DOUBLE
                lastFirmEnd = 0L
            }
            if (out == Click.NONE && dur >= firm * 7 / 10) lastFirmEnd = now
        }
        if (out != Click.NONE) lastClick = now
        return out
    }
}

/** Zoom maths, separate so it can be tested: a fast flick makes a bigger step than slow movement. */
object ZoomMath {
    /** [dr] change of the pinch ratio this frame, [speed] its rate per second, [w] screen width in px. */
    fun step(dr: Float, speed: Float, w: Float, userSpeed: Float): Float {
        val gain = (0.9f + 2.2f * min(1f, abs(speed) / 3f)) * userSpeed
        return dr * w * 0.5f * gain
    }

    fun level(dTarget: Float, dStart: Float): Float = (dTarget / dStart.coerceAtLeast(1f)).coerceIn(0.5f, 8f)
}

/**
 * Continuous two-finger pinch on the real screen: two strokes that spread or close, chained with
 * willContinue so the app sees one smooth gesture instead of steps.
 */
class ZoomInjector {
    private var cx = 0f
    private var cy = 0f
    private var curD = 0f
    private var target = 0f
    private var s1: GestureDescription.StrokeDescription? = null
    private var s2: GestureDescription.StrokeDescription? = null
    private var inFlight = false
    private var ending = false
    var active = false
        private set

    fun begin(centerX: Float, centerY: Float, d0: Float) {
        if (active) return
        cx = centerX; cy = centerY; curD = d0; target = d0
        s1 = null; s2 = null; ending = false
        active = true
        next()
    }

    fun setTarget(d: Float) { target = d }

    fun end() {
        if (!active) return
        active = false
        ending = true
        if (!inFlight) next()
    }

    private fun next() {
        val svc = AirFlowAccessibilityService.instance
        if (svc == null) { reset(); return }
        val fin = ending
        val nd = target
        val dur = 60L
        val p1 = Path().apply { moveTo(cx - curD, cy); lineTo(cx - nd, cy) }
        val p2 = Path().apply { moveTo(cx + curD, cy); lineTo(cx + nd, cy) }
        val a = s1?.continueStroke(p1, 0, dur, !fin) ?: GestureDescription.StrokeDescription(p1, 0, dur, !fin)
        val b = s2?.continueStroke(p2, 0, dur, !fin) ?: GestureDescription.StrokeDescription(p2, 0, dur, !fin)
        s1 = a; s2 = b; curD = nd
        inFlight = true
        val ok = svc.dispatchGesture(
            GestureDescription.Builder().addStroke(a).addStroke(b).build(),
            object : AccessibilityService.GestureResultCallback() {
                override fun onCompleted(g: GestureDescription?) {
                    inFlight = false
                    if (fin) { reset(); return }
                    if (active) next() else { ending = true; next() }
                }

                override fun onCancelled(g: GestureDescription?) { reset() }
            }, null
        )
        if (!ok) reset()
    }

    private fun reset() {
        s1 = null; s2 = null; inFlight = false; ending = false; active = false
    }
}

object HandsFree {
    private val fx = OneEuroF()
    private val fy = OneEuroF()
    private val blink = BlinkClassifier(loadBaseline())
    private val zoomer = ZoomInjector()

    private var on = false
    private var paused = false
    private var lastT = 0L
    private var hasBase = false
    private var baseX = 0.5f
    private var baseY = 0.5f
    private var curX = 0f
    private var curY = 0f
    private var hasCur = false
    private var lostSince = 0L
    private var dimmed = false

    private class Pos(val t: Long, val x: Float, val y: Float)
    private val hist = ArrayDeque<Pos>()

    // dwell
    private var dwellX = 0f
    private var dwellY = 0f
    private var dwellStart = 0L
    private var dwellArmed = true

    // generic holds
    private val holdStart = LongArray(8)
    private val holdDone = BooleanArray(8)
    private val hyst = BooleanArray(8)
    private var lastGestureAt = 0L
    private var lastWarnAt = 0L
    private var edgeSince = 0L
    private var lastEdgeAt = 0L
    private var smileClickArmed = true
    private var baselineSaved = 0

    // pitch history for nods
    private class P(val t: Long, val v: Float)
    private val pitchHist = ArrayDeque<P>()

    // zoom
    private var zActive = false
    private var zPrevR = -1f
    private var zPrevT = 0L
    private var zFast = 0
    private var zSlowSince = 0L
    private var zStartD = 0f
    private var zTarget = 0f
    private var zLastToast = 0L

    private fun loadBaseline(): List<Long> = try {
        Prefs.hfBlinkBase.split(",").mapNotNull { it.trim().toLongOrNull() }
    } catch (e: Throwable) { emptyList() }

    /** Called when the user taps "Recenter": the current head position becomes the middle of the screen. */
    fun recenter() { hasBase = false; fx.reset(); fy.reset() }

    fun isPaused(): Boolean = paused
    fun setPaused(p: Boolean) { paused = p }

    /** Returns true while a hand zoom is running, so the normal hand gestures stay quiet. */
    fun onFrame(r: FrameResult, now: Long, shareBusy: Boolean): Boolean {
        val svc = AirFlowAccessibilityService.instance
        if (!Prefs.handsFree || svc == null) {
            if (on) shutdown(svc)
            return false
        }
        if (!on) startup(svc)
        val dt = if (lastT == 0L) 0.033f else ((now - lastT) / 1000f).coerceIn(0.005f, 0.12f)
        lastT = now

        val busy = if (shareBusy) endZoom() else handZoom(svc, r, now)
        val face = r.face
        if (face == null) { faceLost(svc, now); return busy }
        if (lostSince != 0L) { lostSince = 0L; if (dimmed) { dimmed = false; svc.overlayHandVisible(true) } }
        onFace(svc, face, now, dt)
        return busy
    }

    private fun startup(svc: AirFlowAccessibilityService) {
        on = true; paused = false; hasBase = false; hasCur = false
        fx.reset(); fy.reset()
        if (Prefs.hfHead) svc.headCursor(true)
        IslandHost.toast("🙂", "Hands-free on", if (Prefs.hfHead) "Move your head to point" else "Face and hand gestures")
    }

    private fun shutdown(svc: AirFlowAccessibilityService?) {
        on = false
        endZoom()
        svc?.headCursor(false)
        saveBaseline()
    }

    private fun saveBaseline() {
        try { Prefs.hfBlinkBase = blink.naturalList().joinToString(",") } catch (_: Throwable) {}
    }

    private fun faceLost(svc: AirFlowAccessibilityService, now: Long) {
        if (lostSince == 0L) lostSince = now
        val lost = now - lostSince
        if (lost > 350L) { fx.reset(); fy.reset() }
        if (lost > 3000L && !dimmed) { dimmed = true; svc.overlayHandVisible(false) }
        if (lost > 2000L && now - lastWarnAt > 8000L) {
            lastWarnAt = now
            IslandHost.toast("🫥", "Face not found", "Look at the camera, add some light")
        }
    }

    // ------------------------------------------------------------------ face

    private fun onFace(svc: AirFlowAccessibilityService, f: FaceFrame, now: Long, dt: Float) {
        // mouth open held = pause or resume everything
        if (Prefs.hfFace && held(0, hy(0, f.jawOpen, 0.55f, 0.3f), now, 700L)) {
            paused = !paused
            svc.buzz()
            IslandHost.toast(if (paused) "⏸" else "▶", if (paused) "Paused" else "Resumed", "Open your mouth to toggle")
        }
        if (paused) { svc.overlayHandVisible(false); return }
        if (!dimmed) svc.overlayHandVisible(true)

        if (f.size < 0.10f && now - lastWarnAt > 8000L) {
            lastWarnAt = now
            IslandHost.toast("↔", "Move a little closer", "Your face looks small")
        }

        val click = blink.update(f.blinkL, f.blinkR, now)
        val closed = blink.closing

        // ---- cursor ----
        val (w, h) = svc.screenSize()
        val headOn = Prefs.hfHead && !AirFlowState.cursorMode.value
        if (headOn) {
            if (!closed) {
                val nx = fx.filter(f.noseX, dt, 0.9f, 22f)
                val ny = fy.filter(f.noseY, dt, 0.9f, 22f)
                if (!hasBase) { baseX = nx; baseY = ny; hasBase = true }
                val k = Prefs.hfSens.coerceIn(0.4f, 2.5f)
                val tx = (w / 2f + (nx - baseX) * 4.0f * k * w).coerceIn(0f, w)
                val ty = (h / 2f + (ny - baseY) * 5.2f * k * h).coerceIn(0f, h)
                curX = tx; curY = ty; hasCur = true
            }
            if (hasCur) {
                hist.addLast(Pos(now, curX, curY))
                while (hist.isNotEmpty() && now - hist.first().t > 600L) hist.removeFirst()
            }
        }

        // ---- dwell progress ----
        var progress = 0f
        if (headOn && hasCur && Prefs.hfClick == "dwell" && !closed) {
            val radius = max(45f, w * 0.045f)
            if (hypot(curX - dwellX, curY - dwellY) > radius) {
                dwellX = curX; dwellY = curY; dwellStart = now; dwellArmed = true
            } else if (dwellArmed) {
                progress = ((now - dwellStart) / 900f).coerceIn(0f, 1f)
                if (progress >= 1f) { doClick(svc, dwellX, dwellY, "Dwell"); dwellArmed = false; progress = 0f }
            }
        }
        if (headOn && hasCur) svc.overlayUpdate(curX, curY, CursorOverlay.S_IDLE, 0f, 0f, progress)

        // ---- blink clicks ----
        if (headOn && hasCur && click != BlinkClassifier.Click.NONE) {
            val m = Prefs.hfClick
            val ok = (m == "wink" && click == BlinkClassifier.Click.WINK) ||
                (m == "firm" && click == BlinkClassifier.Click.FIRM) ||
                (m == "double" && click == BlinkClassifier.Click.DOUBLE)
            if (ok) {
                // click where the cursor was just before the eye started to close
                val p = posAt(blink.closeStartMs - 120L)
                doClick(svc, p.x, p.y, when (click) { BlinkClassifier.Click.WINK -> "Wink"; BlinkClassifier.Click.DOUBLE -> "Double blink"; else -> "Blink" })
            }
            if (++baselineSaved % 10 == 0) saveBaseline()
        }

        // ---- smile click ----
        val smiling = hy(1, f.smile, 0.55f, 0.3f)
        if (Prefs.hfClick == "smile" && headOn && hasCur) {
            if (!smiling) smileClickArmed = true
            else if (held(1, smiling, now, 450L) && smileClickArmed) { smileClickArmed = false; doClick(svc, curX, curY, "Smile") }
        } else if (Prefs.hfFace && held(1, smiling, now, 700L)) {
            recenter()
            IslandHost.toast("🎯", "Centered", "Your head position is the middle now")
        }

        if (!Prefs.hfFace || closed) return
        // ---- face gestures ----
        val cool = now - lastGestureAt > 900L
        if (held(2, hy(2, f.browUp, 0.6f, 0.35f), now, 500L) && cool) {
            lastGestureAt = now
            svc.hfBack(); svc.buzz(); IslandHost.toast("↩", "Back", "Eyebrows up")
        }
        val tiltOn = f.rollDeg > 16f
        val tiltOff = f.rollDeg < -16f
        if (cool && held(3, hy(3, if (tiltOn) 1f else 0f, 0.5f, 0.2f), now, 450L)) {
            lastGestureAt = now
            svc.hfSwipeSide(true); svc.buzz(); IslandHost.toast("➡", "Next", "Head tilt")
        } else if (cool && held(4, hy(4, if (tiltOff) 1f else 0f, 0.5f, 0.2f), now, 450L)) {
            lastGestureAt = now
            svc.hfSwipeSide(false); svc.buzz(); IslandHost.toast("⬅", "Previous", "Head tilt")
        }
        if (!headOn) nods(svc, f, now)

        // ---- edge scroll: rest the cursor at the top or bottom edge ----
        if (headOn && Prefs.hfEdgeScroll && hasCur && !closed) {
            val up = curY < h * 0.04f
            val down = curY > h * 0.96f
            if (up || down) {
                if (edgeSince == 0L) edgeSince = now
                if (now - edgeSince > 450L && now - lastEdgeAt > 750L) {
                    lastEdgeAt = now
                    svc.hfScroll(down)
                }
            } else edgeSince = 0L
        }
    }

    private fun nods(svc: AirFlowAccessibilityService, f: FaceFrame, now: Long) {
        pitchHist.addLast(P(now, f.pitch))
        while (pitchHist.isNotEmpty() && now - pitchHist.first().t > 380L) pitchHist.removeFirst()
        if (pitchHist.size < 4 || now - lastGestureAt < 900L) return
        val d = f.pitch - pitchHist.first().v
        if (d > 0.06f) { lastGestureAt = now; pitchHist.clear(); svc.hfScroll(true); IslandHost.toast("⬇", "Scroll down", "Nod") }
        else if (d < -0.06f) { lastGestureAt = now; pitchHist.clear(); svc.hfScroll(false); IslandHost.toast("⬆", "Scroll up", "Nod up") }
    }

    private fun doClick(svc: AirFlowAccessibilityService, x: Float, y: Float, label: String) {
        svc.tapAt(x, y)
        svc.overlayRipple(x, y)
        svc.buzz()
        IslandHost.toast("👆", "Click", label)
    }

    private fun posAt(t: Long): Pos {
        var best: Pos? = null
        for (p in hist) { if (p.t <= t) best = p else break }
        return best ?: hist.firstOrNull() ?: Pos(t, curX, curY)
    }

    /** True once when [on] has stayed true for [ms]; re-arms when it goes false. */
    private fun held(i: Int, on: Boolean, now: Long, ms: Long): Boolean {
        if (!on) { holdStart[i] = 0L; holdDone[i] = false; return false }
        if (holdStart[i] == 0L) holdStart[i] = now
        if (!holdDone[i] && now - holdStart[i] >= ms) { holdDone[i] = true; return true }
        return false
    }

    /** Hysteresis: turns on above [hi], off below [lo], so a value near the line never flickers. */
    private fun hy(i: Int, v: Float, hi: Float, lo: Float): Boolean {
        if (v > hi) hyst[i] = true else if (v < lo) hyst[i] = false
        return hyst[i]
    }

    // ------------------------------------------------------------------ zoom

    private fun endZoom(): Boolean {
        if (zActive) { zoomer.end(); zActive = false; IslandHost.toast("🔍", "Zoom done", "") }
        zFast = 0; zPrevR = -1f
        return false
    }

    private fun handZoom(svc: AirFlowAccessibilityService, r: FrameResult, now: Long): Boolean {
        if (!Prefs.hfZoom || AirFlowState.cursorMode.value || paused) return endZoom()
        val lm: List<PointF>? = r.landmarks
        val p = r.pose
        val okPose = p == GestureEngine.Pose.OPEN || p == GestureEngine.Pose.PINCH || p == GestureEngine.Pose.OTHER
        if (lm == null || lm.size < 21 || !okPose) return endZoom()
        for (q in lm) if (q.x < 0.03f || q.x > 0.97f || q.y < 0.03f || q.y > 0.97f) return endZoom()
        val palm = hypot((lm[0].x - lm[9].x).toDouble(), (lm[0].y - lm[9].y).toDouble()).toFloat()
        if (palm < 0.02f) return endZoom()
        // distance-free: how far thumb and index are apart compared with the size of the hand
        val rat = hypot((lm[4].x - lm[8].x).toDouble(), (lm[4].y - lm[8].y).toDouble()).toFloat() / palm
        if (zPrevR < 0f) { zPrevR = rat; zPrevT = now; return false }
        val dt = ((now - zPrevT) / 1000f).coerceAtLeast(0.01f)
        val dr = rat - zPrevR
        val speed = abs(dr) / dt
        zPrevR = rat; zPrevT = now
        val (w, h) = svc.screenSize()

        if (!zActive) {
            zFast = if (speed > 0.9f && abs(dr) > 0.035f) zFast + 1 else 0
            if (zFast >= 2 && rat in 0.2f..2.3f) {
                val cx = if (Prefs.hfHead && hasCur) curX else w / 2f
                val cy = if (Prefs.hfHead && hasCur) curY else h / 2f
                zStartD = w * 0.12f
                zTarget = zStartD
                zoomer.begin(cx, cy, zStartD)
                zActive = true; zSlowSince = 0L
                svc.buzz()
            }
            return zActive
        }
        if (speed > 0.25f) {
            zSlowSince = 0L
            zTarget = (zTarget + ZoomMath.step(dr, speed, w, Prefs.hfZoomSpeed.coerceIn(0.4f, 2.5f))).coerceIn(w * 0.05f, w * 0.45f)
            zoomer.setTarget(zTarget)
            if (now - zLastToast > 180L) {
                zLastToast = now
                val pct = (ZoomMath.level(zTarget, zStartD) * 100f).toInt()
                IslandHost.toast("🔍", "Zoom $pct%", if (dr > 0) "Spreading: zoom in" else "Closing: zoom out")
            }
        } else if (zSlowSince == 0L) zSlowSince = now
        else if (now - zSlowSince > 400L) endZoom()
        return zActive
    }
}
