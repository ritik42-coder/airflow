package com.airflow.app

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.PointF
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.util.Base64
import com.google.android.gms.nearby.Nearby
import com.google.android.gms.nearby.connection.AdvertisingOptions
import com.google.android.gms.nearby.connection.ConnectionInfo
import com.google.android.gms.nearby.connection.ConnectionLifecycleCallback
import com.google.android.gms.nearby.connection.ConnectionResolution
import com.google.android.gms.nearby.connection.ConnectionsClient
import com.google.android.gms.nearby.connection.DiscoveredEndpointInfo
import com.google.android.gms.nearby.connection.DiscoveryOptions
import com.google.android.gms.nearby.connection.EndpointDiscoveryCallback
import com.google.android.gms.nearby.connection.Payload
import com.google.android.gms.nearby.connection.PayloadCallback
import com.google.android.gms.nearby.connection.PayloadTransferUpdate
import com.google.android.gms.nearby.connection.Strategy
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.RandomAccessFile

// ---------------------------------------------------------------------------------------------
// Air Blast: one flick sends a file or link to every phone in the room.
//
// Nearby "star" mode: the sending phone (host) advertises, every listening phone (receiver) finds it
// and joins. Joining moves nothing. Each blast starts with a small OFFER; a receiver only gets the
// real data after its owner taps Accept, so nothing lands uninvited. Class code: host and receivers
// must use the same one (empty = open room), so two classes next door do not mix.
// ---------------------------------------------------------------------------------------------

/** An offer that is waiting for the receiver's Accept or Decline. */
class BlastPrompt(
    val id: String,
    val host: String,
    val kind: String,      // "file" or "qd"
    val title: String,
    val count: Int,
    val bytes: Long,
    val thumb: Bitmap?
)

interface BlastCallbacks {
    // ---- host ----
    /** Phones currently in the room. */
    fun receivers(count: Int) {}
    /** Answers so far to the last offer. */
    fun responses(accepted: Int, declined: Int, total: Int) {}
    fun sendProgress(done: Long, total: Long) {}
    fun sendDone(delivered: Int, total: Int) {}

    // ---- receiver ----
    fun joined(host: String) {}
    fun left() {}
    /** Ask the owner. Nothing is saved until [BlastLink.answer] is called with accept = true. */
    fun prompt(p: BlastPrompt) {}
    fun promptGone(id: String) {}
    fun recvStarted(count: Int, bytes: Long) {}
    fun recvProgress(done: Long, total: Long) {}
    fun recvSaved(item: RecvItem) {}
    fun recvDone() {}
    fun recvQuick(item: QuickItem) {}

    fun failed(msg: String) {}
}

class BlastLink(ctx: Context, private val cb: BlastCallbacks) {

    private val app = ctx.applicationContext
    private val client: ConnectionsClient = Nearby.getConnectionsClient(app)
    private val strategy = Strategy.P2P_STAR
    private val mainH = Handler(Looper.getMainLooper())
    private val myName: String = (Build.MODEL ?: "Phone").take(24).replace("|", " ")

    // ================================================================== HOST

    private var hosting = false
    private var hostCode = ""
    private val members = LinkedHashMap<String, String>()   // endpoint id -> phone name

    val memberCount: Int get() = members.size
    val isHosting: Boolean get() = hosting

    // the offer in flight
    private var offerId = ""
    private var offerFiles: List<File> = emptyList()
    private var offerQuick: QuickItem? = null
    private val waiting = LinkedHashSet<String>()           // asked, no answer yet
    private val accepted = LinkedHashSet<String>()
    private var declined = 0
    private var targetCount = 0
    private var streaming = false
    private var fileIdx = 0
    private var fileOffset = 0L
    private var totalBytes = 0L
    private var ackedBytes = 0L
    private var inFlight = 0
    private val chunkWait = HashMap<Long, MutableSet<String>>()
    private val chunkSize = HashMap<Long, Int>()
    private var ended = false

    private val answerTimeout = Runnable { beginStream() }

    fun startHost(code: String) {
        hostCode = code.trim().take(8).replace("|", "")
        if (hosting) return
        hosting = true
        val name = "AB|$hostCode|$myName"
        client.startAdvertising(name, SERVICE, hostConn, AdvertisingOptions.Builder().setStrategy(strategy).build())
            .addOnFailureListener { hosting = false; fail(it) }
    }

    fun stopHost() {
        if (!hosting) return
        hosting = false
        mainH.removeCallbacks(answerTimeout)
        try { client.stopAdvertising() } catch (_: Exception) {}
        for (id in members.keys.toList()) { try { client.disconnectFromEndpoint(id) } catch (_: Exception) {} }
        members.clear()
        resetOffer()
        cb.receivers(0)
    }

    private val hostConn = object : ConnectionLifecycleCallback() {
        override fun onConnectionInitiated(id: String, info: ConnectionInfo) {
            val parts = info.endpointName.split("|")
            val ok = parts.size >= 3 && parts[0] == "AR" && parts[1] == hostCode && members.size < MAX_ROOM
            if (!ok) { try { client.rejectConnection(id) } catch (_: Exception) {}; return }
            pendingNames[id] = parts[2]
            client.acceptConnection(id, hostPayload)
        }

        override fun onConnectionResult(id: String, r: ConnectionResolution) {
            if (r.status.isSuccess) {
                members[id] = pendingNames.remove(id) ?: "Phone"
                cb.receivers(members.size)
            } else pendingNames.remove(id)
        }

        override fun onDisconnected(id: String) {
            members.remove(id)
            cb.receivers(members.size)
            dropTarget(id)
        }
    }

    private val pendingNames = HashMap<String, String>()

    private val hostPayload = object : PayloadCallback() {
        override fun onPayloadReceived(endpointId: String, payload: Payload) {
            if (payload.type != Payload.Type.BYTES) return
            val b = try { payload.asBytes() } catch (e: Exception) { null } ?: return
            if (b.isEmpty() || b[0].toInt() != TYPE_JSON) return
            val o = try { JSONObject(String(b, 1, b.size - 1)) } catch (e: Exception) { return }
            if (o.optString("id") != offerId) return
            when (o.optString("t")) {
                "bok" -> {
                    if (waiting.remove(endpointId)) {
                        accepted.add(endpointId)
                        answered()
                    }
                }
                "bno" -> {
                    if (waiting.remove(endpointId)) {
                        declined++
                        answered()
                    }
                }
            }
        }

        override fun onPayloadTransferUpdate(endpointId: String, u: PayloadTransferUpdate) {
            val set = chunkWait[u.payloadId] ?: return
            when (u.status) {
                PayloadTransferUpdate.Status.SUCCESS -> {
                    set.remove(endpointId)
                    chunkDone(u.payloadId, set)
                }
                PayloadTransferUpdate.Status.FAILURE, PayloadTransferUpdate.Status.CANCELED -> {
                    set.remove(endpointId)
                    accepted.remove(endpointId)
                    chunkDone(u.payloadId, set)
                }
            }
        }
    }

    /**
     * Offers [files] (or [qd], a link or text) to everyone in the room. Receivers answer; whoever accepts
     * gets the data. [thumb] is a small JPEG so the prompt can show a picture.
     */
    fun blast(files: List<File>, names: List<String>, thumb: ByteArray?, qd: QuickItem?) {
        if (members.isEmpty()) { cb.failed("Nobody is in the room yet."); return }
        if (offerId.isNotEmpty() && !ended) { cb.failed("The last blast is still going."); return }
        resetOffer()
        offerId = java.lang.Long.toHexString(System.nanoTime()).takeLast(8)
        offerFiles = files
        offerQuick = qd
        totalBytes = files.sumOf { it.length() }.coerceAtLeast(1L)
        ended = false
        val targets = members.keys.toList()
        targetCount = targets.size
        waiting.addAll(targets)

        val arr = JSONArray()
        files.forEachIndexed { i, f ->
            arr.put(JSONObject().put("n", names.getOrNull(i)?.takeIf { it.isNotBlank() } ?: f.name).put("s", f.length()))
        }
        val title = qd?.shown?.take(80) ?: (names.firstOrNull() ?: files.firstOrNull()?.name ?: "File")
        val o = JSONObject().put("t", "boffer").put("id", offerId)
            .put("k", if (qd != null) "qd" else "file")
            .put("ti", title).put("n", if (qd != null) 1 else files.size)
            .put("b", if (qd != null) 0L else totalBytes).put("h", myName).put("files", arr)
        if (thumb != null && thumb.size <= 14000) o.put("th", Base64.encodeToString(thumb, Base64.NO_WRAP))
        sendJson(targets, o)
        cb.responses(0, 0, targetCount)
        mainH.removeCallbacks(answerTimeout)
        mainH.postDelayed(answerTimeout, ANSWER_MS)
    }

    private fun answered() {
        cb.responses(accepted.size, declined, targetCount)
        if (waiting.isEmpty()) {
            mainH.removeCallbacks(answerTimeout)
            beginStream()
        }
    }

    private fun dropTarget(id: String) {
        if (offerId.isEmpty() || ended) return
        val wasWaiting = waiting.remove(id)
        val wasAccepted = accepted.remove(id)
        for ((pid, set) in chunkWait.entries.toList()) {
            if (set.remove(id)) chunkDone(pid, set)
        }
        if (wasWaiting) answered()
        else if (wasAccepted && streaming) pump()
    }

    private fun beginStream() {
        if (offerId.isEmpty() || streaming || ended) return
        // anyone who did not answer in time is treated as a no
        declined += waiting.size
        waiting.clear()
        if (accepted.isEmpty()) { finish(); return }
        val qd = offerQuick
        if (qd != null) {
            val o = JSONObject().put("t", "bqd").put("id", offerId).put("k", qd.kind).put("x", qd.text).put("ti", qd.title)
            val tb = qd.thumbBytes
            if (tb != null && tb.size <= 14000) o.put("th", Base64.encodeToString(tb, Base64.NO_WRAP))
            sendJson(accepted.toList(), o)
            finish()
            return
        }
        streaming = true
        fileIdx = 0; fileOffset = 0L; ackedBytes = 0L; inFlight = 0
        pump()
    }

    private fun pump() {
        if (!streaming) return
        if (accepted.isEmpty()) { finish(); return }
        while (inFlight < WINDOW) {
            if (fileIdx >= offerFiles.size) {
                if (inFlight == 0) {
                    sendJson(accepted.toList(), JSONObject().put("t", "bend").put("id", offerId))
                    finish()
                }
                return
            }
            val f = offerFiles[fileIdx]
            val left = f.length() - fileOffset
            if (left <= 0L) { fileIdx++; fileOffset = 0L; continue }
            val n = minOf(CHUNK.toLong(), left).toInt()
            val buf = ByteArray(7 + n)
            buf[0] = TYPE_CHUNK.toByte()
            buf[1] = ((fileIdx shr 8) and 0xFF).toByte()
            buf[2] = (fileIdx and 0xFF).toByte()
            val chunk = (fileOffset / CHUNK).toInt()
            buf[3] = ((chunk shr 24) and 0xFF).toByte()
            buf[4] = ((chunk shr 16) and 0xFF).toByte()
            buf[5] = ((chunk shr 8) and 0xFF).toByte()
            buf[6] = (chunk and 0xFF).toByte()
            try {
                RandomAccessFile(f, "r").use { raf -> raf.seek(fileOffset); raf.readFully(buf, 7, n) }
            } catch (e: Exception) {
                streaming = false
                cb.failed("Could not read " + f.name)
                finish()
                return
            }
            val p = Payload.fromBytes(buf)
            val targets = accepted.toList()
            chunkWait[p.id] = targets.toMutableSet()
            chunkSize[p.id] = n
            inFlight++
            fileOffset += n
            try {
                client.sendPayload(targets, p)
            } catch (e: Exception) {
                chunkWait.remove(p.id); chunkSize.remove(p.id); inFlight--
                streaming = false
                cb.failed("The room link dropped.")
                finish()
                return
            }
        }
    }

    private fun chunkDone(pid: Long, set: MutableSet<String>) {
        if (set.isNotEmpty()) return
        chunkWait.remove(pid)
        val n = chunkSize.remove(pid) ?: 0
        inFlight--
        ackedBytes += n
        cb.sendProgress(ackedBytes.coerceAtMost(totalBytes), totalBytes)
        pump()
    }

    private fun finish() {
        if (ended) return
        ended = true
        streaming = false
        mainH.removeCallbacks(answerTimeout)
        cb.sendDone(accepted.size, targetCount)
    }

    private fun resetOffer() {
        offerId = ""
        offerFiles = emptyList()
        offerQuick = null
        waiting.clear(); accepted.clear(); declined = 0; targetCount = 0
        streaming = false; inFlight = 0
        chunkWait.clear(); chunkSize.clear()
    }

    // ================================================================== RECEIVER

    private var listening = false
    private var myCode = ""
    private var hostId: String? = null
    private var hostLabel = ""
    private var requesting = false

    // the offer we were asked about
    private var inId = ""
    private var inKind = ""
    private var inNames: List<String> = emptyList()
    private var inSizes: List<Long> = emptyList()
    private var inTotal = 0L
    private var inDone = 0L
    private var inAccepted = false
    private val inFiles = HashMap<Int, File>()
    private val inWriters = HashMap<Int, RandomAccessFile>()

    val inRoom: Boolean get() = hostId != null
    val isListening: Boolean get() = listening

    fun startListening(code: String) {
        myCode = code.trim().take(8).replace("|", "")
        if (listening) return
        listening = true
        discover()
    }

    fun stopListening() {
        if (!listening) return
        listening = false
        try { client.stopDiscovery() } catch (_: Exception) {}
        hostId?.let { try { client.disconnectFromEndpoint(it) } catch (_: Exception) {} }
        hostId = null
        requesting = false
        clearIncoming()
    }

    private fun discover() {
        if (!listening || hostId != null) return
        val disc = object : EndpointDiscoveryCallback() {
            override fun onEndpointFound(id: String, info: DiscoveredEndpointInfo) {
                val p = info.endpointName.split("|")
                if (p.size < 3 || p[0] != "AB" || p[1] != myCode) return
                if (hostId != null || requesting) return
                requesting = true
                hostLabel = p[2]
                client.requestConnection("AR|$myCode|$myName", id, recvConn)
                    .addOnFailureListener { requesting = false; fail(it) }
            }

            override fun onEndpointLost(id: String) {}
        }
        client.startDiscovery(SERVICE, disc, DiscoveryOptions.Builder().setStrategy(strategy).build())
            .addOnFailureListener { fail(it) }
    }

    private val recvConn = object : ConnectionLifecycleCallback() {
        override fun onConnectionInitiated(id: String, info: ConnectionInfo) {
            // only join the host we asked for
            if (!requesting) { try { client.rejectConnection(id) } catch (_: Exception) {}; return }
            client.acceptConnection(id, recvPayload)
        }

        override fun onConnectionResult(id: String, r: ConnectionResolution) {
            requesting = false
            if (r.status.isSuccess) {
                hostId = id
                try { client.stopDiscovery() } catch (_: Exception) {}
                cb.joined(hostLabel)
            } else {
                mainH.postDelayed({ restartDiscovery() }, 2500L)
            }
        }

        override fun onDisconnected(id: String) {
            if (hostId == id) {
                hostId = null
                if (inId.isNotEmpty()) cb.promptGone(inId)
                clearIncoming()
                cb.left()
                mainH.postDelayed({ restartDiscovery() }, 1500L)
            }
        }
    }

    private fun restartDiscovery() {
        if (!listening || hostId != null) return
        try { client.stopDiscovery() } catch (_: Exception) {}
        discover()
    }

    private val recvPayload = object : PayloadCallback() {
        override fun onPayloadReceived(endpointId: String, payload: Payload) {
            if (payload.type != Payload.Type.BYTES) return
            val b = try { payload.asBytes() } catch (e: Exception) { null } ?: return
            if (b.isEmpty()) return
            when (b[0].toInt()) {
                TYPE_JSON -> onJson(String(b, 1, b.size - 1))
                TYPE_CHUNK -> if (inAccepted) writeChunk(b)
            }
        }

        override fun onPayloadTransferUpdate(endpointId: String, u: PayloadTransferUpdate) {}
    }

    private fun onJson(text: String) {
        val o = try { JSONObject(text) } catch (e: Exception) { return }
        when (o.optString("t")) {
            "boffer" -> {
                clearIncoming()
                inId = o.optString("id")
                inKind = o.optString("k", "file")
                val arr = o.optJSONArray("files") ?: JSONArray()
                val names = ArrayList<String>(); val sizes = ArrayList<Long>()
                for (i in 0 until arr.length()) {
                    val f = arr.optJSONObject(i) ?: continue
                    names.add(f.optString("n", "file_$i")); sizes.add(f.optLong("s"))
                }
                inNames = names; inSizes = sizes
                inTotal = o.optLong("b").coerceAtLeast(1L)
                val th = try {
                    val s = o.optString("th", "")
                    if (s.isEmpty()) null else Base64.decode(s, Base64.NO_WRAP).let { BitmapFactory.decodeByteArray(it, 0, it.size) }
                } catch (e: Exception) { null }
                cb.prompt(BlastPrompt(inId, o.optString("h", hostLabel), inKind, o.optString("ti"), o.optInt("n", names.size), o.optLong("b"), th))
                // an unanswered prompt dies by itself
                val id = inId
                mainH.postDelayed({ if (inId == id && !inAccepted) { answer(id, false); cb.promptGone(id) } }, PROMPT_MS)
            }
            "bqd" -> {
                if (o.optString("id") != inId || !inAccepted) return
                val th = try {
                    val s = o.optString("th", "")
                    if (s.isEmpty()) null else Base64.decode(s, Base64.NO_WRAP).let { BitmapFactory.decodeByteArray(it, 0, it.size) }
                } catch (e: Exception) { null }
                val item = QuickItem(o.optString("k", "text"), o.optString("x"), o.optString("ti"), th)
                clearIncoming()
                cb.recvQuick(item)
            }
            "bend" -> {
                if (o.optString("id") != inId || !inAccepted) return
                finalise()
            }
        }
    }

    /** The owner's answer. Accept starts the arrival; Decline tells the host and forgets the offer. */
    fun answer(id: String, accept: Boolean) {
        if (id != inId || inId.isEmpty()) return
        val host = hostId
        if (host != null) sendJson(listOf(host), JSONObject().put("t", if (accept) "bok" else "bno").put("id", id))
        if (!accept) { clearIncoming(); return }
        inAccepted = true
        inDone = 0L
        if (inKind == "file") cb.recvStarted(inNames.size, inTotal)
    }

    private fun writeChunk(b: ByteArray) {
        if (b.size < 8 || inKind != "file") return
        val idx = ((b[1].toInt() and 0xFF) shl 8) or (b[2].toInt() and 0xFF)
        val chunk = ((b[3].toInt() and 0xFF) shl 24) or ((b[4].toInt() and 0xFF) shl 16) or
            ((b[5].toInt() and 0xFF) shl 8) or (b[6].toInt() and 0xFF)
        val data = b.size - 7
        val tmp = inFiles.getOrPut(idx) { File(app.cacheDir, "blast_in_$idx") }
        try {
            val w = inWriters.getOrPut(idx) { RandomAccessFile(tmp, "rw").also { it.setLength(0L) } }
            w.seek(chunk.toLong() * CHUNK)
            w.write(b, 7, data)
        } catch (e: Exception) { return }
        inDone += data
        cb.recvProgress(inDone.coerceAtMost(inTotal), inTotal)
    }

    private fun finalise() {
        for (w in inWriters.values) { try { w.close() } catch (_: Exception) {} }
        inWriters.clear()
        for (i in inNames.indices) {
            val tmp = inFiles[i]
            val name = inNames[i]
            val image = FileStore.isImage(name)
            val expected = inSizes.getOrNull(i) ?: 0L
            if (tmp == null || !tmp.exists() || tmp.length() == 0L || (expected > 0L && tmp.length() < expected)) {
                cb.recvSaved(RecvItem(name, tmp?.length() ?: 0L, image, null, null))
                try { tmp?.delete() } catch (_: Exception) {}
                continue
            }
            val saved = try { tmp.inputStream().use { FileStore.save(app, name, it, image) } } catch (e: Exception) { null }
            val keep = File(app.cacheDir, "blast_keep_" + System.nanoTime() + "_" + FileStore.safeName(name))
            val kept = if (tmp.renameTo(keep)) keep else null
            if (kept == null) { try { tmp.delete() } catch (_: Exception) {} }
            cb.recvSaved(RecvItem(name, kept?.length() ?: tmp.length(), image, saved, kept))
        }
        inFiles.clear()
        inId = ""; inAccepted = false
        cb.recvDone()
    }

    private fun clearIncoming() {
        for (w in inWriters.values) { try { w.close() } catch (_: Exception) {} }
        inWriters.clear()
        inFiles.clear()
        inId = ""; inKind = ""; inAccepted = false; inDone = 0L
        inNames = emptyList(); inSizes = emptyList()
    }

    // ================================================================== shared

    private fun sendJson(to: List<String>, o: JSONObject) {
        if (to.isEmpty()) return
        try {
            val body = o.toString().toByteArray()
            val buf = ByteArray(body.size + 1)
            buf[0] = TYPE_JSON.toByte()
            System.arraycopy(body, 0, buf, 1, body.size)
            client.sendPayload(to, Payload.fromBytes(buf))
        } catch (_: Exception) {}
    }

    private fun fail(e: Throwable) {
        val m = e.message ?: ""
        if (m.contains("8001") || m.contains("8002")) return
        cb.failed(
            when {
                m.contains("8034") || m.contains("LOCATION") ->
                    if (!Perms.locationServiceOn(app)) "Location is switched off. Turn it on in quick settings."
                    else "Allow Location and Nearby devices permission first."
                m.contains("8032") || m.contains("8033") -> "Turn Bluetooth on."
                m.contains("8007") -> "Nearby is busy. Close other sharing apps."
                else -> m.ifEmpty { "Nearby could not start" }
            }
        )
    }

    fun stop() {
        stopHost()
        stopListening()
        mainH.removeCallbacksAndMessages(null)
        try { client.stopAllEndpoints() } catch (_: Exception) {}
    }

    companion object {
        private const val SERVICE = "com.airflow.app.blast"
        private const val CHUNK = 30 * 1024
        private const val WINDOW = 6
        private const val TYPE_JSON = 0
        private const val TYPE_CHUNK = 1
        /** Nearby star mode: the room is capped here. Real range depends on the phones and the radios. */
        const val MAX_ROOM = 30
        private const val ANSWER_MS = 25_000L
        private const val PROMPT_MS = 45_000L
    }
}

/**
 * "One flick": an open hand thrown quickly upward. Pure motion of the palm centre, so it needs nothing
 * the pose classifier does not already give. Used while a blast is armed, next to the palm, fist, open way.
 */
class FlickDetector {
    private val xs = ArrayList<FloatArray>()   // [time, x, y]
    private var cool = 0L

    fun reset() { xs.clear() }

    fun update(lm: List<PointF>?, open: Boolean, now: Long): Boolean {
        if (lm == null || lm.size < 21 || !open) { xs.clear(); return false }
        if (now < cool) return false
        xs.add(floatArrayOf(now.toFloat(), (lm[0].x + lm[9].x) / 2f, (lm[0].y + lm[9].y) / 2f))
        while (xs.size > 1 && now - xs[0][0] > 380f) xs.removeAt(0)
        if (xs.size < 3) return false
        val a = xs[0]; val z = xs[xs.size - 1]
        val dt = z[0] - a[0]
        val dy = z[2] - a[2]
        val dx = z[1] - a[1]
        if (dt >= 100f && dy < -0.26f && Math.abs(dx) < Math.abs(dy) * 0.9f) {
            cool = now + 2500L
            xs.clear()
            return true
        }
        return false
    }
}

/** The Accept / Decline buttons on the blast notification. */
class BlastActionReceiver : android.content.BroadcastReceiver() {
    override fun onReceive(context: Context, intent: android.content.Intent) {
        AirShareHub.answerBlast(intent.getStringExtra("id"), intent.getBooleanExtra("accept", false))
    }
}
