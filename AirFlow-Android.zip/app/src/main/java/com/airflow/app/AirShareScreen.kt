package com.airflow.app

import android.Manifest
import android.content.ComponentName
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver

/**
 * Air Share anywhere: turn it on once, then send from the share sheet of any app and receive with the
 * app closed. The photo flies as an animated orb over whatever is on screen.
 */
@Composable
fun AirShareAnywhereScreen() {
    val ctx = LocalContext.current
    val owner = LocalLifecycleOwner.current
    val c = Air.c

    val shareOn by AirShareHub.active.collectAsState()
    val status by AirShareHub.status.collectAsState()
    var tick by remember { mutableIntStateOf(0) }
    var demoMsg by remember { mutableStateOf("") }
    var sens by remember { mutableIntStateOf(Prefs.tapSens) }
    var tileMsg by remember { mutableStateOf("") }
    var style by remember { mutableStateOf(Prefs.tapStyle) }
    var autoCopy by remember { mutableStateOf(Prefs.quickAutoCopy) }
    var island by remember { mutableStateOf(Prefs.island) }
    var gpu by remember { mutableStateOf(Prefs.gpuHands) }
    var qdMsg by remember { mutableStateOf("") }
    var recentTick by remember { mutableIntStateOf(0) }
    val recent = remember(tick, recentTick) { QuickHistory.list() }

    DisposableEffect(owner) {
        val obs = LifecycleEventObserver { _, e -> if (e == Lifecycle.Event.ON_RESUME) tick++ }
        owner.lifecycle.addObserver(obs)
        onDispose { owner.lifecycle.removeObserver(obs) }
    }

    val camOk = remember(tick) { ContextCompat.checkSelfPermission(ctx, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED }
    val nearbyOk = remember(tick) { Perms.missing(ctx).isEmpty() }
    val locOn = remember(tick) { Perms.locationServiceOn(ctx) }
    val overlayOk = remember(tick) { AirShareHub.overlayPossible(ctx) }
    val notifOk = remember(tick) {
        Build.VERSION.SDK_INT < 33 ||
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED
    }

    val camLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { tick++ }
    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { tick++ }
    val notifLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { tick++ }

    fun turnOn() {
        if (!camOk) { camLauncher.launch(Manifest.permission.CAMERA); return }
        ContextCompat.startForegroundService(ctx, Intent(ctx, AirFlowService::class.java).setAction(AirFlowService.ACTION_SHARE))
    }

    fun turnOnTap() {
        if (!nearbyOk) { permLauncher.launch(Pairing.nearbyPermissions().toTypedArray()); return }
        ContextCompat.startForegroundService(ctx, Intent(ctx, AirFlowService::class.java).setAction(AirFlowService.ACTION_TAP))
    }

    fun addTile(air: Boolean) {
        if (Build.VERSION.SDK_INT >= 33) {
            try {
                val sbm = ctx.getSystemService(android.app.StatusBarManager::class.java)
                sbm.requestAddTileService(
                    ComponentName(ctx, if (air) AirShareTileService::class.java else TapShareTileService::class.java),
                    if (air) "Air Share" else "Tap Share",
                    android.graphics.drawable.Icon.createWithResource(ctx, R.drawable.ic_notif),
                    ctx.mainExecutor
                ) { _ -> tick++ }
                tileMsg = ""
            } catch (e: Exception) {
                tileMsg = "Could not open the add-tile prompt. Add it by hand: swipe down, tap the pencil, drag it in."
            }
        } else {
            tileMsg = "Swipe down twice, tap the pencil or Edit, and drag " + (if (air) "Air Share" else "Tap Share") + " into your tiles."
        }
    }

    AirScroll(top = 104.dp) {
        ScreenHeader("Air Share", "Send and receive in any app, by hand or by touch")

        SectionCard(if (shareOn) "Air Share is ON" else "Air Share is OFF") {
            Text(
                if (shareOn) (status.ifEmpty { "Waiting for photos." })
                else "Turn it on to receive in the background. To send, you only share a photo to Air Flow.",
                style = MaterialTheme.typography.bodySmall, color = if (shareOn) c.ok else c.dim
            )
            AirButton(
                if (shareOn) "Turn off" else "Turn on Air Share (hand + touch)",
                { if (shareOn) ctx.stopService(Intent(ctx, AirFlowService::class.java)) else turnOn() },
                Modifier.fillMaxWidth(), icon = IconKind.BOLT
            )
            if (!shareOn) {
                AirButton(
                    "Turn on Tap Share only (no camera)",
                    { turnOnTap() },
                    Modifier.fillMaxWidth(), filled = false, icon = IconKind.SHARE
                )
            }
            Text(
                "Air Share uses the front camera for your hand and also lets two phones touch to send. Tap Share only needs the touch. " +
                    "Turning on Air Share pauses the normal Air Flow gestures, because they share the camera.",
                style = MaterialTheme.typography.bodySmall, color = c.dim
            )
        }

        SectionCard("Setup") {
            SetupRow("Camera (reads your hand)", camOk, "Allow") { camLauncher.launch(Manifest.permission.CAMERA) }
            SetupRow("Nearby devices and Location", nearbyOk, "Allow") { permLauncher.launch(Pairing.nearbyPermissions().toTypedArray()) }
            SetupRow("Location switch is ON", locOn, "Turn on") { Perms.openLocationSettings(ctx) }
            SetupRow("Show the animation over other apps", overlayOk, "Allow") {
                try {
                    ctx.startActivity(
                        Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + ctx.packageName))
                            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    )
                } catch (_: Exception) {
                }
            }
            if (!overlayOk) {
                Text(
                    "Or switch on the Air Flow Accessibility service on the Home tab. It can draw over other apps without this permission.",
                    style = MaterialTheme.typography.bodySmall, color = c.dim
                )
            }
            if (Build.VERSION.SDK_INT >= 33) {
                SetupRow("Notifications", notifOk, "Allow") { notifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS) }
            }
        }

        OnlineCard()

        AirBlastCard()

        AirGrabCard()

        SectionCard("Quick Settings tiles") {
            Text(
                "Switch Air Share or Tap Share on and off from the swipe-down panel, without opening the app. Add the tiles once:",
                style = MaterialTheme.typography.bodySmall, color = c.dim
            )
            Row(horizontalArrangement = androidx.compose.foundation.layout.Arrangement.spacedBy(8.dp)) {
                AirButton("Add Air Share", { addTile(true) }, Modifier.weight(1f), filled = false)
                AirButton("Add Tap Share", { addTile(false) }, Modifier.weight(1f), filled = false)
            }
            if (tileMsg.isNotEmpty()) Text(tileMsg, style = MaterialTheme.typography.bodySmall, color = c.a2)
        }

        SectionCard("Live gesture island and speed") {
            Text(
                "A small black island at the top of the screen, over any app, shows your hand live: the pose, a ring that fills while you " +
                    "hold it, a mini skeleton of your hand, and what the gesture did when it fires. It needs the Accessibility service " +
                    "or 'Display over other apps', and shows the next time the Air Flow service starts.",
                style = MaterialTheme.typography.bodySmall, color = c.dim
            )
            AirButton(
                if (island) "Gesture island: ON" else "Gesture island: OFF",
                { island = !island; IslandHost.setEnabled(ctx, island) },
                Modifier.fillMaxWidth(), filled = island, icon = IconKind.CURSOR
            )
            AirButton(
                if (gpu) "Faster hand tracking (GPU): ON" else "Faster hand tracking (GPU): OFF",
                {
                    gpu = !gpu
                    Prefs.gpuHands = gpu
                    if (gpu) Prefs.gpuState = 0 // let it try again
                },
                Modifier.fillMaxWidth(), filled = false, icon = IconKind.BOLT
            )
            Text(
                "Takes effect the next time the service starts. If a phone ever cannot run the GPU model, Air Flow quietly goes back to the normal one.",
                style = MaterialTheme.typography.bodySmall, color = c.dim
            )
        }

        SectionCard("Quick Drop: links, text, YouTube") {
            Text(
                "Send a link, a YouTube video, some text or whatever you copied in one instant message. " +
                    "Share it to Air Flow from any app (or use the Send clipboard tile), then touch the phones together. " +
                    "A wand of light turns it into letters that fly into the other phone and re-form as a card.",
                style = MaterialTheme.typography.bodySmall, color = c.dim
            )
            AirButton(
                "Send what I copied",
                {
                    val text = try {
                        val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                        cm.primaryClip?.takeIf { it.itemCount > 0 }?.getItemAt(0)?.coerceToText(ctx)?.toString()
                    } catch (e: Exception) { null }
                    val item = QuickParser.parse(text)
                    if (item == null) qdMsg = "The clipboard is empty. Copy a link or some text first."
                    else { qdMsg = "Ready. Touch the tops of the two phones together."; QuickSender.start(ctx, item) }
                },
                Modifier.fillMaxWidth(), icon = IconKind.SHARE
            )
            if (qdMsg.isNotEmpty()) Text(qdMsg, style = MaterialTheme.typography.bodySmall, color = c.a2)
            AirButton(
                if (autoCopy) "Copy received drops automatically: ON" else "Copy received drops automatically: OFF",
                { autoCopy = !autoCopy; Prefs.quickAutoCopy = autoCopy },
                Modifier.fillMaxWidth(), filled = false
            )
            if (recent.isNotEmpty()) {
                Text("RECENT DROPS", color = c.a2, fontWeight = androidx.compose.ui.text.font.FontWeight.Black, fontSize = 11.sp, letterSpacing = 2.sp)
                for (item in recent.take(5)) {
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text(item.shown.take(46), color = c.text, fontSize = 12.sp, maxLines = 1, modifier = Modifier.weight(1f))
                        if (item.isLink) AirButton("Open", { QuickActions.open(ctx, item) }, Modifier.width(78.dp), filled = false)
                        AirButton("Copy", { QuickActions.copy(ctx, item) }, Modifier.width(78.dp), filled = false)
                    }
                }
                AirButton("Clear history", { QuickHistory.clear(); recentTick++ }, Modifier.fillMaxWidth(), filled = false)
            }
        }

        SectionCard("How Tap Share sends") {
            Text(
                "Default: after the phones touch, the photo slides across by itself. " +
                    "Samsung style: the photo waits on your screen and YOU drag it up and off the top edge. " +
                    "The other phone sees the part that left, can pull it down to take it, or push it back. A fast flick lands it instantly.",
                style = MaterialTheme.typography.bodySmall, color = c.dim
            )
            Row(horizontalArrangement = androidx.compose.foundation.layout.Arrangement.spacedBy(8.dp)) {
                AirButton("Default", { style = "classic"; Prefs.tapStyle = "classic" }, Modifier.weight(1f), filled = style == "classic")
                AirButton("Samsung style", { style = "drag"; Prefs.tapStyle = "drag" }, Modifier.weight(1f), filled = style == "drag")
            }
        }

        SectionCard("Touch sensitivity") {
            Text(
                "How light a touch of two phones counts. The other phone only accepts a touch it felt too, so a higher setting is safe.",
                style = MaterialTheme.typography.bodySmall, color = c.dim
            )
            Row(horizontalArrangement = androidx.compose.foundation.layout.Arrangement.spacedBy(8.dp)) {
                AirButton("Normal", { sens = 8; AirShareHub.setTapSensitivity(8) }, Modifier.weight(1f), filled = sens == 8)
                AirButton("High", { sens = 11; AirShareHub.setTapSensitivity(11) }, Modifier.weight(1f), filled = sens == 11)
                AirButton("Max", { sens = 13; AirShareHub.setTapSensitivity(13) }, Modifier.weight(1f), filled = sens == 13)
            }
        }

        SectionCard("How it works") {
            Text("SEND from any app", color = c.a2, fontWeight = androidx.compose.ui.text.font.FontWeight.Black, fontSize = 11.sp, letterSpacing = 2.sp)
            Text(
                "1. Open a photo in Gallery, WhatsApp or Files and tap Share, then choose Air Flow.\n" +
                    "2. Show your open palm to the front camera.\n" +
                    "3. Close your fist: the photo becomes an orb in your hand.\n" +
                    "4. Open your hand: the orb launches and flies to the other phone.",
                style = MaterialTheme.typography.bodyMedium, color = c.text
            )
            Text("OR TOUCH THE PHONES", color = c.a2, fontWeight = androidx.compose.ui.text.font.FontWeight.Black, fontSize = 11.sp, letterSpacing = 2.sp)
            Text(
                "Share a photo to Air Flow, then touch the tops of the two phones together. Ripples spread from the touch, the phones link, " +
                    "and the photo chip slides out of the top of yours into the top of theirs, with the percentage on both screens.",
                style = MaterialTheme.typography.bodyMedium, color = c.text
            )
            Text("RECEIVE with any app open", color = c.a2, fontWeight = androidx.compose.ui.text.font.FontWeight.Black, fontSize = 11.sp, letterSpacing = 2.sp)
            Text(
                "Keep Air Share or Tap Share ON. With a touch, the chip slides in through the top edge and blooms into the photo on its own. " +
                    "With a hand send, an orb drops in: make a fist, then open your hand. Either way it is already saved in Gallery > AirFlow.",
                style = MaterialTheme.typography.bodyMedium, color = c.text
            )
            Text(
                "Anyone nearby with Air Flow can connect while Air Share is ON, so turn it off when you are done.",
                style = MaterialTheme.typography.bodySmall, color = c.dim
            )
        }

        SectionCard("See it first") {
            Text(
                "Plays the full story on a sample picture: capture, launch, arrival and release. No second phone needed.",
                style = MaterialTheme.typography.bodySmall, color = c.dim
            )
            AirButton(
                "Preview the animation",
                {
                    demoMsg = if (AirShareHub.playDemo(ctx)) "Playing over your screen. Press Home to see it on top of other apps."
                    else "Allow 'Show the animation over other apps' first (or turn on the Accessibility service)."
                },
                Modifier.fillMaxWidth(), filled = false, icon = IconKind.PLAY
            )
            if (demoMsg.isNotEmpty()) Text(demoMsg, style = MaterialTheme.typography.bodySmall, color = c.a2)
        }
    }
}

@Composable
private fun SetupRow(title: String, ok: Boolean, action: String, onClick: () -> Unit) {
    val c = Air.c
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Box(
            Modifier.size(22.dp).clip(CircleShape).background(if (ok) c.ok else c.glassHi),
            contentAlignment = Alignment.Center
        ) {
            if (ok) AirIcon(IconKind.CHECK, Color.Black, Modifier.size(14.dp))
        }
        Spacer(Modifier.width(10.dp))
        Text(title, color = if (ok) c.text else c.dim, modifier = Modifier.weight(1f), fontSize = 13.sp)
        if (!ok) AirButton(action, onClick, Modifier.width(130.dp), filled = false)
    }
}
