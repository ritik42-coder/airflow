package com.airflow.app

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver

/**
 * Air Share anywhere: turn it on once, then send from the share sheet of any app and receive with the
 * app closed. The photo flies as an animated orb over whatever is on screen.
 */
@Composable
fun AirShareAnywhereScreen() {
    val ctx = LocalContext.current
    val owner = LocalLifecycleOwner.current
    val c = Air.c

    val shareOn by AirShareHub.active.collectAsState()
    val status by AirShareHub.status.collectAsState()
    var tick by remember { mutableIntStateOf(0) }
    var demoMsg by remember { mutableStateOf("") }

    DisposableEffect(owner) {
        val obs = LifecycleEventObserver { _, e -> if (e == Lifecycle.Event.ON_RESUME) tick++ }
        owner.lifecycle.addObserver(obs)
        onDispose { owner.lifecycle.removeObserver(obs) }
    }

    val camOk = remember(tick) { ContextCompat.checkSelfPermission(ctx, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED }
    val nearbyOk = remember(tick) { Perms.missing(ctx).isEmpty() }
    val locOn = remember(tick) { Perms.locationServiceOn(ctx) }
    val overlayOk = remember(tick) { AirShareHub.overlayPossible(ctx) }
    val notifOk = remember(tick) {
        Build.VERSION.SDK_INT < 33 ||
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED
    }

    val camLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { tick++ }
    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { tick++ }
    val notifLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { tick++ }

    fun turnOn() {
        if (!camOk) { camLauncher.launch(Manifest.permission.CAMERA); return }
        ContextCompat.startForegroundService(ctx, Intent(ctx, AirFlowService::class.java).setAction(AirFlowService.ACTION_SHARE))
    }

    AirScroll(top = 104.dp) {
        ScreenHeader("Air Share", "Send and receive in any app, with your hand")

        SectionCard(if (shareOn) "Air Share is ON" else "Air Share is OFF") {
            Text(
                if (shareOn) (status.ifEmpty { "Waiting for photos." })
                else "Turn it on to receive in the background. To send, you only share a photo to Air Flow.",
                style = MaterialTheme.typography.bodySmall, color = if (shareOn) c.ok else c.dim
            )
            AirButton(
                if (shareOn) "Turn off Air Share" else "Turn on Air Share",
                { if (shareOn) ctx.stopService(Intent(ctx, AirFlowService::class.java)) else turnOn() },
                Modifier.fillMaxWidth(), icon = IconKind.BOLT
            )
            Text(
                "Turning it off also pauses the normal Air Flow gestures, because they share the same camera.",
                style = MaterialTheme.typography.bodySmall, color = c.dim
            )
        }

        SectionCard("Setup") {
            SetupRow("Camera (reads your hand)", camOk, "Allow") { camLauncher.launch(Manifest.permission.CAMERA) }
            SetupRow("Nearby devices and Location", nearbyOk, "Allow") { permLauncher.launch(Pairing.nearbyPermissions().toTypedArray()) }
            SetupRow("Location switch is ON", locOn, "Turn on") { Perms.openLocationSettings(ctx) }
            SetupRow("Show the animation over other apps", overlayOk, "Allow") {
                try {
                    ctx.startActivity(
                        Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + ctx.packageName))
                            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    )
                } catch (_: Exception) {
                }
            }
            if (!overlayOk) {
                Text(
                    "Or switch on the Air Flow Accessibility service on the Home tab. It can draw over other apps without this permission.",
                    style = MaterialTheme.typography.bodySmall, color = c.dim
                )
            }
            if (Build.VERSION.SDK_INT >= 33) {
                SetupRow("Notifications", notifOk, "Allow") { notifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS) }
            }
        }

        SectionCard("How it works") {
            Text("SEND from any app", color = c.a2, fontWeight = androidx.compose.ui.text.font.FontWeight.Black, fontSize = 11.sp, letterSpacing = 2.sp)
            Text(
                "1. Open a photo in Gallery, WhatsApp or Files and tap Share, then choose Air Flow.\n" +
                    "2. Show your open palm to the front camera.\n" +
                    "3. Close your fist: the photo becomes an orb in your hand.\n" +
                    "4. Open your hand: the orb launches and flies to the other phone.",
                style = MaterialTheme.typography.bodyMedium, color = c.text
            )
            Text("RECEIVE with any app open", color = c.a2, fontWeight = androidx.compose.ui.text.font.FontWeight.Black, fontSize = 11.sp, letterSpacing = 2.sp)
            Text(
                "Keep Air Share ON and the phone near the sender. The orb drops in over whatever you are doing. " +
                    "Make a fist, then open your hand: the photo blooms out of the orb. It is already saved in Gallery > AirFlow.",
                style = MaterialTheme.typography.bodyMedium, color = c.text
            )
            Text(
                "Anyone nearby with Air Flow can connect while Air Share is ON, so turn it off when you are done.",
                style = MaterialTheme.typography.bodySmall, color = c.dim
            )
        }

        SectionCard("See it first") {
            Text(
                "Plays the full story on a sample picture: capture, launch, arrival and release. No second phone needed.",
                style = MaterialTheme.typography.bodySmall, color = c.dim
            )
            AirButton(
                "Preview the animation",
                {
                    demoMsg = if (AirShareHub.playDemo(ctx)) "Playing over your screen. Press Home to see it on top of other apps."
                    else "Allow 'Show the animation over other apps' first (or turn on the Accessibility service)."
                },
                Modifier.fillMaxWidth(), filled = false, icon = IconKind.PLAY
            )
            if (demoMsg.isNotEmpty()) Text(demoMsg, style = MaterialTheme.typography.bodySmall, color = c.a2)
        }
    }
}

@Composable
private fun SetupRow(title: String, ok: Boolean, action: String, onClick: () -> Unit) {
    val c = Air.c
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Box(
            Modifier.size(22.dp).clip(CircleShape).background(if (ok) c.ok else c.glassHi),
            contentAlignment = Alignment.Center
        ) {
            if (ok) AirIcon(IconKind.CHECK, Color.Black, Modifier.size(14.dp))
        }
        Spacer(Modifier.width(10.dp))
        Text(title, color = if (ok) c.text else c.dim, modifier = Modifier.weight(1f), fontSize = 13.sp)
        if (!ok) AirButton(action, onClick, Modifier.width(130.dp), filled = false)
    }
}
