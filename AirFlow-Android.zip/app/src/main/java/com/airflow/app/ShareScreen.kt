package com.airflow.app

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.PointF
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.CubicBezierEasing
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.core.animateFloat
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.util.lerp
import androidx.core.content.ContextCompat
import com.google.mlkit.vision.codescanner.GmsBarcodeScannerOptions
import com.google.mlkit.vision.codescanner.GmsBarcodeScanning
import com.google.mlkit.vision.barcode.common.Barcode
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.sin

enum class Stage { IDLE, READY, GRABBED, FLYING, SENT, WAITING, INCOMING, RECEIVED, FAILED }

private val SHARE_HAND_LINES = listOf(
    0 to 1, 1 to 2, 2 to 3, 3 to 4, 0 to 5, 5 to 6, 6 to 7, 7 to 8, 5 to 9, 9 to 10, 10 to 11, 11 to 12,
    9 to 13, 13 to 14, 14 to 15, 15 to 16, 13 to 17, 17 to 18, 18 to 19, 19 to 20, 0 to 17
)

// =============================================================================================
// Entry
// =============================================================================================

@Composable
fun TransferScreen() {
    val ctx = LocalContext.current
    var camOk by remember {
        mutableStateOf(ContextCompat.checkSelfPermission(ctx, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED)
    }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { camOk = it }
    if (camOk) {
        ShareContent()
    } else {
        AirScroll {
            ScreenHeader("Air Share", "Send photos with a hand gesture")
            SectionCard("Camera needed") {
                Text("The camera only reads your hand shape on this phone. Video is never saved or sent.", color = Air.c.dim)
                AirButton("Allow camera", { launcher.launch(Manifest.permission.CAMERA) }, Modifier.fillMaxWidth(), icon = IconKind.SCAN)
            }
        }
    }
}

private fun poseLabel(p: GestureEngine.Pose, has: Boolean): String = if (!has) "No hand seen" else when (p) {
    GestureEngine.Pose.OPEN -> "Open palm ✋"
    GestureEngine.Pose.FIST -> "Fist ✊"
    GestureEngine.Pose.PINCH -> "Pinch 🤏"
    GestureEngine.Pose.NONE -> "No hand seen"
    else -> "Other shape (${p.name.lowercase()})"
}

/** Live correction text: tells the user exactly what to change. */
private fun coach(step: Int, pose: GestureEngine.Pose, has: Boolean, palm: Float, photo: Boolean, linked: Boolean): String {
    if (!photo) return "Step 1: pick a photo below."
    if (!has) return "Show your hand to the front camera, about 30 to 50 cm away."
    if (palm < 0.10f) return "Move your hand closer. The whole hand should fill the box."
    if (palm > 0.42f) return "Move your hand back a little so all fingers stay in view."
    val tip = if (!linked) "  (Connect the other phone to really send.)" else ""
    return when (step) {
        0 -> if (pose == GestureEngine.Pose.OPEN) "Good. Hold the open palm still…$tip"
        else "Spread all 5 fingers wide, palm facing the camera.$tip"
        1 -> if (pose == GestureEngine.Pose.FIST) "Closing… hold the fist for a moment."
        else "Now close your hand into a tight fist to CAPTURE the photo."
        else -> if (pose == GestureEngine.Pose.OPEN) "Releasing…"
        else "Captured! Now OPEN your hand to RELEASE it to the other phone."
    }
}

/** Coaching for the receiving phone: fist, then open palm. */
private fun catchCoach(step: Int, pose: GestureEngine.Pose, has: Boolean): String {
    if (!has) return "A photo is waiting. Show your hand to the camera to catch it."
    return if (step == 0) {
        if (pose == GestureEngine.Pose.FIST) "Good. Hold the fist for a moment…"
        else "Make a fist ✊ to arm the catch."
    } else {
        if (pose == GestureEngine.Pose.OPEN) "Opening…"
        else "Now open your palm ✋ and the photo comes down."
    }
}

// =============================================================================================
// Main content
// =============================================================================================

@Composable
private fun ShareContent() {
    val ctx = LocalContext.current
    val owner = LocalLifecycleOwner.current
    val haptic = LocalHapticFeedback.current
    val c = Air.c
    val tc = remember { TransferController(ctx) }
    val tracker = remember { AirGrabTracker() }
    val receive = remember { AirReceiveTracker() }

    var stage by remember { mutableStateOf(Stage.IDLE) }
    var frame by remember { mutableStateOf<Bitmap?>(null) }
    var lms by remember { mutableStateOf<List<PointF>?>(null) }
    var pose by remember { mutableStateOf(GestureEngine.Pose.NONE) }
    var showDemo by remember { mutableStateOf(false) }
    var showSetup by remember { mutableStateOf(false) }
    var codeInput by remember { mutableStateOf("") }
    var pending by remember { mutableStateOf<(() -> Unit)?>(null) }
    val error by AirFlowState.error.collectAsState()

    fun onEvent(ev: AirGrabTracker.Ev) {
        when (ev) {
            AirGrabTracker.Ev.READY -> if (stage == Stage.IDLE) { stage = Stage.READY; haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove) }
            AirGrabTracker.Ev.GRAB -> {
                if (tc.photo != null && stage != Stage.FLYING && stage != Stage.GRABBED) {
                    stage = Stage.GRABBED
                    haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                    tracker.reset()
                } else if (tc.photo == null) {
                    tc.status = "Pick a photo first"
                    tracker.reset()
                    stage = Stage.IDLE
                }
            }
            AirGrabTracker.Ev.RELEASE -> {} // the sender no longer needs a third gesture
            AirGrabTracker.Ev.RESET -> if (stage == Stage.READY || stage == Stage.GRABBED) stage = Stage.IDLE
            AirGrabTracker.Ev.NONE -> {}
        }
    }

    fun onReceive(ev: AirReceiveTracker.Ev) {
        when (ev) {
            AirReceiveTracker.Ev.ACCEPT -> if (stage == Stage.WAITING) {
                stage = Stage.INCOMING
                haptic.performHapticFeedback(HapticFeedbackType.LongPress)
            }
            AirReceiveTracker.Ev.RESET -> if (stage == Stage.WAITING) receive.reset()
            else -> {}
        }
    }

    DisposableEffect(owner) {
        ctx.stopService(Intent(ctx, AirFlowService::class.java)) // the camera is shared with the background service
        val main = Handler(Looper.getMainLooper())
        val controller = HandController(ctx, owner, needBitmap = true) { r ->
            main.post {
                frame = r.bitmap
                lms = r.landmarks
                pose = r.pose
                val now = SystemClock.uptimeMillis()
                if (stage == Stage.WAITING) {
                    tracker.reset()
                    onReceive(receive.update(r.pose, now))
                } else {
                    receive.reset()
                    onEvent(tracker.update(r.pose, now))
                }
            }
        }
        controller.start()
        onDispose { controller.stop(); tc.close() }
    }

    LaunchedEffect(stage) {
        when (stage) {
            Stage.GRABBED -> {
                // let the implode play, then push the photo into the air
                delay(700)
                if (stage == Stage.GRABBED) {
                    stage = Stage.FLYING
                    tc.send { ok -> stage = if (ok) Stage.SENT else Stage.FAILED }
                }
            }
            Stage.SENT, Stage.FAILED -> {
                delay(2600)
                if (stage == Stage.SENT || stage == Stage.FAILED) stage = Stage.IDLE
                tracker.reset()
            }
            Stage.INCOMING -> {
                delay(1300)
                stage = Stage.RECEIVED
            }
            Stage.RECEIVED -> {
                delay(4200)
                if (stage == Stage.RECEIVED) stage = Stage.IDLE
                receive.reset()
            }
            else -> {}
        }
    }
    LaunchedEffect(tc.receivedTick) {
        // a photo arrived: hold it in the air until this phone makes the catch gesture
        if (tc.receivedTick > 0) {
            stage = Stage.WAITING
            haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
        }
    }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { u -> if (u != null) tc.pick(u) }
    val perms = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { _ ->
        pending?.invoke(); pending = null
    }
    fun withPerms(action: () -> Unit) {
        if (tc.mode == TMode.ONLINE) { action(); return }
        val need = Pairing.nearbyPermissions().filter { ContextCompat.checkSelfPermission(ctx, it) != PackageManager.PERMISSION_GRANTED }
        if (need.isEmpty()) action() else { pending = action; perms.launch(need.toTypedArray()) }
    }
    fun scanQr() {
        val opts = GmsBarcodeScannerOptions.Builder().setBarcodeFormats(Barcode.FORMAT_QR_CODE).enableAutoZoom().build()
        GmsBarcodeScanning.getClient(ctx, opts).startScan()
            .addOnSuccessListener { b ->
                val code = Pairing.parse(b.rawValue)
                if (code != null) withPerms { tc.join(code) } else tc.status = "That QR is not an Air Flow code"
            }
            .addOnFailureListener { tc.status = "Scan cancelled or unavailable. Type the code instead." }
    }

    val hasHand = lms != null
    val palm = lms?.let { hypot(it[0].x - it[9].x, it[0].y - it[9].y) } ?: 0f
    val stageBmp = if (stage == Stage.WAITING || stage == Stage.INCOMING || stage == Stage.RECEIVED) tc.received else tc.photo
    val shownProgress = if (stage == Stage.FLYING || stage == Stage.INCOMING) tc.progress else 0f

    AirScroll {
        ScreenHeader("Air Share", "Grab a photo in the air. Release it on another phone.")

        // ---- Stage ----
        SectionCard("Air stage") {
            AirStage(stage, stageBmp, shownProgress, Modifier.fillMaxWidth().aspectRatio(1.05f))
            Text(
                when (stage) {
                    Stage.IDLE -> tc.status
                    Stage.READY -> "Hand detected. Close your fist to capture."
                    Stage.GRABBED -> "Captured. Sending it into the air…"
                    Stage.FLYING -> "Flying through the air… ${(tc.progress * 100).toInt()}%"
                    Stage.SENT -> "In the air ✓ waiting for the other phone"
                    Stage.WAITING -> "A photo is in the air. Fist ✊ then palm ✋ to bring it down."
                    Stage.INCOMING -> "Catching it…"
                    Stage.RECEIVED -> "Received ✓ saved to Gallery > AirFlow"
                    Stage.FAILED -> tc.status
                },
                Modifier.fillMaxWidth(), textAlign = TextAlign.Center, fontWeight = FontWeight.SemiBold,
                color = if (stage == Stage.FAILED) c.warn else c.text
            )
        }

        // ---- Live view + what it sees ----
        SectionCard("What the camera sees") {
            error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Box(
                    Modifier.weight(1f).aspectRatio(0.75f).clip(RoundedCornerShape(22.dp)).background(Color.Black)
                        .border(1.5.dp, Brush.linearGradient(listOf(c.a2, c.a1, c.a3)), RoundedCornerShape(22.dp))
                ) {
                    val f = frame
                    if (f != null) {
                        val img = remember(f) { f.asImageBitmap() }
                        Image(img, null, Modifier.fillMaxSize(), contentScale = ContentScale.FillBounds)
                    } else Text("Starting camera…", Modifier.align(Alignment.Center), color = Color.White)
                    Canvas(Modifier.fillMaxSize()) {
                        val pts = lms ?: return@Canvas
                        SHARE_HAND_LINES.forEach { (a, b) ->
                            val p1 = Offset(pts[a].x * size.width, pts[a].y * size.height)
                            val p2 = Offset(pts[b].x * size.width, pts[b].y * size.height)
                            drawLine(c.a2.copy(alpha = 0.25f), p1, p2, strokeWidth = 10f)
                            drawLine(Color.White.copy(alpha = 0.9f), p1, p2, strokeWidth = 3f)
                        }
                        pts.forEach {
                            val o = Offset(it.x * size.width, it.y * size.height)
                            drawCircle(c.a3.copy(alpha = 0.3f), 11f, o)
                            drawCircle(c.a2, 6f, o)
                        }
                    }
                    Box(Modifier.align(Alignment.TopStart).padding(8.dp)) { Pill(if (hasHand) "TRACKING" else "SEARCHING", if (hasHand) c.ok else c.warn) }
                    Text(
                        poseLabel(pose, hasHand),
                        Modifier.align(Alignment.BottomStart).padding(6.dp).background(Color(0xAA000000), RoundedCornerShape(8.dp))
                            .padding(horizontal = 8.dp, vertical = 2.dp),
                        color = Color.White, fontSize = 12.sp
                    )
                }
                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    val catching = stage == Stage.WAITING
                    val names = if (catching) listOf("Make a fist ✊", "Open your palm ✋")
                    else listOf("Open palm ✋", "Close fist ✊")
                    val verbs = if (catching) listOf("ARM THE CATCH", "BRING IT DOWN")
                    else listOf("READY", "CAPTURE + SEND")
                    val stepNow = if (catching) receive.step else tracker.step
                    val holdNow = if (catching) receive.hold else tracker.hold
                    names.forEachIndexed { i, n ->
                        val done = stepNow > i
                        val cur = stepNow == i
                        Column {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    Modifier.size(22.dp).clip(CircleShape)
                                        .background(if (done) c.ok else if (cur) c.a2 else c.glassHi),
                                    contentAlignment = Alignment.Center
                                ) {
                                    if (done) AirIcon(IconKind.CHECK, Color.Black, Modifier.size(14.dp))
                                    else Text("${i + 1}", fontSize = 11.sp, fontWeight = FontWeight.Black, color = if (cur) Color.Black else c.dim)
                                }
                                Spacer(Modifier.width(8.dp))
                                Column {
                                    Text(n, fontWeight = FontWeight.Bold, fontSize = 13.sp, color = if (cur || done) c.text else c.dim)
                                    Text(verbs[i], fontSize = 10.sp, letterSpacing = 1.sp, color = c.dim)
                                }
                            }
                            if (cur) {
                                Spacer(Modifier.height(5.dp))
                                Box(Modifier.fillMaxWidth().height(5.dp).clip(RoundedCornerShape(50)).background(c.glassHi)) {
                                    Box(Modifier.fillMaxWidth(holdNow.coerceIn(0f, 1f)).height(5.dp)
                                        .background(Brush.horizontalGradient(listOf(c.a2, c.a1))))
                                }
                            }
                        }
                    }
                }
            }
            Text(
                "Seeing: ${poseLabel(pose, hasHand)}",
                fontWeight = FontWeight.Bold, color = c.a2
            )
            Text(
                if (stage == Stage.WAITING) catchCoach(receive.step, pose, hasHand)
                else coach(tracker.step, pose, hasHand, palm, tc.photo != null, tc.link == LinkState.CONNECTED),
                style = MaterialTheme.typography.bodyMedium, color = c.text
            )
            AirButton(if (showDemo) "Hide demo" else "Watch animated demo", { showDemo = !showDemo }, Modifier.fillMaxWidth(), filled = false, icon = IconKind.PLAY)
            if (showDemo) GestureDemo()
        }

        // ---- Step 1: photo ----
        SectionCard("1 · Choose photo") {
            val p = tc.photo
            if (p != null) {
                val img = remember(p) { p.asImageBitmap() }
                Image(img, null, Modifier.fillMaxWidth().height(150.dp).clip(RoundedCornerShape(18.dp)), contentScale = ContentScale.Crop)
            }
            AirButton(if (p == null) "Pick a photo" else "Change photo", { picker.launch("image/*") }, Modifier.fillMaxWidth(), icon = IconKind.SHARE)
        }

        // ---- Step 2: connect ----
        SectionCard("2 · Connect the other phone") {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                AirButton("Nearby (offline)", { if (tc.link == LinkState.IDLE) tc.mode = TMode.NEARBY }, Modifier.weight(1f), filled = tc.mode == TMode.NEARBY)
                AirButton("Online", { if (tc.link == LinkState.IDLE) tc.mode = TMode.ONLINE }, Modifier.weight(1f), filled = tc.mode == TMode.ONLINE)
            }
            Text(
                if (tc.mode == TMode.NEARBY) "Phones talk directly over Bluetooth + Wi-Fi Direct. Fastest when close. No internet needed. Both phones must pick Nearby."
                else "Photo goes through Firebase and Supabase. Works across the room or the world. Both phones must pick Online.",
                style = MaterialTheme.typography.bodySmall, color = c.dim
            )
            when (tc.link) {
                LinkState.IDLE -> {
                    AirButton("Show my QR and code", { withPerms { tc.host() } }, Modifier.fillMaxWidth(), icon = IconKind.SCAN)
                    AirButton("Scan the other phone's QR", { scanQr() }, Modifier.fillMaxWidth(), filled = false, icon = IconKind.SCAN)
                    OutlinedTextField(
                        value = codeInput, onValueChange = { codeInput = it.filter(Char::isDigit).take(6) },
                        label = { Text("or type the 6-digit code") }, singleLine = true, modifier = Modifier.fillMaxWidth()
                    )
                    AirButton("Connect with code", { if (codeInput.length == 6) withPerms { tc.join(codeInput) } }, Modifier.fillMaxWidth(),
                        enabled = codeInput.length == 6, filled = false)
                }
                else -> {
                    val col = when (tc.link) { LinkState.CONNECTED -> c.ok; LinkState.FAILED -> c.warn; else -> c.a2 }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        PulseDot(col, true)
                        Spacer(Modifier.width(8.dp))
                        Text(tc.status, fontWeight = FontWeight.SemiBold, color = col)
                    }
                    if (tc.hosting && tc.link != LinkState.CONNECTED && tc.code.isNotEmpty()) QrCard(tc.code)
                    if (tc.link == LinkState.FAILED) AirButton("Try again", {
                        val code = tc.code; val h = tc.hosting
                        tc.disconnect()
                        if (h) withPerms { tc.host() } else if (code.length == 6) withPerms { tc.join(code) }
                    }, Modifier.fillMaxWidth())
                    AirButton("Disconnect", { tc.disconnect() }, Modifier.fillMaxWidth(), filled = false)
                }
            }
        }

        // ---- Online setup ----
        SectionCard("Online setup (Firebase + Supabase)") {
            AirButton(if (showSetup) "Hide" else "Open setup", { showSetup = !showSetup }, Modifier.fillMaxWidth(), filled = false, icon = IconKind.SLIDERS)
            if (showSetup) {
                var fb by remember { mutableStateOf(Prefs.fbUrl) }
                var su by remember { mutableStateOf(Prefs.sbUrl) }
                var sk by remember { mutableStateOf(Prefs.sbKey) }
                var sb by remember { mutableStateOf(Prefs.sbBucket) }
                Text("Firebase is required (it carries the live signal). Supabase is optional and gives full-quality photos; without it a 1280 px copy goes through Firebase.",
                    style = MaterialTheme.typography.bodySmall, color = c.dim)
                OutlinedTextField(fb, { fb = it; Prefs.fbUrl = it.trim() }, label = { Text("Firebase Realtime DB URL") },
                    placeholder = { Text("https://yourproject-default-rtdb.firebaseio.com") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(su, { su = it; Prefs.sbUrl = it.trim() }, label = { Text("Supabase project URL (optional)") },
                    placeholder = { Text("https://xxxx.supabase.co") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(sk, { sk = it; Prefs.sbKey = it.trim() }, label = { Text("Supabase anon key (optional)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(sb, { sb = it; Prefs.sbBucket = it.trim().ifEmpty { "airflow" } }, label = { Text("Supabase bucket (public)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            }
        }
    }
}

// =============================================================================================
// QR card with scan line
// =============================================================================================

@Composable
private fun QrCard(code: String) {
    val c = Air.c
    val qr = remember(code) { Pairing.qr(Pairing.payload(code)).asImageBitmap() }
    val inf = rememberInfiniteTransition(label = "qr")
    val line = inf.animateFloat(0f, 1f, infiniteRepeatable(tween(1800, easing = FastOutSlowInEasing)), label = "line")
    Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Box(Modifier.size(220.dp).clip(RoundedCornerShape(20.dp)).background(Color.White).padding(10.dp)) {
            Image(qr, null, Modifier.fillMaxSize())
            Canvas(Modifier.fillMaxSize()) {
                val y = size.height * line.value
                drawRect(Brush.verticalGradient(listOf(Color.Transparent, c.a2.copy(alpha = 0.55f), Color.Transparent), y - 40f, y + 40f), Offset(0f, y - 40f), Size(size.width, 80f))
            }
        }
        Text("${code.substring(0, 3)} ${code.substring(3)}", fontSize = 30.sp, fontWeight = FontWeight.Black, letterSpacing = 4.sp, color = c.text)
        Text("Scan this QR or type the code on the other phone", style = MaterialTheme.typography.bodySmall, color = c.dim)
    }
}

// =============================================================================================
// Demo: sender phone -> receiver phone, step by step
// =============================================================================================

@Composable
private fun GestureDemo() {
    val c = Air.c
    var step by remember { mutableIntStateOf(0) }
    val fly = remember { Animatable(0f) }
    val orb = remember { Animatable(0f) }
    LaunchedEffect(Unit) {
        while (true) {
            step = 0; fly.snapTo(0f); orb.snapTo(0f)
            delay(1900)
            step = 1; orb.animateTo(1f, tween(800, easing = FastOutSlowInEasing))
            delay(800)
            step = 2; fly.animateTo(1f, tween(1100, easing = CubicBezierEasing(0.5f, 0f, 0.2f, 1f)))
            step = 3; orb.animateTo(0f, tween(750, easing = FastOutSlowInEasing))
            delay(1700)
        }
    }
    val captions = listOf(
        "1  Sender: show an open palm ✋ and hold still",
        "2  Sender: close into a fist ✊  =  CAPTURE and send",
        "3  Receiver: make a fist ✊  =  arm the catch",
        "4  Receiver: open your palm ✋  =  the photo lands, saved to Gallery"
    )
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        BoxWithConstraints(Modifier.fillMaxWidth().height(190.dp)) {
            val travel = maxWidth - 92.dp
            listOf(Alignment.CenterStart to "Sender", Alignment.CenterEnd to "Receiver").forEach { (al, label) ->
                Column(Modifier.align(al), horizontalAlignment = Alignment.CenterHorizontally) {
                    Box(Modifier.size(92.dp, 150.dp).clip(RoundedCornerShape(18.dp)).background(c.glass).border(1.5.dp, c.stroke, RoundedCornerShape(18.dp)),
                        contentAlignment = Alignment.TopCenter) {
                        if (label == "Sender") Text(
                            if (step == 1) "✊" else if (step == 3) "" else "✋", fontSize = 30.sp, modifier = Modifier.padding(top = 8.dp)
                        )
                    }
                    Text(label, fontSize = 11.sp, color = c.dim)
                }
            }
            Box(
                Modifier.offset(x = 18.dp + travel * fly.value, y = 52.dp).size(56.dp)
                    .graphicsLayer { val s = lerp(1f, 0.7f, orb.value); scaleX = s; scaleY = s; rotationZ = orb.value * 360f }
                    .clip(RoundedCornerShape(percent = (14 + 36 * orb.value).toInt()))
                    .background(Brush.linearGradient(listOf(c.a2, c.a1, c.a3))),
                contentAlignment = Alignment.Center
            ) { Text(if (orb.value > 0.5f) "" else "🏞️", fontSize = 26.sp) }
        }
        captions.forEachIndexed { i, t ->
            Text(t, fontSize = 12.sp, fontWeight = if (i == step) FontWeight.Black else FontWeight.Normal, color = if (i == step) c.a2 else c.dim)
        }
    }
}

// =============================================================================================
// The premium stage: capture implode, release shockwave + comet, receive landing + burst
// =============================================================================================

@Composable
fun AirStage(stage: Stage, bmp: Bitmap?, progress: Float, modifier: Modifier = Modifier) {
    val c = Air.c
    val orb = remember { Animatable(0f) }      // 0 = photo, 1 = glowing orb
    val yOff = remember { Animatable(0f) }     // fraction of stage height; negative = up
    val ring = remember { Animatable(0f) }
    val burst = remember { Animatable(0f) }
    val spin = remember { Animatable(0f) }
    val appear = remember { Animatable(1f) }
    val inf = rememberInfiniteTransition(label = "stage")
    val pulse = inf.animateFloat(0f, 1f, infiniteRepeatable(tween(1200, easing = LinearEasing)), label = "pulse")

    LaunchedEffect(stage) {
        when (stage) {
            Stage.IDLE, Stage.FAILED, Stage.READY -> {
                yOff.snapTo(0f); appear.snapTo(1f)
                orb.animateTo(0f, tween(450, easing = FastOutSlowInEasing))
                spin.snapTo(0f)
            }
            Stage.GRABBED -> {
                ring.snapTo(0f)
                launch { ring.animateTo(1f, tween(650)) }
                launch { spin.animateTo(360f, tween(900, easing = FastOutSlowInEasing)) }
                orb.animateTo(1f, tween(750, easing = FastOutSlowInEasing))
            }
            Stage.FLYING -> {
                ring.snapTo(0f)
                launch { ring.animateTo(1f, tween(600)) }
                yOff.animateTo(-1.45f, tween(950, easing = CubicBezierEasing(0.55f, 0f, 1f, 0.55f)))
            }
            Stage.SENT -> {
                orb.snapTo(0f); yOff.snapTo(0f); appear.snapTo(0.3f); burst.snapTo(0f)
                launch { burst.animateTo(1f, tween(900)) }
                appear.animateTo(1f, spring(dampingRatio = 0.55f, stiffness = Spring.StiffnessLow))
            }
            Stage.WAITING -> {
                // a glowing orb hangs at the top of the stage, holding the photo
                appear.snapTo(0f); orb.snapTo(1f); yOff.snapTo(-1.12f); spin.snapTo(0f)
                ring.snapTo(0f)
                launch { ring.animateTo(1f, tween(900)) }
            }
            Stage.INCOMING -> {
                appear.snapTo(1f); orb.snapTo(1f); yOff.snapTo(-1.45f)
                yOff.animateTo(0f, spring(dampingRatio = 0.62f, stiffness = Spring.StiffnessLow))
            }
            Stage.RECEIVED -> {
                ring.snapTo(0f); burst.snapTo(0f)
                launch { ring.animateTo(1f, tween(750)) }
                launch { burst.animateTo(1f, tween(1200)) }
                orb.animateTo(0f, tween(700, easing = FastOutSlowInEasing))
                spin.snapTo(0f)
            }
        }
    }

    BoxWithConstraints(
        modifier.clip(RoundedCornerShape(24.dp))
            .background(Brush.radialGradient(listOf(c.a1.copy(alpha = 0.28f), c.bg1.copy(alpha = 0.9f))))
            .border(1.dp, c.stroke, RoundedCornerShape(24.dp))
    ) {
        val boxH = maxHeight
        val photoSize = maxWidth * 0.58f
        val particleColors = listOf(c.a1, c.a2, c.a3, Color.White)

        // layer 1: glow, rings, particles
        Canvas(Modifier.fillMaxSize()) {
            val cx = size.width / 2f
            val cy = size.height / 2f + yOff.value * size.height
            val r = size.minDimension * 0.5f
            if (stage == Stage.READY) {
                drawCircle(c.ok.copy(alpha = 0.25f + 0.4f * pulse.value), r * (0.62f + 0.05f * pulse.value), Offset(cx, cy), style = Stroke(5f))
            }
            if (orb.value > 0.05f) {
                drawCircle(Brush.radialGradient(listOf(c.a2.copy(alpha = 0.55f * orb.value), Color.Transparent), Offset(cx, cy), r * 0.7f), r * 0.7f, Offset(cx, cy))
            }
            if (ring.value in 0.001f..0.999f) {
                drawCircle(c.a2.copy(alpha = (1f - ring.value) * 0.85f), r * (0.2f + 0.85f * ring.value), Offset(cx, cy), style = Stroke(5f + 7f * (1f - ring.value)))
                drawCircle(c.a3.copy(alpha = (1f - ring.value) * 0.55f), r * (0.1f + 0.65f * ring.value), Offset(cx, cy), style = Stroke(3f))
            }
            if (stage == Stage.GRABBED && orb.value < 0.98f) {
                for (i in 0 until 28) {
                    val a = i * 2.39996f
                    val rr = r * 0.95f * (1f - orb.value) * (0.55f + 0.45f * ((i * 7) % 5) / 4f)
                    drawCircle(particleColors[i % 4].copy(alpha = 0.9f * (1f - orb.value)), 4f + (i % 3) * 2f, Offset(cx + cos(a) * rr, cy + sin(a) * rr))
                }
            }
            if (burst.value in 0.001f..0.999f) {
                for (i in 0 until 36) {
                    val a = i * 2.39996f
                    val rr = r * (0.25f + 0.85f * burst.value) * (0.65f + 0.35f * ((i * 13) % 7) / 6f)
                    drawCircle(particleColors[i % 4].copy(alpha = 1f - burst.value), 6f * (1f - burst.value) + 2f, Offset(cx + cos(a) * rr, cy + sin(a) * rr))
                }
            }
            if (stage == Stage.FLYING) {
                for (k in 1..16) {
                    val t = k / 16f
                    drawCircle(c.a2.copy(alpha = 0.55f * (1f - t)), r * 0.13f * (1f - 0.6f * t), Offset(cx + sin(k * 0.9f) * 6f, cy + k * r * 0.11f))
                }
            }
            if (progress > 0.01f && progress < 0.999f) {
                drawArc(c.a2, -90f, 360f * progress, false, Offset(cx - r * 0.78f, size.height / 2f - r * 0.78f), Size(r * 1.56f, r * 1.56f), style = Stroke(8f, cap = androidx.compose.ui.graphics.StrokeCap.Round))
            }
        }

        // layer 2: the photo that shrinks into an orb
        Box(
            Modifier.align(Alignment.Center).size(photoSize)
                .graphicsLayer {
                    translationY = yOff.value * boxH.toPx()
                    val s = lerp(1f, 0.22f, orb.value) * appear.value
                    scaleX = s; scaleY = s
                    rotationZ = spin.value * orb.value
                    alpha = if (yOff.value < -1.2f) 0f else 1f
                }
                .clip(RoundedCornerShape(percent = (7 + 43 * orb.value).toInt().coerceIn(7, 50)))
                .border(2.dp, Brush.linearGradient(listOf(c.a2, c.a3)), RoundedCornerShape(percent = (7 + 43 * orb.value).toInt().coerceIn(7, 50)))
        ) {
            if (bmp != null) {
                val img = remember(bmp) { bmp.asImageBitmap() }
                Image(img, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
            } else {
                Box(Modifier.fillMaxSize().background(c.glass), contentAlignment = Alignment.Center) {
                    Text("Pick a photo", color = c.dim, fontWeight = FontWeight.SemiBold)
                }
            }
            Box(
                Modifier.fillMaxSize().graphicsLayer { alpha = orb.value * orb.value }
                    .background(Brush.radialGradient(listOf(Color.White, c.a2, c.a1)))
            )
        }
    }
}
