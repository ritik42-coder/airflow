package com.airflow.app

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PointF
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import kotlin.math.hypot
import kotlin.math.min
import kotlin.math.sin

/** Where the typed characters go: an app text field, or the editor of any other app. */
interface TypeSink {
    fun text(s: String)
    fun del()
    fun enter()
}

/**
 * The air keyboard: a slab of glass hanging in the air in front of the camera. It is drawn through
 * a perspective matrix, so it has real depth; it tilts with the phone (parallax) and it can be
 * moved and resized with two hands. Typing is by pinch, touch still works, and every hit is tested
 * through the inverse matrix so what you point at is what you press.
 */
class AirKeyboardView(ctx: Context, private val sink: TypeSink) : View(ctx) {

    private val keys = ArrayList<AirKey>()
    private var pressTimes = LongArray(0)
    private var shift = false
    private var autoShift = false
    private var symbols = false

    private var cursorX = -1f
    private var cursorY = -1f
    private var visible = false
    private var pinchDown = false
    private var cooldownUntil = 0L
    private var hoverIdx = -1
    private var frame: Bitmap? = null
    private var hands: List<List<PointF>> = emptyList()

    // ---- the floating slab -------------------------------------------------------------
    private var scale = 1f
    private var shiftX = 0f
    private var shiftY = 0f
    private var tiltX = 0f
    private var tiltY = 0f
    private var baseX = Float.NaN
    private var baseY = Float.NaN
    private var twoHandDist = 0f
    private var twoHandMid = PointF()
    private var twoHand = false

    private val kb = RectF()
    private val panel = RectF()
    private val flatQuad = FloatArray(8)
    private val quad = FloatArray(8)
    private val matrix = Matrix()
    private val inverse = Matrix()
    private val tmp = RectF()
    private val tmp2 = RectF()

    private val density = resources.displayMetrics.density
    private val bgPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val keyPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val glowPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val smallPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val linePaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val path = Path()

    private val accent = 0xFF22D3EE.toInt()
    private val accent2 = 0xFF8B5CFF.toInt()
    private val ink = 0xFFF3F6FF.toInt()

    private val sensors = ctx.getSystemService(Context.SENSOR_SERVICE) as? SensorManager
    private val accel = sensors?.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)
    private val tiltListener = object : SensorEventListener {
        override fun onSensorChanged(e: SensorEvent) {
            val ax = e.values[0] / 9.81f
            val ay = e.values[1] / 9.81f
            if (baseX.isNaN()) {
                baseX = ax
                baseY = ay
            }
            tiltX = tiltX * 0.86f + ((ax - baseX).coerceIn(-1f, 1f)) * 0.14f
            tiltY = tiltY * 0.86f + ((ay - baseY).coerceIn(-1f, 1f)) * 0.14f
            invalidate()
        }

        override fun onAccuracyChanged(s: Sensor?, accuracy: Int) {}
    }

    init {
        textPaint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        textPaint.textAlign = Paint.Align.CENTER
        textPaint.color = ink
        smallPaint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        smallPaint.textAlign = Paint.Align.LEFT
        smallPaint.color = 0xFF9AA7CB.toInt()
        linePaint.color = 0x33FFFFFF
        linePaint.strokeWidth = 1f * density
        glowPaint.style = Paint.Style.STROKE
        glowPaint.strokeWidth = 2f * density
        isFocusable = false
        isClickable = true
        scale = Prefs.kbScale.coerceIn(0.62f, 1.12f)
        shiftX = Prefs.kbShiftX
        shiftY = Prefs.kbShiftY
    }

    // ------------------------------------------------------------------------------ lifecycle

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        accel?.let { sensors?.registerListener(tiltListener, it, SensorManager.SENSOR_DELAY_GAME) }
    }

    override fun onDetachedFromWindow() {
        sensors?.unregisterListener(tiltListener)
        Prefs.kbScale = scale
        Prefs.kbShiftX = shiftX
        Prefs.kbShiftY = shiftY
        super.onDetachedFromWindow()
    }

    // ------------------------------------------------------------------------------ measuring

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        val w = MeasureSpec.getSize(widthMeasureSpec)
        val want = (330 * density).toInt()
        val mode = MeasureSpec.getMode(heightMeasureSpec)
        val h = when (mode) {
            MeasureSpec.EXACTLY -> MeasureSpec.getSize(heightMeasureSpec)
            MeasureSpec.AT_MOST -> min(want, MeasureSpec.getSize(heightMeasureSpec))
            else -> want
        }
        setMeasuredDimension(w, h)
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        panel.set(0f, 0f, w.toFloat(), h.toFloat())
        val padX = 10f * density
        val padTop = 34f * density
        val padBottom = 10f * density
        kb.set(padX, padTop, w - padX, h - padBottom)
        build()
    }

    // ------------------------------------------------------------------------------ layout

    private fun build() {
        keys.clear()
        keys.addAll(AirKeyLayout.build(kb.left, kb.top, kb.width(), kb.height(), 3f * density, symbols, shift))
        pressTimes = LongArray(keys.size)
        hoverIdx = -1
    }

    private fun keyAt(x: Float, y: Float): Int = AirKeyLayout.hit(keys, x, y)

    /** Screen point -> flat keyboard point, through the inverse of the perspective matrix. */
    private fun toFlat(x: Float, y: Float): PointF {
        inverse.set(matrix)
        if (!inverse.invert(inverse)) return PointF(x, y)
        val p = floatArrayOf(x, y)
        inverse.mapPoints(p)
        return PointF(p[0], p[1])
    }

    /** Builds the perspective quad from the flat keyboard rect. */
    private fun buildQuad() {
        val w = kb.width()
        val h = kb.height()
        val cx = kb.centerX() + shiftX * width
        val cy = kb.centerY() + shiftY * height
        val sw = w * scale
        val sh = h * scale
        // the top edge is narrower: that is what reads as depth
        val persp = (0.16f + tiltY * 0.10f).coerceIn(0.04f, 0.34f)
        val topW = sw * (1f - persp)
        val skew = (-tiltX * 0.55f) * sw * 0.5f

        val top = cy - sh / 2f
        val bottom = cy + sh / 2f
        val leftB = cx - sw / 2f
        val rightB = cx + sw / 2f
        val leftT = cx - topW / 2f + skew
        val rightT = cx + topW / 2f + skew

        quad[0] = leftT
        quad[1] = top
        quad[2] = rightT
        quad[3] = top
        quad[4] = rightB
        quad[5] = bottom
        quad[6] = leftB
        quad[7] = bottom

        flatQuad[0] = kb.left
        flatQuad[1] = kb.top
        flatQuad[2] = kb.right
        flatQuad[3] = kb.top
        flatQuad[4] = kb.right
        flatQuad[5] = kb.bottom
        flatQuad[6] = kb.left
        flatQuad[7] = kb.bottom

        matrix.setPolyToPoly(flatQuad, 0, quad, 0, 4)
    }

    // ------------------------------------------------------------------------------ input

    fun setAutoShift(on: Boolean) {
        if (autoShift == on) return
        autoShift = on
        if (on != shift) {
            shift = on
            build()
            invalidate()
        }
    }

    fun onHands(hs: List<List<PointF>>) {
        hands = hs
        buildQuad()
        if (hs.isEmpty() || hs[0].size < 21) {
            visible = false
            pinchDown = false
            hoverIdx = -1
            twoHandDist = 0f
            invalidate()
            return
        }
        // two hands: pinch out to resize, move together to slide the slab
        if (hs.size >= 2 && hs[1].size >= 21) {
            val a = hs[0][8]
            val b = hs[1][8]
            val d = hypot(a.x - b.x, a.y - b.y)
            val mx = (a.x + b.x) / 2f
            val my = (a.y + b.y) / 2f
            if (twoHandDist > 0.001f && d > 0.001f) {
                scale = (scale * (d / twoHandDist)).coerceIn(0.62f, 1.12f)
                shiftX = (shiftX + (mx - twoHandMid.x) * 0.9f).coerceIn(-0.22f, 0.22f)
                shiftY = (shiftY + (my - twoHandMid.y) * 0.9f).coerceIn(-0.16f, 0.16f)
            }
            twoHandDist = d
            twoHandMid.set(mx, my)
            twoHand = true
            hoverIdx = -1
            cursorX = mx * width
            cursorY = my * height
            visible = true
            invalidate()
            return
        }
        twoHandDist = 0f
        twoHand = false

        val hand = hs[0]
        val tip = hand[8]
        val thumb = hand[4]
        val d = hypot(tip.x - thumb.x, tip.y - thumb.y)
        val nx = ((tip.x - 0.10f) / 0.80f).coerceIn(0f, 1f)
        val ny = ((tip.y - 0.10f) / 0.80f).coerceIn(0f, 1f)
        cursorX = nx * width
        cursorY = ny * height
        visible = true

        val flat = toFlat(cursorX, cursorY)
        hoverIdx = keyAt(flat.x, flat.y)

        val down = d < 0.052f
        val now = System.currentTimeMillis()
        if (down && !pinchDown) {
            pinchDown = true
            if (hoverIdx >= 0 && now > cooldownUntil) {
                press(hoverIdx)
                cooldownUntil = now + 180
            }
        } else if (!down) {
            pinchDown = false
        }
        invalidate()
    }

    fun onFrame(bmp: Bitmap?) {
        frame = bmp
        invalidate()
    }

    private fun press(i: Int) {
        val k = keys.getOrNull(i) ?: return
        pressTimes[i] = System.currentTimeMillis()
        performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
        when (k.special) {
            AirKey.SHIFT -> {
                shift = !shift
                autoShift = false
                build()
            }
            AirKey.BACKSPACE -> sink.del()
            AirKey.ENTER -> sink.enter()
            AirKey.SPACE -> sink.text(" ")
            AirKey.MODE -> {
                symbols = !symbols
                build()
            }
            else -> {
                var t = k.code
                if (shift && t.length == 1 && t[0].isLetter()) {
                    t = t.uppercase()
                    shift = false
                    autoShift = false
                    build()
                }
                sink.text(t)
            }
        }
        invalidate()
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (e.actionMasked == MotionEvent.ACTION_DOWN) {
            val flat = toFlat(e.x, e.y)
            val i = keyAt(flat.x, flat.y)
            if (i >= 0) {
                press(i)
                return true
            }
        }
        return true
    }

    // ------------------------------------------------------------------------------ drawing

    override fun onDraw(c: Canvas) {
        val now = System.currentTimeMillis()
        buildQuad()

        // 1. the camera behind the slab, so it really looks like it hangs in the air
        bgPaint.color = 0xFF05070E.toInt()
        c.drawRect(panel, bgPaint)
        val b = frame
        if (b != null) {
            c.drawBitmap(b, null, panel, null)
            bgPaint.shader = LinearGradient(
                0f, 0f, 0f, height.toFloat(),
                intArrayOf(0x66000000, 0xAA05070E.toInt(), 0xE605070E.toInt()),
                null, Shader.TileMode.CLAMP
            )
            c.drawRect(panel, bgPaint)
            bgPaint.shader = null
        }
        drawHandOverlay(c)

        // 2. the floating slab, drawn through the perspective matrix
        c.save()
        c.concat(matrix)
        drawSlab(c, now)
        c.restore()

        // 3. edge light around the quad, then the cursor in screen space
        drawQuadEdge(c)
        drawCursor(c, now)
        drawStatus(c)

        var busy = false
        for (t in pressTimes) if (t != 0L && now - t < 240) busy = true
        if (busy || visible) postInvalidateOnAnimation()
    }

    private fun drawSlab(c: Canvas, now: Long) {
        // glass plate
        bgPaint.shader = LinearGradient(
            kb.left, kb.top, kb.right, kb.bottom,
            intArrayOf(0xF00C1222.toInt(), 0xF0060A14.toInt()),
            null, Shader.TileMode.CLAMP
        )
        c.drawRoundRect(kb, 20f * density, 20f * density, bgPaint)
        bgPaint.shader = null

        val r = 9f * density
        for (i in keys.indices) {
            val k = keys[i]
            val t = pressTimes[i]
            val p = if (t != 0L) (1f - (now - t) / 240f).coerceIn(0f, 1f) else 0f
            tmp.set(k.x, k.y, k.x + k.w, k.y + k.h)
            val isSpecial = k.special != AirKey.NORMAL
            if (p > 0f) tmp.offset(0f, 1.5f * density * p)

            keyPaint.shader = LinearGradient(
                0f, tmp.top, 0f, tmp.bottom,
                if (isSpecial) intArrayOf(0xFF16203A.toInt(), 0xFF0D1526.toInt())
                else intArrayOf(0xFF232C48.toInt(), 0xFF161D31.toInt()),
                null, Shader.TileMode.CLAMP
            )
            c.drawRoundRect(tmp, r, r, keyPaint)
            keyPaint.shader = null

            if (p > 0f) {
                keyPaint.shader = LinearGradient(
                    tmp.left, tmp.top, tmp.right, tmp.bottom,
                    accent2, accent, Shader.TileMode.CLAMP
                )
                keyPaint.alpha = (p * 255).toInt()
                c.drawRoundRect(tmp, r, r, keyPaint)
                keyPaint.alpha = 255
                keyPaint.shader = null
            }

            if (i == hoverIdx) {
                glowPaint.color = accent
                glowPaint.alpha = 210
                c.drawRoundRect(tmp, r, r, glowPaint)
            } else {
                linePaint.color = 0x22FFFFFF
                linePaint.strokeWidth = 1f * density
                c.drawRoundRect(tmp, r, r, linePaint)
            }

            textPaint.textSize = if (k.special == AirKey.SPACE) 11f * density else min(k.h * 0.42f, 20f * density)
            textPaint.color = if (p > 0.35f) Color.WHITE else ink
            val label = if (k.special == AirKey.SHIFT && shift) "⇧" else k.label
            c.drawText(label, tmp.centerX(), tmp.centerY() + textPaint.textSize * 0.36f, textPaint)
        }
    }

    private fun drawQuadEdge(c: Canvas) {
        path.reset()
        path.moveTo(quad[0], quad[1])
        path.lineTo(quad[2], quad[3])
        path.lineTo(quad[4], quad[5])
        path.lineTo(quad[6], quad[7])
        path.close()
        glowPaint.color = accent
        glowPaint.alpha = 90
        glowPaint.strokeWidth = 6f * density
        c.drawPath(path, glowPaint)
        glowPaint.color = 0x66FFFFFF
        glowPaint.alpha = 255
        glowPaint.strokeWidth = 1.4f * density
        c.drawPath(path, glowPaint)
    }

    private fun drawHandOverlay(c: Canvas) {
        val h = hands.firstOrNull() ?: return
        if (h.size < 21) return
        for ((a, b) in HAND_BONES) {
            val x1 = h[a].x * width
            val y1 = h[a].y * height
            val x2 = h[b].x * width
            val y2 = h[b].y * height
            linePaint.color = 0x40FFFFFF
            linePaint.strokeWidth = 1.2f * density
            c.drawLine(x1, y1, x2, y2, linePaint)
        }
    }

    private fun drawCursor(c: Canvas, now: Long) {
        if (!visible) return
        val pulse = 0.5f + 0.5f * sin(now / 260f)
        keyPaint.color = accent
        keyPaint.alpha = (40 + 40 * pulse).toInt()
        c.drawCircle(cursorX, cursorY, 20f * density, keyPaint)
        keyPaint.alpha = 255
        glowPaint.color = if (pinchDown) 0xFFFF4FD8.toInt() else accent
        glowPaint.alpha = 255
        glowPaint.strokeWidth = 2.2f * density
        c.drawCircle(cursorX, cursorY, (13f + 3f * pulse) * density, glowPaint)
        keyPaint.color = Color.WHITE
        c.drawCircle(cursorX, cursorY, 4f * density, keyPaint)

        // magnified key above the fingertip: your hand hides the key it is pressing
        val k = keys.getOrNull(hoverIdx)
        if (k != null && !twoHand) {
            val bw = 64f * density
            val bh = 46f * density
            tmp2.set(cursorX - bw / 2f, cursorY - 92f * density, cursorX + bw / 2f, cursorY - 92f * density + bh)
            if (tmp2.top < 6f * density) tmp2.offset(0f, cursorY + 70f * density - tmp2.top)
            bgPaint.color = 0xF0121A2E.toInt()
            c.drawRoundRect(tmp2, 14f * density, 14f * density, bgPaint)
            glowPaint.color = accent
            glowPaint.alpha = 200
            glowPaint.strokeWidth = 1.6f * density
            c.drawRoundRect(tmp2, 14f * density, 14f * density, glowPaint)
            textPaint.color = Color.WHITE
            textPaint.textSize = 24f * density
            val label = if (k.special == AirKey.SHIFT && shift) "⇧" else k.label
            c.drawText(label, tmp2.centerX(), tmp2.centerY() + 8f * density, textPaint)
        }
    }

    private fun drawStatus(c: Canvas) {
        smallPaint.color = if (visible) 0xFF34F5A5.toInt() else 0xFF9AA7CB.toInt()
        smallPaint.textSize = 10f * density
        val msg = when {
            twoHand -> "Two hands · pinch out to resize, move to slide"
            visible -> "Air typing · pinch a key"
            else -> "Show your hand · or touch the keys"
        }
        c.drawText(msg, 12f * density, 22f * density, smallPaint)
        smallPaint.color = 0xFF6F7CA0.toInt()
        smallPaint.textAlign = Paint.Align.RIGHT
        c.drawText(
            (if (symbols) "123" else "abc") + " · " + (scale * 100).toInt() + "%",
            width - 12f * density, 22f * density, smallPaint
        )
        smallPaint.textAlign = Paint.Align.LEFT
    }
}
