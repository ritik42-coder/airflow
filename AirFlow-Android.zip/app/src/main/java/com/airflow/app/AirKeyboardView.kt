package com.airflow.app

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PointF
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import kotlin.math.hypot
import kotlin.math.min
import kotlin.math.sin

/** Where the typed characters go: an app text field, or the editor of any other app. */
interface TypeSink {
    fun text(s: String)
    fun del()
    fun enter()
}

/**
 * The air keyboard itself. One View, drawn with the platform Canvas, so it works both inside the
 * system keyboard (InputMethodService) and inside the app's practice screen.
 * Touch typing and air typing both work at the same time.
 */
class AirKeyboardView(ctx: Context, private val sink: TypeSink) : View(ctx) {

    private val keys = ArrayList<AirKey>()
    private var pressTimes = LongArray(0)
    private var shift = false
    private var autoShift = false
    private var symbols = false

    private var cursorX = -1f
    private var cursorY = -1f
    private var visible = false
    private var pinchDown = false
    private var cooldownUntil = 0L
    private var hoverIdx = -1
    private var frame: Bitmap? = null
    private var hand: List<PointF>? = null

    private val kb = RectF()
    private val strip = RectF()
    private val preview = RectF()
    private val tmp = RectF()

    private val density = resources.displayMetrics.density
    private val bgPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val keyPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val keyEdge = Paint(Paint.ANTI_ALIAS_FLAG)
    private val glowPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val smallPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val linePaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val path = Path()

    private val accent = 0xFF22D3EE.toInt()
    private val accent2 = 0xFF8B5CFF.toInt()
    private val ink = 0xFFF3F6FF.toInt()

    init {
        textPaint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        textPaint.textAlign = Paint.Align.CENTER
        textPaint.color = ink
        smallPaint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        smallPaint.textAlign = Paint.Align.LEFT
        smallPaint.color = 0xFF9AA7CB.toInt()
        linePaint.color = 0x33FFFFFF
        linePaint.strokeWidth = 1f * density
        glowPaint.style = Paint.Style.STROKE
        glowPaint.strokeWidth = 2f * density
        isFocusable = false
        isClickable = true
    }

    // ------------------------------------------------------------------------------ measuring

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        val w = MeasureSpec.getSize(widthMeasureSpec)
        val want = (306 * density).toInt()
        val mode = MeasureSpec.getMode(heightMeasureSpec)
        val h = when (mode) {
            MeasureSpec.EXACTLY -> MeasureSpec.getSize(heightMeasureSpec)
            MeasureSpec.AT_MOST -> min(want, MeasureSpec.getSize(heightMeasureSpec))
            else -> want
        }
        setMeasuredDimension(w, h)
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        val pad = 6f * density
        val stripH = 46f * density
        strip.set(pad, pad, w - pad, pad + stripH)
        preview.set(strip.right - 60f * density, strip.top, strip.right, strip.bottom)
        kb.set(pad, strip.bottom + pad, w - pad, h - pad)
        build()
    }

    // ------------------------------------------------------------------------------ layout

    private fun build() {
        keys.clear()
        keys.addAll(AirKeyLayout.build(kb.left, kb.top, kb.width(), kb.height(), 3f * density, symbols, shift))
        pressTimes = LongArray(keys.size)
        hoverIdx = -1
    }

    private fun keyAt(x: Float, y: Float): Int = AirKeyLayout.hit(keys, x, y)

    // ------------------------------------------------------------------------------ input

    fun setAutoShift(on: Boolean) {
        if (autoShift == on) return
        autoShift = on
        if (on != shift) {
            shift = on
            build()
            invalidate()
        }
    }

    fun onHands(lms: List<PointF>?) {
        hand = lms
        if (lms == null || lms.size < 21) {
            visible = false
            pinchDown = false
            hoverIdx = -1
            invalidate()
            return
        }
        val tip = lms[8]
        val thumb = lms[4]
        val d = hypot(tip.x - thumb.x, tip.y - thumb.y)
        val nx = ((tip.x - 0.10f) / 0.80f).coerceIn(0f, 1f)
        val ny = ((tip.y - 0.10f) / 0.80f).coerceIn(0f, 1f)
        cursorX = kb.left + nx * kb.width()
        cursorY = kb.top + ny * kb.height()
        visible = true
        hoverIdx = keyAt(cursorX, cursorY)

        val down = d < 0.052f
        val now = System.currentTimeMillis()
        if (down && !pinchDown) {
            pinchDown = true
            if (hoverIdx >= 0 && now > cooldownUntil) {
                press(hoverIdx)
                cooldownUntil = now + 180
            }
        } else if (!down) {
            pinchDown = false
        }
        invalidate()
    }

    fun onFrame(bmp: Bitmap?) {
        frame = bmp
        if (visible || bmp != null) invalidate()
    }

    private fun press(i: Int) {
        val k = keys.getOrNull(i) ?: return
        pressTimes[i] = System.currentTimeMillis()
        performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
        when (k.special) {
            AirKey.SHIFT -> {
                shift = !shift
                autoShift = false
                build()
            }
            AirKey.BACKSPACE -> sink.del()
            AirKey.ENTER -> sink.enter()
            AirKey.SPACE -> sink.text(" ")
            AirKey.MODE -> {
                symbols = !symbols
                build()
            }
            else -> {
                var t = k.code
                if (shift && t.length == 1 && t[0].isLetter()) {
                    t = t.uppercase()
                    shift = false
                    autoShift = false
                    build()
                }
                sink.text(t)
            }
        }
        invalidate()
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                val i = keyAt(e.x, e.y)
                if (i >= 0) {
                    press(i)
                    return true
                }
            }
        }
        return true
    }

    // ------------------------------------------------------------------------------ drawing

    override fun onDraw(c: Canvas) {
        val now = System.currentTimeMillis()
        // panel
        bgPaint.shader = LinearGradient(
            0f, 0f, 0f, height.toFloat(),
            intArrayOf(0xFF0C1222.toInt(), 0xFF060A14.toInt()),
            null, Shader.TileMode.CLAMP
        )
        c.drawRoundRect(RectF(0f, 0f, width.toFloat(), height.toFloat()), 22f * density, 22f * density, bgPaint)
        bgPaint.shader = null

        drawStrip(c, now)
        drawKeys(c, now)
        drawCursor(c, now)

        // keep animating while a key is cooling down
        var busy = false
        for (t in pressTimes) if (t != 0L && now - t < 240) busy = true
        if (busy || visible) postInvalidateOnAnimation()
    }

    private fun drawStrip(c: Canvas, now: Long) {
        // camera preview
        c.save()
        path.reset()
        path.addRoundRect(preview, 12f * density, 12f * density, Path.Direction.CW)
        c.clipPath(path)
        keyPaint.color = 0xFF05070E.toInt()
        c.drawRect(preview, keyPaint)
        val b = frame
        if (b != null) {
            c.drawBitmap(b, null, preview, null)
        }
        val h = hand
        if (h != null && h.size >= 21) {
            for ((a, bb) in HAND_BONES) {
                val x1 = preview.left + h[a].x * preview.width()
                val y1 = preview.top + h[a].y * preview.height()
                val x2 = preview.left + h[bb].x * preview.width()
                val y2 = preview.top + h[bb].y * preview.height()
                linePaint.color = 0x88FFFFFF.toInt()
                linePaint.strokeWidth = 1.4f * density
                c.drawLine(x1, y1, x2, y2, linePaint)
            }
            val tx = preview.left + h[8].x * preview.width()
            val ty = preview.top + h[8].y * preview.height()
            keyPaint.color = accent
            c.drawCircle(tx, ty, 2.6f * density, keyPaint)
        }
        c.restore()
        linePaint.color = 0x55FFFFFF.toInt()
        linePaint.strokeWidth = 1.2f * density
        c.drawRoundRect(preview, 12f * density, 12f * density, linePaint)

        // status line
        smallPaint.color = if (visible) 0xFF34F5A5.toInt() else 0xFF9AA7CB.toInt()
        smallPaint.textSize = 11f * density
        c.drawText(if (visible) "AIR TYPING · pinch to press" else "Air typing: show your hand", strip.left + 6f * density, strip.centerY() + 4f * density, smallPaint)
        smallPaint.color = 0xFF6F7CA0.toInt()
        smallPaint.textSize = 9f * density
        c.drawText(
            if (symbols) "numbers & symbols" else "letters",
            strip.left + 6f * density, strip.centerY() + 18f * density, smallPaint
        )
    }

    private fun drawKeys(c: Canvas, now: Long) {
        val r = 9f * density
        for (i in keys.indices) {
            val k = keys[i]
            val t = pressTimes[i]
            val p = if (t != 0L) (1f - (now - t) / 240f).coerceIn(0f, 1f) else 0f
            tmp.set(k.x, k.y, k.x + k.w, k.y + k.h)

            val isSpecial = k.special != AirKey.NORMAL
            val lift = if (p > 0f) 1.5f * density * p else 0f
            tmp.offset(0f, lift)

            keyPaint.shader = LinearGradient(
                0f, tmp.top, 0f, tmp.bottom,
                if (isSpecial) intArrayOf(0xFF16203A.toInt(), 0xFF0D1526.toInt())
                else intArrayOf(0xFF232C48.toInt(), 0xFF161D31.toInt()),
                null, Shader.TileMode.CLAMP
            )
            c.drawRoundRect(tmp, r, r, keyPaint)
            keyPaint.shader = null

            if (p > 0f) {
                keyPaint.shader = LinearGradient(
                    tmp.left, tmp.top, tmp.right, tmp.bottom,
                    accent2, accent, Shader.TileMode.CLAMP
                )
                keyPaint.alpha = (p * 255).toInt()
                c.drawRoundRect(tmp, r, r, keyPaint)
                keyPaint.alpha = 255
                keyPaint.shader = null
            }

            if (i == hoverIdx) {
                glowPaint.color = accent
                glowPaint.alpha = 200
                c.drawRoundRect(tmp, r, r, glowPaint)
            } else {
                linePaint.color = 0x22FFFFFF
                linePaint.strokeWidth = 1f * density
                c.drawRoundRect(tmp, r, r, linePaint)
            }

            textPaint.textSize = if (k.special == AirKey.SPACE) 11f * density else min(k.h * 0.42f, 20f * density)
            textPaint.color = if (p > 0.35f) Color.WHITE else ink
            val label = if (k.special == AirKey.SHIFT && shift) "⇧" else k.label
            c.drawText(label, tmp.centerX(), tmp.centerY() + textPaint.textSize * 0.36f, textPaint)
        }
    }

    private fun drawCursor(c: Canvas, now: Long) {
        if (!visible) return
        val pulse = 0.5f + 0.5f * sin(now / 260f)
        keyPaint.color = accent
        keyPaint.alpha = (40 + 40 * pulse).toInt()
        c.drawCircle(cursorX, cursorY, 22f * density, keyPaint)
        keyPaint.alpha = 255
        glowPaint.color = if (pinchDown) 0xFFFF4FD8.toInt() else accent
        glowPaint.alpha = 255
        glowPaint.strokeWidth = 2.2f * density
        c.drawCircle(cursorX, cursorY, (14f + 3f * pulse) * density, glowPaint)
        keyPaint.color = Color.WHITE
        c.drawCircle(cursorX, cursorY, 4f * density, keyPaint)
    }
}
