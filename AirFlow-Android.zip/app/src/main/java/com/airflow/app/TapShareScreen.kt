package com.airflow.app

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.provider.ContactsContract
import android.view.HapticFeedbackConstants
import android.view.View
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.ui.draw.blur
import androidx.compose.ui.viewinterop.AndroidView
import android.graphics.Bitmap
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import kotlin.math.cos
import kotlin.math.sin
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

// ---------------------------------------------------------------------------------------------
// Tap Share: touch the tops of two phones together, then everything flows across.
// ---------------------------------------------------------------------------------------------

private enum class TapState { IDLE, SEARCHING, CONNECTING, LINKED, FAILED }

/** The Share tab: two ways to move something between phones. */
@Composable
fun ShareHub() {
    val c = Air.c
    var tab by remember { mutableIntStateOf(0) }
    Box(Modifier.fillMaxSize()) {
        when (tab) {
            0 -> AirShareAnywhereScreen()
            1 -> TapShareScreen()
            else -> TransferScreen()
        }
        Row(
            Modifier
                .align(Alignment.TopCenter)
                .padding(top = 46.dp + WindowInsets.statusBars.asPaddingValues().calculateTopPadding())
                .clip(RoundedCornerShape(50))
                .background(c.glass)
                .border(1.dp, c.stroke, RoundedCornerShape(50))
                .padding(4.dp)
        ) {
            HubTab("Anywhere", tab == 0) { tab = 0 }
            HubTab("Tap share", tab == 1) { tab = 1 }
            HubTab("Code & QR", tab == 2) { tab = 2 }
        }
    }
}

@Composable
private fun HubTab(label: String, active: Boolean, onClick: () -> Unit) {
    val c = Air.c
    Box(
        Modifier
            .clip(RoundedCornerShape(50))
            .background(if (active) Brush.horizontalGradient(listOf(c.a1, c.a2)) else Brush.linearGradient(listOf(Color.Transparent, Color.Transparent)))
            .pressClick(scaleTo = 0.94f) { onClick() }
            .padding(horizontal = 14.dp, vertical = 7.dp)
    ) {
        Text(
            label, color = if (active) Color.White else c.dim, fontSize = 12.sp,
            fontWeight = if (active) FontWeight.Bold else FontWeight.Medium
        )
    }
}

@Composable
fun TapShareScreen() {
    val ctx = LocalContext.current
    val owner = LocalLifecycleOwner.current
    val c = Air.c
    val haptic = LocalHapticFeedback.current
    val main = remember { Handler(Looper.getMainLooper()) }

    val topPad = 98.dp + WindowInsets.statusBars.asPaddingValues().calculateTopPadding()
    val bottomPad = 78.dp + WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding()

    var state by remember { mutableStateOf(TapState.IDLE) }
    var peers by remember { mutableIntStateOf(0) }
    var peerName by remember { mutableStateOf("") }
    var status by remember { mutableStateOf("Touch the tops of the two phones together") }
    var picked by remember { mutableStateOf(listOf<TapFile>()) }
    var contact by remember { mutableStateOf<TapContact?>(null) }
    var transferring by remember { mutableStateOf(false) }
    var receiving by remember { mutableStateOf(false) }
    var done by remember { mutableLongStateOf(0L) }
    var total by remember { mutableLongStateOf(1L) }
    var current by remember { mutableStateOf("") }
    var speed by remember { mutableStateOf("") }
    val receivedItems = remember { mutableStateListOf<RecvItem>() }
    var gotContact by remember { mutableStateOf<TapContact?>(null) }
    var showResult by remember { mutableStateOf(false) }
    val bumpLevel = remember { mutableFloatStateOf(0f) }
    val bumpThr = remember { mutableFloatStateOf(9f) }
    val clock = remember { mutableFloatStateOf(0f) }
    var startedAt by remember { mutableLongStateOf(0L) }
    // the premium chip animation: the photo chip that leaves this phone / arrives on the other one
    var pairFlash by remember { mutableStateOf(false) }
    var chipThumb by remember { mutableStateOf<Bitmap?>(null) }
    var chipNames by remember { mutableStateOf(listOf<String>()) }
    val linkRef = remember { arrayOfNulls<TapLink>(1) }
    // Samsung-style drag: the photo is dragged by hand and shows on the other phone as it leaves this one
    var tapStyle by remember { mutableStateOf(Prefs.tapStyle) }
    var dragActive by remember { mutableStateOf(false) }
    var dragSend by remember { mutableStateOf(true) }
    var remoteC by remember { mutableFloatStateOf(0f) }
    var endToken by remember { mutableIntStateOf(0) }
    var endCommit by remember { mutableStateOf(false) }
    var endFling by remember { mutableStateOf(false) }
    var qdItem by remember { mutableStateOf<QuickItem?>(null) }

    /** Nearby calls back on its own thread sometimes; everything lands on the main thread. */
    fun post(block: () -> Unit) {
        main.post(block)
    }

    fun nearbyGranted(): Boolean = Perms.missing(ctx).isEmpty()

    // Nearby will not even start without location + nearby-devices permission (error 8034)
    var permsOk by remember { mutableStateOf(nearbyGranted()) }
    // the phone-wide Location switch is separate from the permission, and Nearby needs both
    var locOn by remember { mutableStateOf(Perms.locationServiceOn(ctx)) }

    val link = remember {
        TapLink(ctx, object : TapLink.Callbacks {
            override fun peers(count: Int) = post {
                peers = count
                if (state == TapState.IDLE && count > 0) {
                    state = TapState.SEARCHING
                    status = "$count phone nearby. Touch the tops together."
                }
            }

            override fun connecting() = post {
                state = TapState.CONNECTING
                status = "Linking…"
            }

            override fun connected(name: String) = post {
                state = TapState.LINKED
                peerName = name
                status = "Linked to $name"
                haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                pairFlash = true
                main.postDelayed({ pairFlash = false }, 1600L)
            }

            override fun lost() = post {
                dragActive = false
                state = TapState.IDLE
                peerName = ""
                status = "Link closed. Touch again to reconnect."
            }

            override fun failed(msg: String) = post {
                state = TapState.FAILED
                status = msg
            }

            override fun progress(d: Long, t: Long, name: String) = post {
                done = d
                total = if (t > 0) t else 1L
                if (name.isNotEmpty() && name != "receiving") current = name
                if (startedAt == 0L) startedAt = System.currentTimeMillis()
                val ms = System.currentTimeMillis() - startedAt
                speed = TapFiles.speed(d, ms)
            }

            override fun peek(count: Int, names: List<String>, thumb: Bitmap?) = post {
                chipThumb = thumb
                chipNames = names
                showResult = false
                remoteC = 0f
                dragSend = false
                dragActive = true
            }

            override fun quick(item: QuickItem) = post {
                QuickHistory.add(item)
                if (Prefs.quickAutoCopy) QuickActions.copy(ctx, item)
                qdItem = item
            }

            override fun dragPos(c: Float, fling: Boolean) = post { remoteC = c }

            override fun dragEnd(commit: Boolean, fling: Boolean) = post {
                endCommit = commit
                endFling = fling
                endToken++
                if (commit && dragSend) { transferring = true; receiving = false }
            }

            override fun finished() = post {
                dragActive = false
                transferring = false
                receiving = false
                showResult = true
                state = TapState.LINKED
                status = "Done"
                haptic.performHapticFeedback(HapticFeedbackType.LongPress)
            }

            override fun incomingOffer(count: Int, bytes: Long) = post {
                receiving = true
                transferring = true
                chipThumb = linkRef[0]?.offerThumb
                chipNames = linkRef[0]?.offerFileNames ?: emptyList()
                startedAt = 0L
                done = 0L
                total = if (bytes > 0) bytes else 1L
                status = "Receiving $count file" + (if (count == 1) "" else "s")
            }

            override fun saved(item: RecvItem) = post {
                receivedItems.add(item)
            }

            override fun contact(c: TapContact) = post {
                gotContact = c
            }
        }).also { linkRef[0] = it }
    }

    // ---- sensor: the bump is the handshake -----------------------------------------------
    val bump = remember {
        BumpDetector(
            ctx,
            { mag ->
                haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                link.bump()
            },
            { level, thr ->
                bumpLevel.floatValue = level
                bumpThr.floatValue = thr
            }
        ).also { it.sensitivity = Prefs.tapSens }
    }

    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        // flipping permsOk restarts the link below, so no separate retry here (two starts at once clash)
        permsOk = nearbyGranted()
        locOn = Perms.locationServiceOn(ctx)
        if (!permsOk) status = "Allow Location and Nearby devices to use Tap Share."
    }
    LaunchedEffect(Unit) {
        // the background Air Share uses the same Nearby channel and camera, so it steps aside while this screen is open
        ctx.stopService(Intent(ctx, AirFlowService::class.java))
        if (!permsOk) permLauncher.launch(Pairing.nearbyPermissions().toTypedArray())
    }
    // coming back from App info must not leave the screen stuck on "permissions needed"
    DisposableEffect(owner) {
        val obs = LifecycleEventObserver { _, e ->
            if (e == Lifecycle.Event.ON_RESUME) {
                val ok = nearbyGranted()
                val loc = Perms.locationServiceOn(ctx)
                val locTurnedOn = loc && !locOn
                locOn = loc
                if (ok != permsOk) {
                    permsOk = ok          // the effect below starts the link
                } else if (ok && locTurnedOn) {
                    link.retry()          // coming back from the Location switch
                }
            }
        }
        owner.lifecycle.addObserver(obs)
        onDispose { owner.lifecycle.removeObserver(obs) }
    }

    DisposableEffect(owner, permsOk) {
        if (permsOk) {
            link.start()
            bump.start()
            state = TapState.IDLE
        }
        val obs = LifecycleEventObserver { _, e ->
            if (e == Lifecycle.Event.ON_RESUME && permsOk) { link.start(); bump.start() }
            if (e == Lifecycle.Event.ON_PAUSE) { bump.stop() }
        }
        owner.lifecycle.addObserver(obs)
        onDispose {
            owner.lifecycle.removeObserver(obs)
            bump.stop()
            link.stop()
        }
    }

    LaunchedEffect(Unit) {
        var last = 0L
        while (true) {
            withFrameNanos { now ->
                val dt = if (last == 0L) 0.016f else ((now - last) / 1_000_000_000.0).toFloat().coerceIn(0.001f, 0.05f)
                last = now
                clock.floatValue += dt
            }
        }
    }

    // ---- pickers ---------------------------------------------------------------------------
    val filePicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris: List<Uri> ->
        if (uris.isNotEmpty()) {
            val add = uris.map { TapFiles.describe(ctx, it) }
            picked = (picked + add).distinctBy { it.uri.toString() }
            status = "${picked.size} item" + (if (picked.size == 1) "" else "s") + " ready"
        }
    }
    val contactPicker = rememberLauncherForActivityResult(ActivityResultContracts.PickContact()) { uri: Uri? ->
        if (uri != null) {
            contact = readContact(ctx, uri)
            if (contact != null) status = "Contact: ${contact!!.name}"
        }
    }
    val contactPerm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        if (ok) contactPicker.launch(null)
    }

    fun askContact() {
        val granted = ContextCompat.checkSelfPermission(ctx, Manifest.permission.READ_CONTACTS) == PackageManager.PERMISSION_GRANTED
        if (granted) contactPicker.launch(null) else contactPerm.launch(Manifest.permission.READ_CONTACTS)
    }

    val scope = rememberCoroutineScope()

    fun doSend() {
        if (picked.isEmpty() && contact == null) {
            status = "Pick a file or a contact first"
            return
        }
        val chosen = picked
        val person = contact
        transferring = true
        receiving = false
        showResult = false
        startedAt = 0L
        done = 0L
        speed = ""
        // copying a big video must not freeze the animation
        scope.launch {
            val pairs = withContext(Dispatchers.IO) {
                chosen.mapNotNull { tf -> TapFiles.materialise(ctx, tf)?.let { it to tf.name } }
            }
            val files = pairs.map { it.first }
            chipNames = pairs.map { it.second }
            val firstImg = pairs.firstOrNull { FileStore.isImage(it.second) }
            chipThumb = if (firstImg != null) withContext(Dispatchers.IO) { PhotoStore.load(ctx, Uri.fromFile(firstImg.first), 700) } else null
            val thumbBytes = if (firstImg != null) withContext(Dispatchers.IO) { ThumbMaker.of(ctx, firstImg.first) } else null
            total = files.sumOf { it.length() }.coerceAtLeast(1L)
            if (files.isEmpty() && person == null) {
                transferring = false
                status = "Could not read those files"
                return@launch
            }
            if (Prefs.tapStyle == "drag" && files.isNotEmpty() && person == null) {
                // Samsung style: nothing is sent yet. The photo waits under the finger and the other phone is told it is coming.
                transferring = false
                remoteC = 0f
                dragSend = true
                dragActive = true
                link.peek(files, pairs.map { it.second }, thumbBytes)
            } else {
                // the receiver must see the real names, not the cache copies' names
                link.send(files, person, pairs.map { it.second }, thumbBytes, "tap")
            }
        }
    }

    // ---- layout ----------------------------------------------------------------------------
    Box(Modifier.fillMaxSize()) {
        // the screen softly blurs while a photo is being dragged between the phones (Android 12+)
        val blurDp by animateDpAsState(if ((dragActive && !showResult) || qdItem != null) 22.dp else 0.dp, tween(450), label = "tapBlur")
        Column(Modifier.fillMaxSize().blur(blurDp).padding(top = topPad, bottom = bottomPad).padding(horizontal = 16.dp)) {

            Text(
                "Tap Share", style = MaterialTheme.typography.headlineLarge, color = c.text
            )
            Text(
                "Touch the tops of the two phones together. No code, no QR — the tap links them, then files flow across.",
                style = MaterialTheme.typography.bodySmall, color = c.dim
            )
            Spacer(Modifier.height(8.dp))
            Text("Send style", style = MaterialTheme.typography.labelMedium, color = c.dim)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                AirButton("Default", { tapStyle = "classic"; Prefs.tapStyle = "classic" }, Modifier.weight(1f), filled = tapStyle == "classic")
                AirButton("Samsung style", { tapStyle = "drag"; Prefs.tapStyle = "drag" }, Modifier.weight(1f), filled = tapStyle == "drag")
            }
            Text(
                if (tapStyle == "drag") "You drag the photo up off the top edge. The other phone sees it arrive and can pull it down."
                else "The photo slides across by itself when you press Send now.",
                style = MaterialTheme.typography.bodySmall, color = c.dim
            )
            if (!permsOk) {
                Spacer(Modifier.height(10.dp))
                GlassCard(Modifier.fillMaxWidth(), reveal = false) {
                    Text("Permission needed", style = MaterialTheme.typography.titleMedium, color = c.warn)
                    Text(
                        "Missing: " + Perms.names(ctx) + ". Android stops showing the request after two denials, " +
                            "so if the Allow button does nothing, open App info › Permissions and turn them on there.",
                        style = MaterialTheme.typography.bodySmall, color = c.dim
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        AirButton(
                            "Allow",
                            { permLauncher.launch(Pairing.nearbyPermissions().toTypedArray()) },
                            Modifier.weight(1f)
                        )
                        AirButton(
                            "App settings",
                            { Perms.openSettings(ctx) },
                            Modifier.weight(1f), filled = false
                        )
                    }
                }
            }
            if (permsOk && !locOn) {
                Spacer(Modifier.height(10.dp))
                GlassCard(Modifier.fillMaxWidth(), reveal = false) {
                    Text("Location is switched off", style = MaterialTheme.typography.titleMedium, color = c.warn)
                    Text(
                        "The permission is allowed, but Android also needs the Location switch ON before it lets phones find each other. " +
                            "Turn it on, come back, and Tap Share starts by itself.",
                        style = MaterialTheme.typography.bodySmall, color = c.dim
                    )
                    AirButton("Turn on Location", { Perms.openLocationSettings(ctx) }, Modifier.fillMaxWidth())
                }
            }
            Spacer(Modifier.height(14.dp))

            // the tap stage
            Box(
                Modifier
                    .fillMaxWidth()
                    .height(212.dp)
                    .clip(RoundedCornerShape(26.dp))
                    .background(Brush.radialGradient(listOf(c.a1.copy(alpha = 0.22f), c.bg1.copy(alpha = 0.9f))))
                    .border(1.dp, c.stroke, RoundedCornerShape(26.dp))
            ) {
                Canvas(Modifier.fillMaxSize()) {
                    drawTapStage(state, clock.floatValue, bumpLevel.floatValue, bumpThr.floatValue, c)
                }
                Column(
                    Modifier.fillMaxSize().padding(14.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Bottom
                ) {
                    Pill(
                        when (state) {
                            TapState.IDLE -> if (peers > 0) "PHONE NEARBY" else "LOOKING"
                            TapState.SEARCHING -> "TAP NOW"
                            TapState.CONNECTING -> "LINKING"
                            TapState.LINKED -> "LINKED"
                            TapState.FAILED -> "RETRY"
                        },
                        when (state) {
                            TapState.LINKED -> c.ok
                            TapState.FAILED -> c.warn
                            TapState.SEARCHING -> c.a2
                            else -> c.dim
                        }
                    )
                    Spacer(Modifier.height(6.dp))
                    Text(
                        status, color = c.text, fontSize = 12.sp, fontWeight = FontWeight.SemiBold,
                        textAlign = TextAlign.Center
                    )
                }
            }

            Spacer(Modifier.height(12.dp))

            // what is going to be sent
            GlassCard(Modifier.fillMaxWidth(), reveal = false) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Send", style = MaterialTheme.typography.titleMedium, color = c.text)
                    Spacer(Modifier.weight(1f))
                    Text(
                        "${picked.size} file" + (if (picked.size == 1) "" else "s"),
                        color = c.dim, fontSize = 11.sp
                    )
                }
                if (picked.isNotEmpty()) {
                    picked.take(4).forEach { f ->
                        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                            Text("•", color = c.a2, fontSize = 14.sp)
                            Spacer(Modifier.width(8.dp))
                            Text(f.name, color = c.text, fontSize = 12.sp, maxLines = 1, modifier = Modifier.weight(1f))
                            Text(TapFiles.human(f.size), color = c.dim, fontSize = 11.sp)
                        }
                    }
                    if (picked.size > 4) {
                        Text("+ ${picked.size - 4} more", color = c.dim, fontSize = 11.sp)
                    }
                }
                contact?.let { k ->
                    Text("Contact: ${k.name}  ${k.phone}", color = c.a2, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    AirButton("Files", { filePicker.launch(arrayOf("*/*")) }, Modifier.weight(1f), filled = false, icon = IconKind.SHARE)
                    AirButton("Contact", { askContact() }, Modifier.weight(1f), filled = false, icon = IconKind.CURSOR)
                }
                AirButton(
                    if (state == TapState.LINKED) "Send now" else "Touch the phones first",
                    { doSend() },
                    Modifier.fillMaxWidth(),
                    enabled = state == TapState.LINKED && (picked.isNotEmpty() || contact != null),
                    icon = IconKind.BOLT
                )
                if (state == TapState.FAILED && permsOk) {
                    Text(
                        "Try again",
                        color = c.a2, fontSize = 12.sp, fontWeight = FontWeight.Bold,
                        modifier = Modifier.pressClick { locOn = Perms.locationServiceOn(ctx); state = TapState.IDLE; link.retry() }
                    )
                }
                if (state != TapState.LINKED && peers > 0) {
                    Text(
                        "Tap did not take? Tap here to link manually.",
                        color = c.a2, fontSize = 11.sp,
                        modifier = Modifier.pressClick { link.connectNow() }
                    )
                }
                if (picked.isNotEmpty() || contact != null) {
                    Text(
                        "Clear selection", color = c.dim, fontSize = 11.sp,
                        modifier = Modifier.pressClick { picked = emptyList(); contact = null }
                    )
                }
            }
        }

        // the premium chip animation (pairing ripples, chip crossing the top edge, reveal) ---------
        LaunchedEffect(qdItem) {
            if (qdItem != null) { delay(18_000L); qdItem = null }
        }
        val scene = when {
            qdItem != null -> 9
            dragActive && !showResult -> if (dragSend) 7 else 8
            transferring && !receiving -> 3
            transferring && receiving -> 4
            showResult && !transferring -> if (receivedItems.isNotEmpty()) 6 else 5
            pairFlash -> 2
            state == TapState.CONNECTING -> 1
            else -> 0
        }
        TapPremiumLayer(
            scene = scene,
            progress = if (total > 0) (done.toFloat() / total).coerceIn(0f, 1f) else 0f,
            peer = peerName.ifEmpty { "the other phone" },
            thumb = chipThumb,
            names = chipNames,
            received = receivedItems.toList(),
            remoteC = remoteC,
            endToken = endToken,
            endCommit = endCommit,
            endFling = endFling,
            qd = qdItem,
            onQuick = { act ->
                val it = qdItem
                if (it != null) {
                    when (act) {
                        AirShareOverlay.QA_OPEN -> QuickActions.open(ctx, it)
                        AirShareOverlay.QA_PLAY -> QuickActions.play(ctx, it)
                        AirShareOverlay.QA_COPY -> QuickActions.copy(ctx, it)
                    }
                    if (act != AirShareOverlay.QA_COPY) qdItem = null
                }
            },
            onDrag = { cc, fl -> linkRef[0]?.sendPos(cc, fl) },
            onRelease = { commit, fl ->
                if (commit) {
                    if (dragSend) { transferring = true; receiving = false; startedAt = 0L; done = 0L }
                    linkRef[0]?.commitDrag(fl)
                } else {
                    linkRef[0]?.cancelDrag()
                }
            }
        )

        // result -------------------------------------------------------------------------------
        AnimatedVisibility(
            visible = showResult && !transferring,
            enter = fadeIn(tween(220)),
            exit = fadeOut(tween(200)),
            modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = bottomPad + 8.dp, start = 16.dp, end = 16.dp)
        ) {
            GlassCard(Modifier.fillMaxWidth(), reveal = false) {
                val gotSomething = receivedItems.isNotEmpty() || gotContact != null
                Text(
                    if (!gotSomething) "Sent ✓" else "Received ✓ · ${receivedItems.size} file" + (if (receivedItems.size == 1) "" else "s"),
                    style = MaterialTheme.typography.titleMedium, color = c.ok
                )
                if (receivedItems.isNotEmpty()) {
                    ReceivedBox(receivedItems.toList(), Modifier.fillMaxWidth(), maxHeight = 250.dp)
                    val okCount = receivedItems.count { it.saved != null }
                    Text(
                        if (okCount == receivedItems.size) "Saved to Gallery > AirFlow and Downloads > AirFlow. Tap a tile to open it."
                        else "${receivedItems.size - okCount} could not be saved. Ask the sender to send again.",
                        style = MaterialTheme.typography.bodySmall, color = c.dim
                    )
                }
                if (!gotSomething) {
                    Text(
                        "The other phone brings it down with the same animation.",
                        style = MaterialTheme.typography.bodySmall, color = c.dim
                    )
                }
                gotContact?.let { k ->
                    Text(
                        "Add ${k.name} to contacts",
                        color = c.a2, fontSize = 12.sp, fontWeight = FontWeight.Bold,
                        modifier = Modifier.pressClick {
                            ctx.startActivity(
                                Intent(Intent.ACTION_INSERT, ContactsContract.Contacts.CONTENT_URI)
                                    .putExtra(ContactsContract.Intents.Insert.NAME, k.name)
                                    .putExtra(ContactsContract.Intents.Insert.PHONE, k.phone)
                            )
                        }
                    )
                }
                Text(
                    "Close", color = c.dim, fontSize = 12.sp,
                    modifier = Modifier.pressClick { showResult = false; receivedItems.clear(); gotContact = null }
                )
            }
        }
    }
}

private fun readContact(ctx: Context, uri: Uri): TapContact? = try {
    var name = "Contact"
    var phone = ""
    ctx.contentResolver.query(uri, null, null, null, null)?.use { c ->
        if (c.moveToFirst()) {
            val ni = c.getColumnIndex(ContactsContract.Contacts.DISPLAY_NAME)
            if (ni >= 0) name = c.getString(ni) ?: name
            val idIdx = c.getColumnIndex(ContactsContract.Contacts._ID)
            val id = if (idIdx >= 0) c.getString(idIdx) else null
            if (id != null) {
                ctx.contentResolver.query(
                    ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                    arrayOf(ContactsContract.CommonDataKinds.Phone.NUMBER),
                    ContactsContract.CommonDataKinds.Phone.CONTACT_ID + " = ?",
                    arrayOf(id), null
                )?.use { p ->
                    if (p.moveToFirst()) phone = p.getString(0) ?: ""
                }
            }
        }
    }
    TapContact(name, phone)
} catch (e: Exception) {
    null
}

// ---------------------------------------------------------------------------------------------
// The stage animation
// ---------------------------------------------------------------------------------------------

private fun DrawScope.drawTapStage(
    state: TapState,
    t: Float,
    level: Float,
    thr: Float,
    c: AirColors
) {
    val cx = size.width / 2f
    val cy = size.height * 0.44f
    val base = size.minDimension * 0.22f
    val pulse = 0.5f + 0.5f * sin(t * 3.2f)

    // rings that breathe while we listen, snap when linked
    val linked = state == TapState.LINKED
    for (k in 0..2) {
        val u = ((t * 0.55f) + k / 3f) % 1f
        val r = base * (0.7f + 0.9f * u)
        val alpha = (1f - u) * (if (linked) 0.5f else 0.28f)
        drawCircle(
            (if (linked) c.ok else c.a2).copy(alpha = alpha),
            r, Offset(cx, cy), style = Stroke(2f)
        )
    }

    // the two phones, top edges almost touching
    val pw = base * 0.62f
    val ph = base * 1.05f
    val gap = base * 0.10f + (1f - level.coerceAtMost(1f)) * 2f
    val left = Offset(cx - gap / 2f - pw, cy - ph / 2f)
    val right = Offset(cx + gap / 2f, cy - ph / 2f)
    val phoneCol = if (linked) c.ok else c.a2
    for (p in listOf(left, right)) {
        drawRoundRect(
            phoneCol.copy(alpha = 0.16f),
            p, Size(pw, ph), CornerRadius(10f, 10f)
        )
        drawRoundRect(
            phoneCol.copy(alpha = 0.75f),
            p, Size(pw, ph), CornerRadius(10f, 10f), style = Stroke(2f)
        )
        // the top edge is the part that touches
        drawLine(
            phoneCol, Offset(p.x + 4f, p.y), Offset(p.x + pw - 4f, p.y),
            strokeWidth = 3.5f, cap = StrokeCap.Round
        )
    }

    // spark at the contact point
    val spark = (level / thr.coerceAtLeast(1f)).coerceIn(0f, 1.4f)
    if (spark > 0.25f) {
        val r = 6f + 26f * spark
        drawCircle(c.a3.copy(alpha = 0.35f * spark.coerceAtMost(1f)), r, Offset(cx, cy - ph / 2f))
        drawCircle(Color.White.copy(alpha = 0.8f * spark.coerceAtMost(1f)), 3f + 4f * spark, Offset(cx, cy - ph / 2f))
        for (i in 0 until 8) {
            val a = i * 0.785f + t
            val d = r * 1.4f
            drawCircle(
                c.a3.copy(alpha = 0.5f * spark.coerceAtMost(1f)),
                2.5f,
                Offset(cx + cos(a) * d, cy - ph / 2f + sin(a) * d)
            )
        }
    }

    // a live bump meter, so the user can see the sensor is awake
    val meterW = size.width * 0.5f
    val mLevel = (level / thr.coerceAtLeast(1f)).coerceIn(0f, 1f)
    val mx = cx - meterW / 2f
    val my = size.height - 16f
    drawRoundRect(Color.White.copy(alpha = 0.10f), Offset(mx, my), Size(meterW, 5f), CornerRadius(3f, 3f))
    drawRoundRect(
        Brush.horizontalGradient(listOf(c.a2, c.a3)),
        Offset(mx, my), Size(meterW * mLevel, 5f), CornerRadius(3f, 3f)
    )
    // the threshold marker
    drawLine(
        Color.White.copy(alpha = 0.45f),
        Offset(mx + meterW * 0.98f, my - 2f), Offset(mx + meterW * 0.98f, my + 7f),
        strokeWidth = 2f
    )
}

// ---------------------------------------------------------------------------------------------
// Full screen transfer: the file really travels, at the speed it is really going
// ---------------------------------------------------------------------------------------------

@Composable
private fun TransferOverlay(
    receiving: Boolean,
    done: Long,
    total: Long,
    current: String,
    speed: String,
    clock: Float,
    peer: String,
    c: AirColors
) {
    val progress = (done.toFloat() / total.coerceAtLeast(1L)).coerceIn(0f, 1f)
    val shown = animateFloatAsState(progress, tween(220, easing = LinearEasing), label = "p")
    val inf = rememberInfiniteTransition(label = "flow")
    val drift = inf.animateFloat(0f, 1f, infiniteRepeatable(tween(1600, easing = LinearEasing), RepeatMode.Restart), label = "drift")

    Box(
        Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(Color(0xF2070B16), Color(0xF20B1224), Color(0xF2070B16))))
    ) {
        Canvas(Modifier.fillMaxSize()) {
            drawTransfer(shown.value, clock, drift.value, receiving, c)
        }
        Column(
            Modifier.fillMaxSize().padding(28.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Text(
                if (receiving) "RECEIVING" else "SENDING",
                color = c.a2, fontSize = 12.sp, fontWeight = FontWeight.Black, letterSpacing = 4.sp
            )
            Spacer(Modifier.height(10.dp))
            Text(
                "${(shown.value * 100).toInt()}%",
                color = Color.White, fontSize = 58.sp, fontWeight = FontWeight.Black
            )
            Spacer(Modifier.height(2.dp))
            Text(
                if (current.isEmpty()) peer else current,
                color = c.dim, fontSize = 13.sp, maxLines = 1
            )
            Spacer(Modifier.height(6.dp))
            Text(
                "${TapFiles.human(done)} of ${TapFiles.human(total)}" + (if (speed.isNotEmpty()) "  ·  $speed" else ""),
                color = c.a2, fontSize = 12.sp, fontWeight = FontWeight.SemiBold
            )
        }
    }
}

private fun DrawScope.drawTransfer(progress: Float, t: Float, drift: Float, receiving: Boolean, c: AirColors) {
    val cx = size.width / 2f
    val cy = size.height * 0.5f
    val pw = size.width * 0.19f
    val ph = pw * 1.9f
    val gap = size.width * 0.10f

    val left = Offset(cx - gap / 2f - pw, cy - ph / 2f)
    val right = Offset(cx + gap / 2f, cy - ph / 2f)
    for (p in listOf(left, right)) {
        drawRoundRect(c.a2.copy(alpha = 0.10f), p, Size(pw, ph), CornerRadius(16f, 16f))
        drawRoundRect(c.a2.copy(alpha = 0.55f), p, Size(pw, ph), CornerRadius(16f, 16f), style = Stroke(2f))
    }

    // the beam between them, as wide as the transfer is fast
    val beamTop = cy - ph * 0.28f
    val beamH = ph * 0.56f
    val from = if (receiving) right.x + pw else left.x + pw
    val to = if (receiving) left.x else right.x
    drawRect(
        Brush.horizontalGradient(
            if (receiving) listOf(c.ok.copy(alpha = 0.55f), c.a2.copy(alpha = 0.10f))
            else listOf(c.a2.copy(alpha = 0.10f), c.a3.copy(alpha = 0.55f))
        ),
        topLeft = Offset(minOf(from, to), beamTop),
        size = Size(kotlin.math.abs(to - from), beamH)
    )
    // travelling packets, one per 8% of progress already crossed
    val packets = 7
    for (i in 0 until packets) {
        val u = ((drift + i.toFloat() / packets) % 1f)
        val x = from + (to - from) * u
        val alpha = (0.35f + 0.65f * sin(u * 3.1416f))
        val w = beamH * 0.30f
        drawRoundRect(
            Color.White.copy(alpha = alpha * 0.9f),
            Offset(x - w / 2f, beamTop + beamH * 0.5f - w / 2f),
            Size(w, w), CornerRadius(4f, 4f)
        )
    }

    // the bar at the bottom, filled to the real progress
    val barW = size.width * 0.62f
    val bx = cx - barW / 2f
    val by = size.height * 0.72f
    drawRoundRect(Color.White.copy(alpha = 0.12f), Offset(bx, by), Size(barW, 8f), CornerRadius(4f, 4f))
    drawRoundRect(
        Brush.horizontalGradient(listOf(c.a1, c.a2, c.ok)),
        Offset(bx, by), Size(barW * progress, 8f), CornerRadius(4f, 4f)
    )
    // a soft head on the bar
    val hx = bx + barW * progress
    drawCircle(c.ok.copy(alpha = 0.35f), 14f, Offset(hx, by + 4f))
    drawCircle(Color.White, 4f, Offset(hx, by + 4f))
}


/**
 * Hosts [AirShareOverlay] inside the screen. The very same animation runs over other apps when Tap Share is
 * used from the background, so the touch looks identical everywhere.
 * Scenes: 1 touching, 2 linked, 3 sending, 4 receiving, 5 sent, 6 received and released.
 */
@Composable
private fun TapPremiumLayer(
    scene: Int,
    progress: Float,
    peer: String,
    thumb: Bitmap?,
    names: List<String>,
    received: List<RecvItem>,
    qd: QuickItem?,
    onQuick: (Int) -> Unit,
    remoteC: Float,
    endToken: Int,
    endCommit: Boolean,
    endFling: Boolean,
    onDrag: (Float, Boolean) -> Unit,
    onRelease: (Boolean, Boolean) -> Unit
) {
    val ctx = LocalContext.current
    var shown by remember { mutableStateOf(false) }
    var pics by remember { mutableStateOf(listOf<Bitmap>()) }

    LaunchedEffect(scene, received.size) {
        if (scene == 6) {
            pics = withContext(Dispatchers.IO) { received.take(3).mapNotNull { loadRecvBitmap(ctx, it, 1000) } }
        }
    }
    LaunchedEffect(scene) {
        when (scene) {
            0 -> shown = false
            5 -> { shown = true; delay(2800L); shown = false }
            6 -> { shown = true; delay(AirShareOverlay.REVEAL_MS.toLong() + 400L); shown = false }
            else -> shown = true
        }
    }
    if (!shown) return
    AndroidView(
        factory = { c ->
            AirShareOverlay(c).apply {
                tapStyle = true
                backdrop = 0.94f
                onDragLocal = { cc, fl -> onDrag(cc, fl) }
                onReleaseLocal = { commit, fl -> onRelease(commit, fl) }
                onQuickAction = { act -> onQuick(act) }
            }
        },
        modifier = Modifier.fillMaxSize(),
        update = { ov ->
            ov.setProgress(progress)
            val applied = (ov.tag as? Int) ?: -1
            if (applied != scene) {
                ov.tag = scene
                ov.backdrop = if (scene == 7 || scene == 8 || scene == 9) 0.5f else 0.94f
                when (scene) {
                    9 -> if (qd != null) ov.qdReceive(qd)
                    7 -> { ov.dragStart(true, thumb, names, names.size); ov.markEndSeen(endToken) }
                    8 -> { ov.dragStart(false, thumb, names, names.size); ov.markEndSeen(endToken) }
                    1 -> { ov.setInfo("Connecting", "Hold the phones together"); ov.tapPair() }
                    2 -> {
                        if (ov.currentMode() != AirShareOverlay.M_TAP_PAIR) ov.tapPair()
                        ov.setInfo("Connected", peer)
                        ov.tapPaired()
                    }
                    3 -> ov.tapTransfer(true, thumb, names, names.size)
                    4 -> ov.tapTransfer(false, thumb, names, names.size)
                    5 -> { ov.setInfo("Sent", "It is on the other phone"); ov.setMode(AirShareOverlay.M_SENT) }
                    6 -> {
                        ov.setInfo(
                            "Saved to Gallery",
                            if (received.size > 1) "${received.size} files in Gallery > AirFlow" else (received.firstOrNull()?.name ?: "")
                        )
                        ov.setPhotos(pics, received.map { it.name }, received.size)
                        ov.setMode(AirShareOverlay.M_REVEAL)
                    }
                }
            }
            if (scene == 7 || scene == 8) {
                ov.setRemoteC(remoteC)
                ov.remoteEnd(endToken, endCommit, endFling)
            }
            if (scene == 6 && pics.isNotEmpty() && !ov.photosSame(pics)) ov.setPhotos(pics, received.map { it.name }, received.size)
        }
    )
}
