package com.airflow.app

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.media.MediaMetadataRetriever
import android.net.Uri
import androidx.core.graphics.drawable.toBitmap
import java.io.File
import kotlin.math.max
import kotlin.math.min

/**
 * Draws a proper preview "chip" for any file, so a video, an app, a song or a document looks like itself instead of
 * a grey box with letters: a real video frame with film edges, play button and length; an APK with its real icon,
 * name, version and size; a song with its cover art; a PDF with its first page; any other file as a paper sheet
 * with a folded corner and a coloured type band.
 */
object ChipArt {

    private val IMG = setOf("jpg", "jpeg", "png", "webp", "gif", "bmp", "heic", "heif")
    private val VID = setOf("mp4", "mkv", "webm", "mov", "3gp", "avi", "m4v", "ts", "flv")
    private val AUD = setOf("mp3", "m4a", "aac", "wav", "flac", "ogg", "opus", "amr")
    private val APK = setOf("apk", "apks", "xapk")

    fun forFile(ctx: Context, f: File, name: String): Bitmap? = make(ctx, f, null, name)

    fun make(ctx: Context, file: File?, uri: Uri?, name: String): Bitmap? {
        if (file == null && uri == null) return null
        val ext = name.substringAfterLast('.', "").lowercase()
        return try {
            when {
                ext in IMG -> PhotoStore.load(ctx, uri ?: Uri.fromFile(file), 720)
                ext in VID -> videoArt(ctx, file, uri, name)
                ext in APK && file != null -> apkArt(ctx, file, name)
                ext in AUD -> audioArt(ctx, file, uri, name)
                ext == "pdf" -> pdfArt(ctx, file, uri, name)
                else -> docArt(name, sizeOf(ctx, file, uri))
            }
        } catch (e: Throwable) {
            try { docArt(name, sizeOf(ctx, file, uri)) } catch (_: Throwable) { null }
        }
    }

    // ------------------------------------------------------------------ helpers

    private fun sizeOf(ctx: Context, file: File?, uri: Uri?): Long {
        if (file != null && file.exists()) return file.length()
        if (uri != null) try { ctx.contentResolver.openFileDescriptor(uri, "r")?.use { return it.statSize } } catch (_: Exception) {}
        return 0L
    }

    private fun paint(color: Int = Color.WHITE, size: Float = 30f, bold: Boolean = false, align: Paint.Align = Paint.Align.LEFT) =
        Paint(Paint.ANTI_ALIAS_FLAG).apply {
            this.color = color; textSize = size; textAlign = align
            typeface = if (bold) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
        }

    private fun ellipsize(p: Paint, s: String, maxW: Float): String {
        if (p.measureText(s) <= maxW) return s
        var t = s
        while (t.length > 1 && p.measureText("$t…") > maxW) t = t.dropLast(1)
        return "$t…"
    }

    private fun fmtDur(ms: Long): String {
        val s = ms / 1000
        val h = s / 3600
        val m = (s % 3600) / 60
        val sec = s % 60
        return if (h > 0) "%d:%02d:%02d".format(h, m, sec) else "%d:%02d".format(m, sec)
    }

    private fun blend(a: Int, b: Int, t: Float): Int {
        val r = (Color.red(a) * (1 - t) + Color.red(b) * t).toInt()
        val g = (Color.green(a) * (1 - t) + Color.green(b) * t).toInt()
        val bl = (Color.blue(a) * (1 - t) + Color.blue(b) * t).toInt()
        return Color.rgb(r, g, bl)
    }

    private fun drawCrop(c: Canvas, src: Bitmap, W: Int, H: Int) {
        val s = max(W.toFloat() / src.width, H.toFloat() / src.height)
        val m = Matrix().apply { setScale(s, s); postTranslate((W - src.width * s) / 2f, (H - src.height * s) / 2f) }
        c.drawBitmap(src, m, Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG))
    }

    private fun chip(c: Canvas, x: Float, y: Float, text: String, bg: Int, fg: Int = Color.WHITE, size: Float = 26f) {
        val p = paint(fg, size, true)
        val w = p.measureText(text) + 30f
        val h = size + 22f
        val r = RectF(x, y, x + w, y + h)
        c.drawRoundRect(r, h / 2f, h / 2f, Paint(Paint.ANTI_ALIAS_FLAG).apply { color = bg })
        c.drawText(text, x + 15f, y + h / 2f + size * 0.35f, p)
    }

    // ------------------------------------------------------------------ video

    private fun videoArt(ctx: Context, file: File?, uri: Uri?, name: String): Bitmap {
        val W = 720
        val H = 440
        val bmp = Bitmap.createBitmap(W, H, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        var frame: Bitmap? = null
        var durMs = 0L
        val r = MediaMetadataRetriever()
        try {
            if (file != null) r.setDataSource(file.path) else r.setDataSource(ctx, uri)
            durMs = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
            val atUs = min(1_500_000L, durMs * 1000L / 4L).coerceAtLeast(0L)
            frame = r.getFrameAtTime(atUs, MediaMetadataRetriever.OPTION_CLOSEST_SYNC)
        } catch (_: Exception) {
        } finally {
            try { r.release() } catch (_: Exception) {}
        }
        if (frame != null) drawCrop(c, frame, W, H)
        else {
            val p = Paint().apply { shader = LinearGradient(0f, 0f, W.toFloat(), H.toFloat(), Color.parseColor("#1B2340"), Color.parseColor("#05070F"), Shader.TileMode.CLAMP) }
            c.drawRect(0f, 0f, W.toFloat(), H.toFloat(), p)
        }
        // cinematic light: darker at the bottom and corners
        val vg = Paint().apply {
            shader = LinearGradient(0f, H * 0.45f, 0f, H.toFloat(), Color.TRANSPARENT, Color.argb(215, 0, 0, 0), Shader.TileMode.CLAMP)
        }
        c.drawRect(0f, 0f, W.toFloat(), H.toFloat(), vg)
        val corner = Paint().apply {
            shader = RadialGradient(W / 2f, H / 2f, W * 0.7f, Color.TRANSPARENT, Color.argb(120, 0, 0, 0), Shader.TileMode.CLAMP)
        }
        c.drawRect(0f, 0f, W.toFloat(), H.toFloat(), corner)
        // film edges with perforations
        val strip = Paint().apply { color = Color.argb(170, 8, 8, 12) }
        c.drawRect(0f, 0f, 38f, H.toFloat(), strip)
        c.drawRect(W - 38f, 0f, W.toFloat(), H.toFloat(), strip)
        val hole = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.argb(215, 235, 238, 245) }
        var y = 16f
        while (y < H - 24f) {
            c.drawRoundRect(RectF(11f, y, 27f, y + 22f), 5f, 5f, hole)
            c.drawRoundRect(RectF(W - 27f, y, W - 11f, y + 22f), 5f, 5f, hole)
            y += 46f
        }
        // play button with a soft halo
        val cx = W / 2f
        val cy = H / 2f - 14f
        c.drawCircle(cx, cy, 104f, Paint(Paint.ANTI_ALIAS_FLAG).apply {
            shader = RadialGradient(cx, cy, 104f, Color.argb(110, 255, 255, 255), Color.TRANSPARENT, Shader.TileMode.CLAMP)
        })
        c.drawCircle(cx, cy, 60f, Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.argb(60, 0, 0, 0); setShadowLayer(18f, 0f, 6f, Color.argb(120, 0, 0, 0)) })
        c.drawCircle(cx, cy, 58f, Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.argb(238, 255, 255, 255) })
        val tri = Path().apply { moveTo(cx - 16f, cy - 28f); lineTo(cx + 30f, cy); lineTo(cx - 16f, cy + 28f); close() }
        c.drawPath(tri, Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#10141F") })
        chip(c, 62f, 22f, "VIDEO", Color.argb(200, 255, 61, 87))
        val np = paint(Color.WHITE, 34f, true)
        np.setShadowLayer(8f, 0f, 2f, Color.BLACK)
        c.drawText(ellipsize(np, name.substringBeforeLast('.'), W - 62f - 190f), 62f, H - 56f, np)
        val sp = paint(Color.parseColor("#C9D0E4"), 24f)
        sp.setShadowLayer(6f, 0f, 2f, Color.BLACK)
        c.drawText(TapFiles.human(sizeOf(ctx, file, uri)), 62f, H - 22f, sp)
        if (durMs > 0) {
            val t = fmtDur(durMs)
            val tp = paint(Color.WHITE, 28f, true, Paint.Align.CENTER)
            val tw = tp.measureText(t) + 34f
            val rr = RectF(W - 62f - tw, H - 74f, W - 62f, H - 28f)
            c.drawRoundRect(rr, 23f, 23f, Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.argb(185, 0, 0, 0) })
            c.drawText(t, rr.centerX(), rr.centerY() + 10f, tp)
        }
        return bmp
    }

    // ------------------------------------------------------------------ APK

    private fun apkArt(ctx: Context, file: File, name: String): Bitmap {
        val W = 720
        val H = 520
        val bmp = Bitmap.createBitmap(W, H, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        var label = name.substringBeforeLast('.')
        var ver = ""
        var pkg = ""
        var icon: Bitmap? = null
        try {
            val pm = ctx.packageManager
            val info = pm.getPackageArchiveInfo(file.path, 0)
            val ai = info?.applicationInfo
            if (info != null && ai != null) {
                ai.sourceDir = file.path
                ai.publicSourceDir = file.path
                label = ai.loadLabel(pm).toString().ifBlank { label }
                ver = info.versionName ?: ""
                pkg = info.packageName ?: ""
                icon = ai.loadIcon(pm).toBitmap(256, 256)
            }
        } catch (_: Throwable) {
        }
        val avg = try { icon?.let { Bitmap.createScaledBitmap(it, 1, 1, true).getPixel(0, 0) } } catch (_: Throwable) { null } ?: Color.parseColor("#2EA37A")
        val c1 = blend(avg or (0xFF shl 24), Color.BLACK, 0.5f)
        val c2 = blend(avg or (0xFF shl 24), Color.parseColor("#0A1020"), 0.82f)
        c.drawRect(0f, 0f, W.toFloat(), H.toFloat(), Paint().apply {
            shader = LinearGradient(0f, 0f, W.toFloat(), H.toFloat(), c1, c2, Shader.TileMode.CLAMP)
        })
        c.drawCircle(W / 2f, 200f, 250f, Paint(Paint.ANTI_ALIAS_FLAG).apply {
            shader = RadialGradient(W / 2f, 200f, 250f, (avg and 0xFFFFFF) or (95 shl 24), Color.TRANSPARENT, Shader.TileMode.CLAMP)
        })
        // the app icon on a soft tile, like an app store listing
        val s = 210f
        val ir = RectF(W / 2f - s / 2f, 70f, W / 2f + s / 2f, 70f + s)
        c.drawRoundRect(ir, 48f, 48f, Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.argb(60, 0, 0, 0); setShadowLayer(34f, 0f, 14f, Color.argb(170, 0, 0, 0)) })
        if (icon != null) {
            val path = Path().apply { addRoundRect(ir, 48f, 48f, Path.Direction.CW) }
            c.save()
            c.clipPath(path)
            c.drawBitmap(icon, null, ir, Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG))
            c.restore()
        } else {
            c.drawRoundRect(ir, 48f, 48f, Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#3DDC84") })
            c.drawText("APK", ir.centerX(), ir.centerY() + 22f, paint(Color.parseColor("#0A1020"), 64f, true, Paint.Align.CENTER))
        }
        c.drawRoundRect(ir, 48f, 48f, Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 2.5f; color = Color.argb(70, 255, 255, 255) })
        val lp = paint(Color.WHITE, 46f, true, Paint.Align.CENTER)
        c.drawText(ellipsize(lp, label, W - 90f), W / 2f, 346f, lp)
        val vp = paint(Color.parseColor("#C9D0E4"), 28f, false, Paint.Align.CENTER)
        val line = (if (ver.isNotBlank()) "Version $ver  ·  " else "") + TapFiles.human(file.length())
        c.drawText(ellipsize(vp, line, W - 90f), W / 2f, 392f, vp)
        if (pkg.isNotBlank()) {
            val pp = paint(Color.argb(150, 201, 208, 228), 22f, false, Paint.Align.CENTER)
            c.drawText(ellipsize(pp, pkg, W - 90f), W / 2f, 428f, pp)
        }
        chip(c, 34f, 26f, "APK", Color.parseColor("#3DDC84"), Color.parseColor("#0A1020"))
        // install pill
        val bp = paint(Color.parseColor("#0A1020"), 27f, true, Paint.Align.CENTER)
        val bw = 250f
        val br = RectF(W / 2f - bw / 2f, 450f, W / 2f + bw / 2f, 498f)
        c.drawRoundRect(br, 24f, 24f, Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#3DDC84") })
        c.drawText("Install package", br.centerX(), br.centerY() + 9.5f, bp)
        return bmp
    }

    // ------------------------------------------------------------------ audio

    private fun audioArt(ctx: Context, file: File?, uri: Uri?, name: String): Bitmap {
        val W = 720
        val H = 520
        val bmp = Bitmap.createBitmap(W, H, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        var art: Bitmap? = null
        var title = name.substringBeforeLast('.')
        var artist = ""
        var durMs = 0L
        val r = MediaMetadataRetriever()
        try {
            if (file != null) r.setDataSource(file.path) else r.setDataSource(ctx, uri)
            r.embeddedPicture?.let { art = android.graphics.BitmapFactory.decodeByteArray(it, 0, it.size) }
            r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_TITLE)?.takeIf { it.isNotBlank() }?.let { title = it }
            artist = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_ARTIST) ?: ""
            durMs = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
        } catch (_: Exception) {
        } finally {
            try { r.release() } catch (_: Exception) {}
        }
        val a = art
        val avg = try { a?.let { Bitmap.createScaledBitmap(it, 1, 1, true).getPixel(0, 0) } } catch (_: Throwable) { null } ?: Color.parseColor("#7B3FE4")
        c.drawRect(0f, 0f, W.toFloat(), H.toFloat(), Paint().apply {
            shader = LinearGradient(0f, 0f, W.toFloat(), H.toFloat(), blend(avg or (0xFF shl 24), Color.BLACK, 0.35f), blend(avg or (0xFF shl 24), Color.parseColor("#0A1020"), 0.8f), Shader.TileMode.CLAMP)
        })
        val cx = W / 2f
        val cy = 190f
        if (a != null) {
            val rr = RectF(cx - 140f, cy - 140f, cx + 140f, cy + 140f)
            c.drawRoundRect(rr, 34f, 34f, Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.argb(60, 0, 0, 0); setShadowLayer(30f, 0f, 12f, Color.argb(170, 0, 0, 0)) })
            val path = Path().apply { addRoundRect(rr, 34f, 34f, Path.Direction.CW) }
            c.save(); c.clipPath(path); drawCrop2(c, a, rr); c.restore()
        } else {
            // a record: dark disc, grooves and a coloured label
            c.drawCircle(cx, cy, 142f, Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#0B0D14"); setShadowLayer(26f, 0f, 10f, Color.argb(160, 0, 0, 0)) })
            val gp = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 2f; color = Color.argb(40, 255, 255, 255) }
            var rad = 56f
            while (rad < 138f) { c.drawCircle(cx, cy, rad, gp); rad += 11f }
            c.drawCircle(cx, cy, 50f, Paint(Paint.ANTI_ALIAS_FLAG).apply {
                shader = LinearGradient(cx - 50f, cy - 50f, cx + 50f, cy + 50f, Color.parseColor("#FF4FD8"), Color.parseColor("#7B3FE4"), Shader.TileMode.CLAMP)
            })
            c.drawCircle(cx, cy, 7f, Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#0B0D14") })
        }
        val tp = paint(Color.WHITE, 40f, true, Paint.Align.CENTER)
        c.drawText(ellipsize(tp, title, W - 90f), cx, 398f, tp)
        val ap = paint(Color.parseColor("#C9D0E4"), 28f, false, Paint.Align.CENTER)
        c.drawText(ellipsize(ap, if (artist.isNotBlank()) artist else TapFiles.human(sizeOf(ctx, file, uri)), W - 90f), cx, 440f, ap)
        // a little equaliser, so it looks like music
        val eq = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.argb(200, 255, 255, 255); strokeCap = Paint.Cap.ROUND; strokeWidth = 8f }
        val hs = floatArrayOf(18f, 34f, 24f, 44f, 30f, 20f, 38f)
        for (i in hs.indices) { val x = cx - 66f + i * 22f; c.drawLine(x, 488f - hs[i] / 2f, x, 488f + hs[i] / 2f, eq) }
        chip(c, 34f, 26f, "AUDIO", Color.argb(200, 123, 63, 228))
        if (durMs > 0) {
            val t = fmtDur(durMs)
            val dp = paint(Color.WHITE, 26f, true, Paint.Align.RIGHT)
            c.drawText(t, W - 38f, 50f, dp)
        }
        return bmp
    }

    private fun drawCrop2(c: Canvas, src: Bitmap, dst: RectF) {
        val s = max(dst.width() / src.width, dst.height() / src.height)
        val m = Matrix().apply { setScale(s, s); postTranslate(dst.left + (dst.width() - src.width * s) / 2f, dst.top + (dst.height() - src.height * s) / 2f) }
        c.drawBitmap(src, m, Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG))
    }

    // ------------------------------------------------------------------ PDF and other documents

    private fun pdfArt(ctx: Context, file: File?, uri: Uri?, name: String): Bitmap {
        val page = (if (file != null) PdfPreview.firstPage(file, 600) else if (uri != null) PdfPreview.firstPage(ctx, uri, 600) else null)
            ?: return docArt(name, sizeOf(ctx, file, uri))
        val out = page.copy(Bitmap.Config.ARGB_8888, true)
        val c = Canvas(out)
        chip(c, 22f, 22f, "PDF", Color.parseColor("#FF4D5E"), Color.WHITE, 30f)
        val g = Paint().apply { shader = LinearGradient(0f, out.height * 0.8f, 0f, out.height.toFloat(), Color.TRANSPARENT, Color.argb(120, 0, 0, 0), Shader.TileMode.CLAMP) }
        c.drawRect(0f, 0f, out.width.toFloat(), out.height.toFloat(), g)
        return out
    }

    private fun docColor(ext: String): Int = when (ext) {
        "zip", "rar", "7z", "tar", "gz" -> Color.parseColor("#F5A524")
        "doc", "docx", "odt", "rtf" -> Color.parseColor("#2B7BFF")
        "xls", "xlsx", "csv", "ods" -> Color.parseColor("#1FAE6B")
        "ppt", "pptx", "odp" -> Color.parseColor("#F26B3A")
        "txt", "md", "log" -> Color.parseColor("#7E8AA8")
        "json", "xml", "html", "js", "kt", "java", "py" -> Color.parseColor("#12B5CB")
        else -> Color.parseColor("#8B5CFF")
    }

    private fun docArt(name: String, size: Long): Bitmap {
        val W = 720
        val H = 540
        val bmp = Bitmap.createBitmap(W, H, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val ext = name.substringAfterLast('.', "").lowercase()
        val col = docColor(ext)
        c.drawRect(0f, 0f, W.toFloat(), H.toFloat(), Paint().apply {
            shader = LinearGradient(0f, 0f, W.toFloat(), H.toFloat(), blend(col, Color.BLACK, 0.62f), Color.parseColor("#0A1020"), Shader.TileMode.CLAMP)
        })
        c.drawCircle(W / 2f, 220f, 230f, Paint(Paint.ANTI_ALIAS_FLAG).apply {
            shader = RadialGradient(W / 2f, 220f, 230f, (col and 0xFFFFFF) or (80 shl 24), Color.TRANSPARENT, Shader.TileMode.CLAMP)
        })
        // a sheet of paper with a folded corner
        val sw = 280f
        val sh = 340f
        val l = W / 2f - sw / 2f
        val t = 40f
        val fold = 70f
        val sheet = Path().apply {
            moveTo(l, t); lineTo(l + sw - fold, t); lineTo(l + sw, t + fold); lineTo(l + sw, t + sh); lineTo(l, t + sh); close()
        }
        c.drawPath(sheet, Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.argb(70, 0, 0, 0); setShadowLayer(30f, 0f, 14f, Color.argb(170, 0, 0, 0)) })
        c.drawPath(sheet, Paint(Paint.ANTI_ALIAS_FLAG).apply {
            shader = LinearGradient(l, t, l + sw, t + sh, Color.parseColor("#FAFBFF"), Color.parseColor("#DDE3F2"), Shader.TileMode.CLAMP)
        })
        val flap = Path().apply { moveTo(l + sw - fold, t); lineTo(l + sw, t + fold); lineTo(l + sw - fold, t + fold); close() }
        c.drawPath(flap, Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#B9C3DC") })
        // type band and lines of "text"
        val bandTop = t + 120f
        c.drawRect(l, bandTop, l + sw, bandTop + 76f, Paint().apply { color = col })
        val ep = paint(Color.WHITE, if (ext.length > 4) 36f else 48f, true, Paint.Align.CENTER)
        c.drawText(if (ext.isBlank()) "FILE" else ext.uppercase().take(6), l + sw / 2f, bandTop + 52f, ep)
        val lp = Paint().apply { color = Color.parseColor("#C5CCE0") }
        var yy = t + 224f
        for (i in 0 until 4) {
            c.drawRoundRect(RectF(l + 30f, yy, l + sw - 30f - (i % 2) * 50f, yy + 10f), 5f, 5f, lp)
            yy += 26f
        }
        val np = paint(Color.WHITE, 36f, true, Paint.Align.CENTER)
        c.drawText(ellipsize(np, name, W - 80f), W / 2f, 450f, np)
        val sp = paint(Color.parseColor("#C9D0E4"), 27f, false, Paint.Align.CENTER)
        c.drawText(if (size > 0) TapFiles.human(size) else "File", W / 2f, 492f, sp)
        return bmp
    }
}
