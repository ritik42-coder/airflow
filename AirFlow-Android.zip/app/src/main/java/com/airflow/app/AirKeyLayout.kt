package com.airflow.app

/** One key: label on screen, the text it types, and its rectangle in view pixels. */
class AirKey(
    val label: String,
    val code: String,
    val special: Int,
    val x: Float,
    val y: Float,
    val w: Float,
    val h: Float
) {
    companion object {
        const val NORMAL = 0
        const val SHIFT = 1
        const val BACKSPACE = 2
        const val ENTER = 3
        const val SPACE = 4
        const val MODE = 5
    }
}

/**
 * The QWERTY layout, kept out of the View so it can be tested on its own.
 * Four rows: 10 / 9 / 9 / 5 keys, the same proportions as a phone keyboard.
 */
object AirKeyLayout {

    fun build(
        left: Float,
        top: Float,
        width: Float,
        height: Float,
        gap: Float,
        symbols: Boolean,
        shift: Boolean
    ): List<AirKey> {
        val out = ArrayList<AirKey>(40)
        val kh = height / 4f
        fun add(label: String, code: String, special: Int, x: Float, y: Float, w: Float, h: Float) {
            out.add(AirKey(label, code, special, x + gap / 2f, y + gap / 2f, w - gap, h - gap))
        }

        val r1 = if (symbols) arrayOf("1", "2", "3", "4", "5", "6", "7", "8", "9", "0")
        else arrayOf("q", "w", "e", "r", "t", "y", "u", "i", "o", "p")
        val w1 = width / 10f
        for (i in r1.indices) add(r1[i], r1[i], AirKey.NORMAL, left + i * w1, top, w1, kh)

        val r2 = if (symbols) arrayOf("@", "#", "$", "%", "&", "-", "+", "(", ")")
        else arrayOf("a", "s", "d", "f", "g", "h", "j", "k", "l")
        val inset = width * 0.05f
        val w2 = (width - inset * 2f) / 9f
        for (i in r2.indices) add(r2[i], r2[i], AirKey.NORMAL, left + inset + i * w2, top + kh, w2, kh)

        val shiftW = width * 0.13f
        add("⇧", "SHIFT", AirKey.SHIFT, left, top + kh * 2f, shiftW, kh)
        val r3 = if (symbols) arrayOf("*", "\"", "'", ":", ";", "!", "?")
        else arrayOf("z", "x", "c", "v", "b", "n", "m")
        val w3 = (width - shiftW * 2f) / 7f
        for (i in r3.indices) add(r3[i], r3[i], AirKey.NORMAL, left + shiftW + i * w3, top + kh * 2f, w3, kh)
        add("⌫", "DEL", AirKey.BACKSPACE, left + width - shiftW, top + kh * 2f, shiftW, kh)

        val modeW = width * 0.15f
        val comW = width * 0.10f
        val entW = width * 0.19f
        val spaceW = width - modeW - comW - entW - comW
        val rowY = top + kh * 3f
        add(if (symbols) "ABC" else "123", if (symbols) "ABC" else "NUM", AirKey.MODE, left, rowY, modeW, kh)
        add(",", ",", AirKey.NORMAL, left + modeW, rowY, comW, kh)
        add("space", " ", AirKey.SPACE, left + modeW + comW, rowY, spaceW, kh)
        add(".", ".", AirKey.NORMAL, left + modeW + comW + spaceW, rowY, comW, kh)
        add("⏎", "ENTER", AirKey.ENTER, left + width - entW, rowY, entW, kh)
        return out
    }

    /** Index of the key under a point, or -1. */
    fun hit(keys: List<AirKey>, x: Float, y: Float): Int {
        for (i in keys.indices) {
            val k = keys[i]
            if (x >= k.x && x <= k.x + k.w && y >= k.y && y <= k.y + k.h) return i
        }
        return -1
    }
}
