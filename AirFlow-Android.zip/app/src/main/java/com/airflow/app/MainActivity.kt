package com.airflow.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.abs
import kotlin.math.roundToInt

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Prefs.init(this)
        AirFlowState.themeMode.value = Prefs.themeMode
        setContent { AirTheme { Root() } }
    }
}

/** Things deep screens can ask the shell to do. */
class AppActions(val replayIntro: () -> Unit)

val LocalActions = staticCompositionLocalOf { AppActions(replayIntro = {}) }

@Composable
fun Root() {
    val activity = LocalContext.current as ComponentActivity
    val dark = isAirDark()
    LaunchedEffect(dark) {
        val bars = if (dark) {
            SystemBarStyle.dark(android.graphics.Color.TRANSPARENT)
        } else {
            SystemBarStyle.light(android.graphics.Color.TRANSPARENT, android.graphics.Color.TRANSPARENT)
        }
        activity.enableEdgeToEdge(statusBarStyle = bars, navigationBarStyle = bars)
    }

    var introDone by rememberSaveable { mutableStateOf(false) }
    var appVisible by rememberSaveable { mutableStateOf(false) }
    val scroll = remember { mutableFloatStateOf(0f) }
    val actions = remember { AppActions(replayIntro = { introDone = false }) }

    CompositionLocalProvider(LocalScroll provides scroll, LocalActions provides actions) {
        Box(Modifier.fillMaxSize()) {
            LiveBackground()
            if (appVisible) AppShell()
            if (!introDone) {
                IntroScreen(
                    onReveal = { appVisible = true },
                    onFinished = {
                        appVisible = true
                        introDone = true
                    }
                )
            }
        }
    }
}

@Composable
fun AppShell() {
    var tab by rememberSaveable { mutableIntStateOf(0) }
    Box(Modifier.fillMaxSize()) {
        AnimatedContent(
            targetState = tab,
            modifier = Modifier.fillMaxSize(),
            transitionSpec = {
                val dir = if (targetState > initialState) 1 else -1
                (slideInHorizontally(spring(dampingRatio = 0.85f, stiffness = Spring.StiffnessMediumLow)) { it * dir / 5 } +
                    fadeIn(tween(320)) + scaleIn(initialScale = 0.96f, animationSpec = tween(320))) togetherWith
                    (slideOutHorizontally(tween(260)) { -it * dir / 6 } + fadeOut(tween(200)))
            },
            label = "tabs"
        ) { t ->
            when (t) {
                0 -> HomeScreen(goDemo = { tab = 1 })
                1 -> DemoScreen(goTest = { tab = 2 })
                2 -> TestScreen()
                3 -> TransferScreen()
                else -> SettingsScreen()
            }
        }
        TopBar(Modifier.align(Alignment.TopCenter))
        NavBar(tab, { tab = it }, Modifier.align(Alignment.BottomCenter))
    }
}

private fun setTheme(dark: Boolean) {
    val m = if (dark) 1 else 2 // tapping flips to the other theme
    AirFlowState.themeMode.value = m
    Prefs.themeMode = m
}

@Composable
private fun TopBar(modifier: Modifier) {
    val c = Air.c
    val running by AirFlowState.running.collectAsState()
    val dark = isAirDark()
    val haptic = LocalHapticFeedback.current
    Row(
        modifier
            .fillMaxWidth()
            .background(Brush.verticalGradient(listOf(c.bg0.copy(alpha = 0.94f), c.bg0.copy(alpha = 0.55f), Color.Transparent)))
            .statusBarsPadding()
            .padding(horizontal = 14.dp, vertical = 2.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        AirLogo(30.dp, Modifier.offset(x = (-8).dp))
        Spacer(Modifier.width(0.dp))
        GradientText(
            "AIR FLOW",
            MaterialTheme.typography.titleMedium.copy(letterSpacing = 3.sp, fontWeight = FontWeight.Black),
            listOf(c.text, c.a2, c.a1)
        )
        Spacer(Modifier.weight(1f))
        Row(
            Modifier.clip(RoundedCornerShape(50)).background(c.glass).border(1.dp, c.stroke, RoundedCornerShape(50))
                .padding(horizontal = 10.dp, vertical = 5.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            PulseDot(c.ok, running)
            Spacer(Modifier.width(4.dp))
            Text(
                if (running) "LIVE" else "OFF", fontSize = 11.sp, fontWeight = FontWeight.Black,
                letterSpacing = 1.2.sp, color = if (running) c.ok else c.dim
            )
        }
        Spacer(Modifier.width(10.dp))
        val rot = animateFloatAsState(if (dark) 0f else 180f, spring(dampingRatio = 0.6f, stiffness = 200f), label = "rot")
        Box(
            Modifier.size(40.dp).clip(CircleShape).background(c.glass).border(1.dp, c.stroke, CircleShape)
                .pressClick {
                    haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                    setTheme(dark)
                },
            contentAlignment = Alignment.Center
        ) {
            Crossfade(targetState = dark, animationSpec = tween(400), label = "ico") { d ->
                Box(Modifier.graphicsLayer { rotationZ = rot.value }) {
                    if (d) AirIcon(IconKind.MOON, c.a2, Modifier.size(20.dp)) else AirIcon(IconKind.SUN, c.warn, Modifier.size(22.dp))
                }
            }
        }
    }
}

@Composable
private fun NavBar(tab: Int, onTab: (Int) -> Unit, modifier: Modifier) {
    val c = Air.c
    val haptic = LocalHapticFeedback.current
    val items = listOf(
        "Home" to IconKind.HOME,
        "Tour" to IconKind.PLAY,
        "Test" to IconKind.SCAN,
        "Share" to IconKind.SHARE,
        "Settings" to IconKind.SLIDERS
    )
    val pos = animateFloatAsState(tab.toFloat(), spring(dampingRatio = 0.72f, stiffness = 380f), label = "navpos")
    val shape = RoundedCornerShape(34.dp)
    BoxWithConstraints(
        modifier.fillMaxWidth().navigationBarsPadding().padding(horizontal = 18.dp, vertical = 12.dp)
    ) {
        val itemW = maxWidth / items.size
        Box(
            Modifier
                .fillMaxWidth()
                .height(68.dp)
                .shadow(if (c.dark) 0.dp else 18.dp, shape, ambientColor = c.shadow.copy(alpha = 0.2f), spotColor = c.shadow.copy(alpha = 0.35f))
                .clip(shape)
                .background(if (c.dark) Color(0xE60A0F24) else Color(0xF2FFFFFF))
                .border(1.dp, Brush.linearGradient(listOf(c.stroke.copy(alpha = 0.9f), c.stroke.copy(alpha = 0.25f))), shape)
        ) {
            // the glowing selection pill glides between tabs with a spring
            Box(
                Modifier
                    .offset {
                        IntOffset((itemW.toPx() * pos.value + 6.dp.toPx()).roundToInt(), 8.dp.roundToPx())
                    }
                    .size(width = itemW - 12.dp, height = 52.dp)
                    .clip(RoundedCornerShape(26.dp))
                    .background(Brush.horizontalGradient(listOf(c.a1, c.a2)))
            )
            Row(Modifier.fillMaxSize()) {
                items.forEachIndexed { i, (label, icon) ->
                    val sel = (1f - abs(pos.value - i)).coerceIn(0f, 1f)
                    Column(
                        Modifier
                            .weight(1f)
                            .fillMaxSize()
                            .pressClick(scaleTo = 0.9f) {
                                if (i != tab) haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                                onTab(i)
                            },
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = androidx.compose.foundation.layout.Arrangement.Center
                    ) {
                        val tint = lerp(c.dim, Color.White, sel)
                        AirIcon(icon, tint, Modifier.size(22.dp).graphicsLayer {
                            val s = 1f + 0.14f * sel
                            scaleX = s
                            scaleY = s
                            translationY = -2.dp.toPx() * sel
                        })
                        Text(
                            label, color = tint, fontSize = 10.sp,
                            fontWeight = if (sel > 0.5f) FontWeight.Black else FontWeight.SemiBold, letterSpacing = 0.5.sp
                        )
                    }
                }
            }
        }
    }
}
