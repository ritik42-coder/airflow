package com.airflow.app

import android.content.ContentValues
import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.os.SystemClock
import android.provider.MediaStore
import android.provider.OpenableColumns
import com.google.android.gms.nearby.Nearby
import com.google.android.gms.nearby.connection.AdvertisingOptions
import com.google.android.gms.nearby.connection.ConnectionInfo
import com.google.android.gms.nearby.connection.ConnectionLifecycleCallback
import com.google.android.gms.nearby.connection.ConnectionResolution
import com.google.android.gms.nearby.connection.ConnectionsClient
import com.google.android.gms.nearby.connection.DiscoveredEndpointInfo
import com.google.android.gms.nearby.connection.DiscoveryOptions
import com.google.android.gms.nearby.connection.EndpointDiscoveryCallback
import com.google.android.gms.nearby.connection.Payload
import com.google.android.gms.nearby.connection.PayloadCallback
import com.google.android.gms.nearby.connection.PayloadTransferUpdate
import com.google.android.gms.nearby.connection.Strategy
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.sqrt

// ---------------------------------------------------------------------------------------------
// Tap Share: touch the two phones together and the file goes. No code, no QR, no menus.
// The bump is the handshake; Nearby Connections carries the bytes.
// ---------------------------------------------------------------------------------------------

/**
 * Detects the "top-to-top touch": a sharp acceleration spike mostly along the phone's long axis.
 * Both phones feel the same impact at the same moment, which is what makes the pairing trustworthy.
 */
class BumpDetector(
    context: Context,
    private val onBump: (Float) -> Unit,
    private val onLevel: (Float, Float) -> Unit
) : SensorEventListener {

    private val sm = context.getSystemService(Context.SENSOR_SERVICE) as SensorManager
    private val linear: Sensor? = sm.getDefaultSensor(Sensor.TYPE_LINEAR_ACCELERATION)
    private val accel: Sensor? = sm.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)

    /** Higher is easier. Both phones must feel the same knock, so the tap has to be deliberate. */
    var sensitivity: Int = 7

    private var running = false
    private var lastBump = 0L
    private var lastLevel = 0L
    private val grav = FloatArray(3)
    private var gravInit = false

    val available: Boolean get() = linear != null || accel != null

    fun threshold(): Float = max(6f, 20.5f - 1.5f * sensitivity)

    fun start() {
        if (running) return
        val s = linear ?: accel ?: return
        gravInit = false
        running = sm.registerListener(this, s, SensorManager.SENSOR_DELAY_GAME)
    }

    fun stop() {
        if (!running) return
        sm.unregisterListener(this)
        running = false
    }

    override fun onSensorChanged(e: SensorEvent) {
        var x = e.values[0]
        var y = e.values[1]
        var z = e.values[2]
        if (e.sensor.type == Sensor.TYPE_ACCELEROMETER) {
            if (!gravInit) {
                grav[0] = x; grav[1] = y; grav[2] = z
                gravInit = true
            }
            val a = 0.85f
            grav[0] = a * grav[0] + (1 - a) * x
            grav[1] = a * grav[1] + (1 - a) * y
            grav[2] = a * grav[2] + (1 - a) * z
            x -= grav[0]; y -= grav[1]; z -= grav[2]
        }
        val mag = sqrt(x * x + y * y + z * z)
        val yShare = if (mag > 0.01f) abs(y) / mag else 0f
        val now = SystemClock.elapsedRealtime()
        val thr = threshold()
        if (now - lastLevel > 80) {
            lastLevel = now
            onLevel(mag, thr)
        }
        if (mag >= thr && yShare >= 0.45f && now - lastBump > 1200) {
            lastBump = now
            onBump(mag)
        }
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}
}

/** One file the user picked, ready to go. */
class TapFile(val uri: Uri, val name: String, val size: Long, val mime: String)

/** A contact picked from the phone book. */
class TapContact(val name: String, val phone: String)

/**
 * The link. Both phones advertise and discover at the same time; a bump on either side triggers the
 * connection. Whoever has the smaller device id asks, so the two phones never both dial at once.
 */
class TapLink(private val ctx: Context, private val cb: Callbacks) {

    interface Callbacks {
        fun peers(count: Int)
        fun connecting()
        fun connected(name: String)
        fun lost()
        fun failed(msg: String)
        fun progress(done: Long, total: Long, name: String)
        fun finished()
        fun incomingOffer(count: Int, bytes: Long)
        fun saved(name: String, ok: Boolean, image: Boolean)
        fun contact(c: TapContact)
    }

    private val app = ctx.applicationContext
    private val client: ConnectionsClient = Nearby.getConnectionsClient(app)
    private val strategy = Strategy.P2P_POINT_TO_POINT
    private val myId = java.lang.Long.toHexString(System.nanoTime()).takeLast(6)
    private val myName = "Air Flow"

    private var started = false
    private var peer: String? = null
    private var peerName = ""
    private val found = LinkedHashMap<String, String>()   // endpointId -> name
    private val incoming = HashMap<Long, Payload>()
    private val outIndex = HashMap<Long, Int>()
    private var sentBytes = 0L
    private var totalBytes = 0L
    private var sending = ArrayList<File>()
    private var sendContact: TapContact? = null
    private var index = 0
    private var offerFrom = ""

    // ------------------------------------------------------------------ payloads

    private val payloadCb = object : PayloadCallback() {
        override fun onPayloadReceived(endpointId: String, payload: Payload) {
            if (payload.type == Payload.Type.BYTES) {
                val text = try { String(payload.asBytes() ?: ByteArray(0)) } catch (e: Exception) { "" }
                if (text.isNotEmpty()) handleMessage(text)
            } else if (payload.type == Payload.Type.FILE) {
                incoming[payload.id] = payload
            }
        }

        override fun onPayloadTransferUpdate(endpointId: String, u: PayloadTransferUpdate) {
            val idx = outIndex[u.payloadId]
            if (idx != null) {
                // sending: report the real byte count so both phones show the true speed
                sentBytes += (u.bytesTransferred - lastFor(u.payloadId)).coerceAtLeast(0L)
                lastFor(u.payloadId, u.bytesTransferred)
                val name = sending.getOrNull(idx)?.name ?: ""
                cb.progress(sentBytes.coerceAtMost(totalBytes), totalBytes, name)
                if (u.status == PayloadTransferUpdate.Status.SUCCESS) {
                    outIndex.remove(u.payloadId)
                    lastFor(u.payloadId, 0L)
                    sendNext()
                } else if (u.status == PayloadTransferUpdate.Status.FAILURE ||
                    u.status == PayloadTransferUpdate.Status.CANCELED
                ) {
                    outIndex.remove(u.payloadId)
                    cb.failed("The transfer stopped. Move the phones closer and try again.")
                }
                return
            }
            if (incoming.containsKey(u.payloadId)) {
                // cumulative across every file, so the bar never jumps back to zero
                val was = recvLast[u.payloadId] ?: 0L
                recvDone += (u.bytesTransferred - was).coerceAtLeast(0L)
                recvLast[u.payloadId] = u.bytesTransferred
                if (recvTotal <= 0L) recvTotal = u.totalBytes.coerceAtLeast(1L)
                cb.progress(recvDone.coerceAtMost(recvTotal), recvTotal, "receiving")
            }
            if (u.status == PayloadTransferUpdate.Status.SUCCESS) {
                val done = incoming.remove(u.payloadId)
                if (done != null) {
                    // copy off the main thread: a big video must not freeze the animation
                    Thread { saveIncoming(done) }.start()
                }
            }
        }
    }

    private val lastBytes = HashMap<Long, Long>()
    private var recvDone = 0L
    private var recvTotal = 0L
    private val recvLast = HashMap<Long, Long>()
    private fun lastFor(id: Long, set: Long? = null): Long {
        return if (set == null) lastBytes[id] ?: 0L else { lastBytes[id] = set; set }
    }

    private val connCb = object : ConnectionLifecycleCallback() {
        override fun onConnectionInitiated(id: String, info: ConnectionInfo) {
            // anyone running Tap Share is a valid peer: the bump was the consent
            peer = id
            peerName = cleanName(info.endpointName)
            client.acceptConnection(id, payloadCb)
            cb.connecting()
        }

        override fun onConnectionResult(id: String, r: ConnectionResolution) {
            if (r.status.isSuccess) {
                peer = id
                stopDiscovery()
                cb.connected(peerName)
                sendHi()
            } else {
                peer = null
                cb.failed("Could not link. Touch the phones together again.")
            }
        }

        override fun onDisconnected(id: String) {
            peer = null
            cb.lost()
        }
    }

    // ------------------------------------------------------------------ advertise + discover

    fun start() {
        if (started) return
        started = true
        val advName = "AF|$myId|$myName"
        client.startAdvertising(
            advName, SERVICE, connCb,
            AdvertisingOptions.Builder().setStrategy(strategy).build()
        ).addOnFailureListener { cb.failed(it.message ?: "Could not start Tap Share") }

        val disc = object : EndpointDiscoveryCallback() {
            override fun onEndpointFound(id: String, info: DiscoveredEndpointInfo) {
                if (info.endpointName.startsWith("AF|")) {
                    found[id] = info.endpointName
                    cb.peers(found.size)
                }
            }

            override fun onEndpointLost(id: String) {
                found.remove(id)
                cb.peers(found.size)
            }
        }
        client.startDiscovery(
            SERVICE, disc,
            DiscoveryOptions.Builder().setStrategy(strategy).build()
        ).addOnFailureListener { cb.failed(it.message ?: "Could not look for phones") }
    }

    private fun stopDiscovery() {
        try { client.stopDiscovery() } catch (_: Exception) {}
    }

    /** A bump on this phone: dial the peer we found, if we are the one that should dial. */
    fun bump() {
        if (peer != null) return
        val target = found.entries.firstOrNull() ?: return
        val peerId = target.value.split("|").getOrNull(1)
        // the phone with the smaller id dials, so both never dial at the same time
        if (peerId != null && myId > peerId) return
        cb.connecting()
        client.requestConnection("AF|$myId|$myName", target.key, connCb)
            .addOnFailureListener { cb.failed(it.message ?: "Could not connect") }
    }

    /** Manual connect, for when a tap did not take. */
    fun connectNow() {
        if (peer != null) return
        val target = found.entries.firstOrNull() ?: return
        cb.connecting()
        client.requestConnection("AF|$myId|$myName", target.key, connCb)
            .addOnFailureListener { cb.failed(it.message ?: "Could not connect") }
    }

    private fun cleanName(endpointName: String): String {
        val parts = endpointName.split("|")
        return if (parts.size >= 3) parts[2] else "Nearby phone"
    }

    // ------------------------------------------------------------------ sending

    fun send(files: List<File>, contact: TapContact?) {
        val id = peer ?: run { cb.failed("Touch the phones together first"); return }
        if (files.isEmpty() && contact == null) return
        sending = ArrayList(files)
        sendContact = contact
        index = 0
        sentBytes = 0
        totalBytes = files.sumOf { it.length() }
        outIndex.clear()
        lastBytes.clear()

        val arr = JSONArray()
        files.forEach { f ->
            arr.put(JSONObject().put("n", f.name).put("s", f.length()).put("m", mimeOf(f)))
        }
        val o = JSONObject()
            .put("t", "offer")
            .put("files", arr)
            .put("bytes", totalBytes)
        contact?.let { o.put("contact", JSONObject().put("n", it.name).put("p", it.phone)) }
        sendJson(id, o)
        if (files.isEmpty()) {
            // a contact on its own: nothing else to stream
            sendJson(id, JSONObject().put("t", "end"))
        }
    }

    private fun sendHi() {
        val id = peer ?: return
        sendJson(id, JSONObject().put("t", "hi").put("n", myName))
    }

    private fun sendNext() {
        val id = peer ?: return
        if (index >= sending.size) {
            sendJson(id, JSONObject().put("t", "end"))
            cb.finished()
            return
        }
        val f = sending[index]
        index++
        try {
            val p = Payload.fromFile(f)
            outIndex[p.id] = index - 1
            lastBytes[p.id] = 0L
            client.sendPayload(id, p)
        } catch (e: Exception) {
            cb.failed("Could not read that file")
        }
    }

    private fun handleMessage(text: String) {
        val o = try { JSONObject(text) } catch (e: Exception) { return }
        when (o.optString("t")) {
            "hi" -> {}
            "offer" -> {
                val arr = o.optJSONArray("files") ?: JSONArray()
                val bytes = o.optLong("bytes")
                offerFrom = peer ?: ""
                if (o.has("contact")) {
                    val c = o.getJSONObject("contact")
                    cb.contact(TapContact(c.optString("n"), c.optString("p")))
                }
                recvDone = 0L
                recvTotal = bytes
                recvLast.clear()
                cb.incomingOffer(arr.length(), bytes)
                if (arr.length() > 0) sendJson(offerFrom, JSONObject().put("t", "ok"))
                else cb.finished()
            }
            "ok" -> sendNext()
            "end" -> cb.finished()
            "no" -> cb.failed("The other phone declined")
        }
    }

    private fun sendJson(ep: String, o: JSONObject) {
        try { client.sendPayload(ep, Payload.fromBytes(o.toString().toByteArray())) } catch (_: Exception) {}
    }

    private fun mimeOf(f: File): String = when (f.extension.lowercase()) {
        "jpg", "jpeg" -> "image/jpeg"
        "png" -> "image/png"
        "mp4" -> "video/mp4"
        "mp3" -> "audio/mpeg"
        "pdf" -> "application/pdf"
        "vcf" -> "text/x-vcard"
        else -> "application/octet-stream"
    }

    // ------------------------------------------------------------------ receiving

    private fun saveIncoming(p: Payload) {
        try {
            val f = p.asFile() ?: return
            val uri = f.asUri()
            val name = f.asJavaFile()?.name ?: "airflow_${System.currentTimeMillis()}"
            val input = if (uri != null) app.contentResolver.openInputStream(uri) else f.asJavaFile()?.inputStream()
            if (input == null) { cb.saved(name, false, false); return }
            val image = isImage(name)
            val ok = input.use { copyToStore(name, it, image) }
            cb.saved(name, ok, image)
        } catch (e: Exception) {
            cb.saved("file", false, false)
        }
    }

    private fun isImage(name: String): Boolean {
        val n = name.lowercase()
        return n.endsWith(".jpg") || n.endsWith(".jpeg") || n.endsWith(".png") ||
            n.endsWith(".webp") || n.endsWith(".gif") || n.endsWith(".heic")
    }

    /** Images land in Pictures/AirFlow, everything else in Downloads/AirFlow. */
    private fun copyToStore(name: String, input: java.io.InputStream, image: Boolean): Boolean {
        return try {
        if (Build.VERSION.SDK_INT >= 29) {
            val collection = if (image) MediaStore.Images.Media.EXTERNAL_CONTENT_URI else MediaStore.Downloads.EXTERNAL_CONTENT_URI
            val v = ContentValues().apply {
                put(MediaStore.MediaColumns.DISPLAY_NAME, name)
                put(MediaStore.MediaColumns.MIME_TYPE, if (image) "image/*" else "application/octet-stream")
                put(MediaStore.MediaColumns.RELATIVE_PATH, if (image) "Pictures/AirFlow" else "Downloads/AirFlow")
                put(MediaStore.MediaColumns.IS_PENDING, 1)
            }
            val uri = app.contentResolver.insert(collection, v) ?: return false
            app.contentResolver.openOutputStream(uri)?.use { o -> input.copyTo(o) }
            v.clear()
            v.put(MediaStore.MediaColumns.IS_PENDING, 0)
            app.contentResolver.update(uri, v, null, null)
            true
        } else {
            val dir = File(app.getExternalFilesDir(if (image) Environment.DIRECTORY_PICTURES else Environment.DIRECTORY_DOWNLOADS), "AirFlow")
            dir.mkdirs()
            File(dir, name).outputStream().use { o -> input.copyTo(o) }
            true
            }
        } catch (e: Exception) {
            false
        }
    }

    fun stop() {
        started = false
        try {
            client.stopAdvertising()
            client.stopDiscovery()
            client.stopAllEndpoints()
        } catch (_: Exception) {}
        peer = null
        found.clear()
        incoming.clear()
        outIndex.clear()
        lastBytes.clear()
    }

    companion object {
        private const val SERVICE = "com.airflow.app.tap"
    }
}

// ---------------------------------------------------------------------------------------------
// Small helpers the screen uses
// ---------------------------------------------------------------------------------------------

object TapFiles {

    fun describe(ctx: Context, uri: Uri): TapFile {
        var name = "file"
        var size = 0L
        try {
            ctx.contentResolver.query(uri, null, null, null, null)?.use { c ->
                if (c.moveToFirst()) {
                    val ni = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    val si = c.getColumnIndex(OpenableColumns.SIZE)
                    if (ni >= 0) name = c.getString(ni) ?: name
                    if (si >= 0) size = c.getLong(si)
                }
            }
        } catch (_: Exception) {}
        val mime = try { ctx.contentResolver.getType(uri) ?: "application/octet-stream" } catch (e: Exception) { "application/octet-stream" }
        return TapFile(uri, name, size, mime)
    }

    /** Copies a picked document into the cache so Nearby can stream it as a plain file. */
    fun materialise(ctx: Context, f: TapFile): File? = try {
        val out = File(ctx.cacheDir, "tap_" + f.name.replace(Regex("[^A-Za-z0-9._-]"), "_"))
        ctx.contentResolver.openInputStream(f.uri)?.use { i -> out.outputStream().use { o -> i.copyTo(o) } }
        if (out.length() > 0) out else null
    } catch (e: Exception) {
        null
    }

    fun human(bytes: Long): String = when {
        bytes >= 1_000_000_000L -> "%.1f GB".format(bytes / 1_000_000_000.0)
        bytes >= 1_000_000L -> "%.1f MB".format(bytes / 1_000_000.0)
        bytes >= 1_000L -> "%.0f KB".format(bytes / 1_000.0)
        else -> "$bytes B"
    }

    fun speed(bytes: Long, ms: Long): String {
        if (ms <= 0) return ""
        val mbps = (bytes / 1_000_000.0) / (ms / 1000.0)
        return "%.1f MB/s".format(mbps)
    }
}
