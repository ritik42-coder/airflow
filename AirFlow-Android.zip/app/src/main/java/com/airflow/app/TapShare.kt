package com.airflow.app

import android.content.ContentValues
import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.net.Uri
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.util.Base64
import android.os.Environment
import android.os.SystemClock
import android.provider.MediaStore
import android.provider.OpenableColumns
import com.google.android.gms.nearby.Nearby
import com.google.android.gms.nearby.connection.AdvertisingOptions
import com.google.android.gms.nearby.connection.ConnectionInfo
import com.google.android.gms.nearby.connection.ConnectionLifecycleCallback
import com.google.android.gms.nearby.connection.ConnectionResolution
import com.google.android.gms.nearby.connection.ConnectionsClient
import com.google.android.gms.nearby.connection.DiscoveredEndpointInfo
import com.google.android.gms.nearby.connection.DiscoveryOptions
import com.google.android.gms.nearby.connection.EndpointDiscoveryCallback
import com.google.android.gms.nearby.connection.Payload
import com.google.android.gms.nearby.connection.PayloadCallback
import com.google.android.gms.nearby.connection.PayloadTransferUpdate
import com.google.android.gms.nearby.connection.Strategy
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.RandomAccessFile
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.sqrt

// ---------------------------------------------------------------------------------------------
// Tap Share: touch the two phones together and the file goes. No code, no QR, no menus.
// The bump is the handshake; the file itself travels in chunks we read and write ourselves, so
// the receiver always ends up with the real name, the real bytes and the real progress.
// ---------------------------------------------------------------------------------------------

/**
 * Detects the "top-to-top touch": a sharp acceleration spike mostly along the phone's long axis.
 * Both phones feel the same impact at the same moment, which is what makes the pairing trustworthy.
 */
class BumpDetector(
    context: Context,
    private val onBump: (Float) -> Unit,
    private val onLevel: (Float, Float) -> Unit
) : SensorEventListener {

    private val sm = context.getSystemService(Context.SENSOR_SERVICE) as SensorManager
    private val linear: Sensor? = sm.getDefaultSensor(Sensor.TYPE_LINEAR_ACCELERATION)
    private val accel: Sensor? = sm.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)

    /**
     * Higher is easier. 11 feels a light touch of two phones. A false knock is harmless because the other
     * phone only accepts a "tap" connection if it felt a knock of its own at the same moment.
     */
    var sensitivity: Int = 11

    private var running = false
    private var lastBump = 0L
    private var lastLevel = 0L
    private val grav = FloatArray(3)
    private var gravInit = false
    private var prevMag = 0f

    val available: Boolean get() = linear != null || accel != null

    fun threshold(): Float = max(2.2f, 20.5f - 1.5f * sensitivity)

    fun start() {
        if (running) return
        val s = linear ?: accel ?: return
        gravInit = false
        // a touch of two phones is over in a few milliseconds, so sample as fast as Android allows without a permission
        running = sm.registerListener(this, s, SensorManager.SENSOR_DELAY_FASTEST)
    }

    fun stop() {
        if (!running) return
        sm.unregisterListener(this)
        running = false
    }

    override fun onSensorChanged(e: SensorEvent) {
        var x = e.values[0]
        var y = e.values[1]
        var z = e.values[2]
        if (e.sensor.type == Sensor.TYPE_ACCELEROMETER) {
            if (!gravInit) {
                grav[0] = x; grav[1] = y; grav[2] = z
                gravInit = true
            }
            val a = 0.85f
            grav[0] = a * grav[0] + (1 - a) * x
            grav[1] = a * grav[1] + (1 - a) * y
            grav[2] = a * grav[2] + (1 - a) * z
            x -= grav[0]; y -= grav[1]; z -= grav[2]
        }
        val mag = sqrt(x * x + y * y + z * z)
        val yShare = if (mag > 0.01f) abs(y) / mag else 0f
        val now = SystemClock.elapsedRealtime()
        val thr = threshold()
        if (now - lastLevel > 80) {
            lastLevel = now
            onLevel(mag, thr)
        }
        // the spike itself, or a sudden jump from calm to hit (a gentle touch is short but sharp)
        val jerk = mag - prevMag
        prevMag = mag
        if ((mag >= thr || jerk >= thr * 0.85f) && yShare >= 0.35f && now - lastBump > 900) {
            lastBump = now
            onBump(mag)
        }
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}
}

/** One file the user picked, ready to go. */
class TapFile(val uri: Uri, val name: String, val size: Long, val mime: String)

/** A contact picked from the phone book. */
class TapContact(val name: String, val phone: String)

/**
 * The link and the pipe.
 *
 * Pairing: both phones advertise and discover; a bump (or a code) decides who dials, so the two
 * never dial each other at once.
 *
 * Transfer: the sender reads its own file in 128 KB chunks and pushes them as BYTES payloads with a
 * tiny 7-byte header (type, file index, chunk index). The receiver writes each chunk straight to a
 * temp file and only at the end copies it into Pictures/AirFlow or Downloads/AirFlow under the name
 * the sender gave. Nothing depends on how Nearby names a received file, which is why the old build
 * showed "sent" with nothing on the other phone.
 */
class TapLink(private val ctx: Context, private val cb: Callbacks) {

    interface Callbacks {
        fun peers(count: Int)
        fun connecting()
        fun connected(name: String)
        fun lost()
        fun failed(msg: String)
        fun progress(done: Long, total: Long, name: String)
        fun finished()
        fun incomingOffer(count: Int, bytes: Long)
        fun saved(item: RecvItem)
        fun contact(c: TapContact)
    }

    private val app = ctx.applicationContext
    private val client: ConnectionsClient = Nearby.getConnectionsClient(app)
    private val strategy = Strategy.P2P_POINT_TO_POINT
    private val myId = java.lang.Long.toHexString(System.nanoTime()).takeLast(6)
    private val myName = "Air Flow"

    private val mainH = Handler(Looper.getMainLooper())
    private var started = false
    private var peer: String? = null
    private var peerName = ""
    private var dialing = false
    private var lastBumpAt = 0L

    /** "tap" when the sender touched phones, "air" when the sender used the hand gesture. */
    @Volatile var offerStyle: String = "tap"
        private set

    /** A small picture of the first photo, sent with the offer so the receiver can draw the chip right away. */
    @Volatile var offerThumb: Bitmap? = null
        private set
    val offerFileNames: List<String> get() = offerNames

    /** Phones this one can currently see. */
    val nearby: Int get() = found.size
    private val found = LinkedHashMap<String, String>()

    // ---- sending ----
    private var files: List<File> = emptyList()
    private var fileIdx = 0
    private var fileOffset = 0L
    private var sentBytes = 0L
    private var totalBytes = 0L
    private var chunkIdx = 0
    private var ackedBytes = 0L
    private var inFlight = 0
    private var sending = false
    private val chunkOf = HashMap<Long, Int>()     // payload id -> bytes in that chunk
    private var sendContact: TapContact? = null

    // ---- receiving ----
    private var offerNames: List<String> = emptyList()
    private var offerSizes: List<Long> = emptyList()
    private var recvTotal = 0L
    private var recvDone = 0L
    private val recvFiles = HashMap<Int, File>()
    private val recvWriters = HashMap<Int, RandomAccessFile>()

    // ------------------------------------------------------------------ payloads

    private val payloadCb = object : PayloadCallback() {
        override fun onPayloadReceived(endpointId: String, payload: Payload) {
            if (payload.type != Payload.Type.BYTES) return
            val bytes = try { payload.asBytes() } catch (e: Exception) { null } ?: return
            if (bytes.isEmpty()) return
            when (bytes[0].toInt()) {
                TYPE_JSON -> handleJson(String(bytes, 1, bytes.size - 1))
                TYPE_CHUNK -> writeChunk(bytes)
            }
        }

        override fun onPayloadTransferUpdate(endpointId: String, u: PayloadTransferUpdate) {
            if (!chunkOf.containsKey(u.payloadId)) return
            // a chunk we sent has landed: free the window and push the next one
            if (u.status == PayloadTransferUpdate.Status.SUCCESS) {
                // progress counts only what the other phone has really received, so both screens agree
                ackedBytes += (chunkOf.remove(u.payloadId) ?: 0)
                inFlight--
                cb.progress(ackedBytes.coerceAtMost(totalBytes), totalBytes, files.getOrNull(fileIdx)?.name ?: "")
                pump()
            } else if (u.status == PayloadTransferUpdate.Status.FAILURE ||
                u.status == PayloadTransferUpdate.Status.CANCELED
            ) {
                chunkOf.remove(u.payloadId)
                inFlight--
                sending = false
                cb.failed("Transfer stopped. Keep the phones close and try again.")
            }
        }
    }

    private val connCb = object : ConnectionLifecycleCallback() {
        override fun onConnectionInitiated(id: String, info: ConnectionInfo) {
            peerName = cleanName(info.endpointName)
            val kind = info.endpointName.split("|").getOrNull(3) ?: "air"
            // A touch connection is only trusted if THIS phone felt a knock too. The knock is felt by both
            // phones at the same moment, so give our own sensor a short moment to report it.
            if (!dialing && kind == "tap" && !recentBump()) {
                mainH.postDelayed({
                    if (recentBump()) acceptFrom(id)
                    else try { client.rejectConnection(id) } catch (_: Exception) {}
                }, 800L)
                return
            }
            acceptFrom(id)
        }

        override fun onConnectionResult(id: String, r: ConnectionResolution) {
            dialing = false
            if (r.status.isSuccess) {
                peer = id
                stopDiscovery()
                cb.connected(peerName)
            } else {
                peer = null
                cb.failed("Could not link. Touch the phones together again.")
            }
        }

        override fun onDisconnected(id: String) {
            peer = null
            sending = false
            inFlight = 0
            chunkOf.clear()
            cb.lost()
        }
    }

    private fun recentBump(): Boolean = SystemClock.elapsedRealtime() - lastBumpAt < 2500L

    private fun acceptFrom(id: String) {
        peer = id
        client.acceptConnection(id, payloadCb)
        cb.connecting()
    }

    // ------------------------------------------------------------------ pairing

    /** Try again after the user grants a permission or turns Bluetooth on. */
    fun retry() {
        if (peer != null) return
        try {
            client.stopAdvertising()
            client.stopDiscovery()
        } catch (_: Exception) {}
        found.clear()
        started = false
        start()
    }

    fun start() {
        if (started) return
        started = true
        val advName = "AF|$myId|$myName"
        client.startAdvertising(advName, SERVICE, connCb, AdvertisingOptions.Builder().setStrategy(strategy).build())
            .addOnFailureListener { fail(it) }

        val disc = object : EndpointDiscoveryCallback() {
            override fun onEndpointFound(id: String, info: DiscoveredEndpointInfo) {
                if (info.endpointName.startsWith("AF|")) {
                    found[id] = info.endpointName
                    cb.peers(found.size)
                }
            }

            override fun onEndpointLost(id: String) {
                found.remove(id)
                cb.peers(found.size)
            }
        }
        client.startDiscovery(SERVICE, disc, DiscoveryOptions.Builder().setStrategy(strategy).build())
            .addOnFailureListener { fail(it) }
    }

    /** "Already advertising / discovering" just means it is already running, so it is not an error. */
    private fun fail(e: Throwable) {
        val m = e.message ?: ""
        if (m.contains("8001") || m.contains("8002")) return
        cb.failed(explain(e))
    }

    /** Turns the raw Nearby error into something a person can act on. */
    private fun explain(e: Throwable): String {
        val m = e.message ?: "Nearby could not start"
        return when {
            m.contains("8034") || m.contains("COARSE_LOCATION") || m.contains("FINE_LOCATION") ->
                if (!Perms.locationServiceOn(app)) "Location is switched off. Turn Location ON in quick settings, then tap Try again."
                else "Allow Location and Nearby devices permission, then tap Try again."
            m.contains("8032") || m.contains("8033") ->
                "Turn Bluetooth on, then touch the phones again."
            m.contains("8007") -> "Nearby is busy. Close other sharing apps and retry."
            else -> m
        }
    }

    private fun stopDiscovery() {
        try { client.stopDiscovery() } catch (_: Exception) {}
    }

    /** A bump on this phone: dial the peer, if we are the one that should dial. */
    fun bump() {
        // stamp our own knock first: the other phone will ask about it (see onConnectionInitiated)
        lastBumpAt = SystemClock.elapsedRealtime()
        if (peer != null) return
        val target = found.entries.firstOrNull() ?: return
        val peerId = target.value.split("|").getOrNull(1)
        if (peerId != null && myId > peerId) return
        dial(target.key, "tap")
    }

    /** Connects without a touch: used by the hand-gesture send, which the other phone accepts on its own. */
    fun connectNow() {
        if (peer != null) return
        val target = found.entries.firstOrNull() ?: return
        dial(target.key, "air")
    }

    private fun dial(endpointId: String, kind: String) {
        dialing = true
        cb.connecting()
        client.requestConnection("AF|$myId|$myName|$kind", endpointId, connCb)
            .addOnFailureListener { dialing = false; fail(it) }
    }

    private fun cleanName(endpointName: String): String {
        val parts = endpointName.split("|")
        return if (parts.size >= 3) parts[2] else "Nearby phone"
    }

    // ------------------------------------------------------------------ sending

    /** True while a phone is connected, so a sender knows whether it can go straight to sending. */
    val isLinked: Boolean get() = peer != null

    /** Drops the current connection and starts looking again, so the next phone can connect. */
    fun resetFresh() {
        try {
            client.stopAdvertising()
            client.stopDiscovery()
            client.stopAllEndpoints()
        } catch (_: Exception) {}
        peer = null
        sending = false
        inFlight = 0
        chunkOf.clear()
        found.clear()
        started = false
        start()
    }

    /** [names] are the real file names to show on the other phone; the cache copies carry a prefix. */
    fun send(list: List<File>, contact: TapContact?, names: List<String>? = null, thumb: ByteArray? = null, style: String = "tap") {
        val id = peer ?: run { cb.failed("Touch the phones together first"); return }
        if (list.isEmpty() && contact == null) return
        files = list
        sendContact = contact
        fileIdx = 0
        fileOffset = 0L
        sentBytes = 0L
        ackedBytes = 0L
        chunkIdx = 0
        inFlight = 0
        chunkOf.clear()
        totalBytes = list.sumOf { it.length() }.coerceAtLeast(1L)

        val arr = JSONArray()
        list.forEachIndexed { i, f ->
            arr.put(JSONObject().put("n", names?.getOrNull(i)?.takeIf { it.isNotBlank() } ?: f.name).put("s", f.length()))
        }
        val o = JSONObject().put("t", "offer").put("files", arr).put("bytes", totalBytes).put("st", style)
        if (thumb != null && thumb.size <= 16000) o.put("th", Base64.encodeToString(thumb, Base64.NO_WRAP))
        contact?.let { o.put("contact", JSONObject().put("n", it.name).put("p", it.phone)) }
        sendJson(id, o)
        if (list.isEmpty()) sendJson(id, JSONObject().put("t", "end"))
    }

    /** Keeps the pipe full: up to WINDOW chunks in flight, then waits for the acks. */
    private fun pump() {
        val id = peer ?: return
        if (!sending) return
        while (inFlight < WINDOW) {
            if (fileIdx >= files.size) {
                if (inFlight == 0) {
                    sendJson(id, JSONObject().put("t", "end"))
                    sending = false
                    cb.progress(totalBytes, totalBytes, "")
                    cb.finished()
                }
                return
            }
            val f = files[fileIdx]
            val left = f.length() - fileOffset
            if (left <= 0L) {
                fileIdx++
                fileOffset = 0L
                continue
            }
            val n = minOf(CHUNK.toLong(), left).toInt()
            val buf = ByteArray(7 + n)
            buf[0] = TYPE_CHUNK.toByte()
            buf[1] = ((fileIdx shr 8) and 0xFF).toByte()
            buf[2] = (fileIdx and 0xFF).toByte()
            val fileChunk = (fileOffset / CHUNK).toInt()
            buf[3] = ((fileChunk shr 24) and 0xFF).toByte()
            buf[4] = ((fileChunk shr 16) and 0xFF).toByte()
            buf[5] = ((fileChunk shr 8) and 0xFF).toByte()
            buf[6] = (fileChunk and 0xFF).toByte()
            val read = try {
                RandomAccessFile(f, "r").use { raf ->
                    raf.seek(fileOffset)
                    raf.readFully(buf, 7, n)
                    n
                }
            } catch (e: Exception) {
                sending = false
                cb.failed("Could not read " + f.name)
                return
            }
            val p = Payload.fromBytes(buf)
            chunkOf[p.id] = read
            inFlight++
            chunkIdx++
            fileOffset += read
            sentBytes += read
            try {
                client.sendPayload(id, p)
            } catch (e: Exception) {
                sending = false
                cb.failed("The link dropped. Touch again.")
                return
            }
        }
    }

    private fun handleJson(text: String) {
        val o = try { JSONObject(text) } catch (e: Exception) { return }
        when (o.optString("t")) {
            "offer" -> {
                val arr = o.optJSONArray("files") ?: JSONArray()
                val names = ArrayList<String>()
                val sizes = ArrayList<Long>()
                for (i in 0 until arr.length()) {
                    val f = arr.optJSONObject(i) ?: continue
                    names.add(f.optString("n", "file_$i"))
                    sizes.add(f.optLong("s"))
                }
                offerStyle = o.optString("st", "tap")
                offerThumb = try {
                    val th = o.optString("th", "")
                    if (th.isEmpty()) null else Base64.decode(th, Base64.NO_WRAP).let { BitmapFactory.decodeByteArray(it, 0, it.size) }
                } catch (e: Exception) { null }
                offerNames = names
                offerSizes = sizes
                recvTotal = o.optLong("bytes").coerceAtLeast(1L)
                recvDone = 0L
                clearRecv()
                o.optJSONObject("contact")?.let { cb.contact(TapContact(it.optString("n"), it.optString("p"))) }
                cb.incomingOffer(names.size, recvTotal)
                if (names.isNotEmpty()) peer?.let { sendJson(it, JSONObject().put("t", "ok")) }
                else cb.finished()
            }
            "ok" -> {
                sending = true
                pump()
            }
            "end" -> {
                finaliseReceived()
                cb.finished()
            }
        }
    }

    private fun sendJson(ep: String, o: JSONObject) {
        try {
            val body = o.toString().toByteArray()
            val buf = ByteArray(body.size + 1)
            buf[0] = TYPE_JSON.toByte()
            System.arraycopy(body, 0, buf, 1, body.size)
            client.sendPayload(ep, Payload.fromBytes(buf))
        } catch (_: Exception) {}
    }

    // ------------------------------------------------------------------ receiving

    private fun writeChunk(b: ByteArray) {
        if (b.size < 8) return
        val idx = ((b[1].toInt() and 0xFF) shl 8) or (b[2].toInt() and 0xFF)
        val chunk = ((b[3].toInt() and 0xFF) shl 24) or ((b[4].toInt() and 0xFF) shl 16) or
            ((b[5].toInt() and 0xFF) shl 8) or (b[6].toInt() and 0xFF)
        val data = b.size - 7
        val tmp = recvFiles.getOrPut(idx) { File(app.cacheDir, "tap_in_$idx") }
        try {
            // a fresh file every time: an old half-copy must never be appended to
            val w = recvWriters.getOrPut(idx) { RandomAccessFile(tmp, "rw").also { it.setLength(0L) } }
            // every chunk goes to its own spot, so the order they arrive in does not matter
            w.seek(chunk.toLong() * CHUNK)
            w.write(b, 7, data)
        } catch (e: Exception) {
            return
        }
        recvDone += data
        val name = offerNames.getOrNull(idx) ?: "file"
        cb.progress(recvDone.coerceAtMost(recvTotal), recvTotal, name)
    }

    private fun finaliseReceived() {
        // close the writers first so every byte is on disk before we read it back
        for (w in recvWriters.values) { try { w.close() } catch (_: Exception) {} }
        recvWriters.clear()
        for (i in offerNames.indices) {
            val tmp = recvFiles[i]
            val name = offerNames.getOrNull(i) ?: "file"
            val image = isImage(name)
            val expected = offerSizes.getOrNull(i) ?: 0L
            if (tmp == null || !tmp.exists() || tmp.length() == 0L || (expected > 0L && tmp.length() < expected)) {
                cb.saved(RecvItem(name, tmp?.length() ?: 0L, image, null, null))
                try { tmp?.delete() } catch (_: Exception) {}
                continue
            }
            val saved = try {
                tmp.inputStream().use { input -> FileStore.save(app, name, input, image) }
            } catch (e: Exception) {
                null
            }
            // keep a copy in the cache so the receiver box can draw it even if the public copy is out of reach
            val keep = File(app.cacheDir, "tap_keep_" + System.nanoTime() + "_" + FileStore.safeName(name))
            val kept = if (tmp.renameTo(keep)) keep else null
            if (kept == null) { try { tmp.delete() } catch (_: Exception) {} }
            cb.saved(RecvItem(name, kept?.length() ?: tmp.length(), image, saved, kept))
        }
        clearRecv()
    }

    private fun clearRecv() {
        for (w in recvWriters.values) { try { w.close() } catch (_: Exception) {} }
        recvWriters.clear()
        recvFiles.clear()
    }

    private fun isImage(name: String): Boolean = FileStore.isImage(name)

    fun stop() {
        started = false
        sending = false
        try {
            client.stopAdvertising()
            client.stopDiscovery()
            client.stopAllEndpoints()
        } catch (_: Exception) {}
        peer = null
        found.clear()
        chunkOf.clear()
        clearRecv()
    }

    companion object {
        private const val SERVICE = "com.airflow.app.tap"
        // Nearby caps a BYTES payload at 32 KB. The old 128 KB chunks were silently refused, which is why
        // the sender said "sent" while nothing reached the other phone. 30 KB + 7 header stays under it.
        private const val CHUNK = 30 * 1024
        private const val WINDOW = 12
        private const val TYPE_JSON = 0
        private const val TYPE_CHUNK = 1
    }
}

// ---------------------------------------------------------------------------------------------
// Small helpers the screen uses
// ---------------------------------------------------------------------------------------------

object TapFiles {

    fun describe(ctx: Context, uri: Uri): TapFile {
        var name = "file"
        var size = 0L
        try {
            ctx.contentResolver.query(uri, null, null, null, null)?.use { c ->
                if (c.moveToFirst()) {
                    val ni = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    val si = c.getColumnIndex(OpenableColumns.SIZE)
                    if (ni >= 0) name = c.getString(ni) ?: name
                    if (si >= 0) size = c.getLong(si)
                }
            }
        } catch (_: Exception) {}
        val mime = try {
            ctx.contentResolver.getType(uri) ?: "application/octet-stream"
        } catch (e: Exception) {
            "application/octet-stream"
        }
        return TapFile(uri, name, size, mime)
    }

    /** Copies a picked document into the cache so it can be streamed chunk by chunk. */
    fun materialise(ctx: Context, f: TapFile): File? = try {
        val safe = f.name.replace(Regex("[^A-Za-z0-9._-]"), "_").ifEmpty { "file" }
        val out = File(ctx.cacheDir, "tap_" + safe)
        ctx.contentResolver.openInputStream(f.uri)?.use { i -> out.outputStream().use { o -> i.copyTo(o) } }
        if (out.length() > 0) out else null
    } catch (e: Exception) {
        null
    }

    fun human(bytes: Long): String = when {
        bytes >= 1_000_000_000L -> "%.1f GB".format(bytes / 1_000_000_000.0)
        bytes >= 1_000_000L -> "%.1f MB".format(bytes / 1_000_000.0)
        bytes >= 1_000L -> "%.0f KB".format(bytes / 1_000.0)
        else -> "$bytes B"
    }

    fun speed(bytes: Long, ms: Long): String {
        if (ms <= 0) return ""
        val mbps = (bytes / 1_000_000.0) / (ms / 1000.0)
        return "%.1f MB/s".format(mbps)
    }
}


/** A small JPEG of a photo, light enough to ride along inside the offer message. */
object ThumbMaker {
    fun of(ctx: Context, f: File): ByteArray? {
        try {
            val b = PhotoStore.load(ctx, Uri.fromFile(f), 360) ?: return null
            var q = 64
            var out: ByteArray
            do {
                val bo = java.io.ByteArrayOutputStream()
                b.compress(Bitmap.CompressFormat.JPEG, q, bo)
                out = bo.toByteArray()
                q -= 14
            } while (out.size > 15000 && q > 18)
            return if (out.size <= 16000) out else null
        } catch (e: Exception) {
            return null
        }
    }
}
