package com.airflow.app

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.widget.Toast
import androidx.core.content.ContextCompat

/**
 * "Air Flow" in the system share sheet. Share a photo (or many) from the gallery, WhatsApp, Files...
 * and it lands here with no screen of its own: the files are copied, Air Share starts in the background,
 * and the animated overlay appears on top of whatever app you were in. Then: palm, fist, open.
 */
class ShareTargetActivity : Activity() {

    private var waiting: List<Uri> = emptyList()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Prefs.init(this)
        handle(intent)
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        if (intent != null) handle(intent)
    }

    @Suppress("DEPRECATION")
    private fun handle(i: Intent) {
        val uris = ArrayList<Uri>()
        when (i.action) {
            Intent.ACTION_SEND -> {
                val u: Uri? = if (Build.VERSION.SDK_INT >= 33) i.getParcelableExtra(Intent.EXTRA_STREAM, Uri::class.java)
                else i.getParcelableExtra(Intent.EXTRA_STREAM)
                if (u != null) uris.add(u)
            }
            Intent.ACTION_SEND_MULTIPLE -> {
                val l: ArrayList<Uri>? = if (Build.VERSION.SDK_INT >= 33) i.getParcelableArrayListExtra(Intent.EXTRA_STREAM, Uri::class.java)
                else i.getParcelableArrayListExtra(Intent.EXTRA_STREAM)
                if (l != null) uris.addAll(l)
            }
        }
        if (uris.isEmpty()) {
            Toast.makeText(this, "Nothing to send with Air Share", Toast.LENGTH_SHORT).show()
            finish()
            return
        }
        // the hand is read with the front camera, so the camera permission has to be there
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            waiting = uris
            requestPermissions(arrayOf(Manifest.permission.CAMERA), 41)
            return
        }
        go(uris)
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 41 && grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            go(waiting)
        } else {
            Toast.makeText(this, "Air Share needs the camera to see your hand", Toast.LENGTH_LONG).show()
            finish()
        }
    }

    private fun go(uris: List<Uri>) {
        val app = applicationContext
        // copying can take a moment for big videos, and the share permission lasts only while this activity lives
        Thread {
            val files = ArrayList<QueuedFile>()
            for (u in uris) {
                val info = TapFiles.describe(app, u)
                val f = TapFiles.materialise(app, info) ?: continue
                files.add(QueuedFile(f, info.name, info.mime.startsWith("image/") || FileStore.isImage(info.name)))
            }
            runOnUiThread {
                if (files.isEmpty()) {
                    Toast.makeText(this, "Could not read that file", Toast.LENGTH_SHORT).show()
                } else {
                    AirShareHub.arm(app, files)
                    try {
                        ContextCompat.startForegroundService(
                            this,
                            Intent(this, AirFlowService::class.java).setAction(AirFlowService.ACTION_SHARE)
                        )
                    } catch (e: Exception) {
                        Toast.makeText(this, "Could not start Air Share: ${e.message}", Toast.LENGTH_LONG).show()
                    }
                    Toast.makeText(this, "Air Share ready. Show your open palm", Toast.LENGTH_SHORT).show()
                }
                finish()
            }
        }.start()
    }
}
