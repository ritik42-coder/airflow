package com.airflow.app

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Matrix
import android.graphics.PointF
import android.os.SystemClock
import android.util.Log
import android.util.Size
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.core.content.ContextCompat
import androidx.lifecycle.LifecycleOwner
import com.google.mediapipe.framework.image.BitmapImageBuilder
import com.google.mediapipe.tasks.core.BaseOptions
import com.google.mediapipe.tasks.vision.core.RunningMode
import com.google.mediapipe.tasks.vision.handlandmarker.HandLandmarker
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

class FrameResult(
    val pose: GestureEngine.Pose,
    val gesture: Gesture?,
    val bitmap: Bitmap,
    val landmarks: List<PointF>?
)

/** Front camera -> MediaPipe hand landmarks -> GestureEngine. Used by the service and the Test screen. */
class HandController(
    private val context: Context,
    private val owner: LifecycleOwner,
    private val onResult: (FrameResult) -> Unit
) {
    private val executor: ExecutorService = Executors.newSingleThreadExecutor()
    private val engine = GestureEngine()
    private var landmarker: HandLandmarker? = null
    private var provider: ProcessCameraProvider? = null
    private var lastFrameMs = 0L
    @Volatile private var stopped = false

    fun start() {
        val future = ProcessCameraProvider.getInstance(context)
        future.addListener({
            try {
                if (stopped) return@addListener
                AirFlowState.error.value = null
                val base = BaseOptions.builder().setModelAssetPath("hand_landmarker.task").build()
                val opts = HandLandmarker.HandLandmarkerOptions.builder()
                    .setBaseOptions(base)
                    .setRunningMode(RunningMode.VIDEO)
                    .setNumHands(1)
                    .setMinHandDetectionConfidence(0.5f)
                    .setMinHandPresenceConfidence(0.5f)
                    .setMinTrackingConfidence(0.5f)
                    .build()
                landmarker = HandLandmarker.createFromOptions(context, opts)

                val analysis = ImageAnalysis.Builder()
                    .setTargetResolution(Size(480, 640))
                    .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                    .setOutputImageFormat(ImageAnalysis.OUTPUT_IMAGE_FORMAT_RGBA_8888)
                    .build()
                analysis.setAnalyzer(executor) { analyze(it) }

                provider = future.get()
                provider?.unbindAll()
                provider?.bindToLifecycle(owner, CameraSelector.DEFAULT_FRONT_CAMERA, analysis)
            } catch (e: Exception) {
                Log.e("AirFlow", "Camera/model start failed", e)
                AirFlowState.error.value = "Could not start camera or hand model: ${e.message}"
            }
        }, ContextCompat.getMainExecutor(context))
    }

    private fun analyze(proxy: ImageProxy) {
        try {
            val now = SystemClock.uptimeMillis()
            if (now - lastFrameMs < 1000L / Prefs.fps.coerceAtLeast(1)) return
            lastFrameMs = now
            val lmk = landmarker ?: return

            val raw = proxy.toBitmap()
            val m = Matrix().apply {
                postRotate(proxy.imageInfo.rotationDegrees.toFloat())
                postScale(-1f, 1f) // mirror like a selfie view
            }
            val bmp = Bitmap.createBitmap(raw, 0, 0, raw.width, raw.height, m, true)
            val result = lmk.detectForVideo(BitmapImageBuilder(bmp).build(), now)
            val pts = result.landmarks().firstOrNull()?.map { PointF(it.x(), it.y()) }
            val out = engine.process(pts, bmp.width.toFloat() / bmp.height, now)
            onResult(FrameResult(out.pose, out.gesture, bmp, pts))
        } catch (e: Exception) {
            Log.e("AirFlow", "analyze failed", e)
        } finally {
            proxy.close()
        }
    }

    fun stop() {
        stopped = true
        try { provider?.unbindAll() } catch (_: Exception) {}
        executor.execute { try { landmarker?.close() } catch (_: Exception) {} }
        executor.shutdown()
    }
}
