package com.airflow.app

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Matrix
import android.graphics.PointF
import android.os.Process
import android.os.SystemClock
import android.util.Log
import android.util.Size
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.core.content.ContextCompat
import androidx.lifecycle.LifecycleOwner
import com.google.mediapipe.framework.image.BitmapImageBuilder
import com.google.mediapipe.tasks.core.BaseOptions
import com.google.mediapipe.tasks.core.Delegate
import com.google.mediapipe.tasks.vision.core.RunningMode
import com.google.mediapipe.tasks.vision.handlandmarker.HandLandmarker
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

class FrameResult(
    val pose: GestureEngine.Pose,
    val gesture: Gesture?,
    val bitmap: Bitmap?,
    val landmarks: List<PointF>?,
    /** Every hand found this frame (0, 1 or 2). [landmarks] is the first one. */
    val hands: List<List<PointF>> = emptyList(),
    /** How far a held pose has got toward firing its gesture (0..1). Drives the live island. */
    val hold: Float = 0f,
    /** The face seen this frame (Hands-free only), else null. */
    val face: FaceFrame? = null
)

/** Front camera -> MediaPipe hand landmarks -> GestureEngine. Used by the service and the Test screen. */
class HandController(
    private val context: Context,
    private val owner: LifecycleOwner,
    /** Only the in-app Test screen needs the picture; skipping it saves memory and time per frame. */
    private val needBitmap: Boolean = false,
    /** 1 for gestures, 2 for the air music keyboard (both hands play at once). */
    private val maxHands: Int = 1,
    /** Air Music wants a steadier frame rate than the default. */
    private val minFps: Int = 0,
    private val onResult: (FrameResult) -> Unit
) {
    // Out of the app the camera thread was being treated like any background job and starved of CPU. Asking for
    // a display-priority thread keeps the hand tracking as quick outside the app as inside it.
    private val executor: ExecutorService = Executors.newSingleThreadExecutor { r ->
        Thread({
            try { Process.setThreadPriority(Process.THREAD_PRIORITY_URGENT_DISPLAY) } catch (_: Exception) {}
            r.run()
        }, "AirFlow-hands")
    }
    private val engine = GestureEngine()
    private var landmarker: HandLandmarker? = null
    private var faceTracker: FaceTracker? = null
    private var faceTick = 0
    private var lastFace: FaceFrame? = null
    private var provider: ProcessCameraProvider? = null
    private var analysisUc: ImageAnalysis? = null
    private var lastFrameMs = 0L
    @Volatile private var stopped = false

    fun start() {
        val future = ProcessCameraProvider.getInstance(context)
        future.addListener({
            try {
                if (stopped) return@addListener
                AirFlowState.error.value = null
                // the hand model is created on the camera thread itself (see ensureLandmarker), so the GPU
                // version works and loading it never stalls the screen

                val analysis = ImageAnalysis.Builder()
                    .setTargetResolution(Size(360, 480))
                    .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                    .setOutputImageFormat(ImageAnalysis.OUTPUT_IMAGE_FORMAT_RGBA_8888)
                    .build()
                analysis.setAnalyzer(executor) { analyze(it) }
                analysisUc = analysis

                provider = future.get()
                provider?.unbindAll()
                provider?.bindToLifecycle(owner, CameraSelector.DEFAULT_FRONT_CAMERA, analysis)
            } catch (e: Exception) {
                Log.e("AirFlow", "Camera/model start failed", e)
                AirFlowState.error.value = "Could not start camera or hand model: ${e.message}"
            }
        }, ContextCompat.getMainExecutor(context))
    }

    private fun build(gpu: Boolean): HandLandmarker {
        val baseB = BaseOptions.builder().setModelAssetPath("hand_landmarker.task")
        if (gpu) baseB.setDelegate(Delegate.GPU)
        val opts = HandLandmarker.HandLandmarkerOptions.builder()
            .setBaseOptions(baseB.build())
            .setRunningMode(RunningMode.VIDEO)
            .setNumHands(maxHands.coerceIn(1, 2))
            .setMinHandDetectionConfidence(0.5f)
            .setMinHandPresenceConfidence(0.5f)
            .setMinTrackingConfidence(0.5f)
            .build()
        return HandLandmarker.createFromOptions(context, opts)
    }

    private var gpuUsed = false
    private var gpuVerified = false

    /**
     * The GPU version of the hand model is a lot quicker than the CPU one, which matters most when the app is in
     * the background and the CPU is busy. It is tried once, with a safety latch: if the phone ever crashes while
     * starting it, the latch stays set and the CPU model is used from then on.
     */
    private fun ensureLandmarker(): HandLandmarker? {
        landmarker?.let { return it }
        if (stopped) return null
        if (Prefs.gpuHands && Prefs.gpuState != 3) {
            if (Prefs.gpuState == 1) {
                Prefs.gpuState = 3 // last time never finished starting: it crashed, so stay on the CPU
            } else {
                try {
                    Prefs.gpuState = 1
                    landmarker = build(true)
                    gpuUsed = true
                    return landmarker
                } catch (e: Throwable) {
                    Log.w("AirFlow", "GPU hand model unavailable, using CPU", e)
                    Prefs.gpuState = 3
                }
            }
        }
        return try {
            landmarker = build(false)
            landmarker
        } catch (e: Throwable) {
            Log.e("AirFlow", "Hand model failed to load", e)
            AirFlowState.error.value = "Could not start the hand model: ${e.message}"
            null
        }
    }

    private fun analyze(proxy: ImageProxy) {
        try {
            val now = SystemClock.uptimeMillis()
            // Cursor mode needs at least 30 FPS or the pointer feels laggy and quick pinches get missed.
            var fps = if (AirFlowState.cursorMode.value) maxOf(Prefs.fps, 30) else Prefs.fps
            if (Prefs.handsFree) fps = maxOf(fps, if (Prefs.hfPerf == 2) 24 else 30)
            if (minFps > fps) fps = minFps
            if (now - lastFrameMs < (850L / fps.coerceAtLeast(1))) return
            lastFrameMs = now
            val lmk = ensureLandmarker() ?: return

            val raw = proxy.toBitmap()
            val m = Matrix().apply {
                postRotate(proxy.imageInfo.rotationDegrees.toFloat())
                postScale(-1f, 1f) // mirror like a selfie view
            }
            val bmp = Bitmap.createBitmap(raw, 0, 0, raw.width, raw.height, m, true)
            raw.recycle()
            val result = try {
                lmk.detectForVideo(BitmapImageBuilder(bmp).build(), now)
            } catch (e: Throwable) {
                if (gpuUsed && !gpuVerified) {
                    // the GPU model loaded but cannot run here: fall back to the CPU one and remember it
                    Log.w("AirFlow", "GPU hand model failed while running, switching to CPU", e)
                    Prefs.gpuState = 3
                    try { lmk.close() } catch (_: Throwable) {}
                    landmarker = null
                    gpuUsed = false
                    bmp.recycle()
                    return
                }
                throw e
            }
            if (gpuUsed && !gpuVerified) { gpuVerified = true; Prefs.gpuState = 2 }
            val all = result.landmarks().map { hand -> hand.map { PointF(it.x(), it.y()) } }
            val pts = all.firstOrNull()
            // Hands-free: the same frame goes to the face model. Battery mode and slow phones run it every 2nd frame.
            var face: FaceFrame? = null
            if (Prefs.handsFree) {
                val ft = faceTracker ?: FaceTracker(context).also { faceTracker = it }
                faceTick++
                val every = if (Prefs.hfPerf == 2 || ft.lastMs > 40f) 2 else 1
                if (faceTick % every == 0) { lastFace = ft.detect(bmp, now) }
                face = lastFace
            } else if (faceTracker != null) {
                faceTracker?.close(); faceTracker = null; lastFace = null
            }
            val out = engine.process(pts, bmp.width.toFloat() / bmp.height, now)
            val hold = engine.holdFraction(now)
            if (needBitmap) {
                onResult(FrameResult(out.pose, out.gesture, bmp, pts, all, hold, face))
            } else {
                bmp.recycle()
                onResult(FrameResult(out.pose, out.gesture, null, pts, all, hold, face))
            }
        } catch (e: Exception) {
            Log.e("AirFlow", "analyze failed", e)
        } finally {
            proxy.close()
        }
    }

    fun stop() {
        stopped = true
        // Unbind only our own use case so a screen that just opened keeps its camera.
        try { analysisUc?.let { provider?.unbind(it) } } catch (_: Exception) {}
        executor.execute { try { landmarker?.close() } catch (_: Exception) {}; try { faceTracker?.close() } catch (_: Exception) {} }
        executor.shutdown()
    }
}
