package com.airflow.app

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapShader
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.os.SystemClock
import android.view.View
import java.util.Random
import kotlin.math.cos
import kotlin.math.exp
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.sin

/**
 * The full-screen, touch-through stage for Air Share. It floats above every app (gallery, WhatsApp...)
 * and draws the whole story: the photo lifting out of the share sheet, the palm and fist prompts, the
 * photo turning into a glowing orb in your hand, the launch, the orb dropping in on the other phone and
 * finally the release where the orb blooms back into the photo.
 *
 * Everything is time-driven on the display refresh, so it stays smooth whatever the camera frame rate is.
 */
class AirShareOverlay(ctx: Context) : View(ctx) {

    companion object {
        const val M_NONE = 0
        const val M_SEND_ARMED = 1
        const val M_SEND_READY = 2
        const val M_CAPTURED = 3
        const val M_SENDING = 4
        const val M_SENT = 5
        const val M_FAILED = 6
        const val M_RECV_INCOMING = 7
        const val M_RECV_WAIT = 8
        const val M_RECV_CATCH = 9
        const val M_REVEAL = 10
        /** Two phones touched: ripples from the top edge, two orbs merging into one link. */
        const val M_TAP_PAIR = 11
        /** This phone is sending: the photo chip slides out through the top edge as the percentage grows. */
        const val M_TAP_SEND = 12
        /** This phone is receiving: the matching chip slides in through the top edge. */
        const val M_TAP_RECV = 13

        const val REVEAL_MS = 4600f

        private val CYAN = Color.parseColor("#22D3EE")
        private val VIOLET = Color.parseColor("#8B5CFF")
        private val PINK = Color.parseColor("#FF4FD8")
        private val GOLD = Color.parseColor("#FFD27A")
        private val MINT = Color.parseColor("#34F5A5")
        private val RED = Color.parseColor("#FF5A6E")
        private val INK = Color.parseColor("#0B1020")
        private const val TRAIL = 26
        private const val BURST = 60
    }

    private val d = resources.displayMetrics.density

    // ---- what the hub tells us ------------------------------------------------------------
    private var mode = M_NONE
    private var modeSince = 0L
    private var photos: List<Bitmap> = emptyList()
    private var shaders: List<BitmapShader> = emptyList()
    private var names: List<String> = emptyList()
    private var total = 0
    private var progress = 0f
    private var hold = 0f
    private var label = ""
    private var sub = ""
    private var hx = 0.5f
    private var hy = 0.55f
    private var handSeen = false

    /** True for the touch (Tap Share) flows: no orb, the photo chip itself travels. */
    var tapStyle = false

    /** 0 = transparent (over other apps), up to 1 = solid dark backdrop (inside the app). */
    var backdrop = 0f

    private var pairOk = false
    private var pairAt = 0L
    private var chipW = 0f
    private var chipH = 0f
    private var dispP = 0f

    // ---- internal animation state ---------------------------------------------------------
    private var ox = 0f
    private var oy = 0f
    private var placed = false
    private var launchX = 0f
    private var launchY = 0f
    private var lastDraw = 0L
    private var shockAt = 0L
    private var shock2At = 0L
    private var shockColor = CYAN

    private val trX = FloatArray(TRAIL)
    private val trY = FloatArray(TRAIL)
    private val trT = LongArray(TRAIL)
    private var trN = 0

    private val bx = FloatArray(BURST)
    private val by = FloatArray(BURST)
    private val bvx = FloatArray(BURST)
    private val bvy = FloatArray(BURST)
    private val bsz = FloatArray(BURST)
    private val bcol = IntArray(BURST)
    private var burstAt = 0L
    private var burstLife = 1000f
    private var burstOn = false

    // ---- paints (allocated once) ----------------------------------------------------------
    private val addMode = PorterDuffXfermode(PorterDuff.Mode.ADD)
    private val glowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { xfermode = addMode }
    private val sparkPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { xfermode = addMode; style = Paint.Style.FILL }
    private val corePaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rimPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 1.5f * d }
    private val ringPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeWidth = 3.5f * d; strokeCap = Paint.Cap.ROUND
    }
    private val photoPaint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    private val fillPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val strokePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 1.5f * d }
    private val pillFill = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = INK; style = Paint.Style.FILL }
    private val pillStroke = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 1.2f * d }
    private val barPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val scrimPaint = Paint().apply { color = Color.BLACK }
    private val bgPaint = Paint().apply { style = Paint.Style.FILL }
    private val textPct = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE; textSize = 42f * d; typeface = Typeface.DEFAULT_BOLD; textAlign = Paint.Align.CENTER
    }
    private val textMain = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE; textSize = 15f * d; typeface = Typeface.DEFAULT_BOLD; textAlign = Paint.Align.CENTER
    }
    private val textSub = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE; textSize = 12f * d; textAlign = Paint.Align.CENTER
    }
    private val textBadge = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE; textSize = 12f * d; typeface = Typeface.DEFAULT_BOLD; textAlign = Paint.Align.CENTER
    }
    private val rect = RectF()
    private val arc = RectF()
    private val mat = Matrix()
    private val clip = Path()
    private val rnd = Random(7)

    // =========================================================================================
    // Hub-facing API
    // =========================================================================================

    fun setMode(m: Int) {
        if (m == mode) { postInvalidateOnAnimation(); return }
        mode = m
        modeSince = SystemClock.uptimeMillis()
        onEnter(m)
        postInvalidateOnAnimation()
    }

    fun currentMode(): Int = mode

    fun photosSame(list: List<Bitmap>): Boolean {
        val l = list.take(3)
        if (l.size != photos.size) return false
        for (i in l.indices) if (l[i] !== photos[i]) return false
        return true
    }

    fun setPhotos(list: List<Bitmap>, fileNames: List<String>, count: Int) {
        photos = list.take(3)
        shaders = photos.map { BitmapShader(it, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP) }
        names = fileNames
        total = count
        postInvalidateOnAnimation()
    }

    fun setInfo(l: String, s: String) { label = l; sub = s }

    /** The phones just touched. Call [tapPaired] when the link is up. */
    fun tapPair() {
        pairOk = false
        tapStyle = true
        progress = 0f
        mode = M_NONE // force a fresh start of the scene even if it was already showing
        setMode(M_TAP_PAIR)
    }

    fun tapPaired() {
        if (!pairOk) { pairOk = true; pairAt = SystemClock.uptimeMillis(); shockAt = pairAt; shockColor = MINT }
        postInvalidateOnAnimation()
    }

    /** The chip scenes: [send] true = leaving through the top edge, false = arriving through it. */
    fun tapTransfer(send: Boolean, thumb: Bitmap?, fileNames: List<String>, count: Int) {
        tapStyle = true
        setPhotos(if (thumb != null) listOf(thumb) else emptyList(), fileNames, count)
        dispP = 0f
        progress = 0f
        setMode(if (send) M_TAP_SEND else M_TAP_RECV)
    }
    fun setProgress(p: Float) { progress = p.coerceIn(0f, 1f) }
    fun setHold(h: Float) { hold = h.coerceIn(0f, 1f) }
    fun setHand(x: Float, y: Float, seen: Boolean) {
        if (seen) { hx = x; hy = y }
        handSeen = seen
    }

    // =========================================================================================
    // Easing and small helpers
    // =========================================================================================

    private fun now() = SystemClock.uptimeMillis()
    private fun clamp01(x: Float) = if (x < 0f) 0f else if (x > 1f) 1f else x
    private fun lerp(a: Float, b: Float, t: Float) = a + (b - a) * t
    private fun easeOut(t: Float): Float { val u = 1f - clamp01(t); return 1f - u * u * u }
    private fun easeIn(t: Float): Float { val x = clamp01(t); return x * x * x }
    private fun easeInOut(t: Float): Float {
        val x = clamp01(t)
        return if (x < 0.5f) 4f * x * x * x else 1f - (-2f * x + 2f).pow(3) / 2f
    }
    private fun easeOutBack(t: Float): Float {
        val x = clamp01(t)
        val c1 = 1.70158f
        val c3 = c1 + 1f
        return 1f + c3 * (x - 1f).pow(3) + c1 * (x - 1f).pow(2)
    }
    private fun withAlpha(color: Int, a: Int): Int = (a.coerceIn(0, 255) shl 24) or (color and 0xFFFFFF)

    private fun onEnter(m: Int) {
        val t = now()
        when (m) {
            M_SEND_ARMED, M_SEND_READY -> { trN = 0; burstOn = false; if (m == M_SEND_ARMED) placed = false }
            M_SENDING -> {
                launchX = ox; launchY = oy
                shockAt = t; shockColor = CYAN
                spawnBurst(ox, oy, 34, 150f, 900f)
            }
            M_SENT -> {
                shockAt = t; shockColor = MINT
                spawnBurst(width / 2f, height * 0.15f, 54, 190f, 1100f)
            }
            M_FAILED -> { shockAt = 0L }
            M_RECV_INCOMING -> { trN = 0; burstOn = false; placed = false; shockAt = 0L }
            M_RECV_CATCH -> { shockAt = t; shockColor = VIOLET }
            M_TAP_PAIR -> { trN = 0; burstOn = false; shockAt = t; shockColor = CYAN; placed = false }
            M_TAP_SEND, M_TAP_RECV -> { burstOn = false; dispP = 0f }
            M_REVEAL -> {
                launchX = ox; launchY = oy
                shockAt = t; shock2At = t + 420L; shockColor = CYAN
                spawnBurst(ox, oy, 56, 230f, 1300f)
            }
        }
    }

    private fun spawnBurst(x: Float, y: Float, n: Int, speedDp: Float, lifeMs: Float) {
        val cols = intArrayOf(CYAN, VIOLET, PINK, GOLD, Color.WHITE)
        val count = min(n, BURST)
        for (i in 0 until BURST) {
            if (i >= count) { bsz[i] = 0f; continue }
            val a = rnd.nextFloat() * 6.2832f
            val sp = (0.35f + 0.65f * rnd.nextFloat()) * speedDp * d
            bx[i] = x; by[i] = y
            bvx[i] = cos(a) * sp; bvy[i] = sin(a) * sp
            bsz[i] = (1.4f + 2.6f * rnd.nextFloat()) * d
            bcol[i] = cols[rnd.nextInt(cols.size)]
        }
        burstAt = now()
        burstLife = lifeMs
        burstOn = true
    }

    // =========================================================================================
    // Drawing blocks
    // =========================================================================================

    private fun drawGlow(c: Canvas, x: Float, y: Float, r: Float, color: Int, a: Float) {
        if (a <= 0.01f || r <= 1f) return
        val ca = (255 * a).toInt()
        glowPaint.shader = RadialGradient(
            x, y, r,
            intArrayOf(withAlpha(color, ca), withAlpha(color, ca / 3), withAlpha(color, 0)),
            floatArrayOf(0f, 0.45f, 1f), Shader.TileMode.CLAMP
        )
        c.drawCircle(x, y, r, glowPaint)
    }

    private fun drawAurora(c: Canvas, w: Float, strength: Float, clock: Float) {
        if (strength <= 0.01f) return
        val x1 = w * (0.5f + 0.32f * sin(clock * 0.9f))
        val x2 = w * (0.5f + 0.32f * sin(clock * 0.7f + 2.1f))
        val r = w * 0.75f
        drawGlow(c, x1, -r * 0.25f, r, CYAN, 0.42f * strength)
        drawGlow(c, x2, -r * 0.25f, r, VIOLET, 0.4f * strength)
        drawGlow(c, w * 0.5f, -r * 0.35f, r * 0.8f, PINK, 0.18f * strength)
    }

    private fun drawOrb(c: Canvas, x: Float, y: Float, r: Float, a: Float, c1: Int, c2: Int, spin: Float) {
        if (a <= 0.01f || r <= 1f) return
        drawGlow(c, x, y, r * 3.4f, c1, 0.55f * a)
        drawGlow(c, x, y, r * 1.9f, c2, 0.5f * a)
        val ca = (255 * a).toInt()
        corePaint.shader = RadialGradient(
            x - r * 0.3f, y - r * 0.35f, r * 1.25f,
            intArrayOf(withAlpha(Color.WHITE, ca), withAlpha(c1, ca), withAlpha(c2, ca)),
            floatArrayOf(0f, 0.55f, 1f), Shader.TileMode.CLAMP
        )
        c.drawCircle(x, y, r, corePaint)
        rimPaint.color = Color.WHITE
        rimPaint.alpha = (110 * a).toInt().coerceIn(0, 255)
        c.drawCircle(x, y, r, rimPaint)
        for (i in 0 until 9) {
            val ang = spin * 1.7f + i * 0.698f
            val rr = r * (1.55f + 0.3f * sin(spin * 2.3f + i))
            val sx = x + cos(ang) * rr
            val sy = y + sin(ang) * rr * 0.8f
            sparkPaint.color = if (i % 2 == 0) c1 else Color.WHITE
            sparkPaint.alpha = (210 * a * (0.5f + 0.5f * sin(spin * 3f + i))).toInt().coerceIn(0, 255)
            c.drawCircle(sx, sy, (1.4f + (i % 3) * 0.7f) * d, sparkPaint)
        }
    }

    private fun pushTrail(x: Float, y: Float, t: Long) {
        val i = trN % TRAIL
        trX[i] = x; trY[i] = y; trT[i] = t
        trN++
    }

    private fun drawTrail(c: Canvas, t: Long, color: Int, baseR: Float, maxAge: Float) {
        val n = min(trN, TRAIL)
        for (i in 0 until n) {
            val age = (t - trT[i]).toFloat()
            if (age < 0f || age > maxAge) continue
            val k = 1f - age / maxAge
            sparkPaint.color = color
            sparkPaint.alpha = (170 * k).toInt().coerceIn(0, 255)
            c.drawCircle(trX[i], trY[i], baseR * (0.2f + 0.55f * k), sparkPaint)
        }
    }

    private fun drawShock(c: Canvas, x: Float, y: Float, start: Long, t: Long, maxR: Float, color: Int) {
        if (start == 0L) return
        val u = (t - start).toFloat() / 950f
        if (u < 0f || u > 1f) return
        val r = maxR * easeOut(u)
        val a = (1f - u).pow(1.6f)
        ringPaint.color = color
        ringPaint.alpha = (230 * a).toInt().coerceIn(0, 255)
        ringPaint.strokeWidth = (1f + 4f * (1f - u)) * d
        c.drawCircle(x, y, r, ringPaint)
        ringPaint.strokeWidth = 3.5f * d
    }

    private fun drawBurst(c: Canvas, t: Long) {
        if (!burstOn) return
        val age = (t - burstAt).toFloat()
        if (age > burstLife) { burstOn = false; return }
        val u = age / burstLife
        val e = easeOut(u)
        for (i in 0 until BURST) {
            if (bsz[i] <= 0f) continue
            val px = bx[i] + bvx[i] * e
            val py = by[i] + bvy[i] * e + 38f * d * u * u
            sparkPaint.color = bcol[i]
            sparkPaint.alpha = (255 * (1f - u) * (1f - u * 0.4f)).toInt().coerceIn(0, 255)
            c.drawCircle(px, py, bsz[i] * (1f - 0.5f * u), sparkPaint)
        }
    }

    private fun badgeOf(i: Int): String = fileBadge(names.getOrNull(i) ?: "FILE")

    /** One photo (or a file tile when there is no picture), drawn as a glass card. */
    private fun drawCard(c: Canvas, idx: Int, cx: Float, cy: Float, w: Float, h: Float, corner: Float, a: Float, rot: Float) {
        if (a <= 0.01f || w < 2f || h < 2f) return
        c.save()
        c.translate(cx, cy)
        if (rot != 0f) c.rotate(rot)
        rect.set(-w / 2f, -h / 2f, w / 2f, h / 2f)
        val bmp = photos.getOrNull(idx)
        val sh = shaders.getOrNull(idx)
        if (bmp != null && sh != null) {
            mat.reset()
            val s = max(w / bmp.width, h / bmp.height)
            mat.setScale(s, s)
            mat.postTranslate(-w / 2f + (w - bmp.width * s) / 2f, -h / 2f + (h - bmp.height * s) / 2f)
            sh.setLocalMatrix(mat)
            photoPaint.shader = sh
            photoPaint.alpha = (255 * a).toInt().coerceIn(0, 255)
            c.drawRoundRect(rect, corner, corner, photoPaint)
        } else {
            fillPaint.shader = LinearGradient(
                -w / 2f, -h / 2f, w / 2f, h / 2f,
                withAlpha(VIOLET, (230 * a).toInt()), withAlpha(CYAN, (230 * a).toInt()), Shader.TileMode.CLAMP
            )
            c.drawRoundRect(rect, corner, corner, fillPaint)
            fillPaint.shader = null
            textBadge.textSize = min(w, h) * 0.22f
            textBadge.alpha = (255 * a).toInt().coerceIn(0, 255)
            c.drawText(badgeOf(idx), 0f, textBadge.textSize * 0.35f, textBadge)
        }
        strokePaint.color = Color.WHITE
        strokePaint.alpha = (150 * a).toInt().coerceIn(0, 255)
        c.drawRoundRect(rect, corner, corner, strokePaint)
        c.restore()
    }

    private fun drawCountBadge(c: Canvas, x: Float, y: Float, a: Float) {
        if (total <= 1 || a <= 0.01f) return
        val r = 13f * d
        fillPaint.shader = null
        fillPaint.color = withAlpha(PINK, (255 * a).toInt())
        c.drawCircle(x, y, r, fillPaint)
        textBadge.textSize = 12f * d
        textBadge.alpha = (255 * a).toInt().coerceIn(0, 255)
        c.drawText(if (total > 99) "99+" else total.toString(), x, y + 4.2f * d, textBadge)
    }

    private fun drawProgressArc(c: Canvas, x: Float, y: Float, r: Float, clock: Float, color: Int, a: Float) {
        arc.set(x - r, y - r, x + r, y + r)
        ringPaint.color = Color.WHITE
        ringPaint.alpha = (45 * a).toInt().coerceIn(0, 255)
        c.drawCircle(x, y, r, ringPaint)
        ringPaint.color = color
        ringPaint.alpha = (255 * a).toInt().coerceIn(0, 255)
        if (progress > 0.01f) c.drawArc(arc, -90f, 360f * progress, false, ringPaint)
        else c.drawArc(arc, (clock * 300f) % 360f, 110f, false, ringPaint)
    }

    private fun drawHoldArc(c: Canvas, x: Float, y: Float, r: Float, color: Int, a: Float) {
        if (hold <= 0.02f) return
        arc.set(x - r, y - r, x + r, y + r)
        ringPaint.color = color
        ringPaint.alpha = (255 * a).toInt().coerceIn(0, 255)
        c.drawArc(arc, -90f, 360f * hold, false, ringPaint)
    }

    private fun drawPill(c: Canvas, cx: Float, cy: Float, a: Float, accent: Int, bar: Float) {
        if (label.isEmpty() || a <= 0.01f) return
        val w1 = textMain.measureText(label)
        val w2 = if (sub.isEmpty()) 0f else textSub.measureText(sub)
        val w = max(w1, w2) + 46f * d
        val h = (if (sub.isEmpty()) 42f else 62f) * d
        rect.set(cx - w / 2f, cy - h / 2f, cx + w / 2f, cy + h / 2f)
        pillFill.alpha = (222 * a).toInt().coerceIn(0, 255)
        c.drawRoundRect(rect, h / 2f, h / 2f, pillFill)
        pillStroke.color = accent
        pillStroke.alpha = (150 * a).toInt().coerceIn(0, 255)
        c.drawRoundRect(rect, h / 2f, h / 2f, pillStroke)
        textMain.alpha = (255 * a).toInt().coerceIn(0, 255)
        if (sub.isEmpty()) {
            c.drawText(label, cx, cy + 5.2f * d, textMain)
        } else {
            c.drawText(label, cx, cy - 4f * d, textMain)
            textSub.alpha = (190 * a).toInt().coerceIn(0, 255)
            c.drawText(sub, cx, cy + 15f * d, textSub)
        }
        if (bar > 0.02f) {
            val left = cx - (w - h) / 2f
            barPaint.color = accent
            barPaint.alpha = (255 * a).toInt().coerceIn(0, 255)
            c.drawRoundRect(left, rect.bottom - 7f * d, left + (w - h) * bar, rect.bottom - 4f * d, 2f * d, 2f * d, barPaint)
        }
    }

    private fun followHand(dt: Long, tau: Float, W: Float, H: Float) {
        val tx = if (handSeen) hx * W else W / 2f
        val ty = if (handSeen) hy * H else H * 0.5f
        val a = 1f - exp(-dt / tau)
        ox += (tx - ox) * a
        oy += (ty - oy) * a
    }

    // =========================================================================================
    // The scenes
    // =========================================================================================

    override fun onDraw(c: Canvas) {
        super.onDraw(c)
        if (mode == M_NONE) return
        val t = now()
        val dt = (t - lastDraw).coerceIn(1L, 50L)
        lastDraw = t
        val W = width.toFloat()
        val H = height.toFloat()
        if (W < 10f || H < 10f) { postInvalidateOnAnimation(); return }
        if (!placed) { ox = W / 2f; oy = H * 0.2f; placed = true }
        val age = (t - modeSince).toFloat()
        val clock = t / 1000f
        val orbR = 30f * d

        if (backdrop > 0.01f) {
            bgPaint.color = withAlpha(INK, (255 * backdrop).toInt())
            c.drawRect(0f, 0f, W, H, bgPaint)
        }

        when (mode) {
            M_TAP_PAIR -> sceneTapPair(c, W, H, age, clock, t, orbR)
            M_TAP_SEND -> sceneTapChip(c, W, H, age, clock, dt, t, true)
            M_TAP_RECV -> sceneTapChip(c, W, H, age, clock, dt, t, false)
            M_SEND_ARMED, M_SEND_READY -> sceneSendCard(c, W, H, age, clock, mode == M_SEND_READY)
            M_CAPTURED -> sceneCaptured(c, W, H, age, clock, dt, t, orbR)
            M_SENDING -> sceneSending(c, W, H, age, clock, t, orbR)
            M_SENT -> sceneSent(c, W, H, age, clock, t, orbR)
            M_FAILED -> sceneFailed(c, W, H, age, clock, orbR)
            M_RECV_INCOMING -> sceneIncoming(c, W, H, age, clock, t, orbR)
            M_RECV_WAIT -> sceneWait(c, W, H, age, clock, t, orbR)
            M_RECV_CATCH -> sceneCatch(c, W, H, age, clock, dt, t, orbR)
            M_REVEAL -> sceneReveal(c, W, H, age, clock, t, orbR)
        }
        drawBurst(c, t)
        postInvalidateOnAnimation()
    }

    /** The photo slides down from the top like a card being dealt, then breathes while it waits for the palm. */
    private fun sceneSendCard(c: Canvas, W: Float, H: Float, age: Float, clock: Float, ready: Boolean) {
        val cw = W * 0.34f
        val ch = cw * 1.25f
        val enter = easeOutBack(age / 700f)
        val a = clamp01(age / 280f)
        val cx = W / 2f
        val cy = H * 0.2f + (1f - clamp01(age / 700f)) * (-H * 0.3f) + sin(clock * 1.6f) * 4f * d
        val sc = 0.55f + 0.45f * enter
        ox = cx; oy = cy
        val breath = 0.5f + 0.5f * sin(clock * (if (ready) 4.6f else 2.2f))
        drawAurora(c, W, 0.5f * a, clock)
        drawGlow(c, cx, cy, cw * (if (ready) 1.3f else 1.0f) * (0.9f + 0.2f * breath), if (ready) CYAN else VIOLET,
            (0.35f + 0.3f * breath) * a * (if (ready) 1f else 0.75f))
        if (photos.size > 1 || total > 1) {
            drawCard(c, if (photos.size > 1) 1 else 0, cx + 10f * d, cy + 6f * d, cw * sc * 0.96f, ch * sc * 0.96f, 22f * d, 0.7f * a, 6f)
        }
        drawCard(c, 0, cx, cy, cw * sc, ch * sc, 22f * d, a, 0f)
        drawCountBadge(c, cx + cw * sc / 2f - 4f * d, cy - ch * sc / 2f + 4f * d, a)
        if (ready) drawHoldArc(c, cx, cy, ch * 0.68f, CYAN, a)
        else drawHoldArc(c, cx, cy, ch * 0.68f, VIOLET, a)
        drawPill(c, cx, cy + ch * 0.5f * sc + 52f * d, clamp01((age - 250f) / 350f), if (ready) CYAN else VIOLET, 0f)
    }

    /** The card folds into a glowing orb and follows the hand around the screen. */
    private fun sceneCaptured(c: Canvas, W: Float, H: Float, age: Float, clock: Float, dt: Long, t: Long, orbR: Float) {
        followHand(dt, if (age < 520f) 170f else 85f, W, H)
        pushTrail(ox, oy, t)
        val m = easeInOut(age / 520f)
        val cw = W * 0.34f
        val ch = cw * 1.25f
        drawAurora(c, W, 0.35f, clock)
        drawTrail(c, t, VIOLET, orbR, 420f)
        if (m < 1f) {
            val w = lerp(cw, orbR * 2f, m)
            val h = lerp(ch, orbR * 2f, m)
            drawCard(c, 0, ox, oy, w, h, lerp(22f * d, w / 2f, m), 1f - m * 0.92f, 0f)
        }
        drawOrb(c, ox, oy, orbR * (0.6f + 0.4f * m), m, CYAN, VIOLET, clock)
        if (total > 1) drawCountBadge(c, ox + orbR * 0.9f, oy - orbR * 0.9f, m)
        drawPill(c, W / 2f, H * 0.9f, clamp01((age - 250f) / 350f), VIOLET, 0f)
    }

    /** Launch: the orb leaps away from the hand, a shockwave rolls out, then a ring shows the real progress. */
    private fun sceneSending(c: Canvas, W: Float, H: Float, age: Float, clock: Float, t: Long, orbR: Float) {
        val hoverX = W / 2f
        val hoverY = H * 0.15f
        val l = easeOut(age / 800f)
        ox = lerp(launchX, hoverX, l)
        oy = lerp(launchY, hoverY, l) + (if (l >= 1f) sin(clock * 2.4f) * 3f * d else 0f)
        pushTrail(ox, oy, t)
        drawAurora(c, W, 0.6f, clock)
        drawShock(c, launchX, launchY, shockAt, t, W * 0.55f, CYAN)
        drawTrail(c, t, CYAN, orbR * 1.1f, 520f)
        drawOrb(c, ox, oy, orbR * (1f + 0.18f * sin(clock * 5f)), 1f, CYAN, VIOLET, clock)
        drawProgressArc(c, ox, oy, orbR * 1.9f, clock, MINT, clamp01((age - 300f) / 300f))
        drawPill(c, W / 2f, H * 0.28f, clamp01((age - 300f) / 350f), CYAN, 0f)
    }

    /** Success: a mint ring, a check mark popping in, the orb rising away. */
    private fun sceneSent(c: Canvas, W: Float, H: Float, age: Float, clock: Float, t: Long, orbR: Float) {
        val hoverY = H * 0.15f
        val rise = easeIn(age / 1100f)
        ox = W / 2f
        oy = hoverY - rise * H * 0.28f
        drawAurora(c, W, 0.5f * (1f - clamp01(age / 1400f)), clock)
        drawShock(c, W / 2f, if (tapStyle) 0f else hoverY, shockAt, t, W * 0.5f, MINT)
        if (!tapStyle) {
            pushTrail(ox, oy, t)
            drawTrail(c, t, MINT, orbR, 480f)
            drawOrb(c, ox, oy, orbR * (1f - 0.5f * rise), 1f - rise, CYAN, VIOLET, clock)
        }
        // the check mark
        val pop = easeOutBack(age / 520f)
        val fade = 1f - clamp01((age - 1300f) / 500f)
        val cr = 30f * d * pop
        if (cr > 1f) {
            fillPaint.shader = null
            fillPaint.color = withAlpha(MINT, (255 * fade).toInt())
            c.drawCircle(W / 2f, H * 0.3f, cr, fillPaint)
            ringPaint.color = Color.parseColor("#0B1020")
            ringPaint.alpha = (255 * fade).toInt().coerceIn(0, 255)
            ringPaint.strokeWidth = 4f * d
            clip.reset()
            clip.moveTo(W / 2f - cr * 0.42f, H * 0.3f + cr * 0.02f)
            clip.lineTo(W / 2f - cr * 0.1f, H * 0.3f + cr * 0.34f)
            clip.lineTo(W / 2f + cr * 0.46f, H * 0.3f - cr * 0.3f)
            ringPaint.style = Paint.Style.STROKE
            c.drawPath(clip, ringPaint)
            ringPaint.strokeWidth = 3.5f * d
        }
        drawPill(c, W / 2f, H * 0.3f + 66f * d, clamp01((age - 200f) / 300f) * fade, MINT, 0f)
    }

    private fun sceneFailed(c: Canvas, W: Float, H: Float, age: Float, clock: Float, orbR: Float) {
        val a = 1f - clamp01(age / 1100f)
        val shake = sin(age / 28f) * 7f * d * (1f - clamp01(age / 700f))
        drawOrb(c, W / 2f + shake, H * 0.15f, orbR * (0.6f + 0.4f * a), a, RED, VIOLET, clock)
        drawPill(c, W / 2f, H * 0.28f, clamp01((age - 150f) / 300f), RED, 0f)
    }

    /** Receiver: an aurora washes over the top edge and the orb drops in with a soft bounce. */
    private fun sceneIncoming(c: Canvas, W: Float, H: Float, age: Float, clock: Float, t: Long, orbR: Float) {
        val e = easeOutBack(age / 950f)
        ox = W / 2f
        oy = lerp(-H * 0.08f, H * 0.15f, e)
        pushTrail(ox, oy, t)
        drawAurora(c, W, easeOut(age / 700f), clock)
        drawTrail(c, t, CYAN, orbR, 460f)
        drawOrb(c, ox, oy, orbR * (1f + 0.12f * sin(clock * 4.4f)), clamp01(age / 250f), CYAN, VIOLET, clock)
        drawProgressArc(c, ox, oy, orbR * 1.9f, clock, MINT, clamp01((age - 400f) / 300f))
        drawCountBadge(c, ox + orbR * 0.95f, oy - orbR * 0.95f, clamp01(age / 500f))
        drawPill(c, W / 2f, H * 0.28f, clamp01((age - 300f) / 350f), CYAN, 0f)
    }

    /** Receiver: the photo hangs in the air as a breathing orb until the fist-then-open gesture. */
    private fun sceneWait(c: Canvas, W: Float, H: Float, age: Float, clock: Float, t: Long, orbR: Float) {
        ox = W / 2f
        oy = H * 0.15f + sin(clock * 1.9f) * 7f * d
        val breath = 0.5f + 0.5f * sin(clock * 3.2f)
        drawAurora(c, W, 0.45f + 0.15f * breath, clock)
        drawOrb(c, ox, oy, orbR * (1f + 0.1f * breath), 1f, CYAN, VIOLET, clock)
        drawHoldArc(c, ox, oy, orbR * 1.9f, GOLD, 1f)
        drawCountBadge(c, ox + orbR * 0.95f, oy - orbR * 0.95f, 1f)
        drawPill(c, W / 2f, H * 0.28f, clamp01(age / 350f), GOLD, 0f)
    }

    /** Receiver: the orb flies into your fist and sticks to it. */
    private fun sceneCatch(c: Canvas, W: Float, H: Float, age: Float, clock: Float, dt: Long, t: Long, orbR: Float) {
        followHand(dt, 120f, W, H)
        pushTrail(ox, oy, t)
        drawAurora(c, W, 0.3f, clock)
        drawShock(c, ox, oy, shockAt, t, W * 0.3f, VIOLET)
        drawTrail(c, t, VIOLET, orbR, 460f)
        drawOrb(c, ox, oy, orbR * 0.85f, 1f, PINK, VIOLET, clock)
        drawHoldArc(c, ox, oy, orbR * 1.7f, GOLD, 1f)
        drawCountBadge(c, ox + orbR * 0.8f, oy - orbR * 0.8f, 1f)
        drawPill(c, W / 2f, H * 0.9f, clamp01(age / 300f), PINK, 0f)
    }

    /**
     * Touch: a flash and ripples roll down from the top edge where the phones meet, two orbs (this phone and
     * the other one) slide together and merge, a ring spins while linking and turns into a check when done.
     */
    private fun sceneTapPair(c: Canvas, W: Float, H: Float, age: Float, clock: Float, t: Long, orbR: Float) {
        val cx = W / 2f
        val flash = 1f - clamp01(age / 800f)
        drawGlow(c, cx, 0f, W * (0.45f + 0.55f * easeOut(age / 520f)), CYAN, 0.6f * flash + 0.1f)
        drawGlow(c, cx, 0f, W * 0.7f, VIOLET, 0.3f + 0.12f * sin(clock * 3.2f))
        drawAurora(c, W, 0.35f, clock)
        // ripples keep rolling down from the touch point while we are linking
        for (k in 0 until 3) {
            val local = age - k * 280f
            if (local < 0f) continue
            val u = (local % 1800f) / 1800f
            val r = W * 1.15f * easeOut(u)
            val a = (1f - u).pow(1.7f)
            ringPaint.color = if (k == 1) VIOLET else CYAN
            ringPaint.alpha = (200 * a * (if (pairOk) 0.4f else 1f)).toInt().coerceIn(0, 255)
            ringPaint.strokeWidth = (1.2f + 3f * (1f - u)) * d
            c.drawCircle(cx, 0f, r, ringPaint)
        }
        ringPaint.strokeWidth = 3.5f * d

        val cy = H * 0.4f
        val m = clamp01(easeOutBack(age / 850f))
        val sep = lerp(W * 0.3f, 0f, m)
        val r = orbR * (1f + 0.5f * m)
        drawOrb(c, cx - sep, cy, r, 1f, CYAN, VIOLET, clock)
        drawOrb(c, cx + sep, cy, r, 1f, PINK, VIOLET, clock + 1.3f)
        if (!pairOk) {
            drawProgressArc(c, cx, cy, r * 2.1f, clock, CYAN, clamp01((age - 500f) / 300f))
        } else {
            val pa = (SystemClock.uptimeMillis() - pairAt).toFloat()
            drawShock(c, cx, cy, shockAt, t, W * 0.6f, MINT)
            val pop = easeOutBack(pa / 480f)
            val cr = r * 1.05f * pop
            if (cr > 1f) {
                fillPaint.shader = null
                fillPaint.color = MINT
                c.drawCircle(cx, cy, cr, fillPaint)
                ringPaint.color = INK
                ringPaint.alpha = 255
                ringPaint.strokeWidth = 4f * d
                clip.reset()
                clip.moveTo(cx - cr * 0.42f, cy + cr * 0.02f)
                clip.lineTo(cx - cr * 0.1f, cy + cr * 0.34f)
                clip.lineTo(cx + cr * 0.46f, cy - cr * 0.3f)
                c.drawPath(clip, ringPaint)
                ringPaint.strokeWidth = 3.5f * d
            }
        }
        drawPill(c, cx, cy + r * 2.6f + 24f * d, clamp01((age - 350f) / 350f), if (pairOk) MINT else CYAN, 0f)
    }

    /**
     * The photo chip crossing from one phone to the other. At 50% the chip sits half off the top of the
     * sender and, at the same moment, half in from the top of the receiver, so with the phones touching
     * top to top it looks like one chip passing through the gap.
     */
    private fun sceneTapChip(c: Canvas, W: Float, H: Float, age: Float, clock: Float, dt: Long, t: Long, send: Boolean) {
        // glide the shown percentage toward the real one, so coarse updates still move smoothly
        dispP += (progress - dispP) * (1f - exp(-dt / 150f))
        if (progress >= 0.999f && dispP > 0.994f) dispP = 1f
        val p = clamp01(dispP)

        val bmp = photos.firstOrNull()
        val aspect = if (bmp != null) bmp.height.toFloat() / bmp.width else 1.15f
        chipW = W * 0.52f
        chipH = (chipW * aspect).coerceIn(chipW * 0.75f, chipW * 1.45f)
        val cx = W / 2f

        val topY = if (send) {
            // first the chip lifts to the touching edge, then it slides out as data leaves
            val dock = easeInOut(age / 700f)
            lerp(H * 0.32f, -p * chipH, dock)
        } else {
            -(1f - p) * chipH
        }
        val cy = topY + chipH / 2f
        ox = cx; oy = cy

        // the seam where the phones meet glows hardest while the chip straddles it
        val straddle = if (topY < 0f && topY + chipH > 0f) 1f else 0.35f
        val pulse = 0.5f + 0.5f * sin(clock * 5f)
        val seam = (0.3f + 0.55f * sin(p * 3.14159f)) * straddle + 0.12f * pulse
        drawGlow(c, cx, 0f, chipW * 1.25f, CYAN, seam)
        drawGlow(c, cx, 0f, chipW * 0.9f, VIOLET, seam * 0.7f)
        drawAurora(c, W, 0.35f + 0.25f * sin(p * 3.14159f), clock)

        // glow behind the chip and the chip itself
        drawGlow(c, cx, cy, chipW * 0.95f, if (send) CYAN else PINK, 0.3f)
        drawCard(c, 0, cx, cy, chipW, chipH, 26f * d, 1f, 0f)

        // light threads rushing through the visible part of the chip toward (or away from) the seam
        val bottom = max(0f, topY + chipH)
        if (bottom > 8f * d) {
            for (i in 0 until 14) {
                val ph = ((clock * 0.85f + i * 0.37f) % 1f)
                val hx = cx - chipW / 2f + chipW * (0.08f + 0.84f * (((i * 53) % 97) / 97f))
                val y = if (send) lerp(bottom, 0f, ph) else lerp(0f, bottom, ph)
                sparkPaint.color = if (i % 3 == 0) Color.WHITE else CYAN
                sparkPaint.alpha = (230 * sin(ph * 3.14159f)).toInt().coerceIn(0, 255)
                c.drawCircle(hx, y, (1.4f + (i % 3) * 0.8f) * d, sparkPaint)
            }
        }

        // the percentage, under whatever part of the chip is on this screen
        val labelY = bottom + 62f * d
        val a = clamp01(age / 350f)
        textPct.alpha = (255 * a).toInt().coerceIn(0, 255)
        textSub.alpha = (200 * a).toInt().coerceIn(0, 255)
        val head = if (!send && p < 0.02f) "Incoming" else (p * 100).toInt().toString() + "%"
        c.drawText(head, cx, labelY, textPct)
        val first = names.firstOrNull() ?: ""
        val line = if (total > 1) "$total files" + (if (first.isEmpty()) "" else "  ·  $first") else first
        if (line.isNotEmpty()) c.drawText(if (line.length > 34) line.take(33) + "…" else line, cx, labelY + 24f * d, textSub)
        val verb = if (send) "Sending" else "Receiving"
        if (p < 1f) {
            textSub.alpha = (150 * a).toInt().coerceIn(0, 255)
            c.drawText(verb, cx, labelY - 44f * d, textSub)
        }
    }

    /** Release: the orb detonates into light and the photo blooms out of it, with a shine across the glass. */
    private fun sceneReveal(c: Canvas, W: Float, H: Float, age: Float, clock: Float, t: Long, orbR: Float) {
        val outFade = 1f - clamp01((age - (REVEAL_MS - 650f)) / 650f)
        val scrim = 0.62f * easeOut(age / 500f) * outFade
        scrimPaint.alpha = (255 * scrim).toInt().coerceIn(0, 255)
        c.drawRect(0f, 0f, W, H, scrimPaint)

        val bmp = photos.firstOrNull()
        val aspect = if (bmp != null) bmp.height.toFloat() / bmp.width else 1.25f
        val cw = W * 0.78f
        val chh = (cw * aspect).coerceIn(cw * 0.62f, H * 0.62f)
        val cx = W / 2f
        val cy = H * 0.46f

        drawShock(c, launchX, launchY, shockAt, t, W * 0.8f, CYAN)
        drawShock(c, cx, cy, shock2At, t, W * 0.9f, PINK)

        val grow = easeOutBack(age / 780f)
        val move = easeOut(age / 780f)
        val px = lerp(launchX, cx, move)
        val py = lerp(launchY, cy, move)
        val startW = if (tapStyle && chipW > 0f) chipW else orbR * 2f
        val startH = if (tapStyle && chipH > 0f) chipH else orbR * 2f
        val wNow = lerp(startW, cw, grow.coerceAtLeast(0f))
        val hNow = lerp(startH, chh, grow.coerceAtLeast(0f))
        val corner = if (tapStyle) lerp(26f * d, 28f * d, clamp01(age / 600f)) else lerp(orbR, 28f * d, clamp01(age / 600f))
        val sc = 1f - 0.04f * (1f - outFade)

        // the orb fades as the photo takes over
        if (!tapStyle) drawOrb(c, px, py, orbR * (1f - 0.6f * clamp01(age / 300f)), 1f - clamp01(age / 320f), CYAN, PINK, clock)
        drawGlow(c, px, py, max(wNow, hNow) * 0.95f, CYAN, 0.38f * clamp01(age / 400f) * outFade)
        drawGlow(c, px, py, max(wNow, hNow) * 0.7f, PINK, 0.2f * clamp01(age / 500f) * outFade)

        // back cards of a fan when several photos arrived
        if (photos.size > 1 || total > 1) {
            val s2 = clamp01((age - 420f) / 420f)
            val e2 = easeOutBack(s2)
            if (photos.size > 2 || total > 2) {
                drawCard(c, if (photos.size > 2) 2 else 1, px + 16f * d * e2, py + 8f * d * e2, wNow * 0.94f * sc, hNow * 0.94f * sc, corner, 0.85f * s2 * outFade, 9f * e2)
            }
            drawCard(c, 1.coerceAtMost(max(0, photos.size - 1)), px - 14f * d * e2, py + 4f * d * e2, wNow * 0.96f * sc, hNow * 0.96f * sc, corner, 0.9f * s2 * outFade, -7f * e2)
        }
        drawCard(c, 0, px, py, wNow * sc, hNow * sc, corner, clamp01((age - 120f) / 350f) * outFade, 0f)

        // the shine sweep, clipped to the card
        val sweep = (age - 760f) / 800f
        if (sweep in 0f..1f && wNow > 10f) {
            val half = wNow * sc / 2f
            val halfH = hNow * sc / 2f
            clip.reset()
            rect.set(px - half, py - halfH, px + half, py + halfH)
            clip.addRoundRect(rect, corner, corner, Path.Direction.CW)
            c.save()
            c.clipPath(clip)
            val bandX = lerp(px - half - wNow * 0.5f, px + half + wNow * 0.5f, easeInOut(sweep))
            fillPaint.shader = LinearGradient(
                bandX - wNow * 0.18f, py - halfH, bandX + wNow * 0.18f, py + halfH,
                intArrayOf(withAlpha(Color.WHITE, 0), withAlpha(Color.WHITE, (95 * outFade).toInt()), withAlpha(Color.WHITE, 0)),
                floatArrayOf(0f, 0.5f, 1f), Shader.TileMode.CLAMP
            )
            c.drawRect(rect, fillPaint)
            fillPaint.shader = null
            c.restore()
        }
        drawCountBadge(c, px + wNow * sc / 2f - 6f * d, py - hNow * sc / 2f + 6f * d, clamp01((age - 500f) / 300f) * outFade)
        drawPill(c, W / 2f, min(H * 0.88f, py + hNow / 2f + 62f * d), clamp01((age - 700f) / 400f) * outFade, MINT, 0f)
    }
}
