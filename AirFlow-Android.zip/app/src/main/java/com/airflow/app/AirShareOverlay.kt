package com.airflow.app

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapShader
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.os.SystemClock
import android.view.MotionEvent
import android.view.View
import kotlin.math.abs
import java.util.Random
import kotlin.math.cos
import kotlin.math.exp
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.sin

/**
 * The full-screen, touch-through stage for Air Share. It floats above every app (gallery, WhatsApp...)
 * and draws the whole story: the photo lifting out of the share sheet, the palm and fist prompts, the
 * photo turning into a glowing orb in your hand, the launch, the orb dropping in on the other phone and
 * finally the release where the orb blooms back into the photo.
 *
 * Everything is time-driven on the display refresh, so it stays smooth whatever the camera frame rate is.
 */
class AirShareOverlay(ctx: Context) : View(ctx) {

    companion object {
        const val M_NONE = 0
        const val M_SEND_ARMED = 1
        const val M_SEND_READY = 2
        const val M_CAPTURED = 3
        const val M_SENDING = 4
        const val M_SENT = 5
        const val M_FAILED = 6
        const val M_RECV_INCOMING = 7
        const val M_RECV_WAIT = 8
        const val M_RECV_CATCH = 9
        const val M_REVEAL = 10
        /** Two phones touched: ripples from the top edge, two orbs merging into one link. */
        const val M_TAP_PAIR = 11
        /** This phone is sending: the photo chip slides out through the top edge as the percentage grows. */
        const val M_TAP_SEND = 12
        /** This phone is receiving: the matching chip slides in through the top edge. */
        const val M_TAP_RECV = 13
        /** Samsung style, sending: drag the photo by hand off the top edge toward the other phone. */
        const val M_DRAG_SEND = 14
        /** Samsung style, receiving: the part that left the other phone shows here; pull it down to take it. */
        const val M_DRAG_RECV = 15

        private const val DP_WAIT = 0
        private const val DP_COMMIT = 1
        private const val DP_TRANSFER = 2
        private const val DP_BACK = 3
        private const val AMB = 64
        private const val ST = 160

        const val REVEAL_MS = 4600f

        private val CYAN = Color.parseColor("#22D3EE")
        private val VIOLET = Color.parseColor("#8B5CFF")
        private val PINK = Color.parseColor("#FF4FD8")
        private val GOLD = Color.parseColor("#FFD27A")
        private val MINT = Color.parseColor("#34F5A5")
        private val RED = Color.parseColor("#FF5A6E")
        private val INK = Color.parseColor("#0B1020")
        private const val TRAIL = 26
        private const val BURST = 60
    }

    private val d = resources.displayMetrics.density

    // ---- what the hub tells us ------------------------------------------------------------
    private var mode = M_NONE
    private var modeSince = 0L
    private var photos: List<Bitmap> = emptyList()
    private var shaders: List<BitmapShader> = emptyList()
    private var names: List<String> = emptyList()
    private var total = 0
    private var progress = 0f
    private var hold = 0f
    private var label = ""
    private var sub = ""
    private var hx = 0.5f
    private var hy = 0.55f
    private var handSeen = false

    /** True for the touch (Tap Share) flows: no orb, the photo chip itself travels. */
    var tapStyle = false

    /** 0 = transparent (over other apps), up to 1 = solid dark backdrop (inside the app). */
    var backdrop = 0f

    // ---- Samsung-style drag: the host wires these up ----------------------------------------
    /** Called while a finger moves the chip: [crossed] is how much of it has left this screen (0..1, above 1 = pulled in). */
    var onDragLocal: ((crossed: Float, fling: Boolean) -> Unit)? = null
    /** Called when the finger lifts: [commit] true = send it for real. */
    var onReleaseLocal: ((commit: Boolean, fling: Boolean) -> Unit)? = null
    /** The overlay needs touches only while a chip can be dragged. */
    var onTouchableChange: ((Boolean) -> Unit)? = null
    /** Asks the host to blur what is behind this window (radius in px, 0 = none). */
    var onBlurChange: ((Int) -> Unit)? = null

    private var dragSend = true
    private var dPhase = DP_WAIT
    private var dAt = 0L
    private var dFling = false
    private var touching = false
    private var touchable = false
    private var grabDy = 0f
    private var vel = 0f
    private var lastMoveY = 0f
    private var lastMoveT = 0L
    private var topS = Float.NaN      // sender: top of the chip
    private var cR = 0f               // receiver: crossed fraction on screen
    private var pullPx = 0f           // receiver: pulled below the docking point
    private var remoteC = 0f
    private var lastRemoteAt = 0L
    private var lastEndToken = -1
    private var sentAt = 0L
    private var commitFromTop = 0f
    private var chipTopNow = 0f
    private var restTopPx = 0f
    private var tilt = 0f
    private var blur = 0f
    private var lastBlurPx = -1

    private val ax = FloatArray(AMB)
    private val ay = FloatArray(AMB)
    private val avy = FloatArray(AMB)
    private val asz = FloatArray(AMB)
    private val aph = FloatArray(AMB)
    private var ambInit = false

    private val sx = FloatArray(ST)
    private val sy = FloatArray(ST)
    private val svx = FloatArray(ST)
    private val svy = FloatArray(ST)
    private val sage = FloatArray(ST)
    private val slife = FloatArray(ST)
    private val ssz = FloatArray(ST)
    private val scol = IntArray(ST)
    private val son = BooleanArray(ST)
    private var stNext = 0

    private var pairOk = false
    private var pairAt = 0L
    private var chipW = 0f
    private var chipH = 0f
    private var dispP = 0f

    // ---- internal animation state ---------------------------------------------------------
    private var ox = 0f
    private var oy = 0f
    private var placed = false
    private var launchX = 0f
    private var launchY = 0f
    private var lastDraw = 0L
    private var shockAt = 0L
    private var shock2At = 0L
    private var shockColor = CYAN

    private val trX = FloatArray(TRAIL)
    private val trY = FloatArray(TRAIL)
    private val trT = LongArray(TRAIL)
    private var trN = 0

    private val bx = FloatArray(BURST)
    private val by = FloatArray(BURST)
    private val bvx = FloatArray(BURST)
    private val bvy = FloatArray(BURST)
    private val bsz = FloatArray(BURST)
    private val bcol = IntArray(BURST)
    private var burstAt = 0L
    private var burstLife = 1000f
    private var burstOn = false

    // ---- paints (allocated once) ----------------------------------------------------------
    private val addMode = PorterDuffXfermode(PorterDuff.Mode.ADD)
    private val glowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { xfermode = addMode }
    private val sparkPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { xfermode = addMode; style = Paint.Style.FILL }
    private val corePaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rimPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 1.5f * d }
    private val ringPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeWidth = 3.5f * d; strokeCap = Paint.Cap.ROUND
    }
    private val photoPaint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    private val fillPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val strokePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 1.5f * d }
    private val pillFill = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = INK; style = Paint.Style.FILL }
    private val pillStroke = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 1.2f * d }
    private val barPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val scrimPaint = Paint().apply { color = Color.BLACK }
    private val bgPaint = Paint().apply { style = Paint.Style.FILL }
    private val streakPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        xfermode = addMode; style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND
    }
    private val textPct = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE; textSize = 42f * d; typeface = Typeface.DEFAULT_BOLD; textAlign = Paint.Align.CENTER
    }
    private val textMain = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE; textSize = 15f * d; typeface = Typeface.DEFAULT_BOLD; textAlign = Paint.Align.CENTER
    }
    private val textSub = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE; textSize = 12f * d; textAlign = Paint.Align.CENTER
    }
    private val textBadge = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE; textSize = 12f * d; typeface = Typeface.DEFAULT_BOLD; textAlign = Paint.Align.CENTER
    }
    private val rect = RectF()
    private val arc = RectF()
    private val mat = Matrix()
    private val clip = Path()
    private val rnd = Random(7)

    // =========================================================================================
    // Hub-facing API
    // =========================================================================================

    fun setMode(m: Int) {
        if (m == mode) { postInvalidateOnAnimation(); return }
        mode = m
        modeSince = SystemClock.uptimeMillis()
        onEnter(m)
        val need = m == M_DRAG_SEND || m == M_DRAG_RECV
        if (need != touchable) {
            touchable = need
            if (!need) touching = false
            onTouchableChange?.invoke(need)
        }
        postInvalidateOnAnimation()
    }

    fun currentMode(): Int = mode

    fun photosSame(list: List<Bitmap>): Boolean {
        val l = list.take(3)
        if (l.size != photos.size) return false
        for (i in l.indices) if (l[i] !== photos[i]) return false
        return true
    }

    fun setPhotos(list: List<Bitmap>, fileNames: List<String>, count: Int) {
        photos = list.take(3)
        shaders = photos.map { BitmapShader(it, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP) }
        names = fileNames
        total = count
        postInvalidateOnAnimation()
    }

    fun setInfo(l: String, s: String) { label = l; sub = s }

    /** Starts the Samsung-style scene. [send] = this phone owns the photo and its owner drags it away. */
    fun dragStart(send: Boolean, thumb: Bitmap?, fileNames: List<String>, count: Int) {
        tapStyle = true
        dragSend = send
        dPhase = DP_WAIT
        dAt = SystemClock.uptimeMillis()
        touching = false
        remoteC = 0f
        cR = 0f
        pullPx = 0f
        topS = Float.NaN
        vel = 0f
        tilt = 0f
        setPhotos(if (thumb != null) listOf(thumb) else emptyList(), fileNames, count)
        progress = 0f
        dispP = 0f
        mode = M_NONE
        setMode(if (send) M_DRAG_SEND else M_DRAG_RECV)
    }

    /** The other phone moved the chip: [c] is how much of it has crossed (0..1). */
    fun setRemoteC(c: Float) {
        remoteC = c.coerceIn(0f, 1.3f)
        lastRemoteAt = SystemClock.uptimeMillis()
        if (dPhase == DP_BACK && remoteC > 0.02f) dPhase = DP_WAIT
    }

    /** Ignore the "let go" event with this token: it happened before this scene started. */
    fun markEndSeen(token: Int) { lastEndToken = token }

    /** The other phone let go. [token] makes the same event apply only once. */
    fun remoteEnd(token: Int, commit: Boolean, fling: Boolean) {
        if (token == lastEndToken) return
        lastEndToken = token
        if (commit) beginCommit(fling) else beginBack()
    }

    private fun beginCommit(fling: Boolean) {
        if (dPhase == DP_COMMIT || dPhase == DP_TRANSFER) return
        dPhase = DP_COMMIT
        dAt = SystemClock.uptimeMillis()
        dFling = fling
        touching = false
        commitFromTop = chipTopNow
        spawnBurst(width / 2f, if (dragSend) max(0f, chipTopNow) else max(0f, chipTopNow + chipH * 0.5f), 52, 250f, 1300f)
        shockAt = dAt; shockColor = if (dragSend) CYAN else PINK
    }

    private fun beginBack() {
        if (dPhase == DP_COMMIT || dPhase == DP_TRANSFER) return
        dPhase = DP_BACK
        dAt = SystemClock.uptimeMillis()
        remoteC = 0f
        touching = false
    }

    private fun reportDrag(c: Float, fling: Boolean) {
        val t = SystemClock.uptimeMillis()
        if (fling || t - sentAt >= 30L) {
            sentAt = t
            onDragLocal?.invoke(c, fling)
        }
    }

    private fun chipDims(W: Float, H: Float) {
        val bmp = photos.firstOrNull()
        val aspect = if (bmp != null) bmp.height.toFloat() / bmp.width else 1.15f
        chipW = W * 0.56f
        chipH = (chipW * aspect).coerceIn(chipW * 0.75f, chipW * 1.4f)
        restTopPx = H * 0.4f - chipH / 2f
        if (topS.isNaN()) topS = restTopPx
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (mode != M_DRAG_SEND && mode != M_DRAG_RECV) return false
        if (dPhase == DP_COMMIT || dPhase == DP_TRANSFER) return true
        val W = width.toFloat()
        val H = height.toFloat()
        if (W < 10f) return true
        chipDims(W, H)
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                val m = 40f * d
                val cx = W / 2f
                val top = chipTopNow
                val visible = dragSend || cR > 0.04f
                val hit = visible && e.x >= cx - chipW / 2f - m && e.x <= cx + chipW / 2f + m &&
                    e.y >= top - m && e.y <= top + chipH + m
                if (!hit) return true
                touching = true
                if (dPhase == DP_BACK) dPhase = DP_WAIT
                grabDy = e.y - top
                vel = 0f
                lastMoveY = e.y
                lastMoveT = e.eventTime
                parent?.requestDisallowInterceptTouchEvent(true)
            }
            MotionEvent.ACTION_MOVE -> {
                if (!touching) return true
                val dtm = (e.eventTime - lastMoveT).coerceAtLeast(1L)
                vel = vel * 0.55f + ((e.y - lastMoveY) / dtm * 1000f) * 0.45f
                lastMoveY = e.y
                lastMoveT = e.eventTime
                val desired = e.y - grabDy
                if (dragSend) {
                    topS = desired.coerceIn(-chipH, restTopPx + 70f * d)
                    reportDrag(clamp01(-topS / chipH), false)
                } else {
                    val dd = desired.coerceIn(-chipH, H * 0.3f)
                    cR = clamp01(1f + min(dd, 0f) / chipH)
                    pullPx = max(dd, 0f)
                    reportDrag(cR + clamp01(pullPx / (chipH * 0.6f)) * 0.25f, false)
                }
                tilt = (vel * 0.004f).coerceIn(-7f, 7f)
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                if (!touching) return true
                touching = false
                val cancelled = e.actionMasked == MotionEvent.ACTION_CANCEL
                val flingV = 900f * d
                val commit: Boolean
                val fling: Boolean
                if (dragSend) {
                    val c = clamp01(-topS / chipH)
                    val lifted = topS < restTopPx - 24f * d
                    fling = vel < -flingV && lifted
                    commit = !cancelled && (c >= 0.5f || fling)
                } else {
                    val cc = cR + clamp01(pullPx / (chipH * 0.6f)) * 0.25f
                    fling = vel > flingV
                    commit = !cancelled && (cc >= 0.55f || (fling && cR > 0.08f))
                }
                if (commit) {
                    beginCommit(fling)
                    onReleaseLocal?.invoke(true, fling)
                } else {
                    beginBack()
                    onReleaseLocal?.invoke(false, false)
                }
            }
        }
        return true
    }

    /** The phones just touched. Call [tapPaired] when the link is up. */
    fun tapPair() {
        pairOk = false
        tapStyle = true
        progress = 0f
        mode = M_NONE // force a fresh start of the scene even if it was already showing
        setMode(M_TAP_PAIR)
    }

    fun tapPaired() {
        if (!pairOk) { pairOk = true; pairAt = SystemClock.uptimeMillis(); shockAt = pairAt; shockColor = MINT }
        postInvalidateOnAnimation()
    }

    /** The chip scenes: [send] true = leaving through the top edge, false = arriving through it. */
    fun tapTransfer(send: Boolean, thumb: Bitmap?, fileNames: List<String>, count: Int) {
        tapStyle = true
        setPhotos(if (thumb != null) listOf(thumb) else emptyList(), fileNames, count)
        dispP = 0f
        progress = 0f
        setMode(if (send) M_TAP_SEND else M_TAP_RECV)
    }
    fun setProgress(p: Float) { progress = p.coerceIn(0f, 1f) }
    fun setHold(h: Float) { hold = h.coerceIn(0f, 1f) }
    fun setHand(x: Float, y: Float, seen: Boolean) {
        if (seen) { hx = x; hy = y }
        handSeen = seen
    }

    // =========================================================================================
    // Easing and small helpers
    // =========================================================================================

    private fun now() = SystemClock.uptimeMillis()
    private fun clamp01(x: Float) = if (x < 0f) 0f else if (x > 1f) 1f else x
    private fun lerp(a: Float, b: Float, t: Float) = a + (b - a) * t
    private fun easeOut(t: Float): Float { val u = 1f - clamp01(t); return 1f - u * u * u }
    private fun easeIn(t: Float): Float { val x = clamp01(t); return x * x * x }
    private fun easeInOut(t: Float): Float {
        val x = clamp01(t)
        return if (x < 0.5f) 4f * x * x * x else 1f - (-2f * x + 2f).pow(3) / 2f
    }
    private fun easeOutBack(t: Float): Float {
        val x = clamp01(t)
        val c1 = 1.70158f
        val c3 = c1 + 1f
        return 1f + c3 * (x - 1f).pow(3) + c1 * (x - 1f).pow(2)
    }
    private fun withAlpha(color: Int, a: Int): Int = (a.coerceIn(0, 255) shl 24) or (color and 0xFFFFFF)

    private fun onEnter(m: Int) {
        val t = now()
        when (m) {
            M_SEND_ARMED, M_SEND_READY -> { trN = 0; burstOn = false; if (m == M_SEND_ARMED) placed = false }
            M_SENDING -> {
                launchX = ox; launchY = oy
                shockAt = t; shockColor = CYAN
                spawnBurst(ox, oy, 34, 150f, 900f)
            }
            M_SENT -> {
                shockAt = t; shockColor = MINT
                spawnBurst(width / 2f, height * 0.15f, 54, 190f, 1100f)
            }
            M_FAILED -> { shockAt = 0L }
            M_RECV_INCOMING -> { trN = 0; burstOn = false; placed = false; shockAt = 0L }
            M_RECV_CATCH -> { shockAt = t; shockColor = VIOLET }
            M_TAP_PAIR -> { trN = 0; burstOn = false; shockAt = t; shockColor = CYAN; placed = false }
            M_TAP_SEND, M_TAP_RECV -> { burstOn = false; dispP = 0f }
            M_REVEAL -> {
                launchX = ox; launchY = oy
                shockAt = t; shock2At = t + 420L; shockColor = CYAN
                spawnBurst(ox, oy, 56, 230f, 1300f)
            }
        }
    }

    private fun spawnBurst(x: Float, y: Float, n: Int, speedDp: Float, lifeMs: Float) {
        val cols = intArrayOf(CYAN, VIOLET, PINK, GOLD, Color.WHITE)
        val count = min(n, BURST)
        for (i in 0 until BURST) {
            if (i >= count) { bsz[i] = 0f; continue }
            val a = rnd.nextFloat() * 6.2832f
            val sp = (0.35f + 0.65f * rnd.nextFloat()) * speedDp * d
            bx[i] = x; by[i] = y
            bvx[i] = cos(a) * sp; bvy[i] = sin(a) * sp
            bsz[i] = (1.4f + 2.6f * rnd.nextFloat()) * d
            bcol[i] = cols[rnd.nextInt(cols.size)]
        }
        burstAt = now()
        burstLife = lifeMs
        burstOn = true
    }

    // =========================================================================================
    // Drawing blocks
    // =========================================================================================

    private fun drawGlow(c: Canvas, x: Float, y: Float, r: Float, color: Int, a: Float) {
        if (a <= 0.01f || r <= 1f) return
        val ca = (255 * a).toInt()
        glowPaint.shader = RadialGradient(
            x, y, r,
            intArrayOf(withAlpha(color, ca), withAlpha(color, ca / 3), withAlpha(color, 0)),
            floatArrayOf(0f, 0.45f, 1f), Shader.TileMode.CLAMP
        )
        c.drawCircle(x, y, r, glowPaint)
    }

    private fun drawAurora(c: Canvas, w: Float, strength: Float, clock: Float) {
        if (strength <= 0.01f) return
        val x1 = w * (0.5f + 0.32f * sin(clock * 0.9f))
        val x2 = w * (0.5f + 0.32f * sin(clock * 0.7f + 2.1f))
        val r = w * 0.75f
        drawGlow(c, x1, -r * 0.25f, r, CYAN, 0.42f * strength)
        drawGlow(c, x2, -r * 0.25f, r, VIOLET, 0.4f * strength)
        drawGlow(c, w * 0.5f, -r * 0.35f, r * 0.8f, PINK, 0.18f * strength)
    }

    private fun drawOrb(c: Canvas, x: Float, y: Float, r: Float, a: Float, c1: Int, c2: Int, spin: Float) {
        if (a <= 0.01f || r <= 1f) return
        drawGlow(c, x, y, r * 3.4f, c1, 0.55f * a)
        drawGlow(c, x, y, r * 1.9f, c2, 0.5f * a)
        val ca = (255 * a).toInt()
        corePaint.shader = RadialGradient(
            x - r * 0.3f, y - r * 0.35f, r * 1.25f,
            intArrayOf(withAlpha(Color.WHITE, ca), withAlpha(c1, ca), withAlpha(c2, ca)),
            floatArrayOf(0f, 0.55f, 1f), Shader.TileMode.CLAMP
        )
        c.drawCircle(x, y, r, corePaint)
        rimPaint.color = Color.WHITE
        rimPaint.alpha = (110 * a).toInt().coerceIn(0, 255)
        c.drawCircle(x, y, r, rimPaint)
        for (i in 0 until 9) {
            val ang = spin * 1.7f + i * 0.698f
            val rr = r * (1.55f + 0.3f * sin(spin * 2.3f + i))
            val sx = x + cos(ang) * rr
            val sy = y + sin(ang) * rr * 0.8f
            sparkPaint.color = if (i % 2 == 0) c1 else Color.WHITE
            sparkPaint.alpha = (210 * a * (0.5f + 0.5f * sin(spin * 3f + i))).toInt().coerceIn(0, 255)
            c.drawCircle(sx, sy, (1.4f + (i % 3) * 0.7f) * d, sparkPaint)
        }
    }

    private fun pushTrail(x: Float, y: Float, t: Long) {
        val i = trN % TRAIL
        trX[i] = x; trY[i] = y; trT[i] = t
        trN++
    }

    private fun drawTrail(c: Canvas, t: Long, color: Int, baseR: Float, maxAge: Float) {
        val n = min(trN, TRAIL)
        for (i in 0 until n) {
            val age = (t - trT[i]).toFloat()
            if (age < 0f || age > maxAge) continue
            val k = 1f - age / maxAge
            sparkPaint.color = color
            sparkPaint.alpha = (170 * k).toInt().coerceIn(0, 255)
            c.drawCircle(trX[i], trY[i], baseR * (0.2f + 0.55f * k), sparkPaint)
        }
    }

    private fun drawShock(c: Canvas, x: Float, y: Float, start: Long, t: Long, maxR: Float, color: Int) {
        if (start == 0L) return
        val u = (t - start).toFloat() / 950f
        if (u < 0f || u > 1f) return
        val r = maxR * easeOut(u)
        val a = (1f - u).pow(1.6f)
        ringPaint.color = color
        ringPaint.alpha = (230 * a).toInt().coerceIn(0, 255)
        ringPaint.strokeWidth = (1f + 4f * (1f - u)) * d
        c.drawCircle(x, y, r, ringPaint)
        ringPaint.strokeWidth = 3.5f * d
    }

    private fun drawBurst(c: Canvas, t: Long) {
        if (!burstOn) return
        val age = (t - burstAt).toFloat()
        if (age > burstLife) { burstOn = false; return }
        val u = age / burstLife
        val e = easeOut(u)
        for (i in 0 until BURST) {
            if (bsz[i] <= 0f) continue
            val px = bx[i] + bvx[i] * e
            val py = by[i] + bvy[i] * e + 38f * d * u * u
            sparkPaint.color = bcol[i]
            sparkPaint.alpha = (255 * (1f - u) * (1f - u * 0.4f)).toInt().coerceIn(0, 255)
            c.drawCircle(px, py, bsz[i] * (1f - 0.5f * u), sparkPaint)
        }
    }

    private fun badgeOf(i: Int): String = fileBadge(names.getOrNull(i) ?: "FILE")

    /** One photo (or a file tile when there is no picture), drawn as a glass card. */
    private fun drawCard(c: Canvas, idx: Int, cx: Float, cy: Float, w: Float, h: Float, corner: Float, a: Float, rot: Float) {
        if (a <= 0.01f || w < 2f || h < 2f) return
        c.save()
        c.translate(cx, cy)
        if (rot != 0f) c.rotate(rot)
        rect.set(-w / 2f, -h / 2f, w / 2f, h / 2f)
        val bmp = photos.getOrNull(idx)
        val sh = shaders.getOrNull(idx)
        if (bmp != null && sh != null) {
            mat.reset()
            val s = max(w / bmp.width, h / bmp.height)
            mat.setScale(s, s)
            mat.postTranslate(-w / 2f + (w - bmp.width * s) / 2f, -h / 2f + (h - bmp.height * s) / 2f)
            sh.setLocalMatrix(mat)
            photoPaint.shader = sh
            photoPaint.alpha = (255 * a).toInt().coerceIn(0, 255)
            c.drawRoundRect(rect, corner, corner, photoPaint)
        } else {
            fillPaint.shader = LinearGradient(
                -w / 2f, -h / 2f, w / 2f, h / 2f,
                withAlpha(VIOLET, (230 * a).toInt()), withAlpha(CYAN, (230 * a).toInt()), Shader.TileMode.CLAMP
            )
            c.drawRoundRect(rect, corner, corner, fillPaint)
            fillPaint.shader = null
            textBadge.textSize = min(w, h) * 0.22f
            textBadge.alpha = (255 * a).toInt().coerceIn(0, 255)
            c.drawText(badgeOf(idx), 0f, textBadge.textSize * 0.35f, textBadge)
        }
        strokePaint.color = Color.WHITE
        strokePaint.alpha = (150 * a).toInt().coerceIn(0, 255)
        c.drawRoundRect(rect, corner, corner, strokePaint)
        c.restore()
    }

    private fun drawCountBadge(c: Canvas, x: Float, y: Float, a: Float) {
        if (total <= 1 || a <= 0.01f) return
        val r = 13f * d
        fillPaint.shader = null
        fillPaint.color = withAlpha(PINK, (255 * a).toInt())
        c.drawCircle(x, y, r, fillPaint)
        textBadge.textSize = 12f * d
        textBadge.alpha = (255 * a).toInt().coerceIn(0, 255)
        c.drawText(if (total > 99) "99+" else total.toString(), x, y + 4.2f * d, textBadge)
    }

    private fun drawProgressArc(c: Canvas, x: Float, y: Float, r: Float, clock: Float, color: Int, a: Float) {
        arc.set(x - r, y - r, x + r, y + r)
        ringPaint.color = Color.WHITE
        ringPaint.alpha = (45 * a).toInt().coerceIn(0, 255)
        c.drawCircle(x, y, r, ringPaint)
        ringPaint.color = color
        ringPaint.alpha = (255 * a).toInt().coerceIn(0, 255)
        if (progress > 0.01f) c.drawArc(arc, -90f, 360f * progress, false, ringPaint)
        else c.drawArc(arc, (clock * 300f) % 360f, 110f, false, ringPaint)
    }

    private fun drawHoldArc(c: Canvas, x: Float, y: Float, r: Float, color: Int, a: Float) {
        if (hold <= 0.02f) return
        arc.set(x - r, y - r, x + r, y + r)
        ringPaint.color = color
        ringPaint.alpha = (255 * a).toInt().coerceIn(0, 255)
        c.drawArc(arc, -90f, 360f * hold, false, ringPaint)
    }

    private fun drawPill(c: Canvas, cx: Float, cy: Float, a: Float, accent: Int, bar: Float) {
        if (label.isEmpty() || a <= 0.01f) return
        val w1 = textMain.measureText(label)
        val w2 = if (sub.isEmpty()) 0f else textSub.measureText(sub)
        val w = max(w1, w2) + 46f * d
        val h = (if (sub.isEmpty()) 42f else 62f) * d
        rect.set(cx - w / 2f, cy - h / 2f, cx + w / 2f, cy + h / 2f)
        pillFill.alpha = (222 * a).toInt().coerceIn(0, 255)
        c.drawRoundRect(rect, h / 2f, h / 2f, pillFill)
        pillStroke.color = accent
        pillStroke.alpha = (150 * a).toInt().coerceIn(0, 255)
        c.drawRoundRect(rect, h / 2f, h / 2f, pillStroke)
        textMain.alpha = (255 * a).toInt().coerceIn(0, 255)
        if (sub.isEmpty()) {
            c.drawText(label, cx, cy + 5.2f * d, textMain)
        } else {
            c.drawText(label, cx, cy - 4f * d, textMain)
            textSub.alpha = (190 * a).toInt().coerceIn(0, 255)
            c.drawText(sub, cx, cy + 15f * d, textSub)
        }
        if (bar > 0.02f) {
            val left = cx - (w - h) / 2f
            barPaint.color = accent
            barPaint.alpha = (255 * a).toInt().coerceIn(0, 255)
            c.drawRoundRect(left, rect.bottom - 7f * d, left + (w - h) * bar, rect.bottom - 4f * d, 2f * d, 2f * d, barPaint)
        }
    }

    private fun followHand(dt: Long, tau: Float, W: Float, H: Float) {
        val tx = if (handSeen) hx * W else W / 2f
        val ty = if (handSeen) hy * H else H * 0.5f
        val a = 1f - exp(-dt / tau)
        ox += (tx - ox) * a
        oy += (ty - oy) * a
    }

    // =========================================================================================
    // The scenes
    // =========================================================================================

    override fun onDraw(c: Canvas) {
        super.onDraw(c)
        if (mode == M_NONE) return
        val t = now()
        val dt = (t - lastDraw).coerceIn(1L, 50L)
        lastDraw = t
        val W = width.toFloat()
        val H = height.toFloat()
        if (W < 10f || H < 10f) { postInvalidateOnAnimation(); return }
        if (!placed) { ox = W / 2f; oy = H * 0.2f; placed = true }
        val age = (t - modeSince).toFloat()
        val clock = t / 1000f
        val orbR = 30f * d

        if (backdrop > 0.01f) {
            bgPaint.color = withAlpha(INK, (255 * backdrop).toInt())
            c.drawRect(0f, 0f, W, H, bgPaint)
        }
        // leaving the drag scene: the frosted stage fades out instead of snapping off
        if (mode != M_DRAG_SEND && mode != M_DRAG_RECV && blur > 0.01f) {
            blur -= blur * (1f - exp(-dt / (if (mode == M_REVEAL) 900f else 350f)))
            if (blur < 0.01f) blur = 0f
            requestBlur((blur * 34f * d).toInt())
            drawBlurScene(c, W, H, clock, dt / 1000f, blur)
        }

        when (mode) {
            M_TAP_PAIR -> sceneTapPair(c, W, H, age, clock, t, orbR)
            M_TAP_SEND -> sceneTapChip(c, W, H, age, clock, dt, t, true)
            M_TAP_RECV -> sceneTapChip(c, W, H, age, clock, dt, t, false)
            M_DRAG_SEND, M_DRAG_RECV -> sceneDrag(c, W, H, age, clock, dt, t)
            M_SEND_ARMED, M_SEND_READY -> sceneSendCard(c, W, H, age, clock, mode == M_SEND_READY)
            M_CAPTURED -> sceneCaptured(c, W, H, age, clock, dt, t, orbR)
            M_SENDING -> sceneSending(c, W, H, age, clock, t, orbR)
            M_SENT -> sceneSent(c, W, H, age, clock, t, orbR)
            M_FAILED -> sceneFailed(c, W, H, age, clock, orbR)
            M_RECV_INCOMING -> sceneIncoming(c, W, H, age, clock, t, orbR)
            M_RECV_WAIT -> sceneWait(c, W, H, age, clock, t, orbR)
            M_RECV_CATCH -> sceneCatch(c, W, H, age, clock, dt, t, orbR)
            M_REVEAL -> sceneReveal(c, W, H, age, clock, t, orbR)
        }
        drawBurst(c, t)
        postInvalidateOnAnimation()
    }

    /** The photo slides down from the top like a card being dealt, then breathes while it waits for the palm. */
    private fun sceneSendCard(c: Canvas, W: Float, H: Float, age: Float, clock: Float, ready: Boolean) {
        val cw = W * 0.34f
        val ch = cw * 1.25f
        val enter = easeOutBack(age / 700f)
        val a = clamp01(age / 280f)
        val cx = W / 2f
        val cy = H * 0.2f + (1f - clamp01(age / 700f)) * (-H * 0.3f) + sin(clock * 1.6f) * 4f * d
        val sc = 0.55f + 0.45f * enter
        ox = cx; oy = cy
        val breath = 0.5f + 0.5f * sin(clock * (if (ready) 4.6f else 2.2f))
        drawAurora(c, W, 0.5f * a, clock)
        drawGlow(c, cx, cy, cw * (if (ready) 1.3f else 1.0f) * (0.9f + 0.2f * breath), if (ready) CYAN else VIOLET,
            (0.35f + 0.3f * breath) * a * (if (ready) 1f else 0.75f))
        if (photos.size > 1 || total > 1) {
            drawCard(c, if (photos.size > 1) 1 else 0, cx + 10f * d, cy + 6f * d, cw * sc * 0.96f, ch * sc * 0.96f, 22f * d, 0.7f * a, 6f)
        }
        drawCard(c, 0, cx, cy, cw * sc, ch * sc, 22f * d, a, 0f)
        drawCountBadge(c, cx + cw * sc / 2f - 4f * d, cy - ch * sc / 2f + 4f * d, a)
        if (ready) drawHoldArc(c, cx, cy, ch * 0.68f, CYAN, a)
        else drawHoldArc(c, cx, cy, ch * 0.68f, VIOLET, a)
        drawPill(c, cx, cy + ch * 0.5f * sc + 52f * d, clamp01((age - 250f) / 350f), if (ready) CYAN else VIOLET, 0f)
    }

    /** The card folds into a glowing orb and follows the hand around the screen. */
    private fun sceneCaptured(c: Canvas, W: Float, H: Float, age: Float, clock: Float, dt: Long, t: Long, orbR: Float) {
        followHand(dt, if (age < 520f) 170f else 85f, W, H)
        pushTrail(ox, oy, t)
        val m = easeInOut(age / 520f)
        val cw = W * 0.34f
        val ch = cw * 1.25f
        drawAurora(c, W, 0.35f, clock)
        drawTrail(c, t, VIOLET, orbR, 420f)
        if (m < 1f) {
            val w = lerp(cw, orbR * 2f, m)
            val h = lerp(ch, orbR * 2f, m)
            drawCard(c, 0, ox, oy, w, h, lerp(22f * d, w / 2f, m), 1f - m * 0.92f, 0f)
        }
        drawOrb(c, ox, oy, orbR * (0.6f + 0.4f * m), m, CYAN, VIOLET, clock)
        if (total > 1) drawCountBadge(c, ox + orbR * 0.9f, oy - orbR * 0.9f, m)
        drawPill(c, W / 2f, H * 0.9f, clamp01((age - 250f) / 350f), VIOLET, 0f)
    }

    /** Launch: the orb leaps away from the hand, a shockwave rolls out, then a ring shows the real progress. */
    private fun sceneSending(c: Canvas, W: Float, H: Float, age: Float, clock: Float, t: Long, orbR: Float) {
        val hoverX = W / 2f
        val hoverY = H * 0.15f
        val l = easeOut(age / 800f)
        ox = lerp(launchX, hoverX, l)
        oy = lerp(launchY, hoverY, l) + (if (l >= 1f) sin(clock * 2.4f) * 3f * d else 0f)
        pushTrail(ox, oy, t)
        drawAurora(c, W, 0.6f, clock)
        drawShock(c, launchX, launchY, shockAt, t, W * 0.55f, CYAN)
        drawTrail(c, t, CYAN, orbR * 1.1f, 520f)
        drawOrb(c, ox, oy, orbR * (1f + 0.18f * sin(clock * 5f)), 1f, CYAN, VIOLET, clock)
        drawProgressArc(c, ox, oy, orbR * 1.9f, clock, MINT, clamp01((age - 300f) / 300f))
        drawPill(c, W / 2f, H * 0.28f, clamp01((age - 300f) / 350f), CYAN, 0f)
    }

    /** Success: a mint ring, a check mark popping in, the orb rising away. */
    private fun sceneSent(c: Canvas, W: Float, H: Float, age: Float, clock: Float, t: Long, orbR: Float) {
        val hoverY = H * 0.15f
        val rise = easeIn(age / 1100f)
        ox = W / 2f
        oy = hoverY - rise * H * 0.28f
        drawAurora(c, W, 0.5f * (1f - clamp01(age / 1400f)), clock)
        drawShock(c, W / 2f, if (tapStyle) 0f else hoverY, shockAt, t, W * 0.5f, MINT)
        if (!tapStyle) {
            pushTrail(ox, oy, t)
            drawTrail(c, t, MINT, orbR, 480f)
            drawOrb(c, ox, oy, orbR * (1f - 0.5f * rise), 1f - rise, CYAN, VIOLET, clock)
        }
        // the check mark
        val pop = easeOutBack(age / 520f)
        val fade = 1f - clamp01((age - 1300f) / 500f)
        val cr = 30f * d * pop
        if (cr > 1f) {
            fillPaint.shader = null
            fillPaint.color = withAlpha(MINT, (255 * fade).toInt())
            c.drawCircle(W / 2f, H * 0.3f, cr, fillPaint)
            ringPaint.color = Color.parseColor("#0B1020")
            ringPaint.alpha = (255 * fade).toInt().coerceIn(0, 255)
            ringPaint.strokeWidth = 4f * d
            clip.reset()
            clip.moveTo(W / 2f - cr * 0.42f, H * 0.3f + cr * 0.02f)
            clip.lineTo(W / 2f - cr * 0.1f, H * 0.3f + cr * 0.34f)
            clip.lineTo(W / 2f + cr * 0.46f, H * 0.3f - cr * 0.3f)
            ringPaint.style = Paint.Style.STROKE
            c.drawPath(clip, ringPaint)
            ringPaint.strokeWidth = 3.5f * d
        }
        drawPill(c, W / 2f, H * 0.3f + 66f * d, clamp01((age - 200f) / 300f) * fade, MINT, 0f)
    }

    private fun sceneFailed(c: Canvas, W: Float, H: Float, age: Float, clock: Float, orbR: Float) {
        val a = 1f - clamp01(age / 1100f)
        val shake = sin(age / 28f) * 7f * d * (1f - clamp01(age / 700f))
        drawOrb(c, W / 2f + shake, H * 0.15f, orbR * (0.6f + 0.4f * a), a, RED, VIOLET, clock)
        drawPill(c, W / 2f, H * 0.28f, clamp01((age - 150f) / 300f), RED, 0f)
    }

    /** Receiver: an aurora washes over the top edge and the orb drops in with a soft bounce. */
    private fun sceneIncoming(c: Canvas, W: Float, H: Float, age: Float, clock: Float, t: Long, orbR: Float) {
        val e = easeOutBack(age / 950f)
        ox = W / 2f
        oy = lerp(-H * 0.08f, H * 0.15f, e)
        pushTrail(ox, oy, t)
        drawAurora(c, W, easeOut(age / 700f), clock)
        drawTrail(c, t, CYAN, orbR, 460f)
        drawOrb(c, ox, oy, orbR * (1f + 0.12f * sin(clock * 4.4f)), clamp01(age / 250f), CYAN, VIOLET, clock)
        drawProgressArc(c, ox, oy, orbR * 1.9f, clock, MINT, clamp01((age - 400f) / 300f))
        drawCountBadge(c, ox + orbR * 0.95f, oy - orbR * 0.95f, clamp01(age / 500f))
        drawPill(c, W / 2f, H * 0.28f, clamp01((age - 300f) / 350f), CYAN, 0f)
    }

    /** Receiver: the photo hangs in the air as a breathing orb until the fist-then-open gesture. */
    private fun sceneWait(c: Canvas, W: Float, H: Float, age: Float, clock: Float, t: Long, orbR: Float) {
        ox = W / 2f
        oy = H * 0.15f + sin(clock * 1.9f) * 7f * d
        val breath = 0.5f + 0.5f * sin(clock * 3.2f)
        drawAurora(c, W, 0.45f + 0.15f * breath, clock)
        drawOrb(c, ox, oy, orbR * (1f + 0.1f * breath), 1f, CYAN, VIOLET, clock)
        drawHoldArc(c, ox, oy, orbR * 1.9f, GOLD, 1f)
        drawCountBadge(c, ox + orbR * 0.95f, oy - orbR * 0.95f, 1f)
        drawPill(c, W / 2f, H * 0.28f, clamp01(age / 350f), GOLD, 0f)
    }

    /** Receiver: the orb flies into your fist and sticks to it. */
    private fun sceneCatch(c: Canvas, W: Float, H: Float, age: Float, clock: Float, dt: Long, t: Long, orbR: Float) {
        followHand(dt, 120f, W, H)
        pushTrail(ox, oy, t)
        drawAurora(c, W, 0.3f, clock)
        drawShock(c, ox, oy, shockAt, t, W * 0.3f, VIOLET)
        drawTrail(c, t, VIOLET, orbR, 460f)
        drawOrb(c, ox, oy, orbR * 0.85f, 1f, PINK, VIOLET, clock)
        drawHoldArc(c, ox, oy, orbR * 1.7f, GOLD, 1f)
        drawCountBadge(c, ox + orbR * 0.8f, oy - orbR * 0.8f, 1f)
        drawPill(c, W / 2f, H * 0.9f, clamp01(age / 300f), PINK, 0f)
    }

    private fun requestBlur(px: Int) {
        if (abs(px - lastBlurPx) >= 2) {
            lastBlurPx = px
            onBlurChange?.invoke(px)
        }
    }

    private fun spawnN(rate: Float, dts: Float): Int {
        val e = rate * dts
        var n = e.toInt()
        if (rnd.nextFloat() < e - n) n++
        return n
    }

    private fun emit(x: Float, y: Float, vx: Float, vy: Float, life: Float, size: Float, color: Int) {
        val i = stNext
        stNext = (stNext + 1) % ST
        sx[i] = x; sy[i] = y; svx[i] = vx; svy[i] = vy
        sage[i] = 0f; slife[i] = life; ssz[i] = size; scol[i] = color; son[i] = true
    }

    private fun updateStreams(dts: Float) {
        for (i in 0 until ST) {
            if (!son[i]) continue
            sage[i] += dts * 1000f
            if (sage[i] >= slife[i]) { son[i] = false; continue }
            sx[i] += svx[i] * dts
            sy[i] += svy[i] * dts
            svx[i] *= (1f - 0.9f * dts)
        }
    }

    private fun drawStreams(c: Canvas) {
        for (i in 0 until ST) {
            if (!son[i]) continue
            val u = sage[i] / slife[i]
            val a = (1f - u).pow(1.3f)
            streakPaint.color = scol[i]
            streakPaint.alpha = (235 * a).toInt().coerceIn(0, 255)
            streakPaint.strokeWidth = ssz[i] * (1f - 0.55f * u)
            c.drawLine(sx[i] - svx[i] * 0.045f, sy[i] - svy[i] * 0.045f, sx[i], sy[i], streakPaint)
        }
    }

    /** The frosted stage: a dim wash, slow drifting light, and dust drifting up through it. */
    private fun drawBlurScene(c: Canvas, W: Float, H: Float, clock: Float, dts: Float, strength: Float) {
        if (strength <= 0.01f) return
        bgPaint.color = withAlpha(INK, (255 * 0.5f * strength).toInt())
        c.drawRect(0f, 0f, W, H, bgPaint)
        drawGlow(c, W * (0.2f + 0.12f * sin(clock * 0.5f)), H * (0.25f + 0.1f * cos(clock * 0.4f)), W * 0.85f, VIOLET, 0.3f * strength)
        drawGlow(c, W * (0.8f + 0.1f * cos(clock * 0.45f)), H * (0.62f + 0.1f * sin(clock * 0.35f)), W * 0.95f, CYAN, 0.24f * strength)
        drawGlow(c, W * 0.5f, H * (0.98f + 0.05f * sin(clock * 0.6f)), W * 0.85f, PINK, 0.2f * strength)
        if (!ambInit) {
            for (i in 0 until AMB) {
                ax[i] = rnd.nextFloat(); ay[i] = rnd.nextFloat()
                avy[i] = 0.015f + 0.05f * rnd.nextFloat()
                asz[i] = 0.8f + 2.6f * rnd.nextFloat()
                aph[i] = rnd.nextFloat() * 6.28f
            }
            ambInit = true
        }
        for (i in 0 until AMB) {
            ay[i] -= avy[i] * dts * (0.6f + asz[i] * 0.25f)
            if (ay[i] < -0.02f) { ay[i] = 1.02f; ax[i] = rnd.nextFloat() }
            val tw = 0.35f + 0.65f * (0.5f + 0.5f * sin(aph[i] + clock * (1.2f + i % 5 * 0.3f)))
            sparkPaint.color = if (i % 3 == 0) CYAN else if (i % 3 == 1) Color.WHITE else PINK
            sparkPaint.alpha = (150 * tw * strength).toInt().coerceIn(0, 255)
            c.drawCircle(ax[i] * W + sin(clock * 0.6f + aph[i]) * 8f * d, ay[i] * H, asz[i] * d, sparkPaint)
        }
    }

    private fun chevrons(c: Canvas, cx: Float, y: Float, up: Boolean, clock: Float, a: Float) {
        for (k in 0 until 3) {
            val ph = (clock * 1.4f - k * 0.22f) % 1f
            val pa = a * sin(ph.coerceIn(0f, 1f) * 3.14159f)
            if (pa <= 0.02f) continue
            val off = (if (up) -1f else 1f) * (k * 20f * d + ph * 10f * d)
            ringPaint.color = Color.WHITE
            ringPaint.alpha = (230 * pa).toInt().coerceIn(0, 255)
            ringPaint.strokeWidth = 3f * d
            val yy = y + off
            val dy = if (up) 8f * d else -8f * d
            clip.reset()
            clip.moveTo(cx - 14f * d, yy - dy)
            clip.lineTo(cx, yy + dy)
            clip.lineTo(cx + 14f * d, yy - dy)
            c.drawPath(clip, ringPaint)
        }
        ringPaint.strokeWidth = 3.5f * d
    }

    /**
     * Samsung style. The sender drags the photo up and off the top edge; at the same moment the part that left
     * shows on the receiver, who can pull it down to take it, or push it back. A flick lands it instantly.
     */
    private fun sceneDrag(c: Canvas, W: Float, H: Float, age: Float, clock: Float, dt: Long, t: Long) {
        val dts = dt / 1000f
        chipDims(W, H)
        val cx = W / 2f
        val send = dragSend
        // frosted background fades in
        blur += (1f - blur) * (1f - exp(-dt / 220f))
        requestBlur((blur * 34f * d).toInt())
        drawBlurScene(c, W, H, clock, dts, blur)
        updateStreams(dts)

        val remoteHolds = t - lastRemoteAt < 450L
        val dAge = (t - dAt).toFloat()
        val centerTop = H * 0.4f - chipH / 2f
        val top: Float

        when (dPhase) {
            DP_WAIT, DP_BACK -> {
                if (send) {
                    if (touching) {
                        // topS is set by the finger
                    } else if (remoteHolds && remoteC > 0.005f) {
                        val target = lerp(restTopPx, -clamp01(remoteC) * chipH, clamp01(remoteC * 12f))
                        topS += (target - topS) * (1f - exp(-dt / 55f))
                    } else {
                        topS += (restTopPx - topS) * (1f - exp(-dt / (if (dPhase == DP_BACK) 100f else 150f)))
                        if (dPhase == DP_BACK && abs(topS - restTopPx) < 1.5f * d && dAge > 250f) dPhase = DP_WAIT
                    }
                    top = topS
                } else {
                    if (!touching) {
                        val target = if (dPhase == DP_BACK) 0f else clamp01(remoteC)
                        cR += (target - cR) * (1f - exp(-dt / (if (remoteHolds) 55f else 95f)))
                        pullPx += (0f - pullPx) * (1f - exp(-dt / 90f))
                        if (dPhase == DP_BACK && cR < 0.01f && dAge > 250f) dPhase = DP_WAIT
                    }
                    top = -(1f - cR) * chipH + pullPx
                }
                if (!touching) tilt += (0f - tilt) * (1f - exp(-dt / 120f))
            }
            DP_COMMIT -> {
                val dur = if (dFling) 430f else 620f
                val u = clamp01(dAge / dur)
                top = if (send) lerp(commitFromTop, -chipH * 1.2f, easeIn(u))
                else lerp(commitFromTop, centerTop, easeOutBack(u))
                tilt += (0f - tilt) * (1f - exp(-dt / 100f))
                if (u >= 1f) { dPhase = DP_TRANSFER; dAt = t }
            }
            else -> {
                top = if (send) -chipH * 1.2f else centerTop + sin(clock * 1.7f) * 5f * d
            }
        }
        chipTopNow = top
        val cy = top + chipH / 2f
        ox = cx; oy = cy

        // ---- particles ----
        if (send) {
            val lifted = top < restTopPx - 6f * d && top > -chipH
            if (lifted && dPhase != DP_TRANSFER) {
                val speed = abs(vel)
                val n = spawnN(40f + speed * 0.1f + (if (dPhase == DP_COMMIT) 140f else 0f), dts)
                for (k in 0 until n) {
                    val x = cx - chipW / 2f + chipW * rnd.nextFloat()
                    val col = if (rnd.nextInt(3) == 0) Color.WHITE else CYAN
                    emit(x, top + 6f * d * rnd.nextFloat(), (rnd.nextFloat() - 0.5f) * 90f * d,
                        -(180f * d + speed * 0.35f) * (0.6f + 0.8f * rnd.nextFloat()), 500f + 450f * rnd.nextFloat(),
                        (1.4f + 1.8f * rnd.nextFloat()) * d, col)
                }
            }
            if (dPhase == DP_TRANSFER) {
                val n = spawnN(70f + 140f * progress, dts)
                for (k in 0 until n) {
                    emit(W * (0.25f + 0.5f * rnd.nextFloat()), H * (0.38f + 0.1f * rnd.nextFloat()), (rnd.nextFloat() - 0.5f) * 60f * d,
                        -(420f + 520f * rnd.nextFloat()) * d, 650f + 500f * rnd.nextFloat(), (1.4f + 1.8f * rnd.nextFloat()) * d,
                        if (rnd.nextInt(3) == 0) Color.WHITE else CYAN)
                }
            }
        } else {
            val seen = top + chipH > 2f * d && dPhase != DP_TRANSFER
            if (seen) {
                val n = spawnN(36f + 120f * (if (touching) 1f else 0f) + (if (dPhase == DP_COMMIT) 120f else 0f), dts)
                for (k in 0 until n) {
                    val x = cx - chipW / 2f + chipW * rnd.nextFloat()
                    emit(x, max(0f, top + chipH * 0.9f * rnd.nextFloat()), sin(clock * 3f + x * 0.02f) * 50f * d,
                        (140f + 190f * rnd.nextFloat()) * d, 750f + 600f * rnd.nextFloat(), (1.4f + 1.8f * rnd.nextFloat()) * d,
                        when (rnd.nextInt(3)) { 0 -> PINK; 1 -> VIOLET; else -> Color.WHITE })
                }
            }
            if (dPhase == DP_TRANSFER) {
                val n = spawnN(60f + 160f * progress, dts)
                for (k in 0 until n) {
                    val sx0 = W * (0.15f + 0.7f * rnd.nextFloat())
                    val dx = cx - sx0
                    val dy = cy
                    val len = kotlin.math.sqrt(dx * dx + dy * dy).coerceAtLeast(1f)
                    val sp = (330f + 260f * rnd.nextFloat()) * d
                    emit(sx0, 0f, dx / len * sp, dy / len * sp, 800f, (1.4f + 1.6f * rnd.nextFloat()) * d,
                        if (rnd.nextInt(3) == 0) Color.WHITE else PINK)
                }
            }
        }

        // ---- the chip ----
        val scale = if (touching) 1.045f else 1f
        val glowA = (if (touching) 0.55f else 0.32f)
        drawGlow(c, cx, cy, chipW * 1.05f, if (send) CYAN else PINK, glowA)
        // receiver: the photo is still "arriving", so it is veiled until the bytes are in
        drawCard(c, 0, cx, cy, chipW * scale, chipH * scale, 26f * d, 1f, tilt)
        if (!send && dPhase == DP_TRANSFER) {
            dispP += (progress - dispP) * (1f - exp(-dt / 150f))
            if (progress >= 0.999f && dispP > 0.994f) dispP = 1f
            rect.set(cx - chipW / 2f, cy - chipH / 2f, cx + chipW / 2f, cy + chipH / 2f)
            scrimPaint.alpha = (150 * (1f - clamp01(dispP))).toInt().coerceIn(0, 255)
            c.drawRoundRect(rect, 26f * d, 26f * d, scrimPaint)
        }
        drawStreams(c)
        drawBurst(c, t)
        drawShock(c, cx, if (send) 0f else cy, shockAt, t, W * 0.7f, if (send) CYAN else PINK)

        // ---- words and arrows ----
        val a = clamp01(age / 450f)
        when {
            dPhase == DP_TRANSFER -> {
                dispP += (progress - dispP) * (1f - exp(-dt / 150f))
                if (progress >= 0.999f && dispP > 0.994f) dispP = 1f
                val p = clamp01(dispP)
                val ringR = if (send) 64f * d else max(chipW, chipH) * 0.66f
                val ringY = if (send) H * 0.42f else cy
                drawProgressArcFixed(c, cx, ringY, ringR, p, if (send) CYAN else PINK, a)
                val labelY = if (send) H * 0.42f + ringR + 54f * d else cy + chipH / 2f + 60f * d
                textPct.alpha = (255 * a).toInt().coerceIn(0, 255)
                c.drawText((p * 100).toInt().toString() + "%", cx, if (send) H * 0.42f + 14f * d else labelY, textPct)
                textSub.alpha = (210 * a).toInt().coerceIn(0, 255)
                val first = names.firstOrNull() ?: ""
                val line = if (total > 1) "$total files" + (if (first.isEmpty()) "" else "  ·  $first") else first
                c.drawText(if (send) "Sending" else "Receiving", cx, if (send) labelY - 22f * d else labelY - 40f * d, textSub)
                if (line.isNotEmpty()) c.drawText(if (line.length > 34) line.take(33) + "…" else line, cx, if (send) labelY else labelY + 24f * d, textSub)
                if (!send) {
                    for (k in 0 until 9) {
                        val ang = clock * 1.3f + k * 0.698f
                        val rr = max(chipW, chipH) * 0.66f
                        sparkPaint.color = if (k % 2 == 0) PINK else Color.WHITE
                        sparkPaint.alpha = (220 * (0.5f + 0.5f * sin(clock * 3f + k))).toInt().coerceIn(0, 255)
                        c.drawCircle(cx + cos(ang) * rr, cy + sin(ang) * rr, (1.6f + (k % 3)) * d, sparkPaint)
                    }
                }
            }
            dPhase == DP_COMMIT -> {}
            send && !touching && !(remoteHolds && remoteC > 0.02f) && top > restTopPx - 30f * d -> {
                chevrons(c, cx, top - 18f * d, true, clock, a)
                label = "Drag up to send"; sub = "Slide it off the top edge toward the other phone"
                drawPill(c, cx, min(H * 0.86f, top + chipH + 66f * d), clamp01((age - 300f) / 350f), CYAN, 0f)
            }
            send -> {
                label = if (touching) "Let go to send" else "Holding..."; sub = "Drag back down to keep it"
                drawPill(c, cx, min(H * 0.9f, max(top + chipH, 0f) + 66f * d), a, CYAN, 0f)
            }
            !send && cR < 0.03f && !touching -> {
                label = "Waiting for the photo"; sub = "Keep the tops of the phones touching"
                drawPill(c, cx, H * 0.4f, clamp01((age - 200f) / 400f), PINK, 0f)
            }
            else -> {
                chevrons(c, cx, top + chipH + 24f * d, false, clock, a)
                label = "Pull down to take it"; sub = "Push it back up to give it back"
                drawPill(c, cx, min(H * 0.9f, top + chipH + 84f * d), a, PINK, 0f)
            }
        }
    }

    private fun drawProgressArcFixed(c: Canvas, x: Float, y: Float, r: Float, p: Float, color: Int, a: Float) {
        arc.set(x - r, y - r, x + r, y + r)
        ringPaint.color = Color.WHITE
        ringPaint.alpha = (45 * a).toInt().coerceIn(0, 255)
        c.drawCircle(x, y, r, ringPaint)
        ringPaint.color = color
        ringPaint.alpha = (255 * a).toInt().coerceIn(0, 255)
        c.drawArc(arc, -90f, 360f * p.coerceAtLeast(0.01f), false, ringPaint)
    }

    /**
     * Touch: a flash and ripples roll down from the top edge where the phones meet, two orbs (this phone and
     * the other one) slide together and merge, a ring spins while linking and turns into a check when done.
     */
    private fun sceneTapPair(c: Canvas, W: Float, H: Float, age: Float, clock: Float, t: Long, orbR: Float) {
        val cx = W / 2f
        val flash = 1f - clamp01(age / 800f)
        drawGlow(c, cx, 0f, W * (0.45f + 0.55f * easeOut(age / 520f)), CYAN, 0.6f * flash + 0.1f)
        drawGlow(c, cx, 0f, W * 0.7f, VIOLET, 0.3f + 0.12f * sin(clock * 3.2f))
        drawAurora(c, W, 0.35f, clock)
        // ripples keep rolling down from the touch point while we are linking
        for (k in 0 until 3) {
            val local = age - k * 280f
            if (local < 0f) continue
            val u = (local % 1800f) / 1800f
            val r = W * 1.15f * easeOut(u)
            val a = (1f - u).pow(1.7f)
            ringPaint.color = if (k == 1) VIOLET else CYAN
            ringPaint.alpha = (200 * a * (if (pairOk) 0.4f else 1f)).toInt().coerceIn(0, 255)
            ringPaint.strokeWidth = (1.2f + 3f * (1f - u)) * d
            c.drawCircle(cx, 0f, r, ringPaint)
        }
        ringPaint.strokeWidth = 3.5f * d

        val cy = H * 0.4f
        val m = clamp01(easeOutBack(age / 850f))
        val sep = lerp(W * 0.3f, 0f, m)
        val r = orbR * (1f + 0.5f * m)
        drawOrb(c, cx - sep, cy, r, 1f, CYAN, VIOLET, clock)
        drawOrb(c, cx + sep, cy, r, 1f, PINK, VIOLET, clock + 1.3f)
        if (!pairOk) {
            drawProgressArc(c, cx, cy, r * 2.1f, clock, CYAN, clamp01((age - 500f) / 300f))
        } else {
            val pa = (SystemClock.uptimeMillis() - pairAt).toFloat()
            drawShock(c, cx, cy, shockAt, t, W * 0.6f, MINT)
            val pop = easeOutBack(pa / 480f)
            val cr = r * 1.05f * pop
            if (cr > 1f) {
                fillPaint.shader = null
                fillPaint.color = MINT
                c.drawCircle(cx, cy, cr, fillPaint)
                ringPaint.color = INK
                ringPaint.alpha = 255
                ringPaint.strokeWidth = 4f * d
                clip.reset()
                clip.moveTo(cx - cr * 0.42f, cy + cr * 0.02f)
                clip.lineTo(cx - cr * 0.1f, cy + cr * 0.34f)
                clip.lineTo(cx + cr * 0.46f, cy - cr * 0.3f)
                c.drawPath(clip, ringPaint)
                ringPaint.strokeWidth = 3.5f * d
            }
        }
        drawPill(c, cx, cy + r * 2.6f + 24f * d, clamp01((age - 350f) / 350f), if (pairOk) MINT else CYAN, 0f)
    }

    /**
     * The photo chip crossing from one phone to the other. At 50% the chip sits half off the top of the
     * sender and, at the same moment, half in from the top of the receiver, so with the phones touching
     * top to top it looks like one chip passing through the gap.
     */
    private fun sceneTapChip(c: Canvas, W: Float, H: Float, age: Float, clock: Float, dt: Long, t: Long, send: Boolean) {
        // glide the shown percentage toward the real one, so coarse updates still move smoothly
        dispP += (progress - dispP) * (1f - exp(-dt / 150f))
        if (progress >= 0.999f && dispP > 0.994f) dispP = 1f
        val p = clamp01(dispP)

        val bmp = photos.firstOrNull()
        val aspect = if (bmp != null) bmp.height.toFloat() / bmp.width else 1.15f
        chipW = W * 0.52f
        chipH = (chipW * aspect).coerceIn(chipW * 0.75f, chipW * 1.45f)
        val cx = W / 2f

        val topY = if (send) {
            // first the chip lifts to the touching edge, then it slides out as data leaves
            val dock = easeInOut(age / 700f)
            lerp(H * 0.32f, -p * chipH, dock)
        } else {
            -(1f - p) * chipH
        }
        val cy = topY + chipH / 2f
        ox = cx; oy = cy

        // the seam where the phones meet glows hardest while the chip straddles it
        val straddle = if (topY < 0f && topY + chipH > 0f) 1f else 0.35f
        val pulse = 0.5f + 0.5f * sin(clock * 5f)
        val seam = (0.3f + 0.55f * sin(p * 3.14159f)) * straddle + 0.12f * pulse
        drawGlow(c, cx, 0f, chipW * 1.25f, CYAN, seam)
        drawGlow(c, cx, 0f, chipW * 0.9f, VIOLET, seam * 0.7f)
        drawAurora(c, W, 0.35f + 0.25f * sin(p * 3.14159f), clock)

        // glow behind the chip and the chip itself
        drawGlow(c, cx, cy, chipW * 0.95f, if (send) CYAN else PINK, 0.3f)
        drawCard(c, 0, cx, cy, chipW, chipH, 26f * d, 1f, 0f)

        // light threads rushing through the visible part of the chip toward (or away from) the seam
        val bottom = max(0f, topY + chipH)
        if (bottom > 8f * d) {
            for (i in 0 until 14) {
                val ph = ((clock * 0.85f + i * 0.37f) % 1f)
                val hx = cx - chipW / 2f + chipW * (0.08f + 0.84f * (((i * 53) % 97) / 97f))
                val y = if (send) lerp(bottom, 0f, ph) else lerp(0f, bottom, ph)
                sparkPaint.color = if (i % 3 == 0) Color.WHITE else CYAN
                sparkPaint.alpha = (230 * sin(ph * 3.14159f)).toInt().coerceIn(0, 255)
                c.drawCircle(hx, y, (1.4f + (i % 3) * 0.8f) * d, sparkPaint)
            }
        }

        // the percentage, under whatever part of the chip is on this screen
        val labelY = bottom + 62f * d
        val a = clamp01(age / 350f)
        textPct.alpha = (255 * a).toInt().coerceIn(0, 255)
        textSub.alpha = (200 * a).toInt().coerceIn(0, 255)
        val head = if (!send && p < 0.02f) "Incoming" else (p * 100).toInt().toString() + "%"
        c.drawText(head, cx, labelY, textPct)
        val first = names.firstOrNull() ?: ""
        val line = if (total > 1) "$total files" + (if (first.isEmpty()) "" else "  ·  $first") else first
        if (line.isNotEmpty()) c.drawText(if (line.length > 34) line.take(33) + "…" else line, cx, labelY + 24f * d, textSub)
        val verb = if (send) "Sending" else "Receiving"
        if (p < 1f) {
            textSub.alpha = (150 * a).toInt().coerceIn(0, 255)
            c.drawText(verb, cx, labelY - 44f * d, textSub)
        }
    }

    /** Release: the orb detonates into light and the photo blooms out of it, with a shine across the glass. */
    private fun sceneReveal(c: Canvas, W: Float, H: Float, age: Float, clock: Float, t: Long, orbR: Float) {
        val outFade = 1f - clamp01((age - (REVEAL_MS - 650f)) / 650f)
        val scrim = 0.62f * easeOut(age / 500f) * outFade
        scrimPaint.alpha = (255 * scrim).toInt().coerceIn(0, 255)
        c.drawRect(0f, 0f, W, H, scrimPaint)

        val bmp = photos.firstOrNull()
        val aspect = if (bmp != null) bmp.height.toFloat() / bmp.width else 1.25f
        val cw = W * 0.78f
        val chh = (cw * aspect).coerceIn(cw * 0.62f, H * 0.62f)
        val cx = W / 2f
        val cy = H * 0.46f

        drawShock(c, launchX, launchY, shockAt, t, W * 0.8f, CYAN)
        drawShock(c, cx, cy, shock2At, t, W * 0.9f, PINK)

        val grow = easeOutBack(age / 780f)
        val move = easeOut(age / 780f)
        val px = lerp(launchX, cx, move)
        val py = lerp(launchY, cy, move)
        val startW = if (tapStyle && chipW > 0f) chipW else orbR * 2f
        val startH = if (tapStyle && chipH > 0f) chipH else orbR * 2f
        val wNow = lerp(startW, cw, grow.coerceAtLeast(0f))
        val hNow = lerp(startH, chh, grow.coerceAtLeast(0f))
        val corner = if (tapStyle) lerp(26f * d, 28f * d, clamp01(age / 600f)) else lerp(orbR, 28f * d, clamp01(age / 600f))
        val sc = 1f - 0.04f * (1f - outFade)

        // the orb fades as the photo takes over
        if (!tapStyle) drawOrb(c, px, py, orbR * (1f - 0.6f * clamp01(age / 300f)), 1f - clamp01(age / 320f), CYAN, PINK, clock)
        drawGlow(c, px, py, max(wNow, hNow) * 0.95f, CYAN, 0.38f * clamp01(age / 400f) * outFade)
        drawGlow(c, px, py, max(wNow, hNow) * 0.7f, PINK, 0.2f * clamp01(age / 500f) * outFade)

        // back cards of a fan when several photos arrived
        if (photos.size > 1 || total > 1) {
            val s2 = clamp01((age - 420f) / 420f)
            val e2 = easeOutBack(s2)
            if (photos.size > 2 || total > 2) {
                drawCard(c, if (photos.size > 2) 2 else 1, px + 16f * d * e2, py + 8f * d * e2, wNow * 0.94f * sc, hNow * 0.94f * sc, corner, 0.85f * s2 * outFade, 9f * e2)
            }
            drawCard(c, 1.coerceAtMost(max(0, photos.size - 1)), px - 14f * d * e2, py + 4f * d * e2, wNow * 0.96f * sc, hNow * 0.96f * sc, corner, 0.9f * s2 * outFade, -7f * e2)
        }
        drawCard(c, 0, px, py, wNow * sc, hNow * sc, corner, clamp01((age - 120f) / 350f) * outFade, 0f)

        // the shine sweep, clipped to the card
        val sweep = (age - 760f) / 800f
        if (sweep in 0f..1f && wNow > 10f) {
            val half = wNow * sc / 2f
            val halfH = hNow * sc / 2f
            clip.reset()
            rect.set(px - half, py - halfH, px + half, py + halfH)
            clip.addRoundRect(rect, corner, corner, Path.Direction.CW)
            c.save()
            c.clipPath(clip)
            val bandX = lerp(px - half - wNow * 0.5f, px + half + wNow * 0.5f, easeInOut(sweep))
            fillPaint.shader = LinearGradient(
                bandX - wNow * 0.18f, py - halfH, bandX + wNow * 0.18f, py + halfH,
                intArrayOf(withAlpha(Color.WHITE, 0), withAlpha(Color.WHITE, (95 * outFade).toInt()), withAlpha(Color.WHITE, 0)),
                floatArrayOf(0f, 0.5f, 1f), Shader.TileMode.CLAMP
            )
            c.drawRect(rect, fillPaint)
            fillPaint.shader = null
            c.restore()
        }
        drawCountBadge(c, px + wNow * sc / 2f - 6f * d, py - hNow * sc / 2f + 6f * d, clamp01((age - 500f) / 300f) * outFade)
        drawPill(c, W / 2f, min(H * 0.88f, py + hNow / 2f + 62f * d), clamp01((age - 700f) / 400f) * outFade, MINT, 0f)
    }
}
