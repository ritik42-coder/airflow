package com.airflow.app

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.snapping.rememberSnapFlingBehavior
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin

@Composable
fun HomeScreen(goDemo: () -> Unit) {
    val c = Air.c
    val ctx = LocalContext.current
    val owner = LocalLifecycleOwner.current
    var tick by remember { mutableIntStateOf(0) }
    DisposableEffect(owner) {
        val obs = LifecycleEventObserver { _, e -> if (e == Lifecycle.Event.ON_RESUME) tick++ }
        owner.lifecycle.addObserver(obs)
        onDispose { owner.lifecycle.removeObserver(obs) }
    }

    val camOk = remember(tick) {
        ContextCompat.checkSelfPermission(ctx, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED
    }
    val notifOk = remember(tick) {
        Build.VERSION.SDK_INT < 33 ||
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED
    }
    val accOk = remember(tick) { AirFlowAccessibilityService.instance != null }

    val camLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { tick++ }
    val notifLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { tick++ }

    val running by AirFlowState.running.collectAsState()
    val hand by AirFlowState.handVisible.collectAsState()
    val last by AirFlowState.lastGesture.collectAsState()
    val error by AirFlowState.error.collectAsState()
    val cursorOn by AirFlowState.cursorMode.collectAsState()
    val svc = remember { Intent(ctx, AirFlowService::class.java) }
    val setupDone = (if (camOk) 1 else 0) + (if (notifOk) 1 else 0) + (if (accOk) 1 else 0)

    AirScroll {
        Hero()

        // ---- the power orb --------------------------------------------------------------
        Column(Modifier.fillMaxWidth().airReveal(120), horizontalAlignment = Alignment.CenterHorizontally) {
            PowerOrb(running = running, hand = hand, cursor = cursorOn) {
                if (!camOk) camLauncher.launch(Manifest.permission.CAMERA)
                else if (running) ctx.stopService(svc)
                else ContextCompat.startForegroundService(ctx, svc)
            }
            Spacer(Modifier.height(4.dp))
            AnimatedContent(
                targetState = if (running) "AIR FLOW IS LIVE" else if (camOk) "TAP THE ORB TO START" else "TAP TO ALLOW CAMERA",
                transitionSpec = { (slideInVertically { it / 2 } + fadeIn(tween(260))) togetherWith (slideOutVertically { -it / 2 } + fadeOut(tween(160))) },
                label = "orbLabel"
            ) {
                Text(it, color = if (running) c.ok else c.dim, fontWeight = FontWeight.Black, fontSize = 13.sp, letterSpacing = 2.sp)
            }
            error?.let { Text(it, color = MaterialTheme.colorScheme.error, fontSize = 12.sp, textAlign = TextAlign.Center) }
            if (running && !accOk) {
                Text(
                    "Hands are tracked, but nothing will happen until the Accessibility service is on.",
                    color = c.warn, fontSize = 12.sp, textAlign = TextAlign.Center, modifier = Modifier.padding(top = 6.dp)
                )
            }
        }

        // ---- live status ----------------------------------------------------------------
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            StatusTile("SERVICE", if (running) "Running" else "Stopped", if (running) c.ok else c.dim, running, Modifier.weight(1f))
            StatusTile("HAND", if (!running) "-" else if (hand) "Detected" else "Not visible", c.a2, running && hand, Modifier.weight(1f))
        }
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            StatusTile("CURSOR", if (cursorOn) "ON" else "OFF", c.warn, cursorOn, Modifier.weight(1f))
            StatusTile("LAST GESTURE", if (last.isEmpty()) "-" else last, c.a3, last.isNotEmpty(), Modifier.weight(1f))
        }

        // ---- cursor mode ----------------------------------------------------------------
        GlassCard(Modifier.fillMaxWidth()) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                MiniCursorDemo(Modifier.size(78.dp))
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text("Cursor mode", style = MaterialTheme.typography.titleMedium, color = c.text)
                    Text(
                        "Your hand becomes a mouse. Point to move, pinch to tap, hold to long-press, pinch and move to scroll.",
                        style = MaterialTheme.typography.bodySmall, color = c.dim
                    )
                }
                Spacer(Modifier.width(10.dp))
                AirSwitch(checked = cursorOn, enabled = running && accOk, onChange = {
                    AirFlowAccessibilityService.instance?.setCursor(it)
                })
            }
            if (!(running && accOk)) {
                Text("Start Air Flow and enable Accessibility to use it.", style = MaterialTheme.typography.bodySmall, color = c.warn)
            }
        }

        // ---- setup ----------------------------------------------------------------------
        GlassCard(Modifier.fillMaxWidth()) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                SetupRing(setupDone / 3f, Modifier.size(54.dp))
                Spacer(Modifier.width(14.dp))
                Column(Modifier.weight(1f)) {
                    Text(
                        if (setupDone == 3) "All set. You are ready." else "Setup  $setupDone / 3",
                        style = MaterialTheme.typography.titleMedium, color = c.text
                    )
                    Text(
                        if (setupDone == 3) "Everything is allowed. Start the orb above." else "Three quick permissions, one time only.",
                        style = MaterialTheme.typography.bodySmall, color = c.dim
                    )
                }
            }
            if (setupDone < 3) {
                StepRow("Camera access", camOk, "Allow") { camLauncher.launch(Manifest.permission.CAMERA) }
                StepRow("Notifications", notifOk, "Allow") {
                    if (Build.VERSION.SDK_INT >= 33) notifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                }
                StepRow("Accessibility service", accOk, "Enable") {
                    ctx.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
                }
            }
        }

        if (!accOk && Build.VERSION.SDK_INT >= 33) {
            SectionCard("Accessibility switch greyed out?") {
                Text(
                    "Android blocks sideloaded apps at first. Open App info, tap the three-dot menu (top right), choose " +
                        "\"Allow restricted settings\", then enable Air Flow in Accessibility again.",
                    style = MaterialTheme.typography.bodySmall, color = c.dim
                )
                AirButton("Open App info", {
                    ctx.startActivity(
                        Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${ctx.packageName}"))
                    )
                }, Modifier.fillMaxWidth(), filled = false)
            }
        }

        // ---- gesture carousel -----------------------------------------------------------
        Column(Modifier.airReveal(0), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text("Every gesture", style = MaterialTheme.typography.titleLarge, color = c.text)
            Text("Swipe through the cards. Tap the Tour tab to see each one in action.", style = MaterialTheme.typography.bodySmall, color = c.dim)
            GestureCarousel()
        }

        // ---- quick start ----------------------------------------------------------------
        SectionCard("Quick start") {
            QuickStep(1, "Start the orb, then open any app: YouTube, Spotify, Chrome, Instagram.")
            QuickStep(2, "Prop the phone up. Keep your hand 40 to 60 cm away, in good light.")
            QuickStep(3, "Pinch for the next Short. Swipe your open hand to scroll, seek or change volume.")
            QuickStep(4, "Show the rock sign to turn on cursor mode and control the whole phone.")
        }

        AirButton("Watch the interactive tour", goDemo, Modifier.fillMaxWidth(), icon = IconKind.PLAY)
    }
}

// ---------------------------------------------------------------------------------------------

@Composable
private fun Hero() {
    val c = Air.c
    val sc = LocalScrollCtx.current
    val inf = rememberInfiniteTransition(label = "hero")
    val sh = inf.animateFloat(0f, 1f, infiniteRepeatable(tween(4200, easing = LinearEasing)), label = "sh")
    Column(
        Modifier
            .fillMaxWidth()
            .graphicsLayer {
                val y = (sc?.state?.value ?: 0).toFloat()
                translationY = y * 0.45f
                alpha = (1f - y / 520f).coerceIn(0f, 1f)
                val s = (1f - y / 2200f).coerceIn(0.85f, 1f)
                scaleX = s
                scaleY = s
            }
            .airReveal(0),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        AirLogo(96.dp)
        GradientText(
            "AIR FLOW",
            MaterialTheme.typography.headlineLarge.copy(fontSize = 34.sp, letterSpacing = 6.sp),
            listOf(c.text, c.a2, c.a1, c.a3), shimmer = sh
        )
        Spacer(Modifier.height(6.dp))
        Text(
            "Control your phone with the air. Touch nothing. Everything runs on-device.",
            style = MaterialTheme.typography.bodyMedium, color = c.dim, textAlign = TextAlign.Center,
            modifier = Modifier.padding(horizontal = 24.dp)
        )
    }
}

@Composable
private fun PowerOrb(running: Boolean, hand: Boolean, cursor: Boolean, onClick: () -> Unit) {
    val c = Air.c
    val inf = rememberInfiniteTransition(label = "orb")
    val spin = inf.animateFloat(0f, 360f, infiniteRepeatable(tween(9000, easing = LinearEasing)), label = "spin")
    val pulse = inf.animateFloat(0f, 1f, infiniteRepeatable(tween(2400, easing = LinearEasing)), label = "pulse")
    val bob = inf.animateFloat(0f, 1f, infiniteRepeatable(tween(3200, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "bob")
    val live = animateFloatAsState(if (running) 1f else 0f, tween(700), label = "live")
    val handGlow = animateFloatAsState(if (hand) 1f else 0f, tween(300), label = "hg")
    val warm = animateFloatAsState(if (cursor) 1f else 0f, tween(500), label = "warm")
    val src = remember { MutableInteractionSource() }
    val pressed by src.collectIsPressedAsState()
    val press = animateFloatAsState(if (pressed) 0.93f else 1f, spring(dampingRatio = 0.5f, stiffness = 500f), label = "press")
    val haptic = LocalHapticFeedback.current

    Box(
        Modifier
            .size(236.dp)
            .graphicsLayer {
                scaleX = press.value
                scaleY = press.value
                translationY = (bob.value - 0.5f) * 8.dp.toPx()
            }
            .clickable(interactionSource = src, indication = null) {
                haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                onClick()
            },
        contentAlignment = Alignment.Center
    ) {
        Canvas(Modifier.size(236.dp)) {
            val r = size.minDimension / 2f
            val ctr = center
            val base = lerp(c.a1, c.a2, live.value)
            val col = lerp(base, c.warn, warm.value)

            if (live.value > 0.01f) {
                for (k in 0..2) {
                    val u = (pulse.value + k / 3f) % 1f
                    drawCircle(
                        col.copy(alpha = (1f - u) * 0.38f * live.value), r * (0.62f + 0.38f * u), ctr,
                        style = Stroke(width = 2.5.dp.toPx())
                    )
                }
            }
            drawCircle(
                Brush.radialGradient(listOf(col.copy(alpha = 0.42f + 0.28f * handGlow.value), Color.Transparent), ctr, r),
                r, ctr
            )
            rotate(spin.value, ctr) {
                drawCircle(
                    Brush.sweepGradient(listOf(Color.Transparent, col, c.a3.copy(alpha = 0.9f), Color.Transparent), ctr),
                    r * 0.68f, ctr, style = Stroke(width = 4.dp.toPx(), cap = StrokeCap.Round)
                )
            }
            rotate(-spin.value * 1.4f, ctr) {
                drawCircle(
                    Brush.sweepGradient(listOf(Color.Transparent, Color.White.copy(alpha = 0.7f), Color.Transparent), ctr),
                    r * 0.76f, ctr, style = Stroke(width = 1.5.dp.toPx(), cap = StrokeCap.Round)
                )
            }
            // the sphere
            drawCircle(
                Brush.radialGradient(
                    listOf(col.copy(alpha = 0.97f), lerp(col, Color.Black, 0.6f)),
                    Offset(ctr.x - r * 0.18f, ctr.y - r * 0.2f), r * 0.62f
                ),
                r * 0.56f, ctr
            )
            drawCircle(Color.White.copy(alpha = 0.16f), r * 0.2f, Offset(ctr.x - r * 0.2f, ctr.y - r * 0.3f))

            // the hand inside the orb mirrors what the camera sees
            val pts = computeHand(lerpPose(Poses.OPEN, Poses.POINT, warm.value))
            drawHand(
                pts, Offset(ctr.x, ctr.y + r * 0.30f), r * 0.58f, Color.White, Color(0xFFBFF8FF),
                alpha = 0.55f + 0.4f * handGlow.value + 0.05f * live.value, glow = 0.8f, lineW = 2.2.dp.toPx(), dotR = 2.6.dp.toPx()
            )
        }
        Text(
            if (running) "STOP" else "START",
            color = Color.White.copy(alpha = 0.92f), fontWeight = FontWeight.Black, fontSize = 12.sp, letterSpacing = 3.sp,
            modifier = Modifier.offset(y = 50.dp)
        )
    }
}

@Composable
private fun StatusTile(label: String, value: String, color: Color, active: Boolean, modifier: Modifier) {
    val c = Air.c
    GlassCard(modifier) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            PulseDot(color, active)
            Text(label, color = c.dim, fontSize = 10.sp, fontWeight = FontWeight.Black, letterSpacing = 1.5.sp)
        }
        AnimatedContent(
            targetState = value,
            transitionSpec = { (slideInVertically { it } + fadeIn(tween(240))) togetherWith (slideOutVertically { -it } + fadeOut(tween(160))) },
            label = "tile"
        ) {
            Text(it, color = if (active) color else c.text, fontWeight = FontWeight.Bold, fontSize = 17.sp, maxLines = 1)
        }
    }
}

@Composable
private fun MiniCursorDemo(modifier: Modifier) {
    val c = Air.c
    val inf = rememberInfiniteTransition(label = "mini")
    val t = inf.animateFloat(0f, 1f, infiniteRepeatable(tween(4200, easing = LinearEasing)), label = "t")
    Canvas(modifier.clip(RoundedCornerShape(18.dp)).background(c.glass)) {
        val w = size.width
        val h = size.height
        // a tiny grid of "app icons"
        for (i in 0..1) for (j in 0..1) {
            drawRoundRect(
                c.a1.copy(alpha = 0.28f), Offset(w * (0.16f + 0.4f * i), h * (0.16f + 0.4f * j)),
                androidx.compose.ui.geometry.Size(w * 0.28f, h * 0.28f),
                androidx.compose.ui.geometry.CornerRadius(8f, 8f)
            )
        }
        val a = t.value * 6.2832f
        val cx = w * (0.5f + 0.22f * cos(a))
        val cy = h * (0.5f + 0.22f * sin(a * 2f))
        val tap = seg(t.value, 0.72f, 0.9f)
        if (tap > 0f && tap < 1f) drawCircle(c.a2.copy(alpha = 1f - tap), 6f + 22f * tap, Offset(cx, cy), style = Stroke(2f))
        drawCircle(c.a2.copy(alpha = 0.3f), 11f, Offset(cx, cy))
        drawCircle(c.a2, 5f, Offset(cx, cy))
    }
}

@Composable
private fun SetupRing(progress: Float, modifier: Modifier) {
    val c = Air.c
    val p = animateFloatAsState(progress, tween(700), label = "ring")
    Canvas(modifier) {
        val sw = 5.dp.toPx()
        drawCircle(c.glassHi, size.minDimension / 2f - sw / 2f, center, style = Stroke(sw))
        drawArc(
            Brush.sweepGradient(listOf(c.a2, c.a1, c.a3, c.a2), center), -90f, 360f * p.value, false,
            Offset(sw / 2f, sw / 2f), androidx.compose.ui.geometry.Size(size.width - sw, size.height - sw),
            style = Stroke(sw, cap = StrokeCap.Round)
        )
    }
}

@Composable
private fun StepRow(label: String, ok: Boolean, button: String, onClick: () -> Unit) {
    val c = Air.c
    val s = animateFloatAsState(if (ok) 1f else 0f, spring(dampingRatio = 0.5f, stiffness = 400f), label = "chk")
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Box(
            Modifier.size(26.dp).clip(CircleShape)
                .background(lerp(Color.Transparent, c.ok, s.value))
                .border(1.5.dp, if (ok) c.ok else c.stroke, CircleShape),
            contentAlignment = Alignment.Center
        ) {
            if (ok) AirIcon(IconKind.CHECK, Color.White, Modifier.size(16.dp).graphicsLayer { scaleX = s.value; scaleY = s.value })
        }
        Spacer(Modifier.width(12.dp))
        Text(label, Modifier.weight(1f), color = if (ok) c.dim else c.text, fontWeight = FontWeight.SemiBold)
        if (!ok) {
            Box(
                Modifier.clip(RoundedCornerShape(50)).background(Brush.horizontalGradient(listOf(c.a1, c.a2)))
                    .pressClick(onClick = onClick).padding(horizontal = 16.dp, vertical = 8.dp)
            ) { Text(button, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp) }
        }
    }
}

@Composable
private fun QuickStep(n: Int, text: String) {
    val c = Air.c
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(
            Modifier.size(30.dp).clip(CircleShape).background(Brush.linearGradient(listOf(c.a1, c.a2))),
            contentAlignment = Alignment.Center
        ) { Text("$n", color = Color.White, fontWeight = FontWeight.Black, fontSize = 14.sp) }
        Spacer(Modifier.width(12.dp))
        Text(text, style = MaterialTheme.typography.bodyMedium, color = c.text)
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun GestureCarousel() {
    val state = rememberLazyListState()
    val fling = rememberSnapFlingBehavior(lazyListState = state)
    LazyRow(
        state = state,
        flingBehavior = fling,
        horizontalArrangement = Arrangement.spacedBy(12.dp),
        contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 4.dp, vertical = 8.dp)
    ) {
        items(Gesture.values().toList(), key = { it.name }) { g ->
            Box(
                Modifier.graphicsLayer {
                    val info = state.layoutInfo
                    val it = info.visibleItemsInfo.firstOrNull { x -> x.key == g.name }
                    if (it != null) {
                        val mid = (info.viewportStartOffset + info.viewportEndOffset) / 2f
                        val ic = it.offset + it.size / 2f
                        val d = ((ic - mid) / (it.size * 1.4f)).coerceIn(-1f, 1f)
                        val s = 1f - 0.12f * abs(d)
                        scaleX = s
                        scaleY = s
                        alpha = 1f - 0.4f * abs(d)
                        rotationY = d * -22f
                        cameraDistance = 14f * density
                    }
                }
            ) { GestureCard(g) }
        }
    }
}

@Composable
private fun GestureCard(g: Gesture) {
    val c = Air.c
    GlassCard(Modifier.width(158.dp), reveal = false) {
        Box(
            Modifier.fillMaxWidth().height(120.dp).clip(RoundedCornerShape(18.dp)).background(if (c.dark) Color(0x66000000) else Color(0x14000000))
        ) { MiniHand(g, Modifier.fillMaxWidth().height(120.dp)) }
        Text(g.title, fontWeight = FontWeight.Bold, color = c.text, fontSize = 14.sp, maxLines = 1)
        Text(g.action, color = c.dim, fontSize = 11.sp, maxLines = 2, lineHeight = 14.sp)
    }
}
