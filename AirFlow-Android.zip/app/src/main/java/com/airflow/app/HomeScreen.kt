package com.airflow.app

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver

@Composable
fun HomeScreen(goDemo: () -> Unit) {
    val ctx = LocalContext.current
    val owner = LocalLifecycleOwner.current
    var tick by remember { mutableIntStateOf(0) }
    DisposableEffect(owner) {
        val obs = LifecycleEventObserver { _, e -> if (e == Lifecycle.Event.ON_RESUME) tick++ }
        owner.lifecycle.addObserver(obs)
        onDispose { owner.lifecycle.removeObserver(obs) }
    }

    val camOk = remember(tick) {
        ContextCompat.checkSelfPermission(ctx, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED
    }
    val notifOk = remember(tick) {
        Build.VERSION.SDK_INT < 33 ||
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED
    }
    val accOk = remember(tick) { AirFlowAccessibilityService.instance != null }

    val camLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { tick++ }
    val notifLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { tick++ }

    val running by AirFlowState.running.collectAsState()
    val hand by AirFlowState.handVisible.collectAsState()
    val last by AirFlowState.lastGesture.collectAsState()
    val error by AirFlowState.error.collectAsState()
    val svc = remember { Intent(ctx, AirFlowService::class.java) }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("🖐️ Air Flow", style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.Bold)
        Text("Scroll YouTube Shorts, Reels and more with your hand in the air. Everything runs on your phone, nothing is uploaded.")

        SectionCard("Setup (one time)") {
            StepRow("1. Camera access", camOk, "Allow") { camLauncher.launch(Manifest.permission.CAMERA) }
            StepRow("2. Notifications", notifOk, "Allow") {
                if (Build.VERSION.SDK_INT >= 33) notifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
            }
            StepRow("3. Accessibility service", accOk, "Enable") {
                ctx.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            }
        }

        if (!accOk && Build.VERSION.SDK_INT >= 33) {
            SectionCard("Accessibility switch greyed out?") {
                Text(
                    "Android blocks sideloaded apps at first. Open App info, tap the ⋮ menu (top right), choose " +
                        "\"Allow restricted settings\", then enable Air Flow in Accessibility again.",
                    style = MaterialTheme.typography.bodySmall
                )
                OutlinedButton(onClick = {
                    ctx.startActivity(
                        Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${ctx.packageName}"))
                    )
                }) { Text("Open App info") }
            }
        }

        Button(
            onClick = {
                if (running) ctx.stopService(svc) else ContextCompat.startForegroundService(ctx, svc)
            },
            enabled = running || camOk,
            modifier = Modifier.fillMaxWidth()
        ) { Text(if (running) "⏹ Stop Air Flow" else "▶ Start Air Flow") }

        if (running && !accOk) {
            Text("Hands are tracked, but nothing will scroll until the Accessibility service is on.",
                color = MaterialTheme.colorScheme.error)
        }
        error?.let { Text(it, color = MaterialTheme.colorScheme.error) }

        SectionCard("Live status") {
            Text(if (running) "Service: running" else "Service: stopped")
            Text(if (running) (if (hand) "Hand: detected ✋" else "Hand: not visible") else "Hand: -")
            Text("Last gesture: ${if (last.isEmpty()) "-" else last}")
        }

        SectionCard("How to use") {
            Text("1. Press Start, then open YouTube Shorts (or Reels).")
            Text("2. Prop the phone up, 40–60 cm from you, with good light on your hand.")
            Text("3. Flick your open palm up or down to change video.")
            Text("4. Not sure how? Watch the Demo, then practise in Test.")
            Text("By default gestures only act inside video apps (change in Settings).",
                style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }

        FilledTonalButton(onClick = goDemo, modifier = Modifier.fillMaxWidth()) { Text("Watch gesture demo") }
    }
}

@Composable
private fun StepRow(label: String, ok: Boolean, button: String, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(if (ok) "✅" else "⬜", Modifier.padding(end = 8.dp))
        Text(label, Modifier.weight(1f))
        if (!ok) FilledTonalButton(onClick = onClick) { Text(button) }
    }
}
