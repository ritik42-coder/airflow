package com.airflow.app

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Context
import android.content.Intent
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.Rect
import android.media.AudioManager
import android.os.Build
import android.os.SystemClock
import android.os.VibrationEffect
import android.os.Vibrator
import android.provider.MediaStore
import android.view.KeyEvent
import android.view.WindowManager
import android.widget.Toast
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

class AirFlowAccessibilityService : AccessibilityService() {
    private var currentPkg = ""
    private var overlay: CursorOverlay? = null
    private var lastLikeAt = 0L
    val cursor: CursorController by lazy { CursorController(this) }

    override fun onServiceConnected() {
        super.onServiceConnected()
        Prefs.init(this)
        instance = this
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event?.eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) {
            val p = event.packageName?.toString() ?: return
            if (p != packageName && p != "com.android.systemui" && !p.contains("inputmethod")) {
                currentPkg = p
            }
        }
    }

    override fun onInterrupt() {}

    override fun onUnbind(intent: Intent?): Boolean {
        setCursor(false, feedback = false)
        instance = null
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        setCursor(false, feedback = false)
        instance = null
        super.onDestroy()
    }

    // ---------------------------------------------------------------------------------------
    // Cursor mode (hand mouse): overlay + click helpers used by CursorController
    // ---------------------------------------------------------------------------------------

    fun setCursor(on: Boolean, feedback: Boolean = true) {
        if (on) showOverlay() else hideOverlay()
        cursor.reset()
        AirFlowState.cursorMode.value = on
        if (feedback) buzz()
    }

    private fun showOverlay() {
        if (overlay != null) return
        try {
            val v = CursorOverlay(this)
            val lp = WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT
            )
            if (Build.VERSION.SDK_INT >= 28) {
                lp.layoutInDisplayCutoutMode =
                    WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            }
            (getSystemService(Context.WINDOW_SERVICE) as WindowManager).addView(v, lp)
            overlay = v
        } catch (e: Exception) {
            toast("Could not show the cursor: ${e.message}")
        }
    }

    private fun hideOverlay() {
        val v = overlay ?: return
        try { (getSystemService(Context.WINDOW_SERVICE) as WindowManager).removeView(v) } catch (_: Exception) {}
        overlay = null
    }

    /** Real display size in pixels (what gesture coordinates use). */
    @Suppress("DEPRECATION")
    fun screenSize(): Pair<Float, Float> {
        val wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        return if (Build.VERSION.SDK_INT >= 30) {
            val b = wm.maximumWindowMetrics.bounds
            Pair(b.width().toFloat(), b.height().toFloat())
        } else {
            val dm = android.util.DisplayMetrics()
            wm.defaultDisplay.getRealMetrics(dm)
            Pair(dm.widthPixels.toFloat(), dm.heightPixels.toFloat())
        }
    }

    fun overlayUpdate(
        x: Float, y: Float, state: Int, fromX: Float = 0f, fromY: Float = 0f, progress: Float = 0f
    ) {
        overlay?.update(x, y, state, fromX, fromY, progress)
    }
    fun overlayRipple(x: Float, y: Float) { overlay?.ripple(x, y) }
    fun overlayHandVisible(v: Boolean) { overlay?.setHandVisible(v) }

    fun tapAt(x: Float, y: Float) = tap(x, y)

    fun longPressAt(x: Float, y: Float) {
        val p = Path().apply { moveTo(x, y) }
        dispatchGesture(
            GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(p, 0, 550)).build(),
            null, null
        )
    }

    /**
     * Drag from A to B. With [holdFirst] the finger rests on A for a moment before moving (what
     * moving a home-screen icon or reordering a list needs); otherwise it is a plain swipe/scroll.
     */
    fun dragFromTo(x1: Float, y1: Float, x2: Float, y2: Float, ms: Long, holdFirst: Boolean) {
        if (!holdFirst) { swipe(x1, y1, x2, y2, ms); return }
        val hold = Path().apply { moveTo(x1, y1) }
        val first = GestureDescription.StrokeDescription(hold, 0, 600, true)
        dispatchGesture(
            GestureDescription.Builder().addStroke(first).build(),
            object : AccessibilityService.GestureResultCallback() {
                override fun onCompleted(gestureDescription: GestureDescription?) {
                    val move = Path().apply { moveTo(x1, y1); lineTo(x2, y2) }
                    val second = first.continueStroke(move, 0, ms, false)
                    dispatchGesture(GestureDescription.Builder().addStroke(second).build(), null, null)
                }
            },
            null
        )
    }

    private fun toast(msg: String) {
        try { Toast.makeText(this, msg, Toast.LENGTH_SHORT).show() } catch (_: Exception) {}
    }

    private fun launchPackage(pkg: String?) {
        if (pkg.isNullOrEmpty()) { toast("No app chosen yet. Pick one in Air Flow > Settings."); return }
        val i = packageManager.getLaunchIntentForPackage(pkg)
        if (i == null) { toast("That app is not installed."); return }
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
        try { startActivity(i) } catch (e: Exception) { toast("Could not open the app.") }
    }

    private fun openCamera() {
        try {
            startActivity(Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (e: Exception) {
            toast("Could not open the camera app.")
        }
    }

    // ---------------------------------------------------------------------------------------
    // Entry point: gesture -> action (user choice, or "Auto" picks by app) -> do it
    // ---------------------------------------------------------------------------------------

    fun perform(g: Gesture) {
        // In cursor mode a fist hold (or the rock sign) leaves cursor mode.
        if (AirFlowState.cursorMode.value && (g == Gesture.FIST_HOLD || g == Gesture.ROCK_HOLD)) {
            setCursor(false)
            return
        }
        val root = rootInActiveWindow
        val pkg = root?.packageName?.toString() ?: currentPkg

        var action = Prefs.actionFor(g)
        if (action == Action.NONE) return
        if (action == Action.AUTO) action = AutoMap.resolve(g, detectCtx(pkg, root))
        if (action == Action.NONE || action == Action.AUTO) return
        if (Prefs.onlyVideoApps && pkg !in Apps.VIDEO_ALL && action != Action.TOGGLE_CURSOR) return

        run(action, pkg, root)
        if (action != Action.TOGGLE_CURSOR) buzz()
    }

    private fun detectCtx(pkg: String, root: AccessibilityNodeInfo?): Ctx = when {
        pkg in Apps.YOUTUBE -> {
            // Shorts first; a normal watch page only if its player is on screen. If YouTube ever
            // renames its views we fall back to FEED, which is the original Shorts behaviour.
            if (!hasId(root, pkg, Apps.SHORTS_IDS) && hasId(root, pkg, Apps.WATCH_IDS)) Ctx.YT_WATCH
            else Ctx.FEED
        }
        pkg in Apps.FEED -> Ctx.FEED
        pkg in Apps.PLAYER -> Ctx.PLAYER
        pkg in Apps.MUSIC -> Ctx.MUSIC
        else -> Ctx.GENERIC
    }

    private fun hasId(root: AccessibilityNodeInfo?, pkg: String, ids: List<String>): Boolean {
        if (root == null) return false
        return try {
            ids.any { root.findAccessibilityNodeInfosByViewId("$pkg:id/$it").isNotEmpty() }
        } catch (_: Exception) {
            false
        }
    }

    // ---------------------------------------------------------------------------------------
    // Actions
    // ---------------------------------------------------------------------------------------

    private fun run(a: Action, pkg: String, root: AccessibilityNodeInfo?) {
        val dm = resources.displayMetrics
        val w = dm.widthPixels.toFloat()
        val h = dm.heightPixels.toFloat()
        val landscape = w > h
        when (a) {
            Action.NEXT -> swipe(w / 2, h * 0.78f, w / 2, h * 0.22f, 140)
            Action.PREVIOUS -> swipe(w / 2, h * 0.25f, w / 2, h * 0.80f, 140)
            Action.PAGE_DOWN -> swipe(w / 2, h * 0.70f, w / 2, h * 0.30f, 260)
            Action.PAGE_UP -> swipe(w / 2, h * 0.30f, w / 2, h * 0.70f, 260)
            Action.SIDE_LEFT -> swipe(w * 0.8f, h / 2, w * 0.2f, h / 2, 140)
            Action.SIDE_RIGHT -> swipe(w * 0.2f, h / 2, w * 0.8f, h / 2, 140)

            Action.TAP_CENTER -> tap(w / 2, h / 2)
            Action.LIKE -> {
                // A held thumb repeats; never let it un-like what it just liked.
                val nowMs = SystemClock.uptimeMillis()
                if (nowMs - lastLikeAt < 4000) return
                lastLikeAt = nowMs
                // On a normal YouTube page use the real Like button; everywhere else double-tap.
                val ytWatch = pkg in Apps.YOUTUBE && !hasId(root, pkg, Apps.SHORTS_IDS) &&
                    hasId(root, pkg, Apps.WATCH_IDS)
                if (ytWatch) clickByText(root, "like this video") else doubleTap(w / 2, h / 2)
            }
            Action.SEEK_BACK -> doubleTap(w * 0.15f, playerY(pkg, root, h, landscape))
            Action.SEEK_FORWARD -> doubleTap(w * 0.85f, playerY(pkg, root, h, landscape))
            Action.FULLSCREEN_ON -> {
                if (!clickByText(root, "enter fullscreen", "full screen")) {
                    val y = playerY(pkg, root, h, landscape)
                    swipe(w / 2, y + h * 0.07f, w / 2, y - h * 0.07f, 160)
                }
            }
            Action.FULLSCREEN_OFF -> {
                if (!clickByText(root, "exit fullscreen", "exit full screen")) {
                    val y = playerY(pkg, root, h, landscape)
                    swipe(w / 2, y - h * 0.07f, w / 2, y + h * 0.07f, 160)
                }
            }

            Action.MEDIA_PLAY_PAUSE -> mediaKey(KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE)
            Action.MEDIA_NEXT -> mediaKey(KeyEvent.KEYCODE_MEDIA_NEXT)
            Action.MEDIA_PREVIOUS -> mediaKey(KeyEvent.KEYCODE_MEDIA_PREVIOUS)
            Action.VOLUME_UP -> volume(AudioManager.ADJUST_RAISE)
            Action.VOLUME_DOWN -> volume(AudioManager.ADJUST_LOWER)
            Action.MUTE -> audio().adjustStreamVolume(
                AudioManager.STREAM_MUSIC, AudioManager.ADJUST_TOGGLE_MUTE, AudioManager.FLAG_SHOW_UI
            )

            Action.BACK -> performGlobalAction(GLOBAL_ACTION_BACK)
            Action.HOME -> performGlobalAction(GLOBAL_ACTION_HOME)
            Action.RECENTS -> performGlobalAction(GLOBAL_ACTION_RECENTS)
            Action.NOTIFICATIONS -> performGlobalAction(GLOBAL_ACTION_NOTIFICATIONS)
            Action.QUICK_SETTINGS -> performGlobalAction(GLOBAL_ACTION_QUICK_SETTINGS)
            Action.SCREENSHOT -> if (Build.VERSION.SDK_INT >= 28) performGlobalAction(GLOBAL_ACTION_TAKE_SCREENSHOT)
            Action.LOCK_SCREEN -> if (Build.VERSION.SDK_INT >= 28) performGlobalAction(GLOBAL_ACTION_LOCK_SCREEN)

            Action.TOGGLE_CURSOR -> setCursor(!AirFlowState.cursorMode.value)
            Action.OPEN_YOUTUBE -> launchPackage("com.google.android.youtube")
            Action.OPEN_CAMERA -> openCamera()
            Action.OPEN_FAV_1 -> launchPackage(Prefs.fav(1))
            Action.OPEN_FAV_2 -> launchPackage(Prefs.fav(2))
            Action.OPEN_FAV_3 -> launchPackage(Prefs.fav(3))

            Action.AUTO, Action.NONE -> {}
        }
    }

    private fun audio() = getSystemService(Context.AUDIO_SERVICE) as AudioManager

    /** Adjusts whatever stream is playing right now (music, video, call), with the system slider. */
    private fun volume(direction: Int) {
        audio().adjustSuggestedStreamVolume(
            direction, AudioManager.USE_DEFAULT_STREAM_TYPE, AudioManager.FLAG_SHOW_UI
        )
    }

    private fun mediaKey(code: Int) {
        val am = audio()
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, code))
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, code))
    }

    /** Vertical centre of the video player, so double-tap seeking lands on the video itself. */
    private fun playerY(pkg: String, root: AccessibilityNodeInfo?, h: Float, landscape: Boolean): Float {
        if (landscape) return h / 2
        if (root != null) {
            for (id in Apps.PLAYER_IDS) {
                try {
                    val n = root.findAccessibilityNodeInfosByViewId("$pkg:id/$id").firstOrNull() ?: continue
                    val r = Rect()
                    n.getBoundsInScreen(r)
                    if (r.height() > 0) return r.exactCenterY()
                } catch (_: Exception) {
                }
            }
        }
        return if (pkg in Apps.YOUTUBE) h * 0.2f else h / 2
    }

    /** Clicks the first visible clickable control whose text or description contains one of [texts]. */
    private fun clickByText(root: AccessibilityNodeInfo?, vararg texts: String): Boolean {
        if (root == null) return false
        for (t in texts) {
            val nodes = try { root.findAccessibilityNodeInfosByText(t) } catch (_: Exception) { emptyList() }
            for (n in nodes) {
                val desc = (n.contentDescription?.toString() ?: n.text?.toString() ?: "")
                if (desc.contains("dislike", ignoreCase = true)) continue
                var c: AccessibilityNodeInfo? = n
                var hops = 0
                while (c != null && !c.isClickable && hops < 4) { c = c.parent; hops++ }
                if (c != null && c.isClickable && c.isVisibleToUser) {
                    c.performAction(AccessibilityNodeInfo.ACTION_CLICK)
                    return true
                }
            }
        }
        return false
    }

    @Suppress("DEPRECATION")
    fun buzz() {
        if (!Prefs.haptic) return
        try {
            val v = getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator ?: return
            v.vibrate(VibrationEffect.createOneShot(25, VibrationEffect.DEFAULT_AMPLITUDE))
        } catch (_: Exception) {
        }
    }

    // ---------------------------------------------------------------------------------------
    // Touch helpers
    // ---------------------------------------------------------------------------------------

    private fun swipe(x1: Float, y1: Float, x2: Float, y2: Float, ms: Long) {
        val p = Path().apply { moveTo(x1, y1); lineTo(x2, y2) }
        val s = GestureDescription.StrokeDescription(p, 0, ms)
        dispatchGesture(GestureDescription.Builder().addStroke(s).build(), null, null)
    }

    private fun tap(x: Float, y: Float) {
        val p = Path().apply { moveTo(x, y) }
        val s = GestureDescription.StrokeDescription(p, 0, 35)
        dispatchGesture(GestureDescription.Builder().addStroke(s).build(), null, null)
    }

    private fun doubleTap(x: Float, y: Float) {
        val p1 = Path().apply { moveTo(x, y) }
        val p2 = Path().apply { moveTo(x, y) }
        val b = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(p1, 0, 40))
            .addStroke(GestureDescription.StrokeDescription(p2, 130, 40))
        dispatchGesture(b.build(), null, null)
    }

    companion object {
        @Volatile var instance: AirFlowAccessibilityService? = null
    }
}
