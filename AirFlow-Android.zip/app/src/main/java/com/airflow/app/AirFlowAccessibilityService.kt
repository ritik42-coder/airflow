package com.airflow.app

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.graphics.Path
import android.view.accessibility.AccessibilityEvent

class AirFlowAccessibilityService : AccessibilityService() {
    private var currentPkg = ""

    override fun onServiceConnected() {
        super.onServiceConnected()
        Prefs.init(this)
        instance = this
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event?.eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) {
            val p = event.packageName?.toString() ?: return
            if (p != packageName && p != "com.android.systemui" && !p.contains("inputmethod")) {
                currentPkg = p
            }
        }
    }

    override fun onInterrupt() {}

    override fun onUnbind(intent: Intent?): Boolean {
        instance = null
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        instance = null
        super.onDestroy()
    }

    fun perform(g: Gesture) {
        if (Prefs.onlyVideoApps) {
            val pkg = rootInActiveWindow?.packageName?.toString() ?: currentPkg
            if (pkg !in VIDEO_APPS) return
        }
        val dm = resources.displayMetrics
        val w = dm.widthPixels.toFloat()
        val h = dm.heightPixels.toFloat()
        when (g) {
            Gesture.SWIPE_UP -> swipe(w / 2, h * 0.72f, w / 2, h * 0.28f)
            Gesture.SWIPE_DOWN -> swipe(w / 2, h * 0.28f, w / 2, h * 0.72f)
            Gesture.SWIPE_LEFT -> swipe(w * 0.8f, h / 2, w * 0.2f, h / 2)
            Gesture.SWIPE_RIGHT -> swipe(w * 0.2f, h / 2, w * 0.8f, h / 2)
            Gesture.PALM_HOLD -> tap(w / 2, h / 2)
            Gesture.PINCH -> doubleTap(w / 2, h / 2)
            Gesture.FIST_HOLD -> performGlobalAction(GLOBAL_ACTION_BACK)
        }
    }

    private fun swipe(x1: Float, y1: Float, x2: Float, y2: Float) {
        val p = Path().apply { moveTo(x1, y1); lineTo(x2, y2) }
        val s = GestureDescription.StrokeDescription(p, 0, 180)
        dispatchGesture(GestureDescription.Builder().addStroke(s).build(), null, null)
    }

    private fun tap(x: Float, y: Float) {
        val p = Path().apply { moveTo(x, y) }
        val s = GestureDescription.StrokeDescription(p, 0, 50)
        dispatchGesture(GestureDescription.Builder().addStroke(s).build(), null, null)
    }

    private fun doubleTap(x: Float, y: Float) {
        val p1 = Path().apply { moveTo(x, y) }
        val p2 = Path().apply { moveTo(x, y) }
        val b = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(p1, 0, 40))
            .addStroke(GestureDescription.StrokeDescription(p2, 130, 40))
        dispatchGesture(b.build(), null, null)
    }

    companion object {
        @Volatile var instance: AirFlowAccessibilityService? = null

        val VIDEO_APPS = setOf(
            "com.google.android.youtube",
            "com.instagram.android",
            "com.facebook.katana",
            "com.facebook.lite",
            "com.zhiliaoapp.musically",
            "com.ss.android.ugc.trill",
            "com.snapchat.android",
            "in.mohalla.sharechat",
            "com.twitter.android",
            "com.linkedin.android"
        )
    }
}
