package com.airflow.app

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.CompositingStrategy
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

private const val TOTAL = 6.0f

private class Warp(val n: Int) {
    val a = FloatArray(n)
    val r0 = FloatArray(n)
    val v = FloatArray(n)

    init {
        val r = java.util.Random(42)
        for (i in 0 until n) {
            a[i] = r.nextFloat() * (2.0 * PI).toFloat()
            r0[i] = 0.02f + r.nextFloat() * 0.25f
            v[i] = r.nextFloat()
        }
    }
}

/**
 * The opening film (~6 s). Everything is drawn from one clock, so it plays like a video:
 * 1. warp-speed starfield   2. a neon hand draws itself, pinches and swipes
 * 3. shockwave -> the hand becomes the logo   4. title, tagline and feature chips
 * 5. camera push-in and cross-fade into the live app.  Tap anywhere to skip.
 */
@Composable
fun IntroScreen(onReveal: () -> Unit, onFinished: () -> Unit) {
    val c = Air.c
    val clock = remember { Animatable(0f) }
    val warp = remember { Warp(150) }

    LaunchedEffect(Unit) {
        clock.animateTo(TOTAL, tween((TOTAL * 1000).toInt(), easing = LinearEasing))
        onFinished()
    }
    LaunchedEffect(Unit) {
        snapshotFlow { clock.value >= 5.0f }.collect { if (it) onReveal() }
    }

    BoxWithConstraints(
        Modifier
            .fillMaxSize()
            .graphicsLayer {
                val k = smooth(seg(clock.value, 5.1f, TOTAL))
                alpha = 1f - k
                val z = 1f + 0.12f * k
                scaleX = z
                scaleY = z
            }
            .pointerInput(Unit) {
                detectTapGestures {
                    onReveal()
                    onFinished()
                }
            }
    ) {
        val cyDp = maxHeight * 0.40f
        val logoDp = min(maxWidth.value, maxHeight.value).dp * 0.34f

        Canvas(Modifier.fillMaxSize()) { drawIntro(clock.value, c, warp) }

        Column(
            Modifier.align(Alignment.TopCenter).offset(y = cyDp + logoDp / 2f + 40.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Row(
                Modifier
                    .graphicsLayer { compositingStrategy = CompositingStrategy.Offscreen }
                    .drawWithContent {
                        drawContent()
                        drawRect(
                            Brush.horizontalGradient(listOf(c.text, c.a2, c.a1, c.a3, c.text), startX = 0f, endX = size.width),
                            blendMode = BlendMode.SrcAtop
                        )
                        val x = (seg(clock.value, 4.2f, 5.0f) * 1.8f - 0.4f) * size.width
                        drawRect(
                            Brush.horizontalGradient(
                                listOf(Color.Transparent, Color.White.copy(alpha = 0.9f), Color.Transparent),
                                startX = x - size.width * 0.15f, endX = x + size.width * 0.15f
                            ),
                            blendMode = BlendMode.SrcAtop
                        )
                    }
            ) {
                "AIR FLOW".forEachIndexed { i, ch ->
                    Text(
                        ch.toString(),
                        fontSize = 40.sp,
                        fontWeight = FontWeight.Black,
                        letterSpacing = 4.sp,
                        color = Color.White,
                        modifier = Modifier.graphicsLayer {
                            val lp = easeOut(seg(clock.value, 3.7f + i * 0.07f, 4.3f + i * 0.07f))
                            alpha = lp
                            translationY = (1f - lp) * 40.dp.toPx()
                            val s = 1.6f - 0.6f * lp
                            scaleX = s
                            scaleY = s
                        }
                    )
                }
            }
            Spacer(Modifier.height(10.dp))
            Text(
                "Control everything. Touch nothing.",
                color = c.dim,
                fontSize = 15.sp,
                fontWeight = FontWeight.Medium,
                letterSpacing = 0.8.sp,
                modifier = Modifier.graphicsLayer {
                    val lp = easeOut(seg(clock.value, 4.4f, 5.0f))
                    alpha = lp
                    translationY = (1f - lp) * 18.dp.toPx()
                }
            )
            Spacer(Modifier.height(22.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                listOf("SWIPE", "PINCH", "CURSOR").forEachIndexed { i, label ->
                    Box(
                        Modifier
                            .graphicsLayer {
                                val lp = backOut(seg(clock.value, 4.55f + i * 0.12f, 5.0f + i * 0.12f))
                                alpha = clamp01(lp)
                                scaleX = lp
                                scaleY = lp
                            }
                            .clip(RoundedCornerShape(50))
                            .background(c.glass)
                            .border(1.dp, c.stroke, RoundedCornerShape(50))
                            .padding(horizontal = 14.dp, vertical = 7.dp)
                    ) {
                        Text(label, color = c.text, fontSize = 12.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.4.sp)
                    }
                }
            }
        }

        Text(
            "Tap to skip",
            color = c.dim,
            fontSize = 12.sp,
            modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = 36.dp).graphicsLayer {
                alpha = 0.6f * smooth(seg(clock.value, 1.0f, 1.6f)) * (1f - smooth(seg(clock.value, 4.7f, 5.1f)))
            }
        )
    }
}

private fun DrawScope.drawIntro(t: Float, c: AirColors, warp: Warp) {
    val w = size.width
    val h = size.height
    val cx = w / 2f
    val cy = h * 0.40f
    val diag = hypot(w, h)
    val plus = if (c.dark) BlendMode.Plus else BlendMode.SrcOver

    drawRect(Brush.verticalGradient(listOf(c.bg0, c.bg1, c.bg0)))

    // light bloom that grows with the story
    val bloom = smooth(seg(t, 0.3f, 2.8f))
    val burst = smooth(seg(t, 2.9f, 3.6f))
    fun glow(x: Float, y: Float, r: Float, col: Color, a: Float) {
        if (a <= 0.01f) return
        drawCircle(
            Brush.radialGradient(listOf(col.copy(alpha = a.coerceIn(0f, 1f)), Color.Transparent), Offset(x, y), r),
            r, Offset(x, y), blendMode = plus
        )
    }
    glow(cx, cy, diag * (0.30f + 0.25f * bloom + 0.2f * burst), c.a1, 0.38f * bloom + 0.25f * burst)
    glow(cx + w * 0.22f, cy + h * 0.10f, diag * 0.30f, c.a2, 0.28f * bloom + 0.12f * burst)
    glow(cx - w * 0.26f, cy + h * 0.20f, diag * 0.28f, c.a3, 0.22f * burst)

    // 1. warp-speed starfield
    val u = seg(t, 0f, 2.6f)
    val fade = smooth(seg(t, 0f, 0.5f)) * (1f - smooth(seg(t, 1.8f, 2.8f)))
    if (fade > 0.01f) {
        for (i in 0 until warp.n) {
            val r = warp.r0[i] * diag * 0.5f + u * u * u * diag * (0.25f + warp.v[i])
            val r2 = max(0f, r - (6f + 110f * u * u))
            val dx = cos(warp.a[i])
            val dy = sin(warp.a[i])
            val col = if (c.dark) (if (i % 3 == 0) c.a2 else Color.White) else (if (i % 3 == 0) c.a1 else if (i % 3 == 1) c.a2 else c.a3)
            drawLine(
                col.copy(alpha = fade * (0.3f + 0.7f * warp.v[i])),
                Offset(cx + dx * r2, cy + dy * r2), Offset(cx + dx * r, cy + dy * r),
                strokeWidth = 1.2f + 2f * u, cap = StrokeCap.Round
            )
        }
    }

    // 2. the neon hand draws itself, pinches and swipes
    val s = min(w, h) * 0.46f
    val handA = smooth(seg(t, 0.6f, 1.0f)) * (1f - smooth(seg(t, 3.0f, 3.5f)))
    if (handA > 0.01f) {
        val pinch = (smooth(seg(t, 2.0f, 2.35f)) - smooth(seg(t, 2.45f, 2.8f))).coerceIn(0f, 1f)
        val pts = computeHand(lerpPose(Poses.OPEN, Poses.PINCH, pinch))
        val lift = smooth(seg(t, 2.8f, 3.3f))
        val origin = Offset(cx, cy + 0.62f * s - lift * s * 0.35f)
        val sc = s * (1f + 0.04f * sin(t * 3f))
        drawHand(
            pts, origin, sc, c.a2, c.a1, alpha = handA, glow = 1f,
            lineW = s * 0.016f + 1.5f, dotR = s * 0.022f + 2f, reveal = seg(t, 0.6f, 1.9f)
        )
        // pinch ripple at the fingertips
        val rp = seg(t, 2.3f, 2.9f)
        if (rp > 0f && rp < 1f) {
            val tip = Offset(origin.x + pts[8].x * sc, origin.y + pts[8].y * sc)
            drawCircle(c.a2.copy(alpha = (1f - rp) * 0.7f), s * 0.05f + s * 0.38f * easeOut(rp), tip, style = Stroke(3f))
        }
        // swipe-up light trails
        if (lift > 0f && lift < 1f) {
            for (f in intArrayOf(8, 12, 16, 20)) {
                val p = Offset(origin.x + pts[f].x * sc, origin.y + pts[f].y * sc)
                drawLine(
                    Brush.verticalGradient(listOf(c.a2.copy(alpha = 0.6f * (1f - lift)), Color.Transparent), p.y, p.y + s * 0.55f),
                    Offset(p.x, p.y), Offset(p.x, p.y + s * 0.55f), strokeWidth = 3f, cap = StrokeCap.Round
                )
            }
        }
    }

    // 3. shockwave rings
    for (k in 0..2) {
        val rs = seg(t, 3.0f + k * 0.18f, 4.4f + k * 0.18f)
        if (rs > 0f && rs < 1f) {
            val col = when (k) { 0 -> c.a2; 1 -> c.a1; else -> c.a3 }
            drawCircle(
                col.copy(alpha = (1f - rs) * (0.6f - 0.12f * k)), easeOut(rs) * diag * 0.55f, Offset(cx, cy),
                style = Stroke(width = 7f - 5f * rs)
            )
        }
    }

    // ...and the hand turns into the logo
    val lp = seg(t, 3.0f, 3.9f)
    if (lp > 0f) {
        val logo = min(w, h) * 0.34f * backOut(lp)
        drawLogoBadge(
            Offset(cx, cy), logo, spin = t * 120f, c1 = c.a1, c2 = c.a2, c3 = c.a3,
            glow = smooth(lp), markAlpha = smooth(seg(lp, 0.2f, 0.7f))
        )
        val orbit = smooth(seg(t, 4.0f, 4.6f))
        if (orbit > 0f) {
            for (k in 0..2) {
                val a = t * 2.4f + k * 2.094f
                val rr = logo * 0.80f
                drawCircle(Color.White.copy(alpha = 0.85f * orbit), logo * 0.022f, Offset(cx + cos(a) * rr, cy + sin(a) * rr))
                drawCircle(c.a2.copy(alpha = 0.25f * orbit), logo * 0.06f, Offset(cx + cos(a) * rr, cy + sin(a) * rr))
            }
        }
    }
}
