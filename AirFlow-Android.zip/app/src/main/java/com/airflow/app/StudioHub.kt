package com.airflow.app

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

// ---------------------------------------------------------------------------------------------
// Studio: one premium home for the three air tools (music, drawing, teaching board)
// ---------------------------------------------------------------------------------------------

@Composable
fun StudioScreen(page: Int, onPage: (Int) -> Unit) {
    AnimatedContent(
        targetState = page,
        transitionSpec = { fadeIn(tween(220)) togetherWith fadeOut(tween(160)) },
        label = "studio"
    ) { p ->
        when (p) {
            1 -> AirMusicScreen()
            2 -> AirDrawScreen()
            3 -> AirBoardScreen()
            else -> StudioHub(onPage)
        }
    }
}

@Composable
private fun StudioHub(onOpen: (Int) -> Unit) {
    val c = Air.c
    AirScroll {
        Column(Modifier.fillMaxWidth().padding(top = 4.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            GradientText(
                "STUDIO",
                MaterialTheme.typography.headlineLarge.copy(fontSize = 32.sp, letterSpacing = 5.sp),
                listOf(c.text, c.a2, c.a1, c.a3)
            )
            Spacer(Modifier.height(4.dp))
            Text(
                "Three instruments for your hands. Nothing is touched, everything runs on the phone.",
                style = MaterialTheme.typography.bodyMedium, color = c.dim, textAlign = TextAlign.Center
            )
        }

        StudioCard(
            title = "Air Music",
            subtitle = "A Casio in the air. Both hands play, ten fingers, six instruments.",
            tag = "MUSIC",
            accent = c.a2,
            onOpen = { onOpen(1) }
        ) { MusicPreview() }

        StudioCard(
            title = "Air Draw",
            subtitle = "Pinch to draw, neon ink, 13 sample outlines to trace, save to Gallery.",
            tag = "DRAW",
            accent = c.a3,
            onOpen = { onOpen(2) }
        ) { DrawPreview() }

        StudioCard(
            title = "Air Board",
            subtitle = "A teaching board: laser pointer, snapping shapes, pages, 3D molecules.",
            tag = "BOARD",
            accent = c.ok,
            onOpen = { onOpen(3) }
        ) { BoardPreview() }

        GlassCard(Modifier.fillMaxWidth()) {
            Text("Gestures", style = MaterialTheme.typography.titleMedium, color = c.text)
            Hint("Pinch", "Pen down · press a button · rotate a molecule")
            Hint("One finger", "Draw or point")
            Hint("Two fingers", "Laser pointer with a fading trail")
            Hint("Open palm", "Erase · swipe left or right to change page")
            Hint("Tap Studio again", "Come back to this screen")
        }
    }
}

@Composable
private fun Hint(g: String, what: String) {
    val c = Air.c
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Box(
            Modifier
                .clip(RoundedCornerShape(50))
                .background(c.glassHi)
                .border(1.dp, c.stroke, RoundedCornerShape(50))
                .padding(horizontal = 9.dp, vertical = 3.dp)
        ) {
            Text(g, color = c.a2, fontSize = 10.sp, fontWeight = FontWeight.Black)
        }
        Spacer(Modifier.width(10.dp))
        Text(what, style = MaterialTheme.typography.bodySmall, color = c.dim)
    }
}

@Composable
private fun StudioCard(
    title: String,
    subtitle: String,
    tag: String,
    accent: Color,
    onOpen: () -> Unit,
    preview: @Composable () -> Unit
) {
    val c = Air.c
    GlassCard(Modifier.fillMaxWidth(), onClick = onOpen) {
        Box(
            Modifier
                .fillMaxWidth()
                .height(104.dp)
                .clip(RoundedCornerShape(18.dp))
                .background(if (c.dark) Color(0x9904050D) else Color(0x0F14172B))
        ) {
            preview()
            Box(
                Modifier
                    .align(Alignment.TopStart)
                    .padding(8.dp)
                    .clip(RoundedCornerShape(50))
                    .background(accent.copy(alpha = 0.18f))
                    .border(1.dp, accent.copy(alpha = 0.45f), RoundedCornerShape(50))
                    .padding(horizontal = 9.dp, vertical = 3.dp)
            ) {
                Text(tag, color = accent, fontSize = 9.sp, fontWeight = FontWeight.Black, letterSpacing = 1.5.sp)
            }
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(title, style = MaterialTheme.typography.titleLarge, color = c.text)
                Text(subtitle, style = MaterialTheme.typography.bodySmall, color = c.dim)
            }
            Spacer(Modifier.width(10.dp))
            Box(
                Modifier
                    .size(44.dp)
                    .clip(CircleShape)
                    .background(Brush.linearGradient(listOf(c.a1, accent))),
                contentAlignment = Alignment.Center
            ) { AirIcon(IconKind.PLAY, Color.White, Modifier.size(20.dp)) }
        }
    }
}

// ---------------------------------------------------------------------------------------------
// Little animated previews
// ---------------------------------------------------------------------------------------------

@Composable
private fun tick(): Float {
    val inf = rememberInfiniteTransition(label = "prev")
    val t = inf.animateFloat(0f, 1f, infiniteRepeatable(tween(6000, easing = LinearEasing)), label = "t")
    return t.value
}

@Composable
private fun MusicPreview() {
    val c = Air.c
    val t = tick()
    Canvas(Modifier.fillMaxSize()) {
        val keys = 9
        val kw = size.width / keys
        for (i in 0 until keys) {
            val glow = (0.5f + 0.5f * sin((t * 6.2832f * 2f) - i * 0.7f)).coerceIn(0f, 1f)
            drawRoundRect(
                Brush.verticalGradient(
                    listOf(Color(0xFFFDFEFF), Color(0xFFD7E1F5))
                ),
                Offset(i * kw + 2f, size.height * 0.35f), Size(kw - 4f, size.height * 0.65f),
                CornerRadius(5f, 5f)
            )
            if (glow > 0.55f) {
                drawRoundRect(
                    Brush.verticalGradient(listOf(c.a2.copy(alpha = 0.9f), c.a1.copy(alpha = 0.6f))),
                    Offset(i * kw + 2f, size.height * 0.35f), Size(kw - 4f, size.height * 0.65f),
                    CornerRadius(5f, 5f)
                )
            }
        }
        // a floating note
        val y = size.height * (0.35f - 0.25f * ((t * 1.7f) % 1f))
        drawCircle(c.a3.copy(alpha = 0.8f), 4f, Offset(size.width * 0.5f, y))
    }
}

@Composable
private fun DrawPreview() {
    val c = Air.c
    val t = tick()
    Canvas(Modifier.fillMaxSize()) {
        val path = Path()
        val n = 60
        for (i in 0..n) {
            val u = i / n.toFloat()
            val x = u * size.width
            val y = size.height * (0.5f + 0.22f * sin(u * 6.2f + t * 6.2832f))
            if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
        }
        drawPath(path, c.a2.copy(alpha = 0.25f), style = Stroke(12f, cap = StrokeCap.Round))
        drawPath(path, Color.White, style = Stroke(3f, cap = StrokeCap.Round))
        val hx = size.width * ((t * 1.3f) % 1f)
        val hy = size.height * (0.5f + 0.22f * sin((hx / size.width) * 6.2f + t * 6.2832f))
        drawCircle(c.a3.copy(alpha = 0.35f), 12f, Offset(hx, hy))
        drawCircle(c.a3, 4f, Offset(hx, hy))
    }
}

@Composable
private fun BoardPreview() {
    val c = Air.c
    val t = tick()
    Canvas(Modifier.fillMaxSize()) {
        // graph paper
        var y = 14f
        while (y < size.height) {
            var x = 14f
            while (x < size.width) {
                drawCircle(c.text.copy(alpha = 0.10f), 1f, Offset(x, y))
                x += 14f
            }
            y += 14f
        }
        val m = Molecules.all[0]
        drawMoleculePreview(m, t * 6.2832f, size.width * 0.5f, size.height * 0.52f, size.minDimension * 0.20f)
    }
}

/** A compact version of the molecule renderer, for the hub preview. */
private fun DrawScope.drawMoleculePreview(m: Molecule, ay: Float, cx: Float, cy: Float, scale: Float) {
    val pts = m.project(0.35f, ay, 0f)
    val n = pts.size
    val sx = FloatArray(n)
    val sy = FloatArray(n)
    val sr = FloatArray(n)
    val sz = FloatArray(n)
    for (i in 0 until n) {
        val persp = 8f / (8f + pts[i].z * 0.8f)
        sx[i] = cx + pts[i].x * scale * persp
        sy[i] = cy + pts[i].y * scale * persp
        sr[i] = Elements.radius(pts[i].el) * scale * persp
        sz[i] = pts[i].z
    }
    for (b in m.bonds) {
        if (b.a >= n || b.b >= n) continue
        drawLine(
            Color(0xFFC6D0EC).copy(alpha = 0.8f),
            Offset(sx[b.a], sy[b.a]), Offset(sx[b.b], sy[b.b]),
            strokeWidth = (scale * 0.10f).coerceIn(2f, 6f), cap = StrokeCap.Round
        )
    }
    for (i in (0 until n).sortedBy { sz[it] }) {
        val col = Color(Elements.color(pts[i].el))
        drawCircle(
            Brush.radialGradient(
                listOf(col, col.copy(alpha = 0.6f)),
                Offset(sx[i] - sr[i] * 0.3f, sy[i] - sr[i] * 0.35f), sr[i] * 1.4f
            ),
            sr[i], Offset(sx[i], sy[i])
        )
        drawCircle(Color.White.copy(alpha = 0.3f), sr[i] * 0.3f, Offset(sx[i] - sr[i] * 0.3f, sy[i] - sr[i] * 0.35f))
    }
}
