package com.airflow.app

import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.State
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import kotlin.math.PI
import kotlin.math.min
import kotlin.math.sin

private const val TAU = (2.0 * PI).toFloat()

/** Fixed random layout for stars / bokeh, so the field never reshuffles. */
private class Field(n: Int, seed: Int) {
    val x = FloatArray(n)
    val y = FloatArray(n)
    val speed = IntArray(n)
    val twinkle = IntArray(n)
    val phase = FloatArray(n)
    val size = FloatArray(n)

    init {
        val r = java.util.Random(seed.toLong())
        for (i in 0 until n) {
            x[i] = r.nextFloat()
            y[i] = r.nextFloat()
            speed[i] = 1 + r.nextInt(3)
            twinkle[i] = 20 + r.nextInt(40)
            phase[i] = r.nextFloat()
            size[i] = 0.5f + r.nextFloat()
        }
    }
}

private fun frac(v: Float): Float {
    val f = v - Math.floor(v.toDouble()).toFloat()
    return if (f < 0f) f + 1f else f
}

/** How "awake" the app is: 0 idle, 0.45 service running, 0.8 hand seen, 1 cursor mode. */
@Composable
private fun rememberEnergy(): State<Float> {
    val running by AirFlowState.running.collectAsState()
    val hand by AirFlowState.handVisible.collectAsState()
    val cursor by AirFlowState.cursorMode.collectAsState()
    val target = if (!running) 0.12f else if (cursor) 1f else if (hand) 0.8f else 0.45f
    return animateFloatAsState(target, tween(900), label = "energy")
}

/**
 * The living wallpaper behind the whole app. Dark = "Aurora Night" (aurora ribbons, stars and a
 * glowing hand constellation). Light = "Pearl Silk" (silk ribbons, pastel light and floating bokeh).
 * It reacts to the app: brighter when the service runs, brightest in cursor mode.
 */
@Composable
fun LiveBackground(modifier: Modifier = Modifier) {
    val c = Air.c
    val energy = rememberEnergy()
    val scroll = LocalScroll.current
    val inf = rememberInfiniteTransition(label = "bg")
    val t = inf.animateFloat(0f, 1f, infiniteRepeatable(tween(90000, easing = LinearEasing)), label = "t")
    val stars = remember { Field(90, 7) }
    val bokeh = remember { Field(26, 11) }
    val hand = remember { computeHand(Poses.OPEN) }

    Crossfade(targetState = c.dark, animationSpec = tween(800), modifier = modifier.fillMaxSize(), label = "bgfade") { dark ->
        Canvas(Modifier.fillMaxSize()) {
            val sy = (scroll?.floatValue ?: 0f)
            if (dark) {
                drawAurora(DarkAir, t.value, energy.value, sy, stars, hand)
            } else {
                drawSilk(LightAir, t.value, energy.value, sy, bokeh, hand)
            }
        }
    }
}

private fun DrawScope.blob(cx: Float, cy: Float, r: Float, color: Color, a: Float, plus: Boolean) {
    drawCircle(
        Brush.radialGradient(listOf(color.copy(alpha = a.coerceIn(0f, 1f)), Color.Transparent), Offset(cx, cy), r),
        r, Offset(cx, cy), blendMode = if (plus) BlendMode.Plus else BlendMode.SrcOver
    )
}

private fun DrawScope.drawAurora(c: AirColors, t: Float, e: Float, scroll: Float, stars: Field, hand: Array<Offset>) {
    val w = size.width
    val h = size.height
    val par = -scroll * 0.06f
    drawRect(Brush.verticalGradient(listOf(c.bg0, c.bg1, c.bg0)))

    val a = 0.30f + 0.28f * e
    blob(w * (0.2f + 0.25f * sin(TAU * t)), h * 0.18f + par, w * 0.95f, c.a1, a, true)
    blob(w * (0.85f - 0.25f * sin(TAU * (t * 2f + 0.3f))), h * 0.35f + par * 0.7f, w * 0.85f, c.a2, a * 0.8f, true)
    blob(w * (0.5f + 0.35f * sin(TAU * (t * 3f + 0.6f))), h * 0.78f + par * 0.4f, w * 0.9f, c.a3, a * 0.55f, true)

    // aurora ribbons
    val steps = 28
    for (k in 0 until 3) {
        val col = when (k) { 0 -> c.a2; 1 -> c.a1; else -> c.a3 }
        val base = h * (0.16f + 0.17f * k) + par * (0.9f - 0.2f * k)
        val amp = h * (0.05f + 0.015f * k)
        val path = Path()
        for (i in 0..steps) {
            val xf = i / steps.toFloat()
            val yy = base + amp * sin(TAU * (xf * (1.1f + 0.4f * k) + t * (2 + k))) +
                amp * 0.5f * sin(TAU * (xf * 2.3f - t * (3 - k)))
            if (i == 0) path.moveTo(0f, yy) else path.lineTo(xf * w, yy)
        }
        val thick = h * (0.16f + 0.05f * e)
        for (i in steps downTo 0) {
            val xf = i / steps.toFloat()
            val yy = base + amp * sin(TAU * (xf * (1.1f + 0.4f * k) + t * (2 + k))) +
                amp * 0.5f * sin(TAU * (xf * 2.3f - t * (3 - k)))
            path.lineTo(xf * w, yy + thick * (0.6f + 0.4f * sin(TAU * (xf * 3f + t * 4f + k))))
        }
        path.close()
        drawPath(
            path,
            Brush.verticalGradient(
                listOf(col.copy(alpha = 0f), col.copy(alpha = 0.16f + 0.16f * e), col.copy(alpha = 0f)),
                startY = base - amp, endY = base + thick + amp
            ),
            blendMode = BlendMode.Plus
        )
    }

    // glowing hand constellation
    val hs = min(w, h) * 0.85f
    val ho = Offset(w * 0.64f, h * 0.60f + par * 0.5f)
    rotate(6f * sin(TAU * t * 2f), Offset(ho.x, ho.y)) {
        drawHand(
            hand, ho, hs, c.a2, c.a1,
            alpha = 0.10f + 0.20f * e, glow = 0.6f, lineW = 1.4f, dotR = 2.6f
        )
    }

    // stars
    for (i in stars.x.indices) {
        val yy = frac(stars.y[i] - t * stars.speed[i]) * h
        val tw = 0.5f + 0.5f * sin(TAU * (t * stars.twinkle[i] + stars.phase[i]))
        val al = (0.18f + 0.7f * tw) * (0.55f + 0.45f * e)
        val col = if (i % 5 == 0) c.a2 else if (i % 7 == 0) c.a3 else Color.White
        drawCircle(col.copy(alpha = al), 0.9f * stars.size[i] * (1f + e * 0.6f), Offset(stars.x[i] * w, yy))
    }
}

private fun DrawScope.drawSilk(c: AirColors, t: Float, e: Float, scroll: Float, bokeh: Field, hand: Array<Offset>) {
    val w = size.width
    val h = size.height
    val par = -scroll * 0.05f
    drawRect(Brush.linearGradient(listOf(c.bg0, c.bg1, Color(0xFFFFF1F6)), Offset.Zero, Offset(w, h)))

    val a = 0.55f + 0.2f * e
    blob(w * (0.15f + 0.2f * sin(TAU * t)), h * 0.12f + par, w * 0.9f, Color(0xFFFFC9AE), a, false)
    blob(w * (0.9f - 0.22f * sin(TAU * (t * 2f + 0.2f))), h * 0.3f + par * 0.7f, w * 0.85f, Color(0xFFA9D9FF), a, false)
    blob(w * (0.3f + 0.3f * sin(TAU * (t * 3f + 0.5f))), h * 0.62f + par * 0.5f, w * 0.9f, Color(0xFFD3BBFF), a * 0.9f, false)
    blob(w * (0.85f + 0.1f * sin(TAU * (t * 2f + 0.8f))), h * 0.92f + par * 0.3f, w * 0.8f, Color(0xFFFFB9D6), a * 0.85f, false)

    // flowing silk ribbons
    val steps = 30
    for (k in 0 until 4) {
        val col = when (k) { 0 -> c.a1; 1 -> c.a2; 2 -> c.a3; else -> c.a1 }
        val base = h * (0.22f + 0.2f * k) + par * (1f - 0.2f * k)
        val amp = h * (0.035f + 0.012f * k)
        val path = Path()
        for (i in 0..steps) {
            val xf = i / steps.toFloat()
            val yy = base + amp * sin(TAU * (xf * (0.9f + 0.3f * k) - t * (2 + k % 2))) +
                amp * 0.6f * sin(TAU * (xf * 2.1f + t * 3f + k))
            if (i == 0) path.moveTo(0f, yy) else path.lineTo(xf * w, yy)
        }
        path.lineTo(w, base + h * 0.30f)
        path.lineTo(0f, base + h * 0.30f)
        path.close()
        drawPath(
            path,
            Brush.verticalGradient(
                listOf(col.copy(alpha = 0.16f + 0.10f * e), col.copy(alpha = 0f)),
                startY = base - amp, endY = base + h * 0.28f
            )
        )
    }

    // faint hand outline
    val hs = min(w, h) * 0.85f
    val ho = Offset(w * 0.64f, h * 0.60f + par * 0.5f)
    rotate(5f * sin(TAU * t * 2f), Offset(ho.x, ho.y)) {
        drawHand(hand, ho, hs, c.a1, c.a3, alpha = 0.07f + 0.10f * e, glow = 0f, lineW = 1.6f, dotR = 2.6f)
    }

    // bokeh bubbles rising slowly
    for (i in bokeh.x.indices) {
        val yy = frac(bokeh.y[i] - t * bokeh.speed[i]) * (h + 80f) - 40f
        val r = (10f + 30f * bokeh.size[i]) * (1f + 0.15f * sin(TAU * (t * bokeh.twinkle[i] + bokeh.phase[i])))
        val ox = bokeh.x[i] * w + 12f * sin(TAU * (t * 2f + bokeh.phase[i]))
        val col = if (i % 3 == 0) c.a1 else if (i % 3 == 1) c.a2 else c.a3
        drawCircle(Color.White.copy(alpha = 0.30f), r, Offset(ox, yy))
        drawCircle(col.copy(alpha = 0.10f + 0.05f * e), r, Offset(ox, yy), style = Stroke(1.5f))
    }
}
