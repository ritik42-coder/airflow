package com.airflow.app

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Paint
import android.graphics.PointF
import android.graphics.Typeface
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.State
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.exp
import kotlin.math.sin
import kotlinx.coroutines.delay

// ---------------------------------------------------------------------------------------------
// Air Music: a Casio in the air. Both hands play. Nothing is touched.
// ---------------------------------------------------------------------------------------------

private val TIPS = intArrayOf(4, 8, 12, 16, 20)

private class Spark(
    var x: Float, var y: Float, var vx: Float, var vy: Float,
    var life: Float, var max: Float, var col: Int
)

private class Ripple(var x: Float, var life: Float, var max: Float)

private class FloatNote(var text: String, var x: Float, var y: Float, var life: Float, var max: Float)

private class Pending(val at: Long, val midi: Int)

/**
 * Everything that moves on the Air Music screen. Plain Kotlin on purpose: the draw code reads it
 * every frame and no recomposition is needed to animate a spark.
 */
private class MusicEngine(private val synth: AirSynth) {

    var stageW = 1f
    var stageH = 1f
    var keysW = 1f
    var keysH = 1f

    /** Where the invisible "touch plane" sits inside the camera view, 0..1 from the top. */
    var planeY = 0.58f

    var startMidi = 60
    var whiteCount = 14
    var keys = Keys(60, 14)

    var time = 0f
    var level = 0f
    var hands: List<List<PointF>> = emptyList()
    var hoverMidi = -1
    var targetMidi = -1
    var handsOn = true

    /** Called on the main thread when the player hits the note the Learn mode is waiting for. */
    var onHit: ((Int) -> Unit)? = null

    val flash = FloatArray(128)
    val sparks = ArrayList<Spark>()
    val ripples = ArrayList<Ripple>()
    val floats = ArrayList<FloatNote>()

    private val pending = ArrayList<Pending>()
    private val tipKey = HashMap<Int, Int>()
    private val noteRefs = HashMap<Int, Int>()

    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        textAlign = Paint.Align.CENTER
    }

    // ------------------------------------------------------------------------------ geometry

    fun setStageSize(w: Float, h: Float) {
        stageW = w
        stageH = h
    }

    fun setKeysSize(w: Float, h: Float) {
        keysW = w
        keysH = h
    }

    fun setKeyboard(start: Int, whites: Int) {
        if (start == startMidi && whites == whiteCount) return
        releaseAll()
        startMidi = start
        whiteCount = whites
        keys = Keys(start, whites)
    }

    // ------------------------------------------------------------------------------ playing

    fun onHands(hs: List<List<PointF>>) {
        hands = hs
        if (!handsOn) {
            releaseAll()
            return
        }
        val seen = HashSet<Int>()
        var hover = -1
        for (hi in hs.indices) {
            val hand = hs[hi]
            if (hand.size < 21) continue
            for (tip in TIPS) {
                val p = hand[tip]
                val id = hi * 32 + tip
                if (p.y > planeY) {
                    val midi = keys.keyAt(p.x)
                    seen.add(id)
                    val prev = tipKey[id]
                    if (prev == null || prev != midi) {
                        if (prev != null) releaseNote(prev)
                        tipKey[id] = midi
                        val depth = ((p.y - planeY) / (1f - planeY).coerceAtLeast(0.01f)).coerceIn(0f, 1f)
                        pressNote(midi, 0.45f + 0.55f * depth, hi, p.x * stageW, p.y * stageH)
                    }
                } else if (hover < 0) {
                    hover = keys.keyAt(p.x)
                }
            }
        }
        hoverMidi = hover
        val it = tipKey.entries.iterator()
        while (it.hasNext()) {
            val e = it.next()
            if (!seen.contains(e.key)) {
                releaseNote(e.value)
                it.remove()
            }
        }
    }

    private fun pressNote(midi: Int, vel: Float, hand: Int, sx: Float, sy: Float) {
        val n = (noteRefs[midi] ?: 0) + 1
        noteRefs[midi] = n
        flash[midi] = 1f
        if (n == 1) {
            synth.noteOn(midi, vel, if (hand == 0) -0.35f else 0.35f)
            burst(midi, vel)
            if (midi == targetMidi) onHit?.invoke(midi)
        }
        floats.add(FloatNote(noteName(midi), sx, sy, 0.9f, 0.9f))
        if (floats.size > 24) floats.removeAt(0)
    }

    private fun releaseNote(midi: Int) {
        val n = (noteRefs[midi] ?: 1) - 1
        if (n <= 0) {
            noteRefs.remove(midi)
            synth.noteOff(midi)
        } else {
            noteRefs[midi] = n
        }
    }

    fun releaseAll() {
        tipKey.clear()
        noteRefs.clear()
        synth.allNotesOff()
    }

    /** Play a note for the demo player. */
    fun autoNote(midi: Int, durMs: Float, hand: Int) {
        flash[midi] = 1f
        synth.noteOn(midi, 0.78f, if (hand == 0) -0.45f else 0.45f)
        burst(midi, 0.78f)
        pending.add(Pending(SystemClock.uptimeMillis() + durMs.toLong(), midi))
        val cx = keys.centerX(midi)
        if (cx >= 0f) floats.add(FloatNote(noteName(midi), cx * stageW, stageH * 0.62f, 0.9f, 0.9f))
        if (floats.size > 24) floats.removeAt(0)
    }

    private fun burst(midi: Int, vel: Float) {
        val cx = keys.centerX(midi)
        if (cx < 0f) return
        ripples.add(Ripple(cx, 0.55f, 0.55f))
        if (ripples.size > 20) ripples.removeAt(0)
        val n = 6 + (vel * 8f).toInt()
        for (k in 0 until n) {
            val a = (Math.random() * 6.28318).toFloat()
            val sp = 0.10f + 0.35f * Math.random().toFloat()
            sparks.add(
                Spark(
                    cx, keysH * 0.55f,
                    cos(a) * sp * 0.35f, -abs(sin(a)) * (140f + 320f * Math.random().toFloat()),
                    0.5f + 0.45f * Math.random().toFloat(), 0.95f,
                    (Math.random() * 3).toInt()
                )
            )
        }
        while (sparks.size > 90) sparks.removeAt(0)
    }

    // ------------------------------------------------------------------------------ frame

    fun frame(dt: Float) {
        time += dt
        level += (synth.level - level) * 0.22f

        val fd = exp(-dt * 5.5f)
        for (i in 0 until 128) if (flash[i] > 0.002f) flash[i] *= fd

        var i = 0
        while (i < sparks.size) {
            val s = sparks[i]
            s.life -= dt
            if (s.life <= 0f) {
                sparks.removeAt(i)
            } else {
                s.x += s.vx * dt
                s.y += s.vy * dt
                s.vy += 620f * dt
                s.vx *= 0.985f
                i++
            }
        }
        i = 0
        while (i < ripples.size) {
            ripples[i].life -= dt
            if (ripples[i].life <= 0f) ripples.removeAt(i) else i++
        }
        i = 0
        while (i < floats.size) {
            val f = floats[i]
            f.life -= dt
            if (f.life <= 0f) {
                floats.removeAt(i)
            } else {
                f.y -= 46f * dt
                i++
            }
        }
        val now = SystemClock.uptimeMillis()
        i = 0
        while (i < pending.size) {
            val p = pending[i]
            if (now >= p.at) {
                synth.noteOff(p.midi)
                pending.removeAt(i)
            } else {
                i++
            }
        }
    }

    // ------------------------------------------------------------------------------ drawing

    fun DrawScope.drawStage(c: AirColors, t: Float) {
        val w = size.width
        val h = size.height
        if (w <= 2f || h <= 2f) return
        val py = h * planeY

        // the play zone under the plane glows with the music
        drawRect(
            Brush.verticalGradient(
                listOf(
                    c.a2.copy(alpha = 0f),
                    c.a2.copy(alpha = 0.07f + 0.09f * level),
                    c.a1.copy(alpha = 0.13f + 0.10f * level)
                )
            ),
            topLeft = Offset(0f, py),
            size = Size(w, h - py)
        )

        // the touch plane itself
        val pulse = 0.55f + 0.45f * sin(t * 2.2f)
        drawLine(c.a2.copy(alpha = 0.06f + 0.05f * pulse), Offset(0f, py), Offset(w, py), strokeWidth = 30f)
        drawLine(c.a2.copy(alpha = 0.16f + 0.10f * pulse), Offset(0f, py), Offset(w, py), strokeWidth = 11f)
        drawLine(
            Brush.horizontalGradient(
                listOf(Color.Transparent, c.a2.copy(alpha = 0.85f), Color.White, c.a2.copy(alpha = 0.85f), Color.Transparent)
            ),
            Offset(0f, py), Offset(w, py), strokeWidth = 2.5f
        )
        for (k in 0..6) {
            val x = w * (k + 0.5f) / 7f
            drawLine(c.a2.copy(alpha = 0.22f * pulse), Offset(x, py - 9f), Offset(x, py + 9f), strokeWidth = 2f, cap = StrokeCap.Round)
        }

        // hover: which key your fingertip is over right now
        if (hoverMidi >= 0) {
            val hx = keys.centerX(hoverMidi)
            if (hx >= 0f) {
                val kw = keys.step * w * (if (isWhiteNote(hoverMidi)) 0.9f else 0.55f)
                drawRect(
                    Brush.verticalGradient(listOf(Color.Transparent, c.a2.copy(alpha = 0.13f))),
                    topLeft = Offset(hx * w - kw / 2f, py),
                    size = Size(kw, h - py)
                )
            }
        }

        // both hands, live
        for (hand in hands) {
            if (hand.size < 21) continue
            for ((a, b) in HAND_BONES) {
                val p1 = Offset(hand[a].x * w, hand[a].y * h)
                val p2 = Offset(hand[b].x * w, hand[b].y * h)
                drawLine(c.a2.copy(alpha = 0.14f), p1, p2, strokeWidth = 13f, cap = StrokeCap.Round)
                drawLine(Color.White.copy(alpha = 0.55f), p1, p2, strokeWidth = 2.4f, cap = StrokeCap.Round)
            }
            for (tip in TIPS) {
                val p = hand[tip]
                val o = Offset(p.x * w, p.y * h)
                val down = p.y > planeY
                val col = if (down) c.a3 else c.a2
                if (down) {
                    drawLine(
                        Brush.verticalGradient(listOf(col.copy(alpha = 0.55f), col.copy(alpha = 0f))),
                        o, Offset(o.x, h), strokeWidth = 5f
                    )
                    drawLine(col.copy(alpha = 0.5f), o, Offset(o.x, py), strokeWidth = 2.5f)
                }
                drawCircle(col.copy(alpha = 0.22f), if (down) 24f else 14f, o)
                drawCircle(col.copy(alpha = 0.85f), if (down) 8f else 5.5f, o)
                drawCircle(Color.White, 2.6f, o)
            }
        }

        // learn mode: the note we are waiting for
        if (targetMidi >= 0) {
            val tx = keys.centerX(targetMidi)
            if (tx >= 0f) {
                val a = 0.45f + 0.55f * (0.5f + 0.5f * sin(t * 5f))
                drawLine(
                    Brush.verticalGradient(listOf(c.ok.copy(alpha = 0.9f * a), Color.Transparent)),
                    Offset(tx * w, py), Offset(tx * w, h), strokeWidth = 4f
                )
                drawCircle(c.ok.copy(alpha = 0.18f * a), 30f, Offset(tx * w, py))
                drawCircle(c.ok.copy(alpha = 0.9f * a), 7f, Offset(tx * w, py))
                textPaint.color = c.ok.copy(alpha = 0.55f + 0.45f * a).toArgb()
                textPaint.textSize = 30f
                drawIntoCanvas { it.nativeCanvas.drawText(noteName(targetMidi), tx * w, py - 46f, textPaint) }
            }
        }

        // note names rising from the fingertips
        for (f in floats) {
            val a = (f.life / f.max).coerceIn(0f, 1f)
            textPaint.color = Color.White.copy(alpha = a).toArgb()
            textPaint.textSize = 26f + 14f * (1f - a)
            drawIntoCanvas { it.nativeCanvas.drawText(f.text, f.x, f.y, textPaint) }
        }

        // a soft light from the music itself
        val glowR = w * (0.5f + 0.25f * level)
        drawCircle(
            Brush.radialGradient(
                listOf(c.a1.copy(alpha = 0.10f + 0.22f * level), Color.Transparent),
                Offset(w / 2f, h), glowR
            ),
            glowR, Offset(w / 2f, h)
        )
    }

    fun DrawScope.drawKeyStrip(c: AirColors, t: Float) {
        val w = size.width
        val h = size.height
        if (w <= 2f || h <= 2f) return
        val k = keys
        val step = k.step * w

        for (i in 0 until k.whiteCount) {
            val m = k.whites[i]
            val x = i * step
            val f = flash[m]
            drawRoundRect(
                Brush.verticalGradient(listOf(Color(0xFFFDFEFF), Color(0xFFD7E1F5))),
                Offset(x + 1.5f, 0f), Size(step - 3f, h), CornerRadius(7f, 7f)
            )
            if (f > 0.01f) {
                drawRoundRect(
                    Brush.verticalGradient(listOf(c.a2.copy(alpha = 0.9f * f), c.a1.copy(alpha = 0.55f * f))),
                    Offset(x + 1.5f, 0f), Size(step - 3f, h), CornerRadius(7f, 7f)
                )
                drawRoundRect(
                    Color.White.copy(alpha = 0.55f * f),
                    Offset(x + 1.5f, 0f), Size(step - 3f, h), CornerRadius(7f, 7f),
                    style = Stroke(2f)
                )
            }
            drawRoundRect(
                Color(0x33000000), Offset(x + 1.5f, 0f), Size(step - 3f, h), CornerRadius(7f, 7f),
                style = Stroke(1f)
            )
            if (step > 32f) {
                textPaint.color = if (f > 0.25f) Color.White.toArgb() else Color(0xFF69739A).toArgb()
                textPaint.textSize = 15f
                drawIntoCanvas { it.nativeCanvas.drawText(noteName(m), x + step / 2f, h - 9f, textPaint) }
            }
        }

        for (i in 0 until k.whiteCount - 1) {
            val m = k.blacks[i]
            if (m < 0) continue
            val bw = k.blackW * w
            val cx = (i + 1) * step
            val bh = h * 0.62f
            val f = flash[m]
            drawRoundRect(
                Brush.verticalGradient(listOf(Color(0xFF2A3350), Color(0xFF0A0D17))),
                Offset(cx - bw / 2f, 0f), Size(bw, bh), CornerRadius(5f, 5f)
            )
            if (f > 0.01f) {
                drawRoundRect(
                    Brush.verticalGradient(listOf(c.a3.copy(alpha = 0.95f * f), c.a1.copy(alpha = 0.8f * f))),
                    Offset(cx - bw / 2f, 0f), Size(bw, bh), CornerRadius(5f, 5f)
                )
            }
            drawRoundRect(
                Color.White.copy(alpha = 0.14f),
                Offset(cx - bw / 2f, 0f), Size(bw, bh), CornerRadius(5f, 5f),
                style = Stroke(1f)
            )
        }

        // rings spreading from every note that just sounded
        for (r in ripples) {
            val a = (r.life / r.max).coerceIn(0f, 1f)
            val rad = 10f + (1f - a) * 90f
            drawCircle(c.a2.copy(alpha = 0.55f * a), rad, Offset(r.x * w, h * 0.42f), style = Stroke(2.5f))
            drawCircle(c.a3.copy(alpha = 0.30f * a), rad * 0.6f, Offset(r.x * w, h * 0.42f), style = Stroke(1.5f))
        }

        // sparks
        for (s in sparks) {
            val a = (s.life / s.max).coerceIn(0f, 1f)
            val col = when (s.col) {
                0 -> c.a2
                1 -> c.a1
                else -> c.a3
            }
            drawCircle(col.copy(alpha = a * 0.85f), 3.2f, Offset(s.x * w, s.y))
            drawCircle(Color.White.copy(alpha = a * 0.5f), 1.4f, Offset(s.x * w, s.y))
        }

        // top edge: the keys catch the light of the stage
        drawRect(
            Brush.verticalGradient(listOf(c.a2.copy(alpha = 0.16f + 0.12f * level), Color.Transparent)),
            topLeft = Offset(0f, 0f), size = Size(w, h * 0.22f)
        )
        if (targetMidi >= 0) {
            val tx = keys.centerX(targetMidi)
            if (tx >= 0f) {
                val a = 0.35f + 0.65f * (0.5f + 0.5f * sin(t * 5f))
                drawRoundRect(
                    c.ok.copy(alpha = 0.9f * a),
                    Offset(tx * w - step * 0.45f, 0f), Size(step * 0.9f, h), CornerRadius(7f, 7f),
                    style = Stroke(3f)
                )
            }
        }
    }
}

// ---------------------------------------------------------------------------------------------
// Screen
// ---------------------------------------------------------------------------------------------

@Composable
fun AirMusicScreen() {
    val ctx = LocalContext.current
    var camOk by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED
        )
    }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { camOk = it }
    if (camOk) {
        MusicStage()
    } else {
        AirScroll {
            ScreenHeader("Air Music", "A Casio in the air, played with both hands")
            SectionCard("Camera needed") {
                Text(
                    "Air Music watches your fingertips to play the notes. Nothing is recorded and the video never leaves your phone.",
                    color = Air.c.dim
                )
                AirButton(
                    "Allow camera", { launcher.launch(Manifest.permission.CAMERA) },
                    Modifier.fillMaxWidth(), icon = IconKind.SCAN
                )
            }
            SectionCard("How to play") {
                Text(
                    "Hold both hands in front of the camera. A glowing line sits across the picture: when a fingertip goes " +
                        "below that line it presses the key under it. Ten fingers, ten notes at once.",
                    style = MaterialTheme.typography.bodySmall, color = Air.c.dim
                )
            }
        }
    }
}

private fun octaveFor(song: Song): Int {
    val lo = song.melody.minOfOrNull { it.midi } ?: 60
    val hi = song.melody.maxOfOrNull { it.midi } ?: 72
    var oct = 4
    while (oct > 2 && lo < (oct + 1) * 12) oct--
    while (oct < 6 && hi > (oct + 1) * 12 + 22) oct++
    return oct
}

@Composable
private fun MusicStage() {
    val ctx = LocalContext.current
    val owner = LocalLifecycleOwner.current
    val c = Air.c

    val synth = remember { AirSynth() }
    val eng = remember { MusicEngine(synth) }

    var instrument by remember {
        val n = Instrument.values().size
        mutableStateOf(Instrument.values()[Prefs.musicInstrument.coerceIn(0, n - 1)])
    }
    var octave by remember { mutableIntStateOf(Prefs.musicOctave.coerceIn(2, 6)) }
    var volume by remember { mutableFloatStateOf(Prefs.musicVolume.coerceIn(0f, 1f)) }
    var reverb by remember { mutableFloatStateOf(Prefs.musicReverb.coerceIn(0f, 1f)) }
    var sustain by remember { mutableStateOf(false) }
    var learn by remember { mutableStateOf(false) }
    var songIdx by remember { mutableIntStateOf(0) }
    var playing by remember { mutableStateOf(false) }
    var panel by remember { mutableStateOf(false) }
    var score by remember { mutableIntStateOf(0) }
    var targetIdx by remember { mutableIntStateOf(0) }
    // These two change on every camera frame, so only tiny composables read them: the rest of the
    // screen must not recompose 30 times a second.
    val frameState = remember { mutableStateOf<Bitmap?>(null) }
    val handsState = remember { mutableIntStateOf(0) }
    val clock = remember { mutableFloatStateOf(0f) }

    val song = Songs.all[songIdx.coerceIn(0, Songs.all.size - 1)]

    // ---- audio engine ------------------------------------------------------------------------
    DisposableEffect(Unit) {
        synth.start()
        onDispose { synth.stop() }
    }
    LaunchedEffect(instrument) {
        synth.setInstrument(instrument)
        Prefs.musicInstrument = instrument.ordinal
    }
    LaunchedEffect(volume) {
        synth.setVolume(volume)
        Prefs.musicVolume = volume
    }
    LaunchedEffect(reverb) {
        synth.setReverb(reverb)
        Prefs.musicReverb = reverb
    }
    LaunchedEffect(sustain) { synth.setSustain(sustain) }
    LaunchedEffect(octave) {
        Prefs.musicOctave = octave
        eng.setKeyboard((octave + 1) * 12, 14)
    }

    // ---- camera and hands --------------------------------------------------------------------
    DisposableEffect(owner) {
        // The music screen owns the camera, so the background scroll service steps aside.
        ctx.stopService(Intent(ctx, AirFlowService::class.java))
        val main = Handler(Looper.getMainLooper())
        val controller = HandController(ctx, owner, needBitmap = true, maxHands = 2, minFps = 30) { r ->
            main.post {
                frameState.value = r.bitmap
                handsState.intValue = r.hands.size
                eng.onHands(r.hands)
            }
        }
        controller.start()
        onDispose {
            controller.stop()
            eng.releaseAll()
        }
    }
    DisposableEffect(owner) {
        val obs = LifecycleEventObserver { _, e ->
            if (e == Lifecycle.Event.ON_PAUSE) {
                eng.releaseAll()
                playing = false
            }
        }
        owner.lifecycle.addObserver(obs)
        onDispose { owner.lifecycle.removeObserver(obs) }
    }

    // ---- animation clock ---------------------------------------------------------------------
    LaunchedEffect(Unit) {
        var last = 0L
        while (true) {
            withFrameNanos { now ->
                val dt = if (last == 0L) 0.016f else ((now - last) / 1000000000.0).toFloat().coerceIn(0.001f, 0.05f)
                last = now
                eng.frame(dt)
                clock.floatValue += dt
            }
        }
    }

    // ---- learn mode --------------------------------------------------------------------------
    SideEffect {
        eng.onHit = {
            score += 1
            targetIdx += 1
        }
    }
    LaunchedEffect(learn, targetIdx, songIdx) {
        val notes = song.melody
        eng.targetMidi = if (learn && notes.isNotEmpty()) notes[targetIdx % notes.size].midi else -1
    }

    // ---- demo player -------------------------------------------------------------------------
    LaunchedEffect(playing, songIdx, learn) {
        if (!playing || learn) return@LaunchedEffect
        val s = Songs.all[songIdx.coerceIn(0, Songs.all.size - 1)]
        val beatMs = 60000f / s.tempo
        val started = SystemClock.uptimeMillis()
        val fired = BooleanArray(s.notes.size)
        while (true) {
            if (!playing) break
            val el = (SystemClock.uptimeMillis() - started).toFloat()
            for (i in s.notes.indices) {
                val n = s.notes[i]
                if (!fired[i] && n.start * beatMs <= el) {
                    fired[i] = true
                    eng.autoNote(n.midi, n.len * beatMs * 0.94f, n.hand)
                }
            }
            if (el > s.lengthBeats * beatMs + 1400f) {
                playing = false
                break
            }
            delay(16)
        }
    }

    // ---- layout ------------------------------------------------------------------------------
    Box(Modifier.fillMaxSize()) {
        Column(Modifier.fillMaxSize().padding(top = 56.dp, bottom = 84.dp)) {

            // the camera stage ---------------------------------------------------------------
            Box(
                Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .padding(horizontal = 10.dp)
                    .clip(RoundedCornerShape(26.dp))
                    .background(Color(0xFF06070E))
                    .border(
                        1.dp,
                        Brush.linearGradient(
                            listOf(
                                c.a2.copy(alpha = 0.55f),
                                c.a1.copy(alpha = 0.20f),
                                c.a3.copy(alpha = 0.55f)
                            )
                        ),
                        RoundedCornerShape(26.dp)
                    )
            ) {
                CameraFrame(frameState, Modifier.fillMaxSize())
                Box(
                    Modifier
                        .fillMaxSize()
                        .background(
                            Brush.verticalGradient(
                                listOf(Color(0xB304050D), Color(0x8C04050D), Color(0xF204050D))
                            )
                        )
                )
                Canvas(
                    Modifier
                        .fillMaxSize()
                        .onSizeChanged { eng.setStageSize(it.width.toFloat(), it.height.toFloat()) }
                ) {
                    with(eng) { drawStage(c, clock.floatValue) }
                }

                // top HUD
                Column(Modifier.fillMaxWidth().padding(10.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            Modifier
                                .clip(RoundedCornerShape(50))
                                .background(Color(0x6604050D))
                                .border(1.dp, c.stroke, RoundedCornerShape(50))
                                .padding(horizontal = 10.dp, vertical = 5.dp)
                        ) {
                            Text(
                                "AIR MUSIC", color = Color.White, fontSize = 10.sp,
                                fontWeight = FontWeight.Black, letterSpacing = 2.sp
                            )
                        }
                        Spacer(Modifier.width(8.dp))
                        HandsBadge(handsState)
                        Spacer(Modifier.weight(1f))
                        LevelBars(eng, c, clock.floatValue, Modifier.width(44.dp).height(18.dp))
                    }
                    Spacer(Modifier.height(6.dp))
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        items(Instrument.values().toList()) { ins ->
                            val sel = ins == instrument
                            Box(
                                Modifier
                                    .clip(RoundedCornerShape(50))
                                    .background(
                                        if (sel) Brush.horizontalGradient(listOf(c.a1, c.a2))
                                        else SolidColor(Color(0x5504050D))
                                    )
                                    .border(1.dp, if (sel) Color.Transparent else c.stroke, RoundedCornerShape(50))
                                    .pressClick(scaleTo = 0.94f) { instrument = ins }
                                    .padding(horizontal = 11.dp, vertical = 5.dp)
                            ) {
                                Text(
                                    ins.label, color = if (sel) Color.White else c.dim,
                                    fontSize = 11.sp, fontWeight = if (sel) FontWeight.Bold else FontWeight.Medium
                                )
                            }
                        }
                    }
                    if (learn) {
                        Spacer(Modifier.height(6.dp))
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Pill("LEARN · ${score} HIT", c.ok)
                            Spacer(Modifier.width(6.dp))
                            Text(
                                "Play the glowing key", color = Color.White.copy(alpha = 0.8f), fontSize = 11.sp
                            )
                        }
                    } else if (playing) {
                        Spacer(Modifier.height(6.dp))
                        Pill("DEMO · ${song.title}", c.a2)
                    }
                }

                NoHandsHint(handsState, Modifier.align(Alignment.Center))
            }

            // the keyboard -------------------------------------------------------------------
            Canvas(
                Modifier
                    .fillMaxWidth()
                    .height(122.dp)
                    .padding(horizontal = 10.dp, vertical = 6.dp)
                    .onSizeChanged { eng.setKeysSize(it.width.toFloat(), it.height.toFloat()) }
            ) {
                with(eng) { drawKeyStrip(c, clock.floatValue) }
            }

            // controls -----------------------------------------------------------------------
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 6.dp),
                horizontalArrangement = Arrangement.SpaceEvenly,
                verticalAlignment = Alignment.CenterVertically
            ) {
                CtrlButton("Songs", IconKind.MUSIC, panel) { panel = !panel }
                CtrlButton(if (playing) "Stop" else "Demo", IconKind.PLAY, playing) {
                    learn = false
                    playing = !playing
                    if (playing) {
                        score = 0
                        targetIdx = 0
                    }
                }
                CtrlButton("Learn", IconKind.BOLT, learn) {
                    learn = !learn
                    playing = false
                    score = 0
                    targetIdx = 0
                    if (learn) octave = octaveFor(song)
                }
                CtrlButton("Sustain", IconKind.CHECK, sustain) { sustain = !sustain }
                CtrlButton("Oct -", null, false) { if (octave > 2) octave -= 1 }
                CtrlButton("Oct +", null, false) { if (octave < 6) octave += 1 }
            }
        }

        // songs panel ------------------------------------------------------------------------
        AnimatedVisibility(
            visible = panel,
            enter = fadeIn(tween(180)),
            exit = fadeOut(tween(160)),
            modifier = Modifier.align(Alignment.BottomCenter).padding(horizontal = 12.dp, vertical = 148.dp)
        ) {
            GlassCard(Modifier.fillMaxWidth(), reveal = false) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Demo songs", style = MaterialTheme.typography.titleMedium, color = c.text)
                    Spacer(Modifier.weight(1f))
                    Text("Close", color = c.a2, fontSize = 12.sp, fontWeight = FontWeight.Bold,
                        modifier = Modifier.pressClick { panel = false })
                }
                Column(
                    Modifier.fillMaxWidth().heightIn(max = 250.dp).verticalScroll(rememberScrollState())
                ) {
                    Songs.all.forEachIndexed { i, s ->
                        val sel = i == songIdx
                        Row(
                            Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(14.dp))
                                .background(if (sel) c.glassHi else Color.Transparent)
                                .pressClick(scaleTo = 0.98f) {
                                    songIdx = i
                                    targetIdx = 0
                                    score = 0
                                    panel = false
                                    octave = octaveFor(s)
                                    learn = false
                                    playing = true
                                }
                                .padding(horizontal = 10.dp, vertical = 9.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                Modifier.size(30.dp).clip(CircleShape)
                                    .background(Brush.linearGradient(listOf(c.a1, c.a2))),
                                contentAlignment = Alignment.Center
                            ) {
                                Text("${i + 1}", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Black)
                            }
                            Spacer(Modifier.width(10.dp))
                            Column(Modifier.weight(1f)) {
                                Text(s.title, color = c.text, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                Text(s.about, color = c.dim, fontSize = 11.sp)
                            }
                            if (sel && playing) PulseDot(c.ok, true)
                        }
                    }
                }
                Text("Volume", color = c.dim, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                AirSlider(volume, { volume = it }, 0f..1f)
                Text("Hall", color = c.dim, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                AirSlider(reverb, { reverb = it }, 0f..1f)
            }
        }
    }
}

/** Only this reads the camera frame, so a new picture does not recompose the whole screen. */
@Composable
private fun CameraFrame(frame: State<Bitmap?>, modifier: Modifier) {
    val bmp = frame.value
    if (bmp != null) {
        val img = remember(bmp) { bmp.asImageBitmap() }
        Image(img, null, modifier, contentScale = ContentScale.FillBounds)
    }
}

@Composable
private fun HandsBadge(hands: State<Int>) {
    val c = Air.c
    val n = hands.value
    Pill(if (n > 1) "2 HANDS" else if (n == 1) "1 HAND" else "SHOW HANDS", if (n > 0) c.ok else c.warn)
}

@Composable
private fun NoHandsHint(hands: State<Int>, modifier: Modifier) {
    if (hands.value == 0) {
        Text(
            "Show both hands to the camera",
            modifier.padding(20.dp),
            color = Color.White.copy(alpha = 0.75f), fontSize = 13.sp,
            fontWeight = FontWeight.Bold, textAlign = TextAlign.Center
        )
    }
}

@Composable
private fun CtrlButton(label: String, icon: IconKind?, active: Boolean, onClick: () -> Unit) {
    val c = Air.c
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier.pressClick(scaleTo = 0.9f) { onClick() }.padding(horizontal = 2.dp)
    ) {
        Box(
            Modifier
                .size(46.dp)
                .clip(CircleShape)
                .background(
                    if (active) Brush.linearGradient(listOf(c.a1, c.a2))
                    else SolidColor(c.glass)
                )
                .border(1.dp, if (active) Color.White.copy(alpha = 0.35f) else c.stroke, CircleShape),
            contentAlignment = Alignment.Center
        ) {
            if (icon != null) {
                AirIcon(icon, if (active) Color.White else c.text, Modifier.size(21.dp))
            } else {
                Text(
                    if (label.endsWith("-")) "−" else "+",
                    color = c.text, fontSize = 22.sp, fontWeight = FontWeight.Black
                )
            }
        }
        Spacer(Modifier.height(3.dp))
        Text(
            label, color = if (active) c.a2 else c.dim, fontSize = 9.sp,
            fontWeight = if (active) FontWeight.Bold else FontWeight.Medium, maxLines = 1
        )
    }
}

/** Five little bars that dance with the music. */
@Composable
private fun LevelBars(eng: MusicEngine, c: AirColors, tick: Float, modifier: Modifier) {
    Canvas(modifier) {
        val n = 5
        val w = size.width / n
        for (i in 0 until n) {
            val v = (eng.level * (0.55f + 0.45f * sin(tick * (3f + i * 0.7f) + i))).coerceIn(0.06f, 1f)
            val hh = size.height * v
            drawRoundRect(
                Brush.verticalGradient(listOf(c.a2, c.a1)),
                Offset(i * w + 2f, size.height - hh), Size(w - 4f, hh),
                CornerRadius(w / 3f, w / 3f)
            )
        }
    }
}
