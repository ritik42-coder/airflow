package com.airflow.app

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import kotlin.math.roundToInt

@Composable
fun SettingsScreen() {
    var sens by remember { mutableFloatStateOf(Prefs.sensitivity) }
    var cool by remember { mutableFloatStateOf(Prefs.cooldownMs.toFloat()) }
    var fps by remember { mutableFloatStateOf(Prefs.fps.toFloat()) }
    var auto by remember { mutableFloatStateOf(Prefs.autoStopMin.toFloat()) }
    var invert by remember { mutableStateOf(Prefs.invertSwipe) }
    var swipe by remember { mutableStateOf(Prefs.swipeEnabled) }
    var palm by remember { mutableStateOf(Prefs.palmHoldEnabled) }
    var pinch by remember { mutableStateOf(Prefs.pinchEnabled) }
    var fist by remember { mutableStateOf(Prefs.fistEnabled) }
    var videoOnly by remember { mutableStateOf(Prefs.onlyVideoApps) }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("Settings", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)

        SectionCard("Gestures") {
            SwitchRow("Swipes", "Up, down, left, right", swipe) { swipe = it; Prefs.swipeEnabled = it }
            SwitchRow("Open palm hold", "Play / pause", palm) { palm = it; Prefs.palmHoldEnabled = it }
            SwitchRow("Pinch", "Next video / short", pinch) { pinch = it; Prefs.pinchEnabled = it }
            SwitchRow("Fist hold", "Back", fist) { fist = it; Prefs.fistEnabled = it }
            SwitchRow("Invert up / down", "Swap next and previous", invert) { invert = it; Prefs.invertSwipe = it }
        }

        SectionCard("Tuning") {
            Text("Swipe sensitivity: ${"%.1f".format(sens)}x  (higher = easier to trigger)")
            Slider(value = sens, onValueChange = { sens = it; Prefs.sensitivity = it },
                valueRange = 0.5f..2f, modifier = Modifier.fillMaxWidth())
            Text("Cooldown after a gesture: ${cool.roundToInt()} ms")
            Slider(value = cool, onValueChange = { cool = it; Prefs.cooldownMs = it.roundToInt() },
                valueRange = 300f..650f)
            Text("Camera speed: ${fps.roundToInt()} FPS  (lower = less battery)")
            Slider(value = fps, onValueChange = { fps = it; Prefs.fps = it.roundToInt() },
                valueRange = 8f..30f)
        }

        SectionCard("Safety & battery") {
            SwitchRow("Only in video apps", "YouTube, Instagram, Facebook, TikTok, Snapchat, etc.",
                videoOnly) { videoOnly = it; Prefs.onlyVideoApps = it }
            Text(
                if (auto.roundToInt() == 0) "Auto-stop timer: off" else "Auto-stop after ${auto.roundToInt()} min",
            )
            Slider(value = auto, onValueChange = { auto = it; Prefs.autoStopMin = it.roundToInt() },
                valueRange = 0f..60f)
            Text("Applies the next time you press Start.", style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant)
        }

        OutlinedButton(onClick = {
            Prefs.reset()
            sens = Prefs.sensitivity; cool = Prefs.cooldownMs.toFloat(); fps = Prefs.fps.toFloat()
            auto = Prefs.autoStopMin.toFloat(); invert = Prefs.invertSwipe; swipe = Prefs.swipeEnabled
            palm = Prefs.palmHoldEnabled; pinch = Prefs.pinchEnabled; fist = Prefs.fistEnabled
            videoOnly = Prefs.onlyVideoApps
        }) { Text("Reset to defaults") }
    }
}
