package com.airflow.app

import android.content.Context
import android.content.Intent
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.TextButton
import androidx.compose.ui.Alignment
import androidx.compose.ui.platform.LocalContext
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import kotlin.math.roundToInt

@Composable
fun SettingsScreen() {
    var sens by remember { mutableFloatStateOf(Prefs.sensitivity) }
    var cool by remember { mutableFloatStateOf(Prefs.cooldownMs.toFloat()) }
    var fps by remember { mutableFloatStateOf(Prefs.fps.toFloat()) }
    var auto by remember { mutableFloatStateOf(Prefs.autoStopMin.toFloat()) }
    var hold by remember { mutableFloatStateOf(Prefs.holdScale) }
    var range by remember { mutableFloatStateOf(Prefs.cursorRange) }
    var smooth by remember { mutableFloatStateOf(Prefs.cursorSmooth) }
    var dwell by remember { mutableStateOf(Prefs.dwellClick) }
    var invert by remember { mutableStateOf(Prefs.invertSwipe) }
    var swipe by remember { mutableStateOf(Prefs.swipeEnabled) }
    var haptic by remember { mutableStateOf(Prefs.haptic) }
    var videoOnly by remember { mutableStateOf(Prefs.onlyVideoApps) }
    var version by remember { mutableIntStateOf(0) }

    val actions = LocalActions.current
    var theme by remember { mutableIntStateOf(Prefs.themeMode) }
    AirScroll {
        ScreenHeader("Settings", "Make Air Flow yours")

        SectionCard("Appearance") {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("System", "Light", "Dark").forEachIndexed { i, n ->
                    AirButton(n, {
                        theme = i; Prefs.themeMode = i; AirFlowState.themeMode.value = i
                    }, Modifier.weight(1f), filled = theme == i)
                }
            }
            AirButton("Replay intro animation", { actions.replayIntro() }, Modifier.fillMaxWidth(), filled = false, icon = IconKind.REPLAY)
        }

        SectionCard("Gesture actions") {
            Text(
                "Pick what each gesture does. \"Auto\" is smart: the same gesture does the right thing in " +
                    "YouTube Shorts, a YouTube video, a music app, a browser or any other app. Choose \"Off\" to disable a gesture.",
                style = MaterialTheme.typography.bodySmall,
                color = Air.c.dim
            )
            key(version) {
                Gesture.values().forEach { g -> ActionRow(g) }
            }
        }

        SectionCard("Favorite apps (for \"Open favorite app\" actions)") {
            Text(
                "Choose up to 3 apps, then give a gesture the action \"Open favorite app 1/2/3\" above. " +
                    "Defaults: call-me sign opens YouTube, three fingers opens the camera.",
                style = MaterialTheme.typography.bodySmall,
                color = Air.c.dim
            )
            key(version) { (1..3).forEach { FavRow(it) } }
        }

        SectionCard("Cursor mode (hand mouse)") {
            Text("Cursor reach: ${"%.2f".format(range)}  (lower = a small hand movement crosses the whole screen)")
            AirSlider(range, { range = it; Prefs.cursorRange = it }, 0.45f..1.0f, Modifier.fillMaxWidth())
            Text("Cursor smoothness: ${"%.2f".format(smooth)}  (higher = ultra smooth, lower = more instant)")
            AirSlider(smooth, { smooth = it; Prefs.cursorSmooth = it }, 0f..1f, Modifier.fillMaxWidth())
            SwitchRow("Hover to tap", "Keep the cursor still for about 1 second and it taps by itself. Easiest way to tap.",
                dwell) { dwell = it; Prefs.dwellClick = it }
            Text(
                "Point with your index finger to move. Pinch = tap. Pinch and hold still 0.6 s (cursor turns orange) " +
                    "then release = long-press; move before releasing = drag and drop. Pinch and move straight away = scroll / swipe. " +
                    "Fist hold or rock sign = exit. Fist swipes still do Home / Back / Recents / Notifications.",
                style = MaterialTheme.typography.bodySmall,
                color = Air.c.dim
            )
        }

        SectionCard("Behaviour") {
            SwitchRow("Swipes", "Master switch for all hand swipes", swipe) { swipe = it; Prefs.swipeEnabled = it }
            SwitchRow("Invert up / down", "Swap next and previous", invert) { invert = it; Prefs.invertSwipe = it }
            SwitchRow("Vibrate on action", "A short buzz so you know it worked", haptic) { haptic = it; Prefs.haptic = it }
        }

        SectionCard("Tuning") {
            Text("Swipe sensitivity: ${"%.1f".format(sens)}x  (higher = easier to trigger)")
            AirSlider(sens, { sens = it; Prefs.sensitivity = it }, 0.5f..2f, Modifier.fillMaxWidth())
            Text("Hold time: ${"%.1f".format(hold)}x  (lower = hold poses trigger faster)")
            AirSlider(hold, { hold = it; Prefs.holdScale = it }, 0.6f..1.6f, Modifier.fillMaxWidth())
            Text("Cooldown after a gesture: ${cool.roundToInt()} ms")
            AirSlider(cool, { cool = it; Prefs.cooldownMs = it.roundToInt() }, 300f..650f, Modifier.fillMaxWidth())
            Text("Camera speed: ${fps.roundToInt()} FPS  (lower = less battery)")
            AirSlider(fps, { fps = it; Prefs.fps = it.roundToInt() }, 8f..30f, Modifier.fillMaxWidth())
        }

        SectionCard("Safety & battery") {
            SwitchRow("Only in video apps", "Off = works in every app (recommended). On = YouTube, Instagram, TikTok, Netflix, etc. only.",
                videoOnly) { videoOnly = it; Prefs.onlyVideoApps = it }
            Text(
                if (auto.roundToInt() == 0) "Auto-stop timer: off" else "Auto-stop after ${auto.roundToInt()} min",
            )
            AirSlider(auto, { auto = it; Prefs.autoStopMin = it.roundToInt() }, 0f..60f, Modifier.fillMaxWidth())
            Text("Applies the next time you press Start.", style = MaterialTheme.typography.bodySmall,
                color = Air.c.dim)
        }

        AirButton("Reset to defaults", filled = false, modifier = Modifier.fillMaxWidth(), onClick = {
            Prefs.reset()
            sens = Prefs.sensitivity; cool = Prefs.cooldownMs.toFloat(); fps = Prefs.fps.toFloat()
            auto = Prefs.autoStopMin.toFloat(); invert = Prefs.invertSwipe; swipe = Prefs.swipeEnabled
            hold = Prefs.holdScale; haptic = Prefs.haptic; videoOnly = Prefs.onlyVideoApps
            range = Prefs.cursorRange; smooth = Prefs.cursorSmooth; dwell = Prefs.dwellClick
            theme = Prefs.themeMode; AirFlowState.themeMode.value = Prefs.themeMode
            version++
        })
    }
}

@Composable
private fun ActionRow(g: Gesture) {
    var sel by remember { mutableStateOf(Prefs.actionFor(g)) }
    var open by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(2.dp)) {
        Text("${g.emoji} ${g.title}", fontWeight = FontWeight.SemiBold)
        Box(Modifier.fillMaxWidth()) {
            AirButton(sel.label, { open = true }, Modifier.fillMaxWidth(), filled = false)
            DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
                Action.values().forEach { a ->
                    DropdownMenuItem(
                        text = { Text(a.label) },
                        onClick = { sel = a; Prefs.setAction(g, a); open = false }
                    )
                }
            }
        }
    }
}

private fun appLabel(ctx: Context, pkg: String): String = try {
    val pm = ctx.packageManager
    pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0)).toString()
} catch (_: Exception) {
    pkg
}

private fun loadApps(ctx: Context): List<Pair<String, String>> {
    val pm = ctx.packageManager
    val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
    return pm.queryIntentActivities(intent, 0)
        .map { it.loadLabel(pm).toString() to it.activityInfo.packageName }
        .distinctBy { it.second }
        .sortedBy { it.first.lowercase() }
}

@Composable
private fun FavRow(slot: Int) {
    val ctx = LocalContext.current
    var pkg by remember { mutableStateOf(Prefs.fav(slot)) }
    var picking by remember { mutableStateOf(false) }
    val name = pkg?.let { appLabel(ctx, it) } ?: "Not set"
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("$slot. $name", Modifier.weight(1f), maxLines = 1)
        AirButton("Choose", { picking = true }, filled = false)
        if (pkg != null) AirButton("Clear", { Prefs.setFav(slot, null); pkg = null }, filled = false)
    }
    if (picking) {
        val apps = remember { loadApps(ctx) }
        AlertDialog(
            onDismissRequest = { picking = false },
            confirmButton = { TextButton(onClick = { picking = false }) { Text("Cancel") } },
            title = { Text("Choose app $slot") },
            text = {
                LazyColumn(Modifier.heightIn(max = 420.dp)) {
                    items(apps) { app ->
                        Text(
                            app.first,
                            Modifier.fillMaxWidth()
                                .clickable { Prefs.setFav(slot, app.second); pkg = app.second; picking = false }
                                .padding(vertical = 12.dp)
                        )
                    }
                }
            }
        )
    }
}
