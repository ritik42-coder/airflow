package com.airflow.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.Handler
import android.os.Looper
import androidx.core.app.NotificationCompat
import androidx.lifecycle.LifecycleService

class AirFlowService : LifecycleService() {
    private var controller: HandController? = null
    private val main = Handler(Looper.getMainLooper())
    private val autoStop = Runnable { stopSelf() }

    override fun onCreate() {
        super.onCreate()
        Prefs.init(this)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        super.onStartCommand(intent, flags, startId)
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }
        try {
            val n = buildNotification()
            if (Build.VERSION.SDK_INT >= 29) {
                startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_CAMERA)
            } else {
                startForeground(1, n)
            }
        } catch (e: Exception) {
            AirFlowState.error.value = "Could not start camera service: ${e.message}"
            stopSelf()
            return START_NOT_STICKY
        }
        if (controller == null) {
            controller = HandController(this, this) { r ->
                AirFlowState.handVisible.value = r.landmarks != null
                r.gesture?.let { g ->
                    AirFlowState.lastGesture.value = g.title
                    main.post { AirFlowAccessibilityService.instance?.perform(g) }
                }
            }.also { it.start() }
            AirFlowState.running.value = true
            val min = Prefs.autoStopMin
            if (min > 0) main.postDelayed(autoStop, min * 60_000L)
        }
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        main.removeCallbacks(autoStop)
        controller?.stop()
        controller = null
        AirFlowState.running.value = false
        AirFlowState.handVisible.value = false
        super.onDestroy()
    }

    private fun buildNotification(): Notification {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL, "Air Flow", NotificationManager.IMPORTANCE_LOW)
        )
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        val stop = PendingIntent.getService(
            this, 1, Intent(this, AirFlowService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(R.drawable.ic_notif)
            .setContentTitle("Air Flow is active")
            .setContentText("Tracking your hand gestures")
            .setContentIntent(open)
            .addAction(0, "Stop", stop)
            .setOngoing(true)
            .build()
    }

    companion object {
        const val ACTION_STOP = "com.airflow.app.STOP"
        const val CHANNEL = "airflow_channel"
    }
}
