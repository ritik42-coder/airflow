package com.airflow.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.SystemClock
import android.os.Handler
import android.os.Looper
import androidx.core.app.NotificationCompat
import androidx.lifecycle.LifecycleService

class AirFlowService : LifecycleService() {
    private var controller: HandController? = null
    private val main = Handler(Looper.getMainLooper())
    private val autoStop = Runnable { stopSelf() }

    override fun onCreate() {
        super.onCreate()
        Prefs.init(this)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        super.onStartCommand(intent, flags, startId)
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }
        if (intent?.action == ACTION_TOGGLE_CURSOR) {
            main.post {
                val svc = AirFlowAccessibilityService.instance
                svc?.setCursor(!AirFlowState.cursorMode.value)
            }
            return START_NOT_STICKY
        }
        // Tap Share only (no hand gestures): no camera is used, so the service is a "connected device" one.
        val tapOnly = intent?.action == ACTION_TAP
        // asking for the tap-only type while the camera is already running would drop the camera
        if (!(tapOnly && controller != null)) {
            try {
                val n = buildNotification(tapOnly)
                if (Build.VERSION.SDK_INT >= 29) {
                    startForeground(
                        1, n,
                        if (tapOnly) ServiceInfo.FOREGROUND_SERVICE_TYPE_CONNECTED_DEVICE
                        else ServiceInfo.FOREGROUND_SERVICE_TYPE_CAMERA
                    )
                } else {
                    startForeground(1, n)
                }
            } catch (e: Exception) {
                AirFlowState.error.value = "Could not start the service: ${e.message}"
                stopSelf()
                return START_NOT_STICKY
            }
        }
        if (controller == null && !tapOnly) {
            // 30 fps floor: the 20 fps default made gestures feel slower out here than inside the app
            controller = HandController(this, this, needBitmap = false, maxHands = 1, minFps = 30) { r ->
                AirFlowState.handVisible.value = r.landmarks != null
                val now = SystemClock.uptimeMillis()
                r.gesture?.let { g -> AirFlowState.lastGesture.value = g.title }
                main.post {
                    // Air Share (palm, fist, open) gets first call on the hand; while it is busy the normal
                    // gestures stay quiet so a fist for sharing does not also press Back.
                    val busy = AirShareHub.onFrame(r.pose, r.landmarks, now)
                    IslandHost.onFrame(r, if (busy) AirShareHub.islandHint() else null)
                    val svc = AirFlowAccessibilityService.instance
                    if (svc != null && !busy) {
                        // Cursor mode: the same camera frames also drive the on-screen hand cursor.
                        if (AirFlowState.cursorMode.value) svc.cursor.onFrame(r.pose, r.landmarks, now)
                        r.gesture?.let { g -> svc.perform(g) }
                    }
                }
            }.also { it.start() }
            AirFlowState.running.value = true
            IslandHost.show(this)
            val min = Prefs.autoStopMin
            if (min > 0) main.postDelayed(autoStop, min * 60_000L)
        }
        if (intent?.action == ACTION_SHARE) AirShareHub.attach(this, true)
        if (tapOnly) AirShareHub.attach(this, false)
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        main.removeCallbacks(autoStop)
        controller?.stop()
        controller = null
        AirShareHub.detach()
        IslandHost.hide()
        AirFlowAccessibilityService.instance?.setCursor(false, feedback = false)
        AirFlowState.running.value = false
        AirFlowState.handVisible.value = false
        super.onDestroy()
    }

    private fun buildNotification(tapOnly: Boolean = false): Notification {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL, "Air Flow", NotificationManager.IMPORTANCE_LOW)
        )
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        val stop = PendingIntent.getService(
            this, 1, Intent(this, AirFlowService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE
        )
        val cursor = PendingIntent.getService(
            this, 2, Intent(this, AirFlowService::class.java).setAction(ACTION_TOGGLE_CURSOR),
            PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(R.drawable.ic_notif)
            .setContentTitle(if (tapOnly) "Tap Share is on" else "Air Flow is active")
            .setContentText(
                if (tapOnly) "Touch two phones together to send or receive"
                else if (AirShareHub.active.value) "Air Share is on: send and receive in any app"
                else "Tracking your hand gestures"
            )
            .setContentIntent(open)
            .apply { if (!tapOnly) addAction(0, "Cursor mode", cursor) }
            .addAction(0, "Stop", stop)
            .setOngoing(true)
            .build()
    }

    companion object {
        const val ACTION_STOP = "com.airflow.app.STOP"
        const val ACTION_TOGGLE_CURSOR = "com.airflow.app.TOGGLE_CURSOR"
        /** Start (or keep) the service and switch on system-wide Air Share. */
        const val ACTION_SHARE = "com.airflow.app.SHARE"
        /** Tap Share only: the touch works from anywhere, no camera is used. */
        const val ACTION_TAP = "com.airflow.app.TAP"
        const val CHANNEL = "airflow_channel"
    }
}
