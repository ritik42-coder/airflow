package com.airflow.app

import android.content.Context
import android.os.SystemClock
import com.google.android.gms.nearby.Nearby
import com.google.android.gms.nearby.connection.AdvertisingOptions
import com.google.android.gms.nearby.connection.ConnectionInfo
import com.google.android.gms.nearby.connection.ConnectionLifecycleCallback
import com.google.android.gms.nearby.connection.ConnectionResolution
import com.google.android.gms.nearby.connection.ConnectionsClient
import com.google.android.gms.nearby.connection.DiscoveredEndpointInfo
import com.google.android.gms.nearby.connection.DiscoveryOptions
import com.google.android.gms.nearby.connection.EndpointDiscoveryCallback
import com.google.android.gms.nearby.connection.Payload
import com.google.android.gms.nearby.connection.PayloadCallback
import com.google.android.gms.nearby.connection.PayloadTransferUpdate
import com.google.android.gms.nearby.connection.Strategy
import org.json.JSONObject
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

// ---------------------------------------------------------------------------------------------
// Three air games, played with the hand tracking that is already running.
//   1. Air Slash  — one player, slice what flies up, avoid the bombs.
//   2. Air Pong   — two players, one phone, a hand each.
//   3. Air Tug    — two players, two phones, pull the rope with your hand.
// ---------------------------------------------------------------------------------------------

class Fruit(
    var x: Float,
    var y: Float,
    var vx: Float,
    var vy: Float,
    var r: Float,
    var kind: Int,          // 0..4 fruit, 5 bomb
    var rot: Float
) {
    var alive = true
    var sliced = false
    var life = 1f
}

/** Single player: fruit flies up, a fast fingertip slices it, bombs cost a life. */
class SlashGame {

    val fruits = ArrayList<Fruit>()
    var score = 0
    var lives = 3
    var combo = 0
    var bestCombo = 0
    var over = false
    var time = 0f
    private var spawnIn = 0.7f
    private var spawnRate = 1.15f
    private val rnd = java.util.Random()

    fun reset() {
        fruits.clear()
        score = 0
        lives = 3
        combo = 0
        bestCombo = 0
        over = false
        time = 0f
        spawnIn = 0.7f
        spawnRate = 1.15f
    }

    fun update(dt: Float) {
        if (over) return
        time += dt
        spawnIn -= dt
        // the longer you survive, the busier it gets
        spawnRate = max(0.42f, 1.15f - time * 0.012f)
        if (spawnIn <= 0f) {
            spawnIn = spawnRate * (0.7f + rnd.nextFloat() * 0.6f)
            val n = if (rnd.nextFloat() < 0.25f) 2 else 1
            for (k in 0 until n) spawn()
        }

        var i = 0
        while (i < fruits.size) {
            val f = fruits[i]
            f.vy += 1.15f * dt
            f.x += f.vx * dt
            f.y += f.vy * dt
            f.rot += dt * 1.4f
            if (f.sliced) {
                f.life -= dt * 1.6f
                if (f.life <= 0f) fruits.removeAt(i) else i++
                continue
            }
            if (f.y - f.r > 1.06f) {
                // fell past the bottom
                fruits.removeAt(i)
                if (f.kind != 5) {
                    lives--
                    combo = 0
                    if (lives <= 0) over = true
                }
                continue
            }
            i++
        }
    }

    private fun spawn() {
        val bomb = rnd.nextFloat() < 0.14f
        val x = 0.16f + rnd.nextFloat() * 0.68f
        val vy = -(1.30f + rnd.nextFloat() * 0.35f)
        val vx = (rnd.nextFloat() - 0.5f) * 0.28f
        fruits.add(Fruit(x, 1.08f, vx, vy, 0.055f + rnd.nextFloat() * 0.012f, if (bomb) 5 else rnd.nextInt(5), rnd.nextFloat() * 6f))
    }

    /** A fingertip moved from (px,py) to (qx,qy): slice whatever the segment crosses. */
    fun slice(px: Float, py: Float, qx: Float, qy: Float, speed: Float): Int {
        if (over || speed < 0.55f) return 0
        var hits = 0
        for (f in fruits) {
            if (!f.alive || f.sliced) continue
            if (segmentHits(px, py, qx, qy, f.x, f.y, f.r + 0.018f)) {
                f.sliced = true
                f.alive = false
                hits++
                if (f.kind == 5) {
                    lives--
                    combo = 0
                    if (lives <= 0) over = true
                } else {
                    score += 10 + combo * 2
                    combo++
                    if (combo > bestCombo) bestCombo = combo
                }
            }
        }
        return hits
    }

    private fun segmentHits(x1: Float, y1: Float, x2: Float, y2: Float, cx: Float, cy: Float, r: Float): Boolean {
        val dx = x2 - x1
        val dy = y2 - y1
        val len2 = dx * dx + dy * dy
        if (len2 < 1e-6f) return hypot(cx - x1, cy - y1) <= r
        var t = ((cx - x1) * dx + (cy - y1) * dy) / len2
        t = t.coerceIn(0f, 1f)
        val px = x1 + dx * t
        val py = y1 + dy * t
        return hypot(cx - px, cy - py) <= r
    }
}

/** Two players, one phone: a hand each, paddle on your own side. */
class PongGame {

    var ballX = 0.5f
    var ballY = 0.5f
    var vx = 0.42f
    var vy = 0.24f
    var p1y = 0.5f
    var p2y = 0.5f
    var s1 = 0
    var s2 = 0
    var over = false
    var winner = 0
    var flash = 0f
    private var serveIn = 0f

    fun reset() {
        ballX = 0.5f; ballY = 0.5f
        vx = 0.42f; vy = 0.24f
        s1 = 0; s2 = 0
        over = false
        winner = 0
        serveIn = 0.6f
    }

    fun update(dt: Float, leftY: Float?, rightY: Float?) {
        if (over) return
        leftY?.let { p1y += (it - p1y) * min(1f, dt * 14f) }
        rightY?.let { p2y += (it - p2y) * min(1f, dt * 14f) }
        p1y = p1y.coerceIn(0.12f, 0.88f)
        p2y = p2y.coerceIn(0.12f, 0.88f)
        flash = max(0f, flash - dt * 3f)

        if (serveIn > 0f) {
            serveIn -= dt
            return
        }

        ballX += vx * dt
        ballY += vy * dt
        if (ballY < 0.06f) { ballY = 0.06f; vy = abs(vy) }
        if (ballY > 0.94f) { ballY = 0.94f; vy = -abs(vy) }

        // left paddle
        if (ballX < 0.10f && ballX > 0.0f && abs(ballY - p1y) < 0.17f) {
            ballX = 0.10f
            vx = (abs(vx) * 1.045f).coerceAtMost(0.85f)
            vy += (ballY - p1y) * 1.9f
            vy = vy.coerceIn(-0.55f, 0.55f)
            flash = 1f
        }
        if (ballX > 0.90f && ballX < 1.0f && abs(ballY - p2y) < 0.17f) {
            ballX = 0.90f
            vx = (-abs(vx) * 1.045f).coerceAtLeast(-0.85f)
            vy += (ballY - p2y) * 1.9f
            vy = vy.coerceIn(-0.55f, 0.55f)
            flash = 1f
        }

        if (ballX < -0.02f) { s2++; point() }
        if (ballX > 1.02f) { s1++; point() }
    }

    private fun point() {
        if (s1 >= 5 || s2 >= 5) {
            over = true
            winner = if (s1 > s2) 1 else 2
            return
        }
        ballX = 0.5f
        ballY = 0.5f
        val toRight = (s1 + s2) % 2 == 0
        vx = if (toRight) 0.42f else -0.42f
        vy = if (toRight) 0.24f else -0.24f
        serveIn = 0.7f
    }
}

/**
 * Two players, two phones: the rope sits between you. Move your hand to pull it your way.
 * The host owns the knot so both screens can never disagree.
 */
class TugGame {

    var knot = 0.5f
    var myPull = 0f
    var theirPull = 0f
    var over = false
    var winner = 0
    var ropeWobble = 0f
    private var smoothed = 0f

    fun reset() {
        knot = 0.5f
        myPull = 0f
        theirPull = 0f
        over = false
        winner = 0
        smoothed = 0f
    }

    /** [handX] is the hand's horizontal position; movement builds pull. */
    fun addHand(handX: Float?, dt: Float) {
        if (handX == null) {
            myPull = max(0f, myPull - dt * 0.9f)
            return
        }
        // how far the hand is from the middle of your side: further out = stronger pull
        val reach = abs(handX - 0.5f) * 2f
        val gain = (0.25f + reach * 1.1f)
        myPull = myPull * 0.82f + gain * dt * 3.4f
        myPull = myPull.coerceIn(0f, 2.4f)
    }

    fun hostUpdate(dt: Float) {
        if (over) return
        smoothed += ((myPull - theirPull) - smoothed) * min(1f, dt * 3f)
        knot -= smoothed * dt * 0.048f
        ropeWobble += dt * (2f + abs(smoothed) * 4f)
        if (knot <= 0.03f) { knot = 0.03f; over = true; winner = 1 }
        if (knot >= 0.97f) { knot = 0.97f; over = true; winner = 2 }
    }

    fun guestUpdate(dt: Float) {
        ropeWobble += dt * (2f + abs(myPull - theirPull) * 4f)
        if (knot <= 0.03f) { over = true; winner = 1 }
        if (knot >= 0.97f) { over = true; winner = 2 }
    }
}

// ---------------------------------------------------------------------------------------------
// Two phones over Nearby, paired by touching them together (same trick as Tap Share)
// ---------------------------------------------------------------------------------------------

class GameLink(private val ctx: Context, private val cb: Callbacks) {

    interface Callbacks {
        fun peers(count: Int)
        fun connected(host: Boolean, name: String)
        fun lost()
        fun failed(msg: String)
        fun message(json: String)
    }

    private val app = ctx.applicationContext
    private val client: ConnectionsClient = Nearby.getConnectionsClient(app)
    private val strategy = Strategy.P2P_POINT_TO_POINT
    val myId: String = java.lang.Long.toHexString(System.nanoTime()).takeLast(6)

    private var started = false
    var host = true
        private set
    private var peer: String? = null
    private val found = LinkedHashMap<String, String>()

    val connected: Boolean get() = peer != null

    private val payloadCb = object : PayloadCallback() {
        override fun onPayloadReceived(endpointId: String, payload: Payload) {
            if (payload.type != Payload.Type.BYTES) return
            val txt = try { String(payload.asBytes() ?: ByteArray(0)) } catch (e: Exception) { "" }
            if (txt.isNotEmpty()) cb.message(txt)
        }

        override fun onPayloadTransferUpdate(endpointId: String, u: PayloadTransferUpdate) {}
    }

    private val connCb = object : ConnectionLifecycleCallback() {
        override fun onConnectionInitiated(id: String, info: ConnectionInfo) {
            peer = id
            host = myId < peerIdOf(info.endpointName)
            client.acceptConnection(id, payloadCb)
        }

        override fun onConnectionResult(id: String, r: ConnectionResolution) {
            if (r.status.isSuccess) {
                peer = id
                try { client.stopDiscovery() } catch (_: Exception) {}
                cb.connected(host, "Player 2")
            } else {
                peer = null
                cb.failed("Could not link. Touch the phones again.")
            }
        }

        override fun onDisconnected(id: String) {
            peer = null
            cb.lost()
        }
    }

    private fun peerIdOf(endpointName: String): String =
        endpointName.split("|").getOrNull(1) ?: "zzzzzz"

    fun start() {
        if (started) return
        started = true
        client.startAdvertising(
            "AG|$myId|Air Flow", SERVICE, connCb,
            AdvertisingOptions.Builder().setStrategy(strategy).build()
        ).addOnFailureListener { cb.failed(it.message ?: "Could not start Nearby") }

        val disc = object : EndpointDiscoveryCallback() {
            override fun onEndpointFound(id: String, info: DiscoveredEndpointInfo) {
                if (info.endpointName.startsWith("AG|")) {
                    found[id] = info.endpointName
                    cb.peers(found.size)
                }
            }

            override fun onEndpointLost(id: String) {
                found.remove(id)
                cb.peers(found.size)
            }
        }
        client.startDiscovery(SERVICE, disc, DiscoveryOptions.Builder().setStrategy(strategy).build())
            .addOnFailureListener { cb.failed(it.message ?: "Could not look for phones") }
    }

    fun retry() {
        started = false
        start()
    }

    fun bump() {
        if (peer != null) return
        val target = found.entries.firstOrNull() ?: return
        val pid = peerIdOf(target.value)
        if (myId > pid) return          // the smaller id dials
        dial(target.key)
    }

    fun connectNow() {
        if (peer != null) return
        found.entries.firstOrNull()?.let { dial(it.key) }
    }

    private fun dial(id: String) {
        client.requestConnection("AG|$myId|Air Flow", id, connCb)
            .addOnFailureListener { cb.failed(it.message ?: "Could not connect") }
    }

    fun send(json: String) {
        val id = peer ?: return
        try { client.sendPayload(id, Payload.fromBytes(json.toByteArray())) } catch (_: Exception) {}
    }

    fun stop() {
        started = false
        peer = null
        found.clear()
        try {
            client.stopAdvertising()
            client.stopDiscovery()
            client.stopAllEndpoints()
        } catch (_: Exception) {}
    }

    companion object {
        private const val SERVICE = "com.airflow.app.game"
    }
}

/** Small maths helpers the games share. */
object GameMath {
    fun lerp(a: Float, b: Float, t: Float) = a + (b - a) * t
    fun clamp(v: Float, a: Float, b: Float) = if (v < a) a else if (v > b) b else v
    fun dist(ax: Float, ay: Float, bx: Float, by: Float) = hypot(ax - bx, ay - by)
    fun polar(angle: Float, r: Float) = cos(angle) * r to sin(angle) * r
    fun now() = SystemClock.uptimeMillis()
}
