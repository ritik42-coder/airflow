package com.airflow.app

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.PointF
import android.os.Handler
import android.os.Looper
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.MutableFloatState
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import kotlin.math.abs
import kotlin.math.hypot
import kotlin.math.sin
import org.json.JSONObject

// ---------------------------------------------------------------------------------------------
// The games hub
// ---------------------------------------------------------------------------------------------

@Composable
fun GamesHub() {
    val c = Air.c
    var open by remember { mutableIntStateOf(0) }
    if (open == 1) { AirSlashScreen { open = 0 }; return }
    if (open == 2) { AirPongScreen { open = 0 }; return }
    if (open == 3) { AirTugScreen { open = 0 }; return }

    AirScroll {
        ScreenHeader("Air Games", "Three games you play with your hand, no controller, no internet.")
        GameCard(
            "Air Slash",
            "One player · slice what flies up, avoid the bombs",
            listOf(Color(0xFF22D3EE), Color(0xFF34F5A5))
        ) { open = 1 }
        GameCard(
            "Air Pong",
            "1 vs 1 on this phone · a hand each, first to 5",
            listOf(Color(0xFFFF4FD8), Color(0xFF8B5CFF))
        ) { open = 2 }
        GameCard(
            "Air Tug",
            "1 vs 1 on two phones · touch them together, then pull",
            listOf(Color(0xFFFFA24A), Color(0xFFFF5A5A))
        ) { open = 3 }
        GlassCard(Modifier.fillMaxWidth(), reveal = false) {
            Text("How to play", style = MaterialTheme.typography.titleMedium, color = c.text)
            Text(
                "Your fingertip is the pointer. Slash by moving fast, pull by reaching out, " +
                    "and keep your whole hand in front of the camera.",
                style = MaterialTheme.typography.bodySmall, color = c.dim
            )
        }
    }
}

@Composable
private fun GameCard(title: String, sub: String, tint: List<Color>, onPlay: () -> Unit) {
    val c = Air.c
    GlassCard(Modifier.fillMaxWidth(), reveal = false) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier
                    .size(46.dp)
                    .clip(RoundedCornerShape(14.dp))
                    .background(Brush.linearGradient(tint)),
                contentAlignment = Alignment.Center
            ) {
                Text(title.take(1), color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Black)
            }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(title, style = MaterialTheme.typography.titleMedium, color = c.text)
                Text(sub, style = MaterialTheme.typography.bodySmall, color = c.dim)
            }
        }
        AirButton("Play", onPlay, Modifier.fillMaxWidth(), icon = IconKind.PLAY)
    }
}

// ---------------------------------------------------------------------------------------------
// Shared plumbing: camera gate, hand feed, frame clock
// ---------------------------------------------------------------------------------------------

/** Where the hands are this frame, in 0..1 screen space. */
private class HandFeed {
    var count = 0
    var tipX = FloatArray(2)
    var tipY = FloatArray(2)
    var palmX = FloatArray(2)
    var palmY = FloatArray(2)
    var prevX = FloatArray(2)
    var prevY = FloatArray(2)
    var speed = FloatArray(2)
    var seenAt = 0L
    var fresh = BooleanArray(2)

    fun update(hands: List<List<PointF>>) {
        val n = minOf(2, hands.size)
        val seen = BooleanArray(2)
        for (i in 0 until n) {
            val h = hands[i]
            if (h.size < 21) continue
            val tip = h[8]
            val px = (h[0].x + h[5].x + h[9].x + h[13].x + h[17].x) / 5f
            val py = (h[0].y + h[5].y + h[9].y + h[13].y + h[17].y) / 5f
            prevX[i] = tipX[i]
            prevY[i] = tipY[i]
            tipX[i] = tip.x
            tipY[i] = tip.y
            palmX[i] = px
            palmY[i] = py
            speed[i] = hypot(tipX[i] - prevX[i], tipY[i] - prevY[i])
            seen[i] = true
        }
        for (i in 0 until 2) fresh[i] = seen[i]
        count = n
        seenAt = System.currentTimeMillis()
    }

    fun alive(): Boolean = System.currentTimeMillis() - seenAt < 400
}

@Composable
private fun CameraGate(content: @Composable () -> Unit) {
    val ctx = LocalContext.current
    var ok by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED
        )
    }
    val ask = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok = it }
    if (ok) content() else AirScroll {
        ScreenHeader("Camera needed", "The games watch your hand")
        SectionCard("Allow the camera") {
            Text(
                "Air games track your fingertips on the device. Nothing is recorded or uploaded.",
                style = MaterialTheme.typography.bodySmall, color = Air.c.dim
            )
            AirButton("Allow camera", { ask.launch(Manifest.permission.CAMERA) }, Modifier.fillMaxWidth(), icon = IconKind.SCAN)
        }
    }
}

@Composable
private fun rememberHandFeed(): HandFeed {
    val ctx = LocalContext.current
    val owner = LocalLifecycleOwner.current
    val feed = remember { HandFeed() }
    val main = remember { Handler(Looper.getMainLooper()) }
    DisposableEffect(owner) {
        ctx.stopService(Intent(ctx, AirFlowService::class.java))
        val c = HandController(ctx, owner, needBitmap = false, maxHands = 2, minFps = 30) { r ->
            main.post { feed.update(r.hands) }
        }
        c.start()
        onDispose { c.stop() }
    }
    return feed
}

@Composable
private fun frameClock(onFrame: (Float) -> Unit): MutableFloatState {
    val clock = remember { mutableFloatStateOf(0f) }
    LaunchedEffect(Unit) {
        var last = 0L
        while (true) {
            withFrameNanos { now ->
                val dt = if (last == 0L) 0.016f else ((now - last) / 1_000_000_000.0).toFloat().coerceIn(0.001f, 0.05f)
                last = now
                clock.floatValue += dt
                onFrame(dt)
            }
        }
    }
    return clock
}

@Composable
private fun GameTopBar(title: String, right: String, onBack: () -> Unit) {
    val c = Air.c
    Row(Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(
            Modifier.clip(CircleShape).background(c.glass).border(1.dp, c.stroke, CircleShape)
                .pressClick { onBack() }.padding(horizontal = 12.dp, vertical = 7.dp)
        ) {
            Text("‹ Games", color = c.text, fontSize = 11.sp, fontWeight = FontWeight.Bold)
        }
        Spacer(Modifier.weight(1f))
        Text(title, color = c.dim, fontSize = 11.sp, fontWeight = FontWeight.Black, letterSpacing = 2.sp)
        Spacer(Modifier.weight(1f))
        Text(right, color = c.a2, fontSize = 13.sp, fontWeight = FontWeight.Black)
    }
}

// ---------------------------------------------------------------------------------------------
// 1. Air Slash
// ---------------------------------------------------------------------------------------------

@Composable
fun AirSlashScreen(onExit: () -> Unit) {
    CameraGate {
        val c = Air.c
        val haptic = LocalHapticFeedback.current
        val feed = rememberHandFeed()
        val game = remember { SlashGame() }
        var score by remember { mutableIntStateOf(0) }
        var lives by remember { mutableIntStateOf(3) }
        var over by remember { mutableStateOf(false) }
        var combo by remember { mutableIntStateOf(0) }
        val trails = remember { Array(2) { ArrayList<Offset>() } }
        val bursts = remember { ArrayList<FloatArray>() }   // x, y, vx, vy, life

        val clock = frameClock { dt ->
            if (!over) {
                game.update(dt)
                if (feed.alive()) {
                    for (i in 0 until 2) {
                        if (!feed.fresh[i]) continue
                        val hits = game.slice(feed.prevX[i], feed.prevY[i], feed.tipX[i], feed.tipY[i], feed.speed[i])
                        if (hits > 0) {
                            haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                            bursts.add(floatArrayOf(feed.tipX[i], feed.tipY[i], 0f, 0f, 1f))
                        }
                        val t = trails[i]
                        t.add(Offset(feed.tipX[i], feed.tipY[i]))
                        if (t.size > 14) t.removeAt(0)
                    }
                }
                score = game.score
                lives = game.lives
                combo = game.combo
                over = game.over
            }
            var i = 0
            while (i < bursts.size) {
                val b = bursts[i]
                b[4] -= dt * 1.6f
                if (b[4] <= 0f) bursts.removeAt(i) else i++
            }
        }

        Box(Modifier.fillMaxSize()) {
            Canvas(Modifier.fillMaxSize()) {
                drawRect(Brush.verticalGradient(listOf(Color(0xFF0A1020), Color(0xFF121A32), Color(0xFF0A1020))))
                // stars
                for (k in 0 until 26) {
                    val x = ((k * 97) % 100) / 100f * size.width
                    val y = ((k * 61) % 100) / 100f * size.height * 0.7f
                    drawCircle(Color.White.copy(alpha = 0.06f), 2.5f, Offset(x, y))
                }
                for (f in game.fruits) {
                    val o = Offset(f.x * size.width, f.y * size.height)
                    val r = f.r * size.width
                    if (f.sliced) {
                        val a = f.life.coerceIn(0f, 1f)
                        drawCircle(Color.White.copy(alpha = 0.25f * a), r * (1.6f - a * 0.6f), o, style = Stroke(3f))
                        continue
                    }
                    if (f.kind == 5) {
                        drawCircle(Color(0xFF2A3350), r, o)
                        drawCircle(Color(0xFFFF5A5A).copy(alpha = 0.85f), r * 0.62f, o, style = Stroke(2.5f))
                        drawCircle(Color(0xFFFF5A5A), r * 0.22f, o)
                    } else {
                        val col = when (f.kind) {
                            0 -> Color(0xFFFF5A5A)
                            1 -> Color(0xFFFFA24A)
                            2 -> Color(0xFF34F5A5)
                            3 -> Color(0xFF22D3EE)
                            else -> Color(0xFFFF4FD8)
                        }
                        drawCircle(Brush.radialGradient(listOf(col, col.copy(alpha = 0.55f)), o, r), r, o)
                        drawCircle(Color.White.copy(alpha = 0.5f), r * 0.22f, Offset(o.x - r * 0.3f, o.y - r * 0.3f))
                    }
                }
                // fingertip trails
                for (t in trails) {
                    for (k in 1 until t.size) {
                        val a = k.toFloat() / t.size
                        drawLine(
                            Color(0xFF9BFFE8).copy(alpha = a * 0.9f),
                            Offset(t[k - 1].x * size.width, t[k - 1].y * size.height),
                            Offset(t[k].x * size.width, t[k].y * size.height),
                            strokeWidth = 2f + 7f * a, cap = StrokeCap.Round
                        )
                    }
                }
                for (b in bursts) {
                    val a = b[4].coerceIn(0f, 1f)
                    drawCircle(Color.White.copy(alpha = a * 0.5f), (1f - a) * 46f + 8f, Offset(b[0] * size.width, b[1] * size.height), style = Stroke(2.5f))
                }
                // fingertips
                if (feed.alive()) {
                    for (i in 0 until 2) {
                        if (!feed.fresh[i]) continue
                        val o = Offset(feed.tipX[i] * size.width, feed.tipY[i] * size.height)
                        drawCircle(Color(0xFF34F5A5).copy(alpha = 0.3f), 16f, o)
                        drawCircle(Color.White, 6f, o)
                    }
                }
            }

            Column(Modifier.fillMaxSize().padding(top = WindowInsets.statusBars.asPaddingValues().calculateTopPadding())) {
                GameTopBar("AIR SLASH", "$score", onExit)
                Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp), verticalAlignment = Alignment.CenterVertically) {
                    repeat(3) { i ->
                        drawLives(i < lives)
                        Spacer(Modifier.width(6.dp))
                    }
                    Spacer(Modifier.weight(1f))
                    if (combo > 1) Text("×$combo COMBO", color = c.a3, fontSize = 12.sp, fontWeight = FontWeight.Black)
                }
                Spacer(Modifier.weight(1f))
                if (!feed.alive()) {
                    Text(
                        "Show your hand to the camera",
                        Modifier.fillMaxWidth().padding(bottom = 40.dp),
                        color = c.dim, fontSize = 12.sp, textAlign = TextAlign.Center
                    )
                }
            }

            if (over) {
                Box(Modifier.fillMaxSize().background(Color(0xD9080C18.toInt()))) {
                    Column(
                        Modifier.fillMaxSize().padding(28.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        Text("GAME OVER", color = c.warn, fontSize = 13.sp, fontWeight = FontWeight.Black, letterSpacing = 4.sp)
                        Spacer(Modifier.height(8.dp))
                        Text("$score", color = Color.White, fontSize = 64.sp, fontWeight = FontWeight.Black)
                        Text("best combo ×${game.bestCombo}", color = c.dim, fontSize = 12.sp)
                        Spacer(Modifier.height(20.dp))
                        AirButton("Play again", {
                            game.reset()
                            score = 0; lives = 3; combo = 0; over = false
                            trails.forEach { it.clear() }
                        }, Modifier.fillMaxWidth(0.7f), icon = IconKind.REPLAY)
                        Spacer(Modifier.height(8.dp))
                        AirButton("Back to games", onExit, Modifier.fillMaxWidth(0.7f), filled = false)
                    }
                }
            }
        }
    }
}

@Composable
private fun drawLives(on: Boolean) {
    val c = Air.c
    Box(
        Modifier
            .size(12.dp)
            .clip(CircleShape)
            .background(if (on) c.a3 else Color.White.copy(alpha = 0.15f))
    )
}

// ---------------------------------------------------------------------------------------------
// 2. Air Pong — two players, one phone
// ---------------------------------------------------------------------------------------------

@Composable
fun AirPongScreen(onExit: () -> Unit) {
    CameraGate {
        val c = Air.c
        val feed = rememberHandFeed()
        val game = remember { PongGame() }
        var s1 by remember { mutableIntStateOf(0) }
        var s2 by remember { mutableIntStateOf(0) }
        var over by remember { mutableStateOf(false) }
        var winner by remember { mutableIntStateOf(0) }

        val clock = frameClock { dt ->
            var leftY: Float? = null
            var rightY: Float? = null
            if (feed.alive()) {
                if (feed.count >= 2 && feed.fresh[0] && feed.fresh[1]) {
                    val a = feed.palmX[0] to feed.palmY[0]
                    val b = feed.palmX[1] to feed.palmY[1]
                    if (a.first <= b.first) { leftY = a.second; rightY = b.second }
                    else { leftY = b.second; rightY = a.second }
                } else {
                    for (i in 0 until 2) {
                        if (!feed.fresh[i]) continue
                        if (feed.palmX[i] < 0.5f) leftY = feed.palmY[i] else rightY = feed.palmY[i]
                    }
                }
            }
            if (!over) game.update(dt, leftY, rightY)
            s1 = game.s1; s2 = game.s2; over = game.over; winner = game.winner
        }

        Box(Modifier.fillMaxSize()) {
            Canvas(Modifier.fillMaxSize()) {
                drawRect(Brush.verticalGradient(listOf(Color(0xFF0B1024), Color(0xFF1A1030))))
                // the middle line
                var y = 0f
                while (y < size.height) {
                    drawRect(Color.White.copy(alpha = 0.10f), Offset(size.width / 2f - 2f, y), Size(4f, size.height / 26f))
                    y += size.height / 13f
                }
                // paddles
                val ph = size.height * 0.28f
                val pw = size.width * 0.022f
                drawRoundRect(
                    Brush.verticalGradient(listOf(Color(0xFF22D3EE), Color(0xFF4F8BFF))),
                    Offset(size.width * 0.055f, game.p1y * size.height - ph / 2f),
                    Size(pw, ph), CornerRadius(pw / 2f, pw / 2f)
                )
                drawRoundRect(
                    Brush.verticalGradient(listOf(Color(0xFFFF4FD8), Color(0xFF8B5CFF))),
                    Offset(size.width * 0.945f - pw, game.p2y * size.height - ph / 2f),
                    Size(pw, ph), CornerRadius(pw / 2f, pw / 2f)
                )
                // ball with a trail
                val bx = game.ballX * size.width
                val by = game.ballY * size.height
                val r = size.width * 0.020f
                for (k in 1..4) {
                    drawCircle(
                        Color.White.copy(alpha = 0.06f * (5 - k)),
                        r * (1f + k * 0.35f),
                        Offset(bx - game.vx * size.width * 0.012f * k, by - game.vy * size.height * 0.012f * k)
                    )
                }
                drawCircle(Color.White, r, Offset(bx, by))
                if (game.flash > 0f) {
                    drawCircle(Color(0xFF34F5A5).copy(alpha = 0.35f * game.flash), r * 4f, Offset(bx, by))
                }
            }

            Column(Modifier.fillMaxSize().padding(top = WindowInsets.statusBars.asPaddingValues().calculateTopPadding())) {
                GameTopBar("AIR PONG", "$s1  ·  $s2", onExit)
                Row(Modifier.fillMaxWidth().padding(horizontal = 20.dp)) {
                    Text("YOU", color = Color(0xFF22D3EE), fontSize = 11.sp, fontWeight = FontWeight.Black)
                    Spacer(Modifier.weight(1f))
                    Text("YOU", color = Color(0xFFFF4FD8), fontSize = 11.sp, fontWeight = FontWeight.Black)
                }
                Spacer(Modifier.weight(1f))
                Text(
                    if (!feed.alive()) "Both players: show a hand to the camera"
                    else if (feed.count < 2) "Waiting for the second player's hand…"
                    else "Move your hand up and down to steer your paddle",
                    Modifier.fillMaxWidth().padding(bottom = 26.dp),
                    color = c.dim, fontSize = 12.sp, textAlign = TextAlign.Center
                )
            }

            if (over) {
                Box(Modifier.fillMaxSize().background(Color(0xDD080C18))) {
                    Column(
                        Modifier.fillMaxSize().padding(28.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        Text(
                            if (winner == 1) "LEFT PLAYER WINS" else "RIGHT PLAYER WINS",
                            color = if (winner == 1) Color(0xFF22D3EE) else Color(0xFFFF4FD8),
                            fontSize = 16.sp, fontWeight = FontWeight.Black, letterSpacing = 2.sp
                        )
                        Spacer(Modifier.height(10.dp))
                        Text("$s1  ·  $s2", color = Color.White, fontSize = 44.sp, fontWeight = FontWeight.Black)
                        Spacer(Modifier.height(20.dp))
                        AirButton("Play again", {
                            game.reset(); s1 = 0; s2 = 0; over = false; winner = 0
                        }, Modifier.fillMaxWidth(0.7f), icon = IconKind.REPLAY)
                        Spacer(Modifier.height(8.dp))
                        AirButton("Back to games", onExit, Modifier.fillMaxWidth(0.7f), filled = false)
                    }
                }
            }
        }
    }
}

// ---------------------------------------------------------------------------------------------
// 3. Air Tug — two phones over Nearby
// ---------------------------------------------------------------------------------------------

@Composable
fun AirTugScreen(onExit: () -> Unit) {
    CameraGate {
        val c = Air.c
        val ctx = LocalContext.current
        val owner = LocalLifecycleOwner.current
        val haptic = LocalHapticFeedback.current
        val feed = rememberHandFeed()
        val game = remember { TugGame() }
        val main = remember { Handler(Looper.getMainLooper()) }

        var status by remember { mutableStateOf("Touch the two phones together") }
        var linked by remember { mutableStateOf(false) }
        var isHost by remember { mutableStateOf(true) }
        var peers by remember { mutableIntStateOf(0) }
        var knot by remember { mutableFloatStateOf(0.5f) }
        var over by remember { mutableStateOf(false) }
        var winner by remember { mutableIntStateOf(0) }
        var myPull by remember { mutableFloatStateOf(0f) }
        var theirPull by remember { mutableFloatStateOf(0f) }
        var countdown by remember { mutableFloatStateOf(0f) }

        fun post(block: () -> Unit) { main.post(block) }

        val link = remember {
            GameLink(ctx, object : GameLink.Callbacks {
                override fun peers(count: Int) = post { peers = count }
                override fun connected(host: Boolean, name: String) = post {
                    isHost = host
                    linked = true
                    countdown = 3.2f
                    status = if (host) "Linked. You are the left side." else "Linked. You are the right side."
                }
                override fun lost() = post { linked = false; status = "Link lost. Touch again." }
                override fun failed(msg: String) = post { status = msg }
                override fun message(json: String) = post {
                    val o = try { JSONObject(json) } catch (e: Exception) { return@post }
                    when (o.optString("k")) {
                        "p" -> game.theirPull = o.optDouble("p", 0.0).toFloat()
                        "s" -> {
                            game.knot = o.optDouble("knot", 0.5).toFloat()
                            game.over = o.optInt("over", 0) == 1
                            game.winner = o.optInt("w", 0)
                            // the guest also sees the host's pull bar
                            if (!isHost) game.theirPull = o.optDouble("p2", 0.0).toFloat()
                        }
                    }
                }
            })
        }

        val bump = remember {
            BumpDetector(ctx, { link.bump() }, { _, _ -> })
        }

        DisposableEffect(owner) {
            link.start()
            bump.start()
            val obs = LifecycleEventObserver { _, e ->
                if (e == Lifecycle.Event.ON_RESUME) { link.start(); bump.start() }
                if (e == Lifecycle.Event.ON_PAUSE) bump.stop()
            }
            owner.lifecycle.addObserver(obs)
            onDispose {
                owner.lifecycle.removeObserver(obs)
                bump.stop()
                link.stop()
            }
        }

        var sendIn = 0f
        val clock = frameClock { dt ->
            if (countdown > 0f) countdown -= dt
            val playing = linked && countdown <= 0f && !over
            val handX = if (feed.alive() && feed.fresh[0]) feed.palmX[0] else null
            if (playing) {
                game.addHand(handX, dt)
                if (isHost) game.hostUpdate(dt) else game.guestUpdate(dt)
            }
            knot = game.knot
            myPull = game.myPull
            theirPull = game.theirPull
            if (game.over && !over) {
                over = true
                winner = game.winner
                haptic.performHapticFeedback(HapticFeedbackType.LongPress)
            }
            // 12 messages a second is plenty for a rope
            sendIn -= dt
            if (sendIn <= 0f && linked) {
                sendIn = 0.08f
                if (isHost) {
                    link.send(
                        JSONObject().put("k", "s").put("knot", game.knot.toDouble())
                            .put("over", if (game.over) 1 else 0).put("w", game.winner)
                            .put("p2", game.theirPull.toDouble()).toString()
                    )
                } else {
                    link.send(JSONObject().put("k", "p").put("p", game.myPull.toDouble()).toString())
                }
            }
        }

        Box(Modifier.fillMaxSize()) {
            Canvas(Modifier.fillMaxSize()) {
                drawRect(Brush.verticalGradient(listOf(Color(0xFF12101C), Color(0xFF241428), Color(0xFF12101C))))
                val midY = size.height * 0.52f
                // ground
                drawRect(
                    Brush.verticalGradient(listOf(Color.White.copy(alpha = 0.04f), Color.Transparent)),
                    Offset(0f, midY + 60f), Size(size.width, size.height - midY)
                )
                // the rope
                val x0 = size.width * 0.12f
                val x1 = size.width * 0.88f
                val knotX = x0 + (x1 - x0) * game.knot
                val sag = 10f + 6f * sin(clock.floatValue * 3f)
                val rope = Path().apply {
                    moveTo(x0, midY)
                    quadraticBezierTo((x0 + knotX) / 2f, midY + sag, knotX, midY)
                    quadraticBezierTo((knotX + x1) / 2f, midY + sag, x1, midY)
                }
                drawPath(rope, Color(0xFFB9C4E0).copy(alpha = 0.85f), style = Stroke(7f, cap = StrokeCap.Round))
                // ends
                drawCircle(Color(0xFF22D3EE), 16f, Offset(x0, midY))
                drawCircle(Color(0xFFFF4FD8), 16f, Offset(x1, midY))
                // the knot
                drawCircle(Color(0xFFFFA24A).copy(alpha = 0.35f), 30f, Offset(knotX, midY))
                drawCircle(Color(0xFFFFA24A), 16f, Offset(knotX, midY))
                drawCircle(Color.White.copy(alpha = 0.8f), 6f, Offset(knotX, midY))
                // pull meters
                val barW = size.width * 0.34f
                drawRoundRect(Color.White.copy(alpha = 0.10f), Offset(size.width * 0.08f, midY + 80f), Size(barW, 10f), CornerRadius(5f, 5f))
                drawRoundRect(
                    Brush.horizontalGradient(listOf(Color(0xFF22D3EE), Color(0xFF4F8BFF))),
                    Offset(size.width * 0.08f, midY + 80f), Size(barW * (game.myPull / 2.4f).coerceIn(0f, 1f), 10f), CornerRadius(5f, 5f)
                )
                drawRoundRect(Color.White.copy(alpha = 0.10f), Offset(size.width * 0.58f, midY + 80f), Size(barW, 10f), CornerRadius(5f, 5f))
                drawRoundRect(
                    Brush.horizontalGradient(listOf(Color(0xFFFF4FD8), Color(0xFF8B5CFF))),
                    Offset(size.width * 0.58f, midY + 80f), Size(barW * (game.theirPull / 2.4f).coerceIn(0f, 1f), 10f), CornerRadius(5f, 5f)
                )
                // fingertip
                if (feed.alive() && feed.fresh[0]) {
                    val o = Offset(feed.tipX[0] * size.width, feed.tipY[0] * size.height)
                    drawCircle(Color(0xFF34F5A5).copy(alpha = 0.3f), 18f, o)
                    drawCircle(Color.White, 6f, o)
                }
            }

            Column(Modifier.fillMaxSize().padding(top = WindowInsets.statusBars.asPaddingValues().calculateTopPadding())) {
                GameTopBar("AIR TUG", if (linked) "LINKED" else "OFFLINE", onExit)
                Text(
                    if (over) "Rope settled" else if (countdown > 0f) "${countdown.toInt() + 1}" else status,
                    Modifier.fillMaxWidth().padding(horizontal = 20.dp),
                    color = c.text, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, textAlign = TextAlign.Center
                )
                Spacer(Modifier.weight(1f))
                if (!linked) {
                    Column(
                        Modifier.fillMaxWidth().padding(20.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            if (peers > 0) "Phone found. Touch the tops together." else "Looking for the other phone…",
                            color = c.dim, fontSize = 12.sp, textAlign = TextAlign.Center
                        )
                        Spacer(Modifier.height(8.dp))
                        AirButton("Link manually", { link.connectNow() }, Modifier.fillMaxWidth(0.6f), filled = false)
                    }
                } else {
                    Text(
                        "Reach your hand to your side to pull the rope",
                        Modifier.fillMaxWidth().padding(bottom = 26.dp),
                        color = c.dim, fontSize = 12.sp, textAlign = TextAlign.Center
                    )
                }
            }

            if (over) {
                Box(Modifier.fillMaxSize().background(Color(0xDD0A0C18))) {
                    Column(
                        Modifier.fillMaxSize().padding(28.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        val iWon = (winner == 1 && isHost) || (winner == 2 && !isHost)
                        Text(
                            if (iWon) "YOU WIN" else "YOU LOSE",
                            color = if (iWon) c.ok else c.warn,
                            fontSize = 30.sp, fontWeight = FontWeight.Black, letterSpacing = 2.sp
                        )
                        Spacer(Modifier.height(18.dp))
                        AirButton("Play again", {
                            game.reset(); over = false; winner = 0; countdown = 3.2f
                        }, Modifier.fillMaxWidth(0.7f), icon = IconKind.REPLAY)
                        Spacer(Modifier.height(8.dp))
                        AirButton("Back to games", onExit, Modifier.fillMaxWidth(0.7f), filled = false)
                    }
                }
            }
        }
    }
}
