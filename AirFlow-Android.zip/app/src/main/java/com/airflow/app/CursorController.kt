package com.airflow.app

import android.graphics.PointF
import kotlin.math.hypot
import kotlin.math.max

/**
 * Hand-as-a-mouse. The index fingertip moves the cursor; a pinch is the mouse button:
 *  - quick pinch            = tap
 *  - pinch, still 0.6 s     = "grab" (orange). Release still = long-press, move then release = press-hold-drag
 *  - pinch and move at once = drag / scroll / swipe (performed as one swipe when you release)
 * Runs on the main thread, fed one camera frame at a time.
 */
class CursorController(private val svc: AirFlowAccessibilityService) {
    private enum class St { IDLE, PRESSED }
    private class P(val t: Long, val x: Float, val y: Float)

    private var st = St.IDLE
    private var x = 0f
    private var y = 0f
    private var hasPos = false
    private val trail = ArrayDeque<P>()
    private var downT = 0L
    private var downX = 0f
    private var downY = 0f
    private var anchorX = 0f
    private var anchorY = 0f
    private var moved = false
    private var grab = false
    private var nonPinchSince = 0L
    private var lostSince = 0L
    private var lastRelease = 0L

    fun reset() {
        st = St.IDLE
        hasPos = false
        trail.clear()
        moved = false
        grab = false
        nonPinchSince = 0L
        lostSince = 0L
    }

    fun onFrame(pose: GestureEngine.Pose, lm: List<PointF>?, now: Long) {
        val size = svc.screenSize()
        val w = size.first
        val h = size.second

        if (lm == null || lm.size < 21) {
            if (lostSince == 0L) lostSince = now
            svc.overlayHandVisible(false)
            if (st == St.PRESSED && now - lostSince > LOST_CANCEL_MS) {
                // Hand vanished mid-press: cancel rather than guess.
                st = St.IDLE
                svc.overlayUpdate(x, y, CursorOverlay.S_IDLE)
            }
            return
        }
        lostSince = 0L
        svc.overlayHandVisible(true)

        // Use only the middle part of the camera frame so you never have to reach the edges.
        val range = Prefs.cursorRange
        val margin = (1f - range) / 2f
        val tipX = ((lm[8].x - margin) / range).coerceIn(0f, 1f) * w
        val tipY = ((lm[8].y - margin) / range).coerceIn(0f, 1f) * h
        val knX = ((lm[5].x - margin) / range).coerceIn(0f, 1f) * w
        val knY = ((lm[5].y - margin) / range).coerceIn(0f, 1f) * h
        val pinch = pose == GestureEngine.Pose.PINCH
        val frozen = pose == GestureEngine.Pose.FIST || pose == GestureEngine.Pose.THUMB_UP ||
            pose == GestureEngine.Pose.THUMB_DOWN

        if (st == St.IDLE) {
            if (frozen) return // fist / thumbs are for the system gestures: leave the cursor where it is
            moveTo(tipX, tipY, now, w)
            if (pinch && now - lastRelease > REPRESS_MS) {
                // The fingertip drifts toward the thumb while pinching, so click where it was a moment ago.
                val p = trail.lastOrNull { it.t <= now - LAG_MS } ?: trail.firstOrNull()
                downX = p?.x ?: x
                downY = p?.y ?: y
                x = downX; y = downY
                anchorX = knX; anchorY = knY
                downT = now
                moved = false; grab = false; nonPinchSince = 0L
                st = St.PRESSED
                svc.overlayUpdate(x, y, CursorOverlay.S_DOWN)
            } else {
                svc.overlayUpdate(x, y, CursorOverlay.S_IDLE)
            }
            return
        }

        // PRESSED
        if (pinch) {
            nonPinchSince = 0L
            // While pinching follow the knuckle (it does not move when you pinch), relative to where we pressed.
            val tx = (downX + (knX - anchorX)).coerceIn(0f, w)
            val ty = (downY + (knY - anchorY)).coerceIn(0f, h)
            x += (tx - x) * 0.55f
            y += (ty - y) * 0.55f
            val th = max(40f, w * 0.04f)
            if (!moved && hypot(x - downX, y - downY) > th) moved = true
            if (!moved && !grab && now - downT >= GRAB_MS) {
                grab = true
                svc.buzz()
            }
            val s = when {
                moved && grab -> CursorOverlay.S_GRAB_DRAG
                moved -> CursorOverlay.S_DRAG
                grab -> CursorOverlay.S_GRAB
                else -> CursorOverlay.S_DOWN
            }
            svc.overlayUpdate(x, y, s, downX, downY)
        } else {
            if (nonPinchSince == 0L) nonPinchSince = now
            if (now - nonPinchSince >= RELEASE_MS) finish(now)
        }
    }

    private fun finish(now: Long) {
        val held = now - downT - RELEASE_MS
        when {
            !moved && grab -> { svc.longPressAt(downX, downY); svc.overlayRipple(downX, downY) }
            !moved -> { svc.tapAt(downX, downY); svc.overlayRipple(downX, downY) }
            grab -> svc.dragFromTo(downX, downY, x, y, 450L, true)
            else -> svc.dragFromTo(downX, downY, x, y, held.coerceIn(150L, 500L), false)
        }
        svc.buzz()
        st = St.IDLE
        lastRelease = now
        trail.clear()
        svc.overlayUpdate(x, y, CursorOverlay.S_IDLE)
    }

    /** Adaptive smoothing: steady when you hover (no jitter), responsive when you move fast. */
    private fun moveTo(tx: Float, ty: Float, now: Long, w: Float) {
        if (!hasPos) {
            x = tx; y = ty; hasPos = true
        } else {
            val d = hypot(tx - x, ty - y) / w
            if (d >= 0.0015f) {
                val a = (0.2f + d * 9f).coerceIn(0.2f, 0.85f)
                x += (tx - x) * a
                y += (ty - y) * a
            }
        }
        trail.addLast(P(now, x, y))
        while (trail.isNotEmpty() && now - trail.first().t > 600L) trail.removeFirst()
    }

    private companion object {
        const val LAG_MS = 180L        // click where the cursor was this long before the pinch registered
        const val GRAB_MS = 600L       // hold a pinch still this long to "grab" / long-press
        const val RELEASE_MS = 120L    // pinch must be open this long to count as released (kills flicker)
        const val REPRESS_MS = 250L    // pause after a click before the next pinch can start
        const val LOST_CANCEL_MS = 350L
    }
}
