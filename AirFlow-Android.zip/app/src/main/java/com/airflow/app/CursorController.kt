package com.airflow.app

import android.graphics.PointF
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.hypot
import kotlin.math.max

/**
 * Hand-as-a-mouse. The index fingertip moves the cursor; a pinch is the mouse button:
 *  - quick pinch            = tap (generous: small hand shake still counts as a tap)
 *  - pinch, still 0.6 s     = "grab" (orange). Release still = long-press, move then release = press-hold-drag
 *  - pinch and move at once = drag / scroll / swipe (performed as one swipe when you release)
 *  - optional hover-to-tap  = keep the cursor still for ~0.9 s and it taps by itself
 * Runs on the main thread, fed one camera frame at a time.
 */
class CursorController(private val svc: AirFlowAccessibilityService) {
    private enum class St { IDLE, PRESSED }
    private class P(val t: Long, val x: Float, val y: Float)

    /** One-Euro filter: very steady when the hand hovers, almost no lag when it moves fast. */
    private class OneEuro {
        private var xPrev = 0f
        private var dxPrev = 0f
        private var rawPrev = 0f
        private var has = false

        fun reset() { has = false }

        fun filter(v: Float, dt: Float, minCut: Float, beta: Float): Float {
            if (!has) {
                has = true; xPrev = v; rawPrev = v; dxPrev = 0f
                return v
            }
            val dx = (v - rawPrev) / dt
            rawPrev = v
            dxPrev += alpha(1.0f, dt) * (dx - dxPrev)
            val cutoff = minCut + beta * abs(dxPrev)
            xPrev += alpha(cutoff, dt) * (v - xPrev)
            return xPrev
        }

        private fun alpha(cutoff: Float, dt: Float): Float {
            val tau = 1f / (2f * PI.toFloat() * cutoff)
            return 1f / (1f + tau / dt)
        }
    }

    private val fx = OneEuro()
    private val fy = OneEuro()

    private var st = St.IDLE
    private var x = 0f
    private var y = 0f
    private var hasPos = false
    private var lastT = 0L
    private val trail = ArrayDeque<P>()
    private var downT = 0L
    private var downX = 0f
    private var downY = 0f
    private var anchorX = 0f
    private var anchorY = 0f
    private var moved = false
    private var grab = false
    private var nonPinchFrames = 0
    private var nonPinchSince = 0L
    private var lostSince = 0L
    private var lastRelease = 0L

    // hover-to-tap
    private var dwellX = 0f
    private var dwellY = 0f
    private var dwellStart = 0L
    private var dwellArmed = true

    fun reset() {
        st = St.IDLE
        hasPos = false
        trail.clear()
        fx.reset(); fy.reset()
        moved = false
        grab = false
        nonPinchFrames = 0
        nonPinchSince = 0L
        lostSince = 0L
        dwellArmed = true
        dwellStart = 0L
    }

    fun onFrame(pose: GestureEngine.Pose, lm: List<PointF>?, now: Long) {
        val size = svc.screenSize()
        val w = size.first
        val h = size.second

        if (lm == null || lm.size < 21) {
            if (lostSince == 0L) lostSince = now
            svc.overlayHandVisible(false)
            dwellStart = 0L
            if (st == St.PRESSED && now - lostSince > LOST_CANCEL_MS) {
                // Hand vanished mid-press: cancel rather than guess.
                st = St.IDLE
                svc.overlayUpdate(x, y, CursorOverlay.S_IDLE)
            }
            return
        }
        lostSince = 0L
        svc.overlayHandVisible(true)

        // Use only the middle part of the camera frame so you never have to reach the edges.
        val range = Prefs.cursorRange
        val margin = (1f - range) / 2f
        val tipX = ((lm[8].x - margin) / range).coerceIn(0f, 1f) * w
        val tipY = ((lm[8].y - margin) / range).coerceIn(0f, 1f) * h
        val knX = ((lm[5].x - margin) / range).coerceIn(0f, 1f) * w
        val knY = ((lm[5].y - margin) / range).coerceIn(0f, 1f) * h
        val pinch = pose == GestureEngine.Pose.PINCH
        val frozen = pose == GestureEngine.Pose.FIST || pose == GestureEngine.Pose.THUMB_UP ||
            pose == GestureEngine.Pose.THUMB_DOWN

        val dt = if (lastT == 0L) 0.033f else ((now - lastT) / 1000f).coerceIn(0.008f, 0.1f)
        lastT = now

        if (st == St.IDLE) {
            if (frozen) { dwellStart = 0L; return } // fist / thumbs are for system gestures: leave cursor alone
            smoothTo(tipX, tipY, now, dt)
            if (pinch && now - lastRelease > REPRESS_MS) {
                // The fingertip drifts toward the thumb while pinching, so click where it was a moment ago.
                val p = trail.lastOrNull { it.t <= now - LAG_MS } ?: trail.firstOrNull()
                downX = p?.x ?: x
                downY = p?.y ?: y
                x = downX; y = downY
                fx.reset(); fy.reset()
                fx.filter(x, dt, 1f, 0f); fy.filter(y, dt, 1f, 0f)
                anchorX = knX; anchorY = knY
                downT = now
                moved = false; grab = false
                nonPinchFrames = 0; nonPinchSince = 0L
                dwellStart = 0L
                st = St.PRESSED
                svc.overlayUpdate(x, y, CursorOverlay.S_DOWN)
            } else {
                svc.overlayUpdate(x, y, CursorOverlay.S_IDLE, 0f, 0f, dwell(now, w, pinch))
            }
            return
        }

        // PRESSED
        if (pinch) {
            nonPinchFrames = 0
            nonPinchSince = 0L
            // While pinching follow the knuckle (it does not move when you pinch), relative to where we pressed.
            val tx = (downX + (knX - anchorX)).coerceIn(0f, w)
            val ty = (downY + (knY - anchorY)).coerceIn(0f, h)
            val minCut = minCutoff()
            x = fx.filter(tx, dt, minCut, BETA)
            y = fy.filter(ty, dt, minCut, BETA)
            val dist = hypot(x - downX, y - downY)
            if (!moved && dist > max(80f, w * 0.08f)) moved = true
            if (!moved && !grab && now - downT >= GRAB_MS) {
                grab = true
                svc.buzz()
            }
            val s = when {
                moved && grab -> CursorOverlay.S_GRAB_DRAG
                moved -> CursorOverlay.S_DRAG
                grab -> CursorOverlay.S_GRAB
                else -> CursorOverlay.S_DOWN
            }
            svc.overlayUpdate(x, y, s, downX, downY)
        } else {
            nonPinchFrames++
            if (nonPinchSince == 0L) nonPinchSince = now
            // Two open frames in a row = released (ignores a single flickery frame, but stays fast).
            if (nonPinchFrames >= 2 || now - nonPinchSince >= RELEASE_MS) finish(now, w)
        }
    }

    private fun finish(now: Long, w: Float) {
        val held = now - downT
        val dist = hypot(x - downX, y - downY)
        val quickSmall = held < 380L && dist < max(120f, w * 0.11f)
        when {
            !moved && grab -> { svc.longPressAt(downX, downY); svc.overlayRipple(downX, downY) }
            !moved || quickSmall -> { svc.tapAt(downX, downY); svc.overlayRipple(downX, downY) }
            grab -> svc.dragFromTo(downX, downY, x, y, 450L, true)
            else -> svc.dragFromTo(downX, downY, x, y, (held - 100L).coerceIn(150L, 500L), false)
        }
        svc.buzz()
        st = St.IDLE
        lastRelease = now
        trail.clear()
        hasPos = false
        fx.reset(); fy.reset() // next frame snaps the cursor to where the fingertip really is
        dwellStart = 0L
        dwellArmed = false
        dwellX = x; dwellY = y
        svc.overlayUpdate(x, y, CursorOverlay.S_IDLE)
    }

    /** Optional hover-to-tap. Returns the progress (0..1) for the ring drawn around the cursor. */
    private fun dwell(now: Long, w: Float, pinch: Boolean): Float {
        if (!Prefs.dwellClick || pinch) { dwellStart = 0L; return 0f }
        val radius = max(45f, w * 0.045f)
        if (hypot(x - dwellX, y - dwellY) > radius) {
            // Moved away: start a new hover here (and allow a tap again).
            dwellX = x; dwellY = y; dwellStart = now; dwellArmed = true
            return 0f
        }
        if (dwellStart == 0L) { dwellStart = now; return 0f }
        if (!dwellArmed) return 0f
        val p = (now - dwellStart) / DWELL_MS.toFloat()
        if (p >= 1f) {
            svc.tapAt(dwellX, dwellY)
            svc.overlayRipple(dwellX, dwellY)
            svc.buzz()
            dwellArmed = false
            lastRelease = now
            return 0f
        }
        return p
    }

    /** Smoothness slider 0..1 (1 = ultra smooth) -> filter cutoff. */
    private fun minCutoff(): Float {
        val smooth = Prefs.cursorSmooth.coerceIn(0f, 1f)
        return 3.2f - 2.6f * smooth // 3.2 Hz (light smoothing) .. 0.6 Hz (ultra smooth)
    }

    private fun smoothTo(tx: Float, ty: Float, now: Long, dt: Float) {
        val minCut = minCutoff()
        x = fx.filter(tx, dt, minCut, BETA)
        y = fy.filter(ty, dt, minCut, BETA)
        hasPos = true
        trail.addLast(P(now, x, y))
        while (trail.isNotEmpty() && now - trail.first().t > 600L) trail.removeFirst()
    }

    private companion object {
        const val BETA = 0.012f        // how fast the filter opens up when the hand moves quickly
        const val LAG_MS = 90L         // click where the cursor was this long before the pinch registered
        const val GRAB_MS = 600L       // hold a pinch still this long to "grab" / long-press
        const val RELEASE_MS = 70L     // max time a pinch can look open before it counts as released
        const val REPRESS_MS = 150L    // pause after a click before the next pinch can start
        const val DWELL_MS = 900L      // hover-to-tap time
        const val LOST_CANCEL_MS = 350L
    }
}
