package com.airflow.app

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.ComponentName
import android.service.quicksettings.TileService
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.PointF
import android.graphics.Shader
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.os.VibrationEffect
import android.os.Vibrator
import android.provider.Settings
import android.view.WindowManager
import androidx.core.app.NotificationCompat
import kotlinx.coroutines.flow.MutableStateFlow
import java.io.File

/**
 * Air Share everywhere. One object owns the whole flow while the Air Flow service is running:
 *
 *  - SEND: a photo shared from any app (gallery, WhatsApp...) is "armed". Show an open palm, close a fist
 *    to capture it, open the hand to release it. The orb launches and the files travel over Nearby.
 *  - RECEIVE: the other phone, with Air Share on, sees the orb arrive over whatever app is open. Make a
 *    fist, then open the hand, and the photo blooms out of the orb. Files are already saved to the gallery.
 *
 * The camera frames come from the existing service (AirFlowService), so there is only one camera user.
 * Everything runs on the main thread.
 */
object AirShareHub {

    private const val S_IDLE = 0
    private const val S_ARMED = 1
    private const val S_READY = 2
    private const val S_CAPTURED = 3
    private const val S_SENDING = 4
    private const val S_DONE = 5
    private const val S_DRAG = 6

    private const val GRAB_MS = 450L

    private const val R_IDLE = 0
    private const val R_INCOMING = 1
    private const val R_WAIT = 2
    private const val R_CATCH = 3
    private const val R_REVEAL = 4

    /** True while the background Air Share is on (the service called [attach]). */
    val active = MutableStateFlow(false)

    /** A short human line for the Anywhere screen: what is going on, or what is wrong. */
    val status = MutableStateFlow("")

    private val main = Handler(Looper.getMainLooper())

    private var svc: Context? = null
    private var link: TapLink? = null
    private var overlay: AirShareOverlay? = null
    private var overlayWm: WindowManager? = null
    private var overlayLp: WindowManager.LayoutParams? = null
    private var endToken = 0

    private val grab = AirGrabTracker()
    private val catcher = AirReceiveTracker()

    private var sendPhase = S_IDLE
    private var recvPhase = R_IDLE

    private var queue: List<QueuedFile> = emptyList()
    private var sendBitmaps: List<Bitmap> = emptyList()
    private val recvItems = ArrayList<RecvItem>()
    private val recvBitmaps = ArrayList<Bitmap>()
    private var recvTotal = 0

    private var bump: BumpDetector? = null
    private var tapActive = false
    private var recvTap = false

    /** True when started with the hand gestures too (Air Share); false when only the touch (Tap Share) is on. */
    @Volatile var airMode = false

    private var quick: QuickItem? = null
    private var shownQuick: QuickItem? = null
    private val quickEnd = Runnable { quickClose() }

    private var linked = false
    private var peers = 0
    private var pendingSend = false
    private var handLostAt = 0L
    private var demo = false

    // ---- Air Blast: one flick to every phone in the room ----
    private var blast: BlastLink? = null
    private var blastMode = false
    private var blastQuick: QuickItem? = null
    private var blastRecv = false
    private val flick = FlickDetector()
    private var lastLm: List<PointF>? = null
    /** Phones in the room (host side). */
    val blastMembers = MutableStateFlow(0)
    /** An offer waiting for this phone's owner to accept or decline (receiver side). */
    val blastPrompt = MutableStateFlow<BlastPrompt?>(null)
    /** True while this phone has joined a sender's room. */
    val blastInRoom = MutableStateFlow(false)
    val blastStatus = MutableStateFlow("")
    private val blastIdle = Runnable { blast?.stopHost(); blastMembers.value = 0; resumeTapIfFree() }

    // ---- Air Grab: a held fist captures what is on screen ----
    private var grabQuick: QuickItem? = null
    private var grabbing = false
    private var fistSince = 0L
    private var fistX = 0f
    private var fistY = 0f
    private var grabCool = 0L

    private val armTimeout = Runnable { cancelSend() }
    private val sendTimeout = Runnable { failSend("No Air Flow phone found. Is Air Share on there, and is it close?") }
    private val recvTimeout = Runnable { endReceive() }
    private val revealEnd = Runnable { endReceive() }
    private val doneEnd = Runnable { finishSendScene() }
    private val tapPairTimeout = Runnable { tapEnd() }

    // =========================================================================================
    // Lifecycle (called by the service)
    // =========================================================================================

    fun attach(ctx: Context, air: Boolean = true) {
        svc = ctx.applicationContext
        airMode = airMode || air
        if (link == null) {
            val l = TapLink(ctx.applicationContext, linkCallbacks)
            link = l
            if (Perms.missing(ctx).isEmpty()) {
                l.start()
                status.value = "Air Share is on. Waiting for photos."
            } else {
                status.value = "Allow Location and Nearby devices to use Air Share."
            }
        }
        // a blast room opened before the service started owns Nearby; Tap Share waits
        blast?.let { if (it.isHosting || it.isListening) link?.pause() }
        if (bump == null) {
            val bd = BumpDetector(ctx.applicationContext, { onBump() }, { _, _ -> })
            bd.sensitivity = Prefs.tapSens
            bump = bd
            bd.start()
        }
        active.value = true
        refreshTiles()
        if (Prefs.blastReceive) startBlastReceiver()
        if (blastMode && blastQuick != null && sendPhase == S_IDLE && airMode) { startArmedScene(); startBlastHost() }
        // a photo may have been shared a moment before the service finished starting
        if (quick != null && sendPhase == S_IDLE) startQuickArmedScene()
        else if (queue.isNotEmpty() && sendPhase == S_IDLE && airMode) startArmedScene()
        else if (queue.isNotEmpty() && sendPhase == S_IDLE) startTapArmedScene()
    }

    /** What the live island should say while Air Share is using the hand (null = nothing special). */
    fun islandHint(): String? = when {
        recvPhase == R_WAIT -> "Fist, then open: catch it"
        recvPhase == R_CATCH -> "Open your hand to release"
        grabbing -> "Grabbing the screen"
        sendPhase == S_ARMED && blastMode -> "Flick up to blast"
        sendPhase == S_ARMED -> "Show your open palm"
        sendPhase == S_READY -> "Close your fist"
        sendPhase == S_CAPTURED -> "Open your hand to send"
        else -> null
    }

    /** Applies a new tap sensitivity right away. */
    fun setTapSensitivity(v: Int) {
        Prefs.tapSens = v
        bump?.sensitivity = v
    }

    fun refreshTiles() {
        val ctx = svc ?: return
        try {
            TileService.requestListeningState(ctx, ComponentName(ctx, AirShareTileService::class.java))
            TileService.requestListeningState(ctx, ComponentName(ctx, TapShareTileService::class.java))
        } catch (_: Exception) {
        }
    }

    fun detach() {
        cancelTimers()
        main.removeCallbacks(tapPairTimeout)
        try { bump?.stop() } catch (_: Exception) {}
        bump = null
        tapActive = false
        recvTap = false
        airMode = false
        val ctxForTiles = svc
        try { link?.stop() } catch (_: Exception) {}
        link = null
        main.removeCallbacks(blastIdle)
        try { blast?.stop() } catch (_: Exception) {}
        blast = null
        blastMode = false; blastQuick = null; blastRecv = false; grabQuick = null; grabbing = false
        blastMembers.value = 0; blastInRoom.value = false; blastPrompt.value = null
        hideOverlay()
        grab.reset()
        catcher.reset()
        sendPhase = S_IDLE
        recvPhase = R_IDLE
        linked = false
        peers = 0
        pendingSend = false
        queue = emptyList()
        sendBitmaps = emptyList()
        quick = null
        shownQuick = null
        main.removeCallbacks(quickEnd)
        clearRecv()
        demo = false
        svc = null
        active.value = false
        status.value = ""
        if (ctxForTiles != null) {
            try {
                TileService.requestListeningState(ctxForTiles, ComponentName(ctxForTiles, AirShareTileService::class.java))
                TileService.requestListeningState(ctxForTiles, ComponentName(ctxForTiles, TapShareTileService::class.java))
            } catch (_: Exception) {
            }
        }
    }

    private fun cancelTimers() {
        main.removeCallbacks(armTimeout)
        main.removeCallbacks(sendTimeout)
        main.removeCallbacks(recvTimeout)
        main.removeCallbacks(revealEnd)
        main.removeCallbacks(doneEnd)
    }

    private fun clearRecv() {
        recvItems.clear()
        recvBitmaps.clear()
        recvTotal = 0
    }

    // =========================================================================================
    // Sender
    // =========================================================================================

    /** Files shared from another app. Safe to call before the service is up: they wait for [attach]. */
    fun arm(ctx: Context, files: List<QueuedFile>) {
        if (files.isEmpty()) return
        if (demo) stopDemo()
        quick = null
        blastMode = false; blastQuick = null; grabQuick = null
        queue = files
        sendBitmaps = emptyList()
        sendPhase = S_IDLE
        if (active.value) { if (airMode) startArmedScene() else startTapArmedScene() }
        // decode previews off the main thread
        val app = ctx.applicationContext
        Thread {
            val bmps = ArrayList<Bitmap>()
            // every kind of file gets a real chip: a photo, a video frame, an app card, cover art, a first page...
            for (f in files.take(3)) {
                val b = try { ChipArt.forFile(app, f.file, f.name) } catch (e: Throwable) { null }
                if (b != null) bmps.add(b)
            }
            main.post {
                if (queue === files) {
                    sendBitmaps = bmps
                    overlay?.setPhotos(bmps, files.map { it.name }, files.size)
                }
            }
        }.start()
    }

    private fun startArmedScene() {
        sendPhase = S_ARMED
        grab.reset()
        main.removeCallbacks(armTimeout)
        main.postDelayed(armTimeout, 120_000L)
        val ov = ensureOverlay(svc ?: return) ?: run {
            status.value = "Photo ready, but the overlay is off. Turn on the Accessibility service or 'Display over other apps'."
            return
        }
        ov.tapStyle = false
        ov.backdrop = 0f
        val bq = blastQuick
        ov.setPhotos(sendBitmaps, if (bq != null) listOf(bq.shown) else queue.map { it.name }, if (bq != null) 1 else queue.size)
        ov.setHold(0f)
        ov.setInfo("Show your open palm", if (queue.size > 1) "${queue.size} files ready" else "Ready to send")
        ov.setMode(AirShareOverlay.M_SEND_ARMED)
        status.value = "Ready to send. Show your palm."
        blastHint()
    }

    // ---- Quick Drop (links, text, YouTube, clipboard) ----------------------------------------

    /** A link or text to send. Safe to call before the service is up: it waits for [attach]. */
    fun armQuick(ctx: Context, item: QuickItem) {
        if (demo) stopDemo()
        blastMode = false; blastQuick = null; grabQuick = null
        quick = item
        queue = emptyList()
        sendBitmaps = emptyList()
        sendPhase = S_IDLE
        if (svc == null) svc = ctx.applicationContext
        if (active.value) startQuickArmedScene()
    }

    /** The title and thumbnail finished loading for the armed item. */
    fun updateQuick(old: QuickItem, rich: QuickItem) {
        main.post {
            if (quick === old) {
                quick = rich
                overlay?.let { if (it.currentMode() == AirShareOverlay.M_QD_READY) it.qdUpdate(rich) }
            }
        }
    }

    private fun startQuickArmedScene() {
        val item = quick ?: return
        sendPhase = S_ARMED
        main.removeCallbacks(armTimeout)
        main.postDelayed(armTimeout, 120_000L)
        val ov = ensureOverlay(svc ?: return) ?: run {
            status.value = "Ready to send. Touch the tops of the phones together."
            return
        }
        ov.backdrop = 0f
        ov.qdReady(item)
        status.value = "Ready to send. Touch the tops of the phones together."
    }

    private fun startQuickSend() {
        val l = link ?: return
        val item = quick ?: return
        main.removeCallbacks(armTimeout)
        main.removeCallbacks(tapPairTimeout)
        sendPhase = S_SENDING
        overlay?.backdrop = 0f
        overlay?.qdSend(item)
        buzz(longArrayOf(0, 16, 30, 16, 30, 40))
        status.value = "Sending..."
        // the whole thing is one tiny message, so it is gone before the spell finishes
        l.sendQuick(item)
        main.postDelayed({
            if (sendPhase == S_SENDING) {
                sendPhase = S_DONE
                overlay?.setInfo("Sent", "It is on the other phone")
                overlay?.setMode(AirShareOverlay.M_SENT)
                buzz(longArrayOf(0, 16, 40, 16, 40, 30))
                status.value = "Sent."
                main.removeCallbacks(doneEnd)
                main.postDelayed(doneEnd, 1900L)
            }
        }, 2500L)
    }

    private fun receiveQuick(item: QuickItem) {
        val ctx = svc ?: return
        QuickHistory.add(item)
        if (Prefs.quickAutoCopy) QuickActions.copy(ctx, item)
        shownQuick = item
        main.removeCallbacks(tapPairTimeout)
        main.removeCallbacks(quickEnd)
        tapActive = true
        recvTap = false
        notifyQuick(item)
        val ov = ensureOverlay(ctx)
        if (ov == null) { status.value = "Received a ${item.kind}. See it in Recent drops."; return }
        ov.backdrop = 0f
        ov.qdReceive(item)
        buzz(longArrayOf(0, 20, 60, 14, 40, 14, 40, 50))
        status.value = "Received."
        main.postDelayed(quickEnd, 18_000L)
    }

    private fun quickClose() {
        main.removeCallbacks(quickEnd)
        tapActive = false
        shownQuick = null
        if (sendPhase == S_IDLE && recvPhase == R_IDLE) hideOverlay()
        main.postDelayed({ if (sendPhase == S_IDLE && recvPhase == R_IDLE) link?.resetFresh() }, 400L)
    }

    private fun onQuickAction(act: Int) {
        val ctx = svc ?: return
        val item = shownQuick ?: return
        when (act) {
            AirShareOverlay.QA_OPEN -> QuickActions.open(ctx, item)
            AirShareOverlay.QA_PLAY -> QuickActions.play(ctx, item)
            AirShareOverlay.QA_COPY -> QuickActions.copy(ctx, item)
        }
        if (act != AirShareOverlay.QA_COPY) main.postDelayed({ quickClose() }, 220L)
    }

    private fun notifyQuick(item: QuickItem) {
        val ctx = svc ?: return
        try {
            val nm = ctx.getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(NotificationChannel("airshare_channel", "Air Share", NotificationManager.IMPORTANCE_DEFAULT))
            val intent = if (item.isLink) Intent(Intent.ACTION_VIEW, Uri.parse(item.text)) else Intent(ctx, MainActivity::class.java)
            val pi = PendingIntent.getActivity(ctx, 6, intent, PendingIntent.FLAG_IMMUTABLE)
            nm.notify(
                8,
                NotificationCompat.Builder(ctx, "airshare_channel")
                    .setSmallIcon(R.drawable.ic_notif)
                    .setContentTitle(if (item.isYoutube) "Video received" else if (item.isLink) "Link received" else "Text received")
                    .setContentText(item.shown.take(120))
                    .setContentIntent(pi)
                    .setAutoCancel(true)
                    .build()
            )
        } catch (_: Exception) {
        }
    }

    /** Tap-only mode: the photo is ready and waits for the two phones to touch. */
    private fun startTapArmedScene() {
        sendPhase = S_ARMED
        main.removeCallbacks(armTimeout)
        main.postDelayed(armTimeout, 120_000L)
        val ov = ensureOverlay(svc ?: return) ?: run {
            status.value = "Photo ready. Touch the tops of the phones together."
            return
        }
        ov.tapStyle = false
        ov.backdrop = 0f
        ov.setPhotos(sendBitmaps, queue.map { it.name }, queue.size)
        ov.setHold(0f)
        ov.setInfo("Touch the phones together", if (queue.size > 1) "${queue.size} files ready" else "Photo ready")
        ov.setMode(AirShareOverlay.M_SEND_ARMED)
        status.value = "Ready to send. Touch the tops of the phones together."
    }

    // ---- the touch flow (Tap Share) ----------------------------------------------------------

    private fun onBump() {
        if (demo) return
        val l = link ?: return
        l.bump() // stamps our own knock: the other phone only trusts a touch it felt too
        if (sendPhase == S_SENDING || sendPhase == S_DONE) return
        if (recvPhase == R_INCOMING || recvPhase == R_REVEAL) return
        if (l.nearby == 0 && !l.isLinked) return // nobody close enough to be touching
        if (tapActive) return
        val ctx = svc ?: return
        tapActive = true
        buzz(longArrayOf(0, 16, 30, 26))
        val ov = ensureOverlay(ctx)
        if (ov != null) {
            ov.backdrop = 0f
            ov.setInfo("Connecting", "Hold the phones together")
            ov.tapPair()
        }
        main.removeCallbacks(tapPairTimeout)
        main.postDelayed(tapPairTimeout, 9000L)
    }

    /** Leaves the touch scene and goes back to whatever was showing before (a ready photo, or nothing). */
    private fun tapEnd() {
        main.removeCallbacks(tapPairTimeout)
        if (sendPhase == S_DRAG) { link?.cancelDrag(); sendPhase = S_ARMED }
        tapActive = false
        recvTap = false
        if (sendPhase == S_ARMED && quick != null) startQuickArmedScene()
        else if (sendPhase == S_ARMED) { if (airMode) startArmedScene() else startTapArmedScene() }
        else if (sendPhase == S_IDLE && recvPhase == R_IDLE) hideOverlay()
        main.postDelayed({ if (sendPhase == S_IDLE || sendPhase == S_ARMED) if (recvPhase == R_IDLE) link?.resetFresh() }, 400L)
    }

    private fun tapLinked(name: String) {
        main.removeCallbacks(tapPairTimeout)
        overlay?.setInfo("Connected", name)
        overlay?.tapPaired()
        buzz(longArrayOf(0, 20, 40, 34))
        if (quick != null && sendPhase == S_ARMED) {
            main.postDelayed({ startQuickSend() }, 800L)
        } else if (queue.isNotEmpty() && (sendPhase == S_ARMED || sendPhase == S_READY || sendPhase == S_CAPTURED)) {
            main.postDelayed({ if (Prefs.tapStyle == "drag") startDragSend() else startTapSend() }, 950L)
        } else {
            // the other phone is the sender: give it a moment to start, then give up quietly
            main.postDelayed(tapPairTimeout, 12_000L)
        }
    }

    private fun startTapSend() {
        val l = link ?: return
        if (queue.isEmpty()) return
        main.removeCallbacks(armTimeout)
        sendPhase = S_SENDING
        grab.reset()
        val files = queue
        val first = files.firstOrNull()
        val app = svc ?: return
        overlay?.backdrop = 0f
        overlay?.tapTransfer(true, sendBitmaps.firstOrNull(), files.map { it.name }, files.size)
        status.value = "Sending..."
        Thread {
            val th = if (first != null) ThumbMaker.of(app, first.file, first.name) else null
            main.post {
                if (sendPhase == S_SENDING) l.send(files.map { it.file }, null, files.map { it.name }, th, "tap")
            }
        }.start()
    }

    /** Samsung style: the photo waits under the finger; nothing is sent until it is dragged over the line. */
    private fun startDragSend() {
        val l = link ?: return
        if (queue.isEmpty()) return
        val app = svc ?: return
        main.removeCallbacks(armTimeout)
        main.removeCallbacks(tapPairTimeout)
        sendPhase = S_DRAG
        grab.reset()
        val files = queue
        val first = files.firstOrNull()
        val ov = overlay ?: return
        ov.backdrop = 0f
        ov.dragStart(true, sendBitmaps.firstOrNull(), files.map { it.name }, files.size)
        status.value = "Drag the photo up and off the top edge to send it."
        main.postDelayed(tapPairTimeout, 90_000L)
        Thread {
            val th = if (first != null) ThumbMaker.of(app, first.file, first.name) else null
            main.post {
                if (sendPhase == S_DRAG) l.peek(files.map { it.file }, files.map { it.name }, th)
            }
        }.start()
    }

    private fun onLocalDrag(c: Float, fling: Boolean) { link?.sendPos(c, fling) }

    private fun onLocalRelease(commit: Boolean, fling: Boolean) {
        val l = link ?: return
        if (commit) {
            main.removeCallbacks(tapPairTimeout)
            buzz(longArrayOf(0, 14, 24, 44))
            if (sendPhase == S_DRAG) sendPhase = S_SENDING
            l.commitDrag(fling)
        } else {
            buzz(longArrayOf(0, 10))
            l.cancelDrag()
        }
    }

    private fun setTouchable(need: Boolean) {
        val v = overlay ?: return
        val lp = overlayLp ?: return
        val wm = overlayWm ?: return
        lp.flags = if (need) lp.flags and WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE.inv()
        else lp.flags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        try { wm.updateViewLayout(v, lp) } catch (_: Exception) {}
    }

    /** Blurs whatever is behind the overlay window (Android 12+ on phones that allow it). */
    @Suppress("DEPRECATION")
    private fun setBlur(px: Int) {
        if (Build.VERSION.SDK_INT < 31) return
        val v = overlay ?: return
        val lp = overlayLp ?: return
        val wm = overlayWm ?: return
        try {
            if (!wm.isCrossWindowBlurEnabled) return
            lp.blurBehindRadius = px
            lp.flags = if (px > 0) lp.flags or WindowManager.LayoutParams.FLAG_BLUR_BEHIND
            else lp.flags and WindowManager.LayoutParams.FLAG_BLUR_BEHIND.inv()
            wm.updateViewLayout(v, lp)
        } catch (_: Exception) {
        }
    }

    /** Receiver, touch flow: wait until the pictures are decoded, then bloom the chip into the photo. */
    private fun revealWhenReady(tries: Int) {
        val need = recvItems.count { it.image || it.name.endsWith(".pdf", true) }.coerceAtMost(3)
        if (recvBitmaps.size >= need || tries > 14) {
            recvPhase = R_WAIT
            reveal()
        } else main.postDelayed({ revealWhenReady(tries + 1) }, 120L)
    }

    private fun cancelSend() {
        quick = null
        blastMode = false; blastQuick = null; grabQuick = null; grabbing = false
        flick.reset()
        main.removeCallbacks(armTimeout)
        main.removeCallbacks(sendTimeout)
        sendPhase = S_IDLE
        pendingSend = false
        queue = emptyList()
        sendBitmaps = emptyList()
        grab.reset()
        if (recvPhase == R_IDLE) hideOverlay()
        status.value = "Air Share is on. Waiting for photos."
    }

    private fun sendFrame(p: GestureEngine.Pose, now: Long, seen: Boolean) {
        val ov = overlay
        // Air Blast: one flick of the open hand fires it, no need for the three steps
        if (blastMode && flick.update(lastLm, p == GestureEngine.Pose.OPEN, now)) {
            startSend()
            return
        }
        // a captured orb that loses its hand for a few seconds drops back into the card
        if (sendPhase == S_CAPTURED) {
            if (!seen) {
                if (handLostAt == 0L) handLostAt = now
                if (now - handLostAt > 4000L) {
                    handLostAt = 0L
                    grab.reset()
                    sendPhase = S_ARMED
                    ov?.setInfo("Show your open palm", "Ready to send")
                    ov?.setMode(AirShareOverlay.M_SEND_ARMED)
                    return
                }
            } else handLostAt = 0L
        }
        val ev = grab.update(p, now)
        ov?.setHold(grab.hold)
        when (ev) {
            AirGrabTracker.Ev.READY -> {
                sendPhase = S_READY
                ov?.setInfo("Close your fist to capture", "Hold it for a moment")
                ov?.setMode(AirShareOverlay.M_SEND_READY)
                buzz(longArrayOf(0, 14))
            }
            AirGrabTracker.Ev.GRAB -> {
                sendPhase = S_CAPTURED
                handLostAt = 0L
                ov?.setInfo("Captured. Open your hand to send", "Move it toward the other phone")
                ov?.setMode(AirShareOverlay.M_CAPTURED)
                buzz(longArrayOf(0, 22, 40, 30))
            }
            AirGrabTracker.Ev.RELEASE -> startSend()
            AirGrabTracker.Ev.RESET -> {
                sendPhase = S_ARMED
                ov?.setInfo("Show your open palm", "Ready to send")
                ov?.setMode(AirShareOverlay.M_SEND_ARMED)
            }
            AirGrabTracker.Ev.NONE -> {}
        }
    }

    private fun startSend() {
        if (blastMode) { startBlastSend(); return }
        sendPhase = S_SENDING
        grab.reset()
        buzz(longArrayOf(0, 18, 30, 40))
        val gq = grabQuick
        if (gq != null) {
            // a grabbed piece of text goes as a Quick Drop card
            overlay?.backdrop = 0f
            overlay?.qdSend(gq)
        } else {
            overlay?.setProgress(0f)
            overlay?.setInfo("Sending...", "Finding the other phone")
            overlay?.setMode(AirShareOverlay.M_SENDING)
        }
        status.value = "Sending..."
        val l = link
        if (l == null) { failSend("Air Share is not running."); return }
        if (linked || l.isLinked) {
            sendNow()
        } else {
            pendingSend = true
            l.connectNow()
            main.removeCallbacks(sendTimeout)
            main.postDelayed(sendTimeout, 12_000L)
        }
    }

    private fun sendNow() {
        val l = link ?: return
        main.removeCallbacks(sendTimeout)
        pendingSend = false
        val gq = grabQuick
        if (gq != null) {
            l.sendQuick(gq)
            main.postDelayed({ if (sendPhase == S_SENDING) sendSucceeded() }, 2500L)
            return
        }
        overlay?.setInfo("Sending...", "0%")
        l.send(queue.map { it.file }, null, queue.map { it.name }, null, "air")
    }

    private fun failSend(msg: String) {
        main.removeCallbacks(sendTimeout)
        pendingSend = false
        sendPhase = S_DONE
        overlay?.setInfo("Could not send", msg)
        overlay?.setMode(AirShareOverlay.M_FAILED)
        status.value = msg
        buzz(longArrayOf(0, 60, 50, 60))
        main.removeCallbacks(doneEnd)
        main.postDelayed(doneEnd, 3400L)
    }

    private fun sendSucceeded() {
        main.removeCallbacks(sendTimeout)
        sendPhase = S_DONE
        overlay?.setInfo("Sent", if (queue.size > 1) "${queue.size} files are in the air" else "It is on the other phone")
        overlay?.setMode(AirShareOverlay.M_SENT)
        status.value = "Sent."
        buzz(longArrayOf(0, 16, 40, 16, 40, 30))
        main.removeCallbacks(doneEnd)
        main.postDelayed(doneEnd, 2300L)
    }

    private fun finishSendScene() {
        quick = null
        grabQuick = null; grabbing = false
        // a blast room stays open for a while so the next one is instant
        if (blastMode) { blastMode = false; blastQuick = null; main.removeCallbacks(blastIdle); main.postDelayed(blastIdle, 10 * 60_000L) }
        flick.reset()
        tapActive = false
        sendPhase = S_IDLE
        queue = emptyList()
        sendBitmaps = emptyList()
        grab.reset()
        if (recvPhase == R_IDLE) hideOverlay()
        status.value = "Air Share is on. Waiting for photos."
        // let go of the other phone so the next one can connect
        main.postDelayed({ if (sendPhase == S_IDLE && recvPhase == R_IDLE) link?.resetFresh() }, 600L)
    }

    // =========================================================================================
    // Receiver
    // =========================================================================================

    private fun offerArrived(count: Int) {
        if (sendPhase == S_SENDING) return
        cancelSendIfArmed()
        main.removeCallbacks(recvTimeout)
        main.removeCallbacks(revealEnd)
        clearRecv()
        recvTotal = count
        recvPhase = R_INCOMING
        catcher.reset()
        val l = link
        recvTap = !blastRecv && l != null && (l.offerStyle == "tap" || l.offerStyle == "drag")
        val ov = ensureOverlay(svc ?: return)
        if (ov == null) {
            status.value = "A photo is arriving, but the overlay is off. It will be saved to the gallery."
            return
        }
        if (recvTap) {
            main.removeCallbacks(tapPairTimeout)
            tapActive = true
            ov.backdrop = 0f
            // a Samsung-style drag is already on screen; only a plain touch send starts the chip scene here
            if (ov.currentMode() != AirShareOverlay.M_DRAG_RECV) {
                ov.tapTransfer(false, l?.offerThumb, l?.offerFileNames ?: emptyList(), count)
            }
            buzz(longArrayOf(0, 20, 50, 20))
            status.value = "Receiving..."
            return
        }
        ov.tapStyle = false
        ov.backdrop = 0f
        ov.setPhotos(emptyList(), emptyList(), count)
        ov.setProgress(0f)
        ov.setHold(0f)
        ov.setInfo(if (count > 1) "$count files arriving" else "Photo arriving", "0%")
        ov.setMode(AirShareOverlay.M_RECV_INCOMING)
        buzz(longArrayOf(0, 20, 50, 20))
        status.value = "Receiving..."
    }

    private fun cancelSendIfArmed() {
        if (sendPhase == S_ARMED || sendPhase == S_READY || sendPhase == S_CAPTURED) {
            main.removeCallbacks(armTimeout)
            sendPhase = S_IDLE
            grab.reset()
            queue = emptyList()
            sendBitmaps = emptyList()
        }
    }

    private fun receiveFinished() {
        if (recvTap) {
            overlay?.setProgress(1f)
            main.postDelayed({ if (link != null) link?.resetFresh() }, 900L)
            revealWhenReady(0)
            return
        }
        recvPhase = R_WAIT
        catcher.reset()
        val ov = overlay
        // the owner already said yes to this blast, so the photo lands by itself after the orb arrives
        if (blastRecv) main.postDelayed({ if (recvPhase == R_WAIT) reveal() }, 1100L)
        ov?.setPhotos(recvBitmaps.toList(), recvItems.map { it.name }, maxOf(recvTotal, recvItems.size))
        ov?.setProgress(1f)
        ov?.setHold(0f)
        ov?.setInfo("Photo in the air", "Make a fist, then open your hand")
        ov?.setMode(AirShareOverlay.M_RECV_WAIT)
        buzz(longArrayOf(0, 30, 40, 18))
        status.value = "Received. Make a fist, then open your hand."
        main.removeCallbacks(recvTimeout)
        main.postDelayed(recvTimeout, 120_000L)
        // the files are on disk; free the link so another phone can connect
        main.postDelayed({ if (sendPhase == S_IDLE) link?.resetFresh() }, 700L)
    }

    private fun recvFrame(p: GestureEngine.Pose, now: Long, seen: Boolean) {
        val ov = overlay
        if (recvPhase != R_WAIT && recvPhase != R_CATCH) return
        val ev = catcher.update(p, now)
        ov?.setHold(catcher.hold)
        when (ev) {
            AirReceiveTracker.Ev.ARM -> {
                recvPhase = R_CATCH
                ov?.setInfo("Caught. Open your hand to release", "")
                ov?.setMode(AirShareOverlay.M_RECV_CATCH)
                buzz(longArrayOf(0, 24, 30, 24))
            }
            AirReceiveTracker.Ev.ACCEPT -> reveal()
            AirReceiveTracker.Ev.RESET -> {
                recvPhase = R_WAIT
                ov?.setInfo("Photo in the air", "Make a fist, then open your hand")
                ov?.setMode(AirShareOverlay.M_RECV_WAIT)
            }
            AirReceiveTracker.Ev.NONE -> {}
        }
    }

    private fun reveal() {
        recvPhase = R_REVEAL
        main.removeCallbacks(recvTimeout)
        val n = maxOf(recvTotal, recvItems.size)
        val ov = overlay
        ov?.setPhotos(recvBitmaps.toList(), recvItems.map { it.name }, n)
        ov?.setHold(0f)
        val saved = recvItems.count { it.saved != null }
        ov?.setInfo(
            if (saved == recvItems.size) "Saved to Gallery" else "$saved of ${recvItems.size} saved",
            if (n > 1) "$n files in Gallery > AirFlow" else (recvItems.firstOrNull()?.name ?: "")
        )
        ov?.setMode(AirShareOverlay.M_REVEAL)
        buzz(longArrayOf(0, 12, 20, 12, 20, 60))
        main.removeCallbacks(revealEnd)
        main.postDelayed(revealEnd, AirShareOverlay.REVEAL_MS.toLong())
        notifyReceived()
    }

    private fun endReceive() {
        main.removeCallbacks(recvTimeout)
        main.removeCallbacks(revealEnd)
        val wasWaiting = (recvPhase == R_WAIT || recvPhase == R_CATCH) && !recvTap
        recvPhase = R_IDLE
        recvTap = false
        blastRecv = false
        tapActive = false
        catcher.reset()
        if (wasWaiting) notifyReceived() // never caught: the files are still safe in the gallery
        clearRecv()
        if (sendPhase == S_IDLE) hideOverlay()
        status.value = "Air Share is on. Waiting for photos."
    }

    private fun notifyReceived() {
        val ctx = svc ?: return
        if (recvItems.isEmpty()) return
        try {
            val nm = ctx.getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(NotificationChannel("airshare_channel", "Air Share", NotificationManager.IMPORTANCE_DEFAULT))
            val open = PendingIntent.getActivity(ctx, 5, Intent(ctx, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
            val n = recvItems.size
            val text = if (n == 1) recvItems[0].name + " saved to your gallery" else "$n files saved to Gallery > AirFlow"
            nm.notify(
                7,
                NotificationCompat.Builder(ctx, "airshare_channel")
                    .setSmallIcon(R.drawable.ic_notif)
                    .setContentTitle("Air Share received")
                    .setContentText(text)
                    .setContentIntent(open)
                    .setAutoCancel(true)
                    .build()
            )
        } catch (_: Exception) {
        }
    }

    private fun loadItemBitmap(ctx: Context, item: RecvItem): Bitmap? {
        val uri: Uri = item.saved?.uri
            ?: item.saved?.file?.let { Uri.fromFile(it) }
            ?: item.temp?.let { Uri.fromFile(it) }
            ?: return null
        return loadRecvBitmap(ctx, item, 1000)
    }

    // =========================================================================================
    // Air Blast
    // =========================================================================================

    private fun ensureBlast(): BlastLink? {
        blast?.let { return it }
        val ctx = svc ?: return null
        return BlastLink(ctx, blastCallbacks).also { blast = it }
    }

    /** Files (or a link/text) to blast to the whole room. Needs Air Share (hand + touch) to be running. */
    fun armBlast(ctx: Context, files: List<QueuedFile>, item: QuickItem? = null) {
        if (files.isEmpty() && item == null) return
        if (svc == null) svc = ctx.applicationContext
        if (item != null) {
            if (demo) stopDemo()
            quick = null; grabQuick = null
            queue = emptyList()
            sendBitmaps = listOf(itemCard(item))
            sendPhase = S_IDLE
            blastMode = true
            blastQuick = item
            if (active.value && airMode) startArmedScene()
        } else {
            arm(ctx, files)
            blastMode = true
            blastQuick = null
        }
        flick.reset()
        startBlastHost()
    }

    /** Tap Share comes back once no blast room (sending or listening) is open. */
    private fun resumeTapIfFree() {
        val b = blast
        if (b != null && (b.isHosting || b.isListening)) return
        link?.resume()
    }

    private fun startBlastHost() {
        val ctx = svc ?: return
        if (Perms.missing(ctx).isNotEmpty()) {
            status.value = "Allow Location and Nearby devices to use Air Blast."
            return
        }
        link?.pause()
        ensureBlast()?.startHost(Prefs.blastCode)
        main.removeCallbacks(blastIdle)
        main.postDelayed(blastIdle, 10 * 60_000L)
        blastHint()
    }

    private fun blastHint() {
        if (!blastMode || sendPhase != S_ARMED) return
        val n = blastMembers.value
        val sub = if (n == 0) "Waiting for phones to join" else "$n phone${if (n == 1) "" else "s"} in the room"
        overlay?.setInfo("Flick up, or show your palm", sub)
        status.value = if (n == 0) "Air Blast is open. Waiting for phones." else "Air Blast ready: $n in the room."
    }

    /** Close the room and forget any armed blast. */
    fun closeBlast() {
        main.removeCallbacks(blastIdle)
        blast?.stopHost()
        blastMembers.value = 0
        if (blastMode) cancelSend()
        resumeTapIfFree()
    }

    private fun startBlastSend() {
        sendPhase = S_SENDING
        grab.reset(); flick.reset()
        buzz(longArrayOf(0, 18, 30, 40))
        val b = blast
        overlay?.setProgress(0f)
        if (b == null || b.memberCount == 0) {
            failSend("Nobody is in the room. Ask them to turn on Receive blasts.")
            return
        }
        overlay?.setInfo("Blasting...", "Asking ${b.memberCount} phones")
        overlay?.setMode(AirShareOverlay.M_SENDING)
        status.value = "Blasting..."
        val thumb = sendBitmaps.firstOrNull()?.let { thumbBytes(it) }
        b.blast(queue.map { it.file }, queue.map { it.name }, thumb, blastQuick)
        main.removeCallbacks(sendTimeout)
        main.postDelayed(sendTimeout, 10 * 60_000L)
    }

    private fun thumbBytes(b: Bitmap): ByteArray? = try {
        val w = 180
        val h = (b.height * (w.toFloat() / b.width)).toInt().coerceIn(40, 260)
        val t = Bitmap.createScaledBitmap(b, w, h, true)
        val o = java.io.ByteArrayOutputStream()
        t.compress(Bitmap.CompressFormat.JPEG, 60, o)
        o.toByteArray().takeIf { it.size <= 14000 }
    } catch (e: Throwable) { null }

    private fun blastDone(delivered: Int, total: Int) {
        main.removeCallbacks(sendTimeout)
        sendPhase = S_DONE
        overlay?.setInfo("Blasted", "$delivered of $total phones got it")
        overlay?.setMode(AirShareOverlay.M_SENT)
        status.value = "Blasted to $delivered of $total phones."
        buzz(longArrayOf(0, 16, 40, 16, 40, 30))
        main.removeCallbacks(doneEnd)
        main.postDelayed(doneEnd, 2600L)
    }

    // ---- receiving a blast ----

    fun setBlastReceive(on: Boolean) {
        Prefs.blastReceive = on
        if (on) startBlastReceiver()
        else {
            blast?.stopListening()
            blastInRoom.value = false
            blastPrompt.value = null
            blastStatus.value = ""
            resumeTapIfFree()
        }
    }

    fun setBlastCode(code: String) {
        Prefs.blastCode = code
        val b = blast ?: return
        if (Prefs.blastReceive) { b.stopListening(); startBlastReceiver() }
        if (b.isHosting) { b.stopHost(); blastMembers.value = 0; startBlastHost() }
    }

    private fun startBlastReceiver() {
        val ctx = svc ?: return
        if (Perms.missing(ctx).isNotEmpty()) { blastStatus.value = "Allow Location and Nearby devices first."; return }
        link?.pause()
        ensureBlast()?.startListening(Prefs.blastCode)
        blastStatus.value = "Listening for a sender nearby..."
    }

    /** Accept or decline the waiting blast. Called by the screen and by the notification buttons. */
    fun answerBlast(id: String?, accept: Boolean) {
        val p = blastPrompt.value ?: return
        if (id != null && id != p.id) return
        blastPrompt.value = null
        cancelBlastNotification()
        blast?.answer(p.id, accept)
        if (accept) buzz(longArrayOf(0, 14, 30, 14))
    }

    private fun cancelBlastNotification() {
        val ctx = svc ?: return
        try { ctx.getSystemService(NotificationManager::class.java).cancel(9) } catch (_: Exception) {}
    }

    private fun notifyBlastPrompt(p: BlastPrompt) {
        val ctx = svc ?: return
        try {
            val nm = ctx.getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(NotificationChannel("airblast_prompt", "Air Blast offers", NotificationManager.IMPORTANCE_HIGH))
            fun pi(code: Int, accept: Boolean) = PendingIntent.getBroadcast(
                ctx, code,
                Intent(ctx, BlastActionReceiver::class.java).putExtra("id", p.id).putExtra("accept", accept),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            val what = when {
                p.kind == "qd" -> "a link or text"
                p.count > 1 -> "${p.count} files"
                else -> "a file"
            }
            nm.notify(
                9,
                NotificationCompat.Builder(ctx, "airblast_prompt")
                    .setSmallIcon(R.drawable.ic_notif)
                    .setContentTitle("${p.host} wants to send you $what")
                    .setContentText(p.title)
                    .setPriority(NotificationCompat.PRIORITY_HIGH)
                    .setCategory(NotificationCompat.CATEGORY_MESSAGE)
                    .setTimeoutAfter(45_000L)
                    .addAction(0, "Accept", pi(91, true))
                    .addAction(0, "Decline", pi(92, false))
                    .setAutoCancel(true)
                    .build()
            )
        } catch (_: Exception) {
        }
    }

    private val blastCallbacks = object : BlastCallbacks {
        override fun receivers(count: Int) { main.post {
            blastMembers.value = count
            blastHint()
        } }

        override fun responses(accepted: Int, declined: Int, total: Int) { main.post {
            if (sendPhase == S_SENDING) overlay?.setInfo("Waiting for answers", "$accepted of $total said yes")
        } }

        override fun sendProgress(done: Long, total: Long) { main.post {
            if (sendPhase != S_SENDING) return@post
            val p = if (total > 0) done.toFloat() / total else 0f
            overlay?.setProgress(p)
            overlay?.setInfo("Blasting...", "${(p * 100).toInt().coerceIn(0, 100)}%")
        } }

        override fun sendDone(delivered: Int, total: Int) { main.post {
            if (sendPhase != S_SENDING) return@post
            if (delivered > 0) blastDone(delivered, total)
            else failSend("Nobody accepted it.")
        } }

        override fun joined(host: String) { main.post {
            blastInRoom.value = true
            blastStatus.value = "In the room of $host"
        } }

        override fun left() { main.post {
            blastInRoom.value = false
            blastStatus.value = "Listening for a sender nearby..."
        } }

        override fun prompt(p: BlastPrompt) { main.post {
            blastPrompt.value = p
            notifyBlastPrompt(p)
            buzz(longArrayOf(0, 30, 60, 30))
        } }

        override fun promptGone(id: String) { main.post {
            if (blastPrompt.value?.id == id) { blastPrompt.value = null; cancelBlastNotification() }
        } }

        override fun recvStarted(count: Int, bytes: Long) { main.post {
            blastRecv = true
            if (count > 0) offerArrived(count)
        } }

        override fun recvProgress(done: Long, total: Long) { linkCallbacks.progress(done, total, "") }

        override fun recvSaved(item: RecvItem) { linkCallbacks.saved(item) }

        override fun recvDone() { main.post {
            if (recvPhase == R_INCOMING) receiveFinished()
        } }

        override fun recvQuick(item: QuickItem) { main.post { receiveQuick(item) } }

        override fun failed(msg: String) { main.post {
            blastStatus.value = msg
            if (sendPhase == S_SENDING && blastMode) failSend(msg)
        } }
    }

    // =========================================================================================
    // Air Grab
    // =========================================================================================

    /**
     * Watches for a fist held still over any app. Returns true once it is sure, so the normal Back
     * gesture does not also fire. A moving fist (a fist swipe) is left alone, and without the
     * Accessibility service the fist keeps its old job.
     */
    private fun grabWatch(p: GestureEngine.Pose, lm: List<PointF>?, now: Long): Boolean {
        if (grabbing) return true
        if (!Prefs.airGrab || !airMode || tapActive || demo || now < grabCool) return false
        if (AirFlowAccessibilityService.instance == null) return false
        if (p != GestureEngine.Pose.FIST || lm == null || lm.size < 21) { fistSince = 0L; return false }
        val cx = (lm[0].x + lm[9].x) / 2f
        val cy = (lm[0].y + lm[9].y) / 2f
        if (fistSince == 0L || Math.hypot((cx - fistX).toDouble(), (cy - fistY).toDouble()) > 0.06) {
            fistSince = now; fistX = cx; fistY = cy
            return false
        }
        val held = now - fistSince
        if (held >= GRAB_MS) { fistSince = 0L; startGrab(); return true }
        return held > 160L
    }

    private fun startGrab() {
        val ctx = svc ?: return
        val acc = AirFlowAccessibilityService.instance ?: return
        grabbing = true
        buzz(longArrayOf(0, 20))
        status.value = "Grabbing the screen..."
        if (Prefs.grabMode == "text") {
            val t = acc.visibleText()
            if (t.isBlank()) { grabFailed("No text found on this screen. Try Screenshot mode."); return }
            enterCaptured(emptyList(), listOf(), QuickItem("text", t))
            return
        }
        acc.grabScreen { bmp, err ->
            if (bmp == null) { main.post { grabFailed(err ?: "Could not grab the screen.") }; return@grabScreen }
            Thread {
                try {
                    val long = maxOf(bmp.width, bmp.height)
                    val scaled = if (long > 1600) {
                        val k = 1600f / long
                        Bitmap.createScaledBitmap(bmp, (bmp.width * k).toInt(), (bmp.height * k).toInt(), true)
                    } else bmp
                    val stamp = java.text.SimpleDateFormat("yyyyMMdd_HHmmss", java.util.Locale.US).format(java.util.Date())
                    val name = "Grab_$stamp.jpg"
                    val f = File(ctx.cacheDir, "grab_$stamp.jpg")
                    f.outputStream().use { scaled.compress(Bitmap.CompressFormat.JPEG, 88, it) }
                    main.post { enterCaptured(listOf(QueuedFile(f, name, true)), listOf(scaled), null) }
                } catch (e: Throwable) {
                    main.post { grabFailed("Could not save the grab.") }
                }
            }.start()
        }
    }

    private fun grabFailed(msg: String) {
        grabbing = false
        grabCool = SystemClock.uptimeMillis() + 3000L
        status.value = msg
        buzz(longArrayOf(0, 60, 50, 60))
        try { svc?.let { android.widget.Toast.makeText(it, msg, android.widget.Toast.LENGTH_SHORT).show() } } catch (_: Exception) {}
    }

    /** The grabbed screen (a picture in [files], or [text]) becomes the orb in the hand. Open the hand to send. */
    private fun enterCaptured(files: List<QueuedFile>, bmps: List<Bitmap>, text: QuickItem?) {
        val ctx = svc ?: run { grabbing = false; return }
        if (demo) stopDemo()
        quick = null
        blastMode = false; blastQuick = null
        queue = files
        grabQuick = text
        sendBitmaps = if (text != null) listOf(itemCard(text)) else bmps
        val ov = ensureOverlay(ctx)
        if (ov == null) {
            grabbing = false
            grabQuick = null; queue = emptyList(); sendBitmaps = emptyList()
            status.value = "Grabbed, but the overlay is off. Turn on the Accessibility service or 'Display over other apps'."
            return
        }
        ov.tapStyle = false
        ov.backdrop = 0f
        ov.setPhotos(sendBitmaps, if (text != null) listOf("Text from screen") else files.map { it.name }, 1)
        ov.setHold(0f)
        sendPhase = S_CAPTURED
        grab.reset()
        grab.step = 2          // the fist already was the capture; only "open your hand" is left
        handLostAt = 0L
        main.removeCallbacks(armTimeout)
        main.postDelayed(armTimeout, 25_000L)
        ov.setInfo(
            "Grabbed. Open your hand to send",
            if (text != null) "Text from your screen" else "A picture of your screen"
        )
        ov.setMode(AirShareOverlay.M_CAPTURED)
        buzz(longArrayOf(0, 22, 40, 30))
        status.value = "Grabbed. Open your hand toward the other phone."
        grabbing = false
    }

    /** A small card that stands in for a link or text in the orb. */
    private fun itemCard(item: QuickItem): Bitmap {
        val w = 640
        val h = 400
        val b = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val c = Canvas(b)
        val bg = Paint(Paint.ANTI_ALIAS_FLAG)
        bg.shader = LinearGradient(0f, 0f, w.toFloat(), h.toFloat(), Color.rgb(36, 28, 92), Color.rgb(12, 62, 112), Shader.TileMode.CLAMP)
        c.drawRoundRect(0f, 0f, w.toFloat(), h.toFloat(), 36f, 36f, bg)
        val tag = Paint(Paint.ANTI_ALIAS_FLAG)
        tag.color = Color.rgb(140, 220, 255)
        tag.textSize = 30f
        tag.isFakeBoldText = true
        c.drawText(when (item.kind) { "yt" -> "VIDEO"; "link" -> "LINK"; else -> "TEXT" }, 40f, 70f, tag)
        val tp = Paint(Paint.ANTI_ALIAS_FLAG)
        tp.color = Color.WHITE
        tp.textSize = 38f
        var y = 132f
        val words = item.shown.replace('\n', ' ').split(' ').filter { it.isNotEmpty() }
        var line = StringBuilder()
        var lines = 0
        for (wd in words) {
            if (line.isNotEmpty() && tp.measureText(line.toString() + " " + wd) > w - 80f) {
                c.drawText(line.toString(), 40f, y, tp); y += 52f; lines++
                line = StringBuilder()
                if (lines >= 6) break
            }
            if (line.isNotEmpty()) line.append(' ')
            line.append(wd.take(40))
        }
        if (lines < 6 && line.isNotEmpty()) c.drawText(line.toString(), 40f, y, tp)
        return b
    }

    // =========================================================================================
    // The Nearby link
    // =========================================================================================

    private val linkCallbacks = object : TapLink.Callbacks {
        override fun peers(count: Int) { main.post {
            peers = count
            if (pendingSend && !linked && count > 0) link?.connectNow()
        } }

        override fun connecting() { main.post {
            if (sendPhase == S_SENDING && !tapActive) overlay?.setInfo("Sending...", "Linking")
        } }

        override fun connected(name: String) { main.post {
            linked = true
            if (pendingSend) sendNow()
            else if (tapActive) tapLinked(name)
        } }

        override fun lost() { main.post {
            linked = false
            if (tapActive && sendPhase != S_SENDING && recvPhase == R_IDLE) tapEnd()
            else if (sendPhase == S_SENDING) failSend("The link dropped. Keep the phones close and try again.")
            else if (recvPhase == R_INCOMING) {
                recvPhase = R_IDLE
                clearRecv()
                if (sendPhase == S_IDLE) hideOverlay()
            }
            // be findable again
            main.postDelayed({ if (sendPhase == S_IDLE && recvPhase == R_IDLE) link?.resetFresh() }, 500L)
        } }

        override fun failed(msg: String) { main.post {
            if (sendPhase == S_SENDING) failSend(msg)
            else { status.value = msg; if (tapActive && recvPhase == R_IDLE) tapEnd() }
        } }

        override fun progress(done: Long, total: Long, name: String) { main.post {
            val p = if (total > 0) done.toFloat() / total else 0f
            overlay?.setProgress(p)
            if ((sendPhase == S_SENDING && !tapActive) || (recvPhase == R_INCOMING && !recvTap)) {
                val pct = (p * 100).toInt().coerceIn(0, 100)
                val head = if (sendPhase == S_SENDING) "Sending..." else if (recvTotal > 1) "$recvTotal files arriving" else "Photo arriving"
                overlay?.setInfo(head, "$pct%")
            }
        } }

        override fun finished() { main.post {
            if (sendPhase == S_SENDING) sendSucceeded()
            else if (recvPhase == R_INCOMING) receiveFinished()
        } }

        override fun incomingOffer(count: Int, bytes: Long) { main.post {
            if (count > 0) offerArrived(count)
        } }

        override fun saved(item: RecvItem) { main.post {
            recvItems.add(item)
            val ctx = svc ?: return@post
            Thread {
                val b = try { loadItemBitmap(ctx, item) } catch (e: Exception) { null }
                main.post {
                    if (b != null) {
                        recvBitmaps.add(b)
                        overlay?.setPhotos(recvBitmaps.toList(), recvItems.map { it.name }, maxOf(recvTotal, recvItems.size))
                    }
                }
            }.start()
        } }

        override fun contact(c: TapContact) {}

        override fun peek(count: Int, names: List<String>, thumb: Bitmap?) { main.post {
            if (sendPhase == S_SENDING || sendPhase == S_DRAG) return@post
            val ctx = svc ?: return@post
            main.removeCallbacks(tapPairTimeout)
            tapActive = true
            recvTap = true
            val ov = ensureOverlay(ctx) ?: return@post
            ov.backdrop = 0f
            ov.dragStart(false, thumb, names, count)
            buzz(longArrayOf(0, 16, 30, 16))
            main.postDelayed(tapPairTimeout, 90_000L)
            status.value = "A photo is coming. Pull it down to take it."
        } }

        override fun quick(item: QuickItem) { main.post { receiveQuick(item) } }

        override fun dragPos(c: Float, fling: Boolean) { main.post { overlay?.setRemoteC(c) } }

        override fun dragEnd(commit: Boolean, fling: Boolean) { main.post {
            overlay?.remoteEnd(++endToken, commit, fling)
            if (commit) {
                main.removeCallbacks(tapPairTimeout)
                if (sendPhase == S_DRAG) sendPhase = S_SENDING
                buzz(longArrayOf(0, 14, 24, 44))
            }
        } }
    }

    // =========================================================================================
    // Camera frames (called by the service for every frame)
    // =========================================================================================

    private fun handInFrame(l: List<PointF>?): Boolean {
        if (l == null || l.size < 21) return false
        for (p in l) if (p.x < 0.04f || p.x > 0.96f || p.y < 0.04f || p.y > 0.96f) return false
        return true
    }

    /**
     * Returns true while Air Share is using the hand, so the normal gestures (play/pause, back...) stay quiet
     * and a fist for Air Share does not also press Back.
     */
    fun onFrame(pose: GestureEngine.Pose, lm: List<PointF>?, now: Long): Boolean {
        if (!active.value || demo) return false
        lastLm = lm
        val seen = lm != null && lm.size >= 21
        if (seen) overlay?.setHand((lm!![0].x + lm[9].x) / 2f, (lm[0].y + lm[9].y) / 2f, true)
        else overlay?.setHand(0.5f, 0.5f, false)
        val p = if (handInFrame(lm)) pose else GestureEngine.Pose.NONE

        if (recvPhase != R_IDLE) {
            recvFrame(p, now, seen)
            return true
        }
        return when (sendPhase) {
            S_ARMED, S_READY, S_CAPTURED -> { sendFrame(p, now, seen); true }
            S_SENDING, S_DONE, S_DRAG -> true
            else -> grabWatch(p, lm, now)
        }
    }

    // =========================================================================================
    // The overlay window
    // =========================================================================================

    /** The overlay can live in the accessibility service (no extra permission) or as an app overlay. */
    fun overlayPossible(ctx: Context): Boolean =
        AirFlowAccessibilityService.instance != null || Settings.canDrawOverlays(ctx)

    private fun ensureOverlay(ctx: Context): AirShareOverlay? {
        overlay?.let { return it }
        val acc = AirFlowAccessibilityService.instance
        val host: Context
        val type: Int
        if (acc != null) {
            host = acc
            type = WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY
        } else if (Settings.canDrawOverlays(ctx)) {
            host = ctx
            type = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else return null
        return try {
            val v = AirShareOverlay(host)
            val lp = WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.MATCH_PARENT,
                type,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT
            )
            if (Build.VERSION.SDK_INT >= 28) {
                lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            }
            val wm = host.getSystemService(Context.WINDOW_SERVICE) as WindowManager
            wm.addView(v, lp)
            overlay = v
            overlayWm = wm
            overlayLp = lp
            v.onTouchableChange = { need -> setTouchable(need) }
            v.onBlurChange = { r -> setBlur(r) }
            v.onDragLocal = { c, f -> onLocalDrag(c, f) }
            v.onReleaseLocal = { commit, f -> onLocalRelease(commit, f) }
            v.onQuickAction = { act -> onQuickAction(act) }
            v
        } catch (e: Exception) {
            status.value = "Could not show the Air Share overlay: ${e.message}"
            null
        }
    }

    private fun hideOverlay() {
        val v = overlay ?: return
        v.setMode(AirShareOverlay.M_NONE)
        try { overlayWm?.removeView(v) } catch (_: Exception) {}
        overlay = null
        overlayWm = null
        overlayLp = null
    }

    private fun buzz(pattern: LongArray) {
        if (!Prefs.haptic) return
        val ctx = svc ?: return
        try {
            val v = ctx.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator ?: return
            v.vibrate(VibrationEffect.createWaveform(pattern, -1))
        } catch (_: Exception) {
        }
    }

    // =========================================================================================
    // Demo: plays the whole story on a sample picture so you can see the animation without a second phone
    // =========================================================================================

    private fun demoBitmap(): Bitmap {
        val w = 720
        val h = 900
        val b = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val c = Canvas(b)
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        p.shader = LinearGradient(0f, 0f, w.toFloat(), h.toFloat(), Color.parseColor("#FF8A4A"), Color.parseColor("#6A2BFF"), Shader.TileMode.CLAMP)
        c.drawRect(0f, 0f, w.toFloat(), h.toFloat(), p)
        p.shader = null
        p.color = Color.argb(70, 255, 255, 255)
        c.drawCircle(w * 0.72f, h * 0.28f, 150f, p)
        p.color = Color.argb(45, 255, 255, 255)
        c.drawCircle(w * 0.25f, h * 0.7f, 240f, p)
        p.color = Color.argb(200, 255, 255, 255)
        p.textSize = 78f
        p.isFakeBoldText = true
        c.drawText("Air Share", 60f, h - 90f, p)
        return b
    }

    private val demoSteps = ArrayList<Runnable>()

    private fun stopDemo() {
        for (r in demoSteps) main.removeCallbacks(r)
        demoSteps.clear()
        demo = false
        if (sendPhase == S_IDLE && recvPhase == R_IDLE) hideOverlay()
    }

    private fun at(ms: Long, block: () -> Unit) {
        val r = Runnable { block() }
        demoSteps.add(r)
        main.postDelayed(r, ms)
    }

    /** Returns false when there is no way to draw over other apps yet. */
    fun playDemo(ctx: Context): Boolean {
        if (demo) return true
        if (sendPhase != S_IDLE || recvPhase != R_IDLE) return true
        val ov = ensureOverlay(ctx.applicationContext) ?: return false
        if (svc == null) svc = ctx.applicationContext
        demo = true
        val pic = demoBitmap()
        val names = listOf("Sunset.jpg", "Trip.jpg", "Party.jpg")
        ov.setPhotos(listOf(pic, pic, pic), names, 3)
        ov.setProgress(0f); ov.setHold(0f)
        ov.setHand(0.5f, 0.6f, true)

        ov.setInfo("Show your open palm", "3 photos ready")
        ov.setMode(AirShareOverlay.M_SEND_ARMED)
        at(1500) { ov.setInfo("Close your fist to capture", "Hold it for a moment"); ov.setMode(AirShareOverlay.M_SEND_READY) }
        at(3000) { ov.setHand(0.5f, 0.62f, true); ov.setInfo("Captured. Open your hand to send", "Move it toward the other phone"); ov.setMode(AirShareOverlay.M_CAPTURED) }
        at(3900) { ov.setHand(0.42f, 0.5f, true) }
        at(4600) { ov.setHand(0.55f, 0.46f, true) }
        at(5200) { ov.setProgress(0f); ov.setInfo("Sending...", "Linking"); ov.setMode(AirShareOverlay.M_SENDING) }
        ramp(5600, 1600) { p -> ov.setProgress(p); ov.setInfo("Sending...", "${(p * 100).toInt()}%") }
        at(7400) { ov.setInfo("Sent", "3 files are in the air"); ov.setMode(AirShareOverlay.M_SENT) }

        at(9800) { ov.setPhotos(emptyList(), emptyList(), 3); ov.setProgress(0f); ov.setInfo("3 files arriving", "0%"); ov.setMode(AirShareOverlay.M_RECV_INCOMING) }
        ramp(10300, 1500) { p -> ov.setProgress(p); ov.setInfo("3 files arriving", "${(p * 100).toInt()}%") }
        at(12000) {
            ov.setPhotos(listOf(pic, pic, pic), names, 3)
            ov.setProgress(1f); ov.setInfo("Photo in the air", "Make a fist, then open your hand"); ov.setMode(AirShareOverlay.M_RECV_WAIT)
        }
        at(13600) { ov.setHand(0.55f, 0.66f, true); ov.setInfo("Caught. Open your hand to release", ""); ov.setMode(AirShareOverlay.M_RECV_CATCH) }
        at(15000) { ov.setInfo("Saved to Gallery", "3 files in Gallery > AirFlow"); ov.setMode(AirShareOverlay.M_REVEAL) }
        at(15000L + AirShareOverlay.REVEAL_MS.toLong() + 200L) { stopDemo() }
        return true
    }

    private fun ramp(startMs: Long, durMs: Long, apply: (Float) -> Unit) {
        val t0 = SystemClock.uptimeMillis() + startMs
        val r = object : Runnable {
            override fun run() {
                val p = ((SystemClock.uptimeMillis() - t0).toFloat() / durMs).coerceIn(0f, 1f)
                apply(p)
                if (p < 1f && demo) main.postDelayed(this, 33L)
            }
        }
        demoSteps.add(r)
        main.postDelayed(r, startMs)
    }
}
