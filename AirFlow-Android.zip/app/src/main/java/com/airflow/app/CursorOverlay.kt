package com.airflow.app

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.os.SystemClock
import android.view.View

/** Full-screen, touch-through view that draws the hand cursor on top of every app. */
class CursorOverlay(ctx: Context) : View(ctx) {
    companion object {
        const val S_IDLE = 0
        const val S_DOWN = 1
        const val S_DRAG = 2
        const val S_GRAB = 3
        const val S_GRAB_DRAG = 4
    }

    private val d = resources.displayMetrics.density
    private val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 3f * d }
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeWidth = 4f * d; strokeCap = Paint.Cap.ROUND
    }
    private val loc = IntArray(2)

    private var cx = -200f
    private var cy = -200f
    private var fromX = 0f
    private var fromY = 0f
    private var state = S_IDLE
    private var handVisible = true
    private var rippleT = 0L
    private var rippleX = 0f
    private var rippleY = 0f

    fun update(x: Float, y: Float, st: Int, fx: Float, fy: Float) {
        cx = x; cy = y; state = st; fromX = fx; fromY = fy
        invalidate()
    }

    fun setHandVisible(v: Boolean) {
        if (handVisible != v) { handVisible = v; invalidate() }
    }

    fun ripple(x: Float, y: Float) {
        rippleX = x; rippleY = y; rippleT = SystemClock.uptimeMillis()
        invalidate()
    }

    private fun colorFor(st: Int): Int = when (st) {
        S_DOWN -> Color.WHITE
        S_DRAG -> Color.parseColor("#69F0AE")
        S_GRAB, S_GRAB_DRAG -> Color.parseColor("#FFAB40")
        else -> Color.parseColor("#4FC3F7")
    }

    override fun onDraw(c: Canvas) {
        super.onDraw(c)
        getLocationOnScreen(loc)
        val ox = loc[0].toFloat()
        val oy = loc[1].toFloat()
        val alpha = if (handVisible) 255 else 90
        val col = colorFor(state)

        if ((state == S_DRAG || state == S_GRAB_DRAG)) {
            line.color = col; line.alpha = 200
            c.drawLine(fromX - ox, fromY - oy, cx - ox, cy - oy, line)
            fill.color = col; fill.alpha = 160
            c.drawCircle(fromX - ox, fromY - oy, 7f * d, fill)
        }

        val pressed = state != S_IDLE
        ring.color = col; ring.alpha = alpha
        c.drawCircle(cx - ox, cy - oy, (if (pressed) 16f else 24f) * d, ring)
        fill.color = col; fill.alpha = if (pressed) alpha else (alpha * 0.9f).toInt()
        c.drawCircle(cx - ox, cy - oy, (if (pressed) 12f else 5f) * d, fill)

        val age = SystemClock.uptimeMillis() - rippleT
        if (age in 0..320) {
            val t = age / 320f
            ring.color = Color.WHITE; ring.alpha = (255 * (1f - t)).toInt()
            c.drawCircle(rippleX - ox, rippleY - oy, (20f + 50f * t) * d, ring)
            postInvalidateOnAnimation()
        }
    }
}
