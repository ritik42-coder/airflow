package com.airflow.app

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.os.SystemClock
import android.view.View
import kotlin.math.exp
import kotlin.math.hypot

/**
 * Full-screen, touch-through view that draws the hand cursor on top of every app.
 * The camera delivers ~30 positions per second, but the screen refreshes 60-120 times per second,
 * so the drawn cursor glides toward the latest target on every display frame. That is what makes
 * it look smooth instead of steppy.
 */
class CursorOverlay(ctx: Context) : View(ctx) {
    companion object {
        const val S_IDLE = 0
        const val S_DOWN = 1
        const val S_DRAG = 2
        const val S_GRAB = 3
        const val S_GRAB_DRAG = 4
        private const val GLIDE_MS = 38f // smaller = snappier, larger = smoother
    }

    private val d = resources.displayMetrics.density
    private val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 3f * d }
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeWidth = 4f * d; strokeCap = Paint.Cap.ROUND
    }
    private val arc = RectF()
    private val loc = IntArray(2)

    private var tx = -200f   // target (latest tracked position)
    private var ty = -200f
    private var px = -200f   // what is drawn
    private var py = -200f
    private var placed = false
    private var lastDraw = 0L
    private var fromX = 0f
    private var fromY = 0f
    private var state = S_IDLE
    private var progress = 0f
    private var handVisible = true
    private var rippleT = 0L
    private var rippleX = 0f
    private var rippleY = 0f

    fun update(x: Float, y: Float, st: Int, fx: Float, fy: Float, prog: Float) {
        tx = x; ty = y; state = st; fromX = fx; fromY = fy; progress = prog
        if (!placed) { px = x; py = y; placed = true }
        postInvalidateOnAnimation()
    }

    fun setHandVisible(v: Boolean) {
        if (handVisible != v) { handVisible = v; postInvalidateOnAnimation() }
    }

    fun ripple(x: Float, y: Float) {
        rippleX = x; rippleY = y; rippleT = SystemClock.uptimeMillis()
        postInvalidateOnAnimation()
    }

    private fun colorFor(st: Int): Int = when (st) {
        S_DOWN -> Color.WHITE
        S_DRAG -> Color.parseColor("#69F0AE")
        S_GRAB, S_GRAB_DRAG -> Color.parseColor("#FFAB40")
        else -> Color.parseColor("#4FC3F7")
    }

    override fun onDraw(c: Canvas) {
        super.onDraw(c)
        getLocationOnScreen(loc)
        val ox = loc[0].toFloat()
        val oy = loc[1].toFloat()

        // Glide toward the target, independent of the camera frame rate.
        val now = SystemClock.uptimeMillis()
        val dt = (now - lastDraw).coerceIn(1L, 50L).toFloat()
        lastDraw = now
        val a = 1f - exp(-dt / GLIDE_MS)
        px += (tx - px) * a
        py += (ty - py) * a

        val alpha = if (handVisible) 255 else 90
        val col = colorFor(state)

        if (state == S_DRAG || state == S_GRAB_DRAG) {
            line.color = col; line.alpha = 200
            c.drawLine(fromX - ox, fromY - oy, px - ox, py - oy, line)
            fill.color = col; fill.alpha = 160
            c.drawCircle(fromX - ox, fromY - oy, 7f * d, fill)
        }

        val pressed = state != S_IDLE
        val cxp = px - ox
        val cyp = py - oy
        ring.color = col; ring.alpha = alpha
        c.drawCircle(cxp, cyp, (if (pressed) 16f else 24f) * d, ring)
        fill.color = col; fill.alpha = if (pressed) alpha else (alpha * 0.9f).toInt()
        c.drawCircle(cxp, cyp, (if (pressed) 12f else 5f) * d, fill)

        // Hover-to-tap progress ring
        if (progress > 0.02f && !pressed) {
            val r = 30f * d
            arc.set(cxp - r, cyp - r, cxp + r, cyp + r)
            ring.color = Color.parseColor("#69F0AE"); ring.alpha = 255
            c.drawArc(arc, -90f, 360f * progress.coerceAtMost(1f), false, ring)
        }

        val age = now - rippleT
        if (age in 0..320) {
            val t = age / 320f
            ring.color = Color.WHITE; ring.alpha = (255 * (1f - t)).toInt()
            c.drawCircle(rippleX - ox, rippleY - oy, (20f + 50f * t) * d, ring)
            postInvalidateOnAnimation()
        } else if (hypot(tx - px, ty - py) > 0.4f) {
            postInvalidateOnAnimation()
        }
    }
}
