package com.airflow.app

import android.graphics.PointF
import kotlin.math.abs
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min

/** Turns 21 hand landmarks per frame into discrete gestures. Pure logic, no Android camera code. */
class GestureEngine {
    enum class Pose { NONE, OPEN, FIST, PINCH, OTHER }
    data class Out(val pose: Pose, val gesture: Gesture?)

    private class Sample(val t: Long, val x: Float, val y: Float)

    private val history = ArrayDeque<Sample>()
    private var lastFire = 0L
    private var holdPose = Pose.NONE
    private var holdStart = 0L
    private var holdFired = false
    private var pinchStart = 0L
    private var pinchFired = false

    private fun resetAll() {
        history.clear()
        holdPose = Pose.NONE
        holdFired = false
        pinchStart = 0L
        pinchFired = false
    }

    fun process(lm: List<PointF>?, aspect: Float, now: Long): Out {
        if (lm == null || lm.size < 21) {
            resetAll()
            return Out(Pose.NONE, null)
        }
        val pose = classify(lm, aspect)

        // Cooldown: ignore motion so the hand returning doesn't trigger the opposite swipe.
        if (now - lastFire < Prefs.cooldownMs) {
            history.clear()
            return Out(pose, null)
        }

        val cx = (lm[0].x + lm[5].x + lm[9].x + lm[13].x + lm[17].x) / 5f
        val cy = (lm[0].y + lm[5].y + lm[9].y + lm[13].y + lm[17].y) / 5f
        history.addLast(Sample(now, cx, cy))
        while (history.isNotEmpty() && now - history.first().t > 450) history.removeFirst()

        // Pinch (fires once per pinch)
        if (pose == Pose.PINCH) {
            if (pinchStart == 0L) pinchStart = now
            if (Prefs.pinchEnabled && !pinchFired && now - pinchStart >= 180) {
                pinchFired = true
                return fire(Gesture.PINCH, pose, now)
            }
        } else {
            pinchStart = 0L
            pinchFired = false
        }

        // Swipes
        if (Prefs.swipeEnabled && (pose == Pose.OPEN || pose == Pose.OTHER) && history.size >= 4) {
            val f = history.first()
            val l = history.last()
            if (l.t - f.t >= 100) {
                val dx = l.x - f.x
                val dy = l.y - f.y
                val th = 0.20f / Prefs.sensitivity
                val ax = abs(dx)
                val ay = abs(dy)
                var g: Gesture? = null
                if (ay > th && ay > ax * 1.6f) {
                    val up = dy < 0
                    g = if (up != Prefs.invertSwipe) Gesture.SWIPE_UP else Gesture.SWIPE_DOWN
                } else if (ax > th && ax > ay * 1.6f) {
                    g = if (dx > 0) Gesture.SWIPE_RIGHT else Gesture.SWIPE_LEFT
                }
                if (g != null) return fire(g, pose, now)
            }
        }

        // Holds (open palm / fist, hand must be still)
        var minX = Float.MAX_VALUE; var maxX = -Float.MAX_VALUE
        var minY = Float.MAX_VALUE; var maxY = -Float.MAX_VALUE
        for (s in history) {
            minX = min(minX, s.x); maxX = max(maxX, s.x)
            minY = min(minY, s.y); maxY = max(maxY, s.y)
        }
        val stationary = history.size >= 3 && (maxX - minX) < 0.07f && (maxY - minY) < 0.07f
        val hp = if (pose == Pose.OPEN || pose == Pose.FIST) pose else Pose.NONE
        if (hp != holdPose) {
            holdPose = hp
            holdStart = now
            holdFired = false
        } else if (!stationary) {
            holdStart = now
        }
        if (!holdFired && hp != Pose.NONE) {
            val need = if (hp == Pose.OPEN) 1100 else 900
            if (now - holdStart >= need) {
                if (hp == Pose.OPEN && Prefs.palmHoldEnabled) return fire(Gesture.PALM_HOLD, pose, now)
                if (hp == Pose.FIST && Prefs.fistEnabled) return fire(Gesture.FIST_HOLD, pose, now)
                holdFired = true
            }
        }
        return Out(pose, null)
    }

    private fun fire(g: Gesture, pose: Pose, now: Long): Out {
        lastFire = now
        history.clear()
        holdFired = true // must change pose or lower the hand before another hold fires
        holdStart = now
        return Out(pose, g)
    }

    private fun d(lm: List<PointF>, a: Int, b: Int, asp: Float): Float =
        hypot((lm[a].x - lm[b].x) * asp, lm[a].y - lm[b].y)

    private fun ext(lm: List<PointF>, tip: Int, pip: Int, asp: Float): Boolean =
        d(lm, 0, tip, asp) > d(lm, 0, pip, asp) * 1.08f

    private fun classify(lm: List<PointF>, asp: Float): Pose {
        val idx = ext(lm, 8, 6, asp)
        val mid = ext(lm, 12, 10, asp)
        val ring = ext(lm, 16, 14, asp)
        val pinky = ext(lm, 20, 18, asp)
        val size = max(d(lm, 0, 9, asp), 0.001f)
        val pinchRatio = d(lm, 4, 8, asp) / size
        val others = listOf(mid, ring, pinky).count { it }
        if (pinchRatio < 0.30f && others >= 2) return Pose.PINCH
        val count = listOf(idx, mid, ring, pinky).count { it }
        return when (count) {
            4 -> Pose.OPEN
            0 -> Pose.FIST
            else -> Pose.OTHER
        }
    }
}
