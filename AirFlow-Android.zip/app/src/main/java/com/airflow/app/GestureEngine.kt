package com.airflow.app

import android.graphics.PointF
import kotlin.math.abs
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min

/** Turns 21 hand landmarks per frame into discrete gestures. Pure logic, no Android camera code. */
class GestureEngine {
    enum class Pose { NONE, OPEN, FIST, PINCH, THUMB_UP, THUMB_DOWN, PEACE, POINT, THREE, ROCK, CALL, OTHER }
    data class Out(val pose: Pose, val gesture: Gesture?)

    private class Sample(val t: Long, val x: Float, val y: Float, val fist: Boolean)

    private val history = ArrayDeque<Sample>()
    private var lastFire = 0L
    private var lastDir: Gesture? = null
    private var lostSince = 0L
    private var holdPose = Pose.NONE
    private var holdStart = 0L
    private var holdFired = false
    private var pinchStart = 0L
    private var pinchFired = false
    private var pinching = false

    private fun prune(now: Long) {
        while (history.isNotEmpty() && now - history.first().t > WINDOW_MS) history.removeFirst()
    }

    /** A gesture is live only if the user has not switched its action to "Off". */
    private fun enabled(g: Gesture): Boolean {
        if (AirFlowState.cursorMode.value) {
            // Cursor mode: the hand is a mouse, so only the exit and phone-navigation gestures stay live.
            if (g == Gesture.FIST_HOLD || g == Gesture.ROCK_HOLD) return true
            if (g !in CURSOR_MODE_OK) return false
        }
        return Prefs.actionFor(g) != Action.NONE && (!g.isSwipe || Prefs.swipeEnabled)
    }

    /** 1 = up, 2 = down, 3 = left, 4 = right, 0 = not a swipe. Fist swipes count like open swipes. */
    private fun dir(g: Gesture): Int = when (g) {
        Gesture.SWIPE_UP, Gesture.FIST_SWIPE_UP -> 1
        Gesture.SWIPE_DOWN, Gesture.FIST_SWIPE_DOWN -> 2
        Gesture.SWIPE_LEFT, Gesture.FIST_SWIPE_LEFT -> 3
        Gesture.SWIPE_RIGHT, Gesture.FIST_SWIPE_RIGHT -> 4
        else -> 0
    }

    /** True when [g] is the reverse of the swipe that just fired (the hand returning to rest). */
    private fun isReturnStroke(g: Gesture, now: Long): Boolean {
        val last = lastDir ?: return false
        if (now - lastFire >= RETURN_LOCK_MS) return false
        val a = dir(last)
        val b = dir(g)
        if (a == 0 || b == 0) return false
        return (a == 1 && b == 2) || (a == 2 && b == 1) || (a == 3 && b == 4) || (a == 4 && b == 3)
    }

    private fun mapVertical(screenUp: Boolean): Gesture =
        if (screenUp != Prefs.invertSwipe) Gesture.SWIPE_UP else Gesture.SWIPE_DOWN

    /** If the hand was a fist for most of the swipe, turn the open-hand swipe into the fist version. */
    private fun withFist(g: Gesture): Gesture {
        if (history.isEmpty()) return g
        val fists = history.count { it.fist }
        if (fists * 10 < history.size * 6) return g
        return when (g) {
            Gesture.SWIPE_UP -> Gesture.FIST_SWIPE_UP
            Gesture.SWIPE_DOWN -> Gesture.FIST_SWIPE_DOWN
            Gesture.SWIPE_LEFT -> Gesture.FIST_SWIPE_LEFT
            Gesture.SWIPE_RIGHT -> Gesture.FIST_SWIPE_RIGHT
            else -> g
        }
    }

    /**
     * Swiping the hand out of the frame (very natural for "down" and "up") makes the tracker lose
     * the hand. Instead of throwing the motion away, treat a fast move toward an edge as a swipe.
     */
    private fun exitSwipe(now: Long): Gesture? {
        if (!Prefs.swipeEnabled) return null
        prune(now)
        if (history.size < 3) return null
        val f = history.first()
        val l = history.last()
        if (now - l.t > 250) return null
        val th = EXIT_TH / Prefs.sensitivity
        val dx = l.x - f.x
        val dy = l.y - f.y
        val base: Gesture? = when {
            abs(dy) > th && abs(dy) >= abs(dx) && dy > 0 && l.y > 0.55f -> mapVertical(false)
            abs(dy) > th && abs(dy) >= abs(dx) && dy < 0 && l.y < 0.45f -> mapVertical(true)
            abs(dx) > th && abs(dx) > abs(dy) && dx > 0 && l.x > 0.6f -> Gesture.SWIPE_RIGHT
            abs(dx) > th && abs(dx) > abs(dy) && dx < 0 && l.x < 0.4f -> Gesture.SWIPE_LEFT
            else -> null
        }
        if (base == null) return null
        val g = withFist(base)
        if (isReturnStroke(g, now) || !enabled(g)) return null
        return g
    }

    /** Looks at the last few hundred ms of hand-centre movement and returns a swipe, if any. */
    private fun detectSwipe(now: Long): Gesture? {
        if (history.size < 3) return null
        val l = history.last()
        if (l.t - history.first().t < 70) return null
        var minX = Float.MAX_VALUE; var maxX = -Float.MAX_VALUE
        var minY = Float.MAX_VALUE; var maxY = -Float.MAX_VALUE
        for (s in history) {
            minX = min(minX, s.x); maxX = max(maxX, s.x)
            minY = min(minY, s.y); maxY = max(maxY, s.y)
        }
        val sens = Prefs.sensitivity
        val thV = V_TH / sens
        val thH = H_TH / sens
        val rangeX = maxX - minX
        val rangeY = maxY - minY
        // Net movement measured from the extreme point, so a swipe still counts when the hand
        // started a little off-centre or slowed at the end.
        val down = l.y - minY
        val up = maxY - l.y
        val right = l.x - minX
        val left = maxX - l.x

        var base: Gesture? = null
        if (rangeY >= rangeX * 0.85f && max(down, up) > thV) {
            base = mapVertical(up > down)
        } else if (rangeX >= rangeY * 1.2f && max(right, left) > thH) {
            base = if (right > left) Gesture.SWIPE_RIGHT else Gesture.SWIPE_LEFT
        }
        if (base == null) return null
        val g = withFist(base)
        if (isReturnStroke(g, now)) return null
        return g
    }

    private fun holdGesture(p: Pose): Gesture? = when (p) {
        Pose.OPEN -> Gesture.PALM_HOLD
        Pose.FIST -> Gesture.FIST_HOLD
        Pose.THUMB_UP -> Gesture.THUMB_UP_HOLD
        Pose.THUMB_DOWN -> Gesture.THUMB_DOWN_HOLD
        Pose.PEACE -> Gesture.PEACE_HOLD
        Pose.POINT -> Gesture.POINT_HOLD
        Pose.THREE -> Gesture.THREE_HOLD
        Pose.ROCK -> Gesture.ROCK_HOLD
        Pose.CALL -> Gesture.CALL_HOLD
        else -> null
    }

    private fun holdNeedMs(p: Pose): Long {
        val base = when (p) {
            Pose.OPEN -> 1100
            Pose.THUMB_UP, Pose.THUMB_DOWN -> 650
            else -> 900
        }
        return (base * Prefs.holdScale).toLong()
    }

    fun process(lm: List<PointF>?, aspect: Float, now: Long): Out {
        if (lm == null || lm.size < 21) {
            if (lostSince == 0L) lostSince = now
            // Hand left the frame while moving fast toward an edge: count it as a swipe.
            val exit = if (now - lastFire >= cooldown()) exitSwipe(now) else null
            holdPose = Pose.NONE
            holdFired = false
            pinchStart = 0L
            pinchFired = false
            if (exit != null) return Out(Pose.NONE, fire(exit, Pose.NONE, now).gesture)
            // Keep a short memory so one dropped frame doesn't erase a swipe in progress.
            if (now - lostSince > LOST_GRACE_MS) history.clear()
            return Out(Pose.NONE, null)
        }
        lostSince = 0L
        val pose = classify(lm, aspect)

        val cx = (lm[0].x + lm[5].x + lm[9].x + lm[13].x + lm[17].x) / 5f
        val cy = (lm[0].y + lm[5].y + lm[9].y + lm[13].y + lm[17].y) / 5f
        history.addLast(Sample(now, cx, cy, pose == Pose.FIST))
        prune(now)

        // After a gesture, wait out the cooldown (history keeps filling so we see real motion).
        if (now - lastFire < cooldown()) return Out(pose, null)

        // Swipes work with any hand shape except a pinch (fast motion often blurs the pose).
        if (Prefs.swipeEnabled && pose != Pose.PINCH) {
            val g = detectSwipe(now)
            if (g != null && enabled(g)) return fire(g, pose, now)
        }

        // Pinch (fires once per pinch)
        if (pose == Pose.PINCH) {
            if (pinchStart == 0L) pinchStart = now
            if (enabled(Gesture.PINCH) && !pinchFired && now - pinchStart >= PINCH_HOLD_MS) {
                pinchFired = true
                return fire(Gesture.PINCH, pose, now)
            }
        } else {
            pinchStart = 0L
            pinchFired = false
        }

        // Holds (hand must be still)
        var minX = Float.MAX_VALUE; var maxX = -Float.MAX_VALUE
        var minY = Float.MAX_VALUE; var maxY = -Float.MAX_VALUE
        for (s in history) {
            minX = min(minX, s.x); maxX = max(maxX, s.x)
            minY = min(minY, s.y); maxY = max(maxY, s.y)
        }
        val stationary = history.size >= 3 && (maxX - minX) < 0.07f && (maxY - minY) < 0.07f
        val hg = holdGesture(pose)
        val hp = if (hg != null) pose else Pose.NONE
        if (hp != holdPose) {
            holdPose = hp
            holdStart = now
            holdFired = false
        } else if (!stationary) {
            holdStart = now
        }
        if (!holdFired && hg != null && now - holdStart >= holdNeedMs(pose)) {
            if (enabled(hg)) return fire(hg, pose, now)
            holdFired = true
        }
        return Out(pose, null)
    }

    private fun cooldown(): Int = Prefs.cooldownMs.coerceAtMost(MAX_COOLDOWN_MS)

    private fun fire(g: Gesture, pose: Pose, now: Long): Out {
        lastFire = now
        lastDir = g
        history.clear()
        // Must change pose or lower the hand before another hold fires, except the thumbs,
        // which repeat while held so you can ramp the volume up or down.
        holdFired = !(g == Gesture.THUMB_UP_HOLD || g == Gesture.THUMB_DOWN_HOLD)
        holdStart = now
        return Out(pose, g)
    }

    private companion object {
        val CURSOR_MODE_OK = setOf(
            Gesture.THUMB_UP_HOLD, Gesture.THUMB_DOWN_HOLD,
            Gesture.FIST_SWIPE_UP, Gesture.FIST_SWIPE_DOWN, Gesture.FIST_SWIPE_LEFT, Gesture.FIST_SWIPE_RIGHT
        )
        const val PINCH_HOLD_MS = 90L
        const val PINCH_ON = 0.34f
        const val PINCH_OFF = 0.50f
        const val PINCH_ON_CURSOR = 0.46f
        const val PINCH_OFF_CURSOR = 0.68f
        const val WINDOW_MS = 380L
        const val V_TH = 0.11f      // vertical travel (fraction of frame height) for a swipe
        const val H_TH = 0.15f      // horizontal travel (fraction of frame width)
        const val EXIT_TH = 0.09f   // travel needed when the hand leaves the frame
        const val LOST_GRACE_MS = 350L
        const val RETURN_LOCK_MS = 750L
        const val MAX_COOLDOWN_MS = 650
        const val THUMB_OUT = 0.55f  // thumb tip to index base, as a fraction of palm length
        const val THUMB_VERT = 0.50f // thumb must point mostly up/down by this much of palm length
    }

    private fun d(lm: List<PointF>, a: Int, b: Int, asp: Float): Float =
        hypot((lm[a].x - lm[b].x) * asp, lm[a].y - lm[b].y)

    private fun ext(lm: List<PointF>, tip: Int, pip: Int, asp: Float): Boolean =
        d(lm, 0, tip, asp) > d(lm, 0, pip, asp) * 1.08f

    private fun classify(lm: List<PointF>, asp: Float): Pose {
        val idx = ext(lm, 8, 6, asp)
        val mid = ext(lm, 12, 10, asp)
        val ring = ext(lm, 16, 14, asp)
        val pinky = ext(lm, 20, 18, asp)
        val size = max(d(lm, 0, 9, asp), 0.001f)
        val pinchRatio = d(lm, 4, 8, asp) / size
        val others = listOf(mid, ring, pinky).count { it }
        val cur = AirFlowState.cursorMode.value
        // Cursor mode uses a much more forgiving pinch (fingers do not have to touch exactly).
        val limit = if (cur) (if (pinching) PINCH_OFF_CURSOR else PINCH_ON_CURSOR)
                    else (if (pinching) PINCH_OFF else PINCH_ON)
        // In cursor mode you point with the other fingers curled, so a pinch is also valid when the
        // index finger is clearly reaching out (this still rejects a fist with the thumb on it).
        val idxReaching = d(lm, 0, 8, asp) > d(lm, 0, 5, asp) * 1.12f
        val pinchOk = others >= 1 || (cur && idxReaching)
        if (pinchRatio < limit && pinchOk) {
            pinching = true
            return Pose.PINCH
        }
        pinching = false
        val count = listOf(idx, mid, ring, pinky).count { it }
        val thumbOut = d(lm, 4, 5, asp) / size > THUMB_OUT
        if (count == 0) {
            // Fist, or a thumbs up / down when the thumb sticks out vertically.
            val vertical = (lm[4].y - lm[2].y) / size
            if (thumbOut && vertical < -THUMB_VERT) return Pose.THUMB_UP
            if (thumbOut && vertical > THUMB_VERT) return Pose.THUMB_DOWN
            return Pose.FIST
        }
        return when {
            count == 4 -> Pose.OPEN
            idx && mid && !ring && !pinky -> Pose.PEACE
            idx && !mid && !ring && !pinky -> Pose.POINT
            idx && mid && ring && !pinky -> Pose.THREE
            idx && pinky && !mid && !ring -> Pose.ROCK
            pinky && thumbOut && !idx && !mid && !ring -> Pose.CALL
            else -> Pose.OTHER
        }
    }
}
