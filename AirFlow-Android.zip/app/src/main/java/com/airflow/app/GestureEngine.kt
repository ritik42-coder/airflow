package com.airflow.app

import android.graphics.PointF
import kotlin.math.abs
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min

/** Turns 21 hand landmarks per frame into discrete gestures. Pure logic, no Android camera code. */
class GestureEngine {
    enum class Pose { NONE, OPEN, FIST, PINCH, OTHER }
    data class Out(val pose: Pose, val gesture: Gesture?)

    private class Sample(val t: Long, val x: Float, val y: Float)

    private val history = ArrayDeque<Sample>()
    private var lastFire = 0L
    private var lastDir: Gesture? = null
    private var lostSince = 0L
    private var holdPose = Pose.NONE
    private var holdStart = 0L
    private var holdFired = false
    private var pinchStart = 0L
    private var pinchFired = false
    private var pinching = false

    private fun resetAll() {
        history.clear()
        holdPose = Pose.NONE
        holdFired = false
        pinchStart = 0L
        pinchFired = false
    }

    private fun prune(now: Long) {
        while (history.isNotEmpty() && now - history.first().t > WINDOW_MS) history.removeFirst()
    }

    /** True when [g] is the reverse of the swipe that just fired (the hand returning to rest). */
    private fun isReturnStroke(g: Gesture, now: Long): Boolean {
        val last = lastDir ?: return false
        if (now - lastFire >= RETURN_LOCK_MS) return false
        return (last == Gesture.SWIPE_UP && g == Gesture.SWIPE_DOWN) ||
            (last == Gesture.SWIPE_DOWN && g == Gesture.SWIPE_UP) ||
            (last == Gesture.SWIPE_LEFT && g == Gesture.SWIPE_RIGHT) ||
            (last == Gesture.SWIPE_RIGHT && g == Gesture.SWIPE_LEFT)
    }

    private fun mapVertical(screenUp: Boolean): Gesture =
        if (screenUp != Prefs.invertSwipe) Gesture.SWIPE_UP else Gesture.SWIPE_DOWN

    /**
     * Swiping the hand out of the frame (very natural for "down" and "up") makes the tracker lose
     * the hand. Instead of throwing the motion away, treat a fast move toward an edge as a swipe.
     */
    private fun exitSwipe(now: Long): Gesture? {
        if (!Prefs.swipeEnabled) return null
        prune(now)
        if (history.size < 3) return null
        val f = history.first()
        val l = history.last()
        if (now - l.t > 250) return null
        val th = EXIT_TH / Prefs.sensitivity
        val dx = l.x - f.x
        val dy = l.y - f.y
        val g: Gesture? = when {
            abs(dy) > th && abs(dy) >= abs(dx) && dy > 0 && l.y > 0.55f -> mapVertical(false)
            abs(dy) > th && abs(dy) >= abs(dx) && dy < 0 && l.y < 0.45f -> mapVertical(true)
            abs(dx) > th && abs(dx) > abs(dy) && dx > 0 && l.x > 0.6f -> Gesture.SWIPE_RIGHT
            abs(dx) > th && abs(dx) > abs(dy) && dx < 0 && l.x < 0.4f -> Gesture.SWIPE_LEFT
            else -> null
        }
        if (g == null || isReturnStroke(g, now)) return null
        return g
    }

    /** Looks at the last few hundred ms of hand-centre movement and returns a swipe, if any. */
    private fun detectSwipe(now: Long): Gesture? {
        if (history.size < 3) return null
        val l = history.last()
        if (l.t - history.first().t < 70) return null
        var minX = Float.MAX_VALUE; var maxX = -Float.MAX_VALUE
        var minY = Float.MAX_VALUE; var maxY = -Float.MAX_VALUE
        for (s in history) {
            minX = min(minX, s.x); maxX = max(maxX, s.x)
            minY = min(minY, s.y); maxY = max(maxY, s.y)
        }
        val sens = Prefs.sensitivity
        val thV = V_TH / sens
        val thH = H_TH / sens
        val rangeX = maxX - minX
        val rangeY = maxY - minY
        // Net movement measured from the extreme point, so a swipe still counts when the hand
        // started a little off-centre or slowed at the end.
        val down = l.y - minY
        val up = maxY - l.y
        val right = l.x - minX
        val left = maxX - l.x

        var g: Gesture? = null
        if (rangeY >= rangeX * 0.85f && max(down, up) > thV) {
            g = mapVertical(up > down)
        } else if (rangeX >= rangeY * 1.2f && max(right, left) > thH) {
            g = if (right > left) Gesture.SWIPE_RIGHT else Gesture.SWIPE_LEFT
        }
        if (g != null && isReturnStroke(g, now)) return null
        return g
    }

    fun process(lm: List<PointF>?, aspect: Float, now: Long): Out {
        if (lm == null || lm.size < 21) {
            if (lostSince == 0L) lostSince = now
            // Hand left the frame while moving fast toward an edge: count it as a swipe.
            val exit = if (now - lastFire >= cooldown()) exitSwipe(now) else null
            holdPose = Pose.NONE
            holdFired = false
            pinchStart = 0L
            pinchFired = false
            if (exit != null) return Out(Pose.NONE, fire(exit, Pose.NONE, now).gesture)
            // Keep a short memory so one dropped frame doesn't erase a swipe in progress.
            if (now - lostSince > LOST_GRACE_MS) history.clear()
            return Out(Pose.NONE, null)
        }
        lostSince = 0L
        val pose = classify(lm, aspect)

        val cx = (lm[0].x + lm[5].x + lm[9].x + lm[13].x + lm[17].x) / 5f
        val cy = (lm[0].y + lm[5].y + lm[9].y + lm[13].y + lm[17].y) / 5f
        history.addLast(Sample(now, cx, cy))
        prune(now)

        // After a gesture, wait out the cooldown (history keeps filling so we see real motion).
        if (now - lastFire < cooldown()) return Out(pose, null)

        // Swipes work with any hand shape except a pinch (fast motion often blurs the pose).
        if (Prefs.swipeEnabled && pose != Pose.PINCH) {
            val g = detectSwipe(now)
            if (g != null) return fire(g, pose, now)
        }

        // Pinch (fires once per pinch)
        if (pose == Pose.PINCH) {
            if (pinchStart == 0L) pinchStart = now
            if (Prefs.pinchEnabled && !pinchFired && now - pinchStart >= PINCH_HOLD_MS) {
                pinchFired = true
                return fire(Gesture.PINCH, pose, now)
            }
        } else {
            pinchStart = 0L
            pinchFired = false
        }

        // Holds (open palm / fist, hand must be still)
        var minX = Float.MAX_VALUE; var maxX = -Float.MAX_VALUE
        var minY = Float.MAX_VALUE; var maxY = -Float.MAX_VALUE
        for (s in history) {
            minX = min(minX, s.x); maxX = max(maxX, s.x)
            minY = min(minY, s.y); maxY = max(maxY, s.y)
        }
        val stationary = history.size >= 3 && (maxX - minX) < 0.07f && (maxY - minY) < 0.07f
        val hp = if (pose == Pose.OPEN || pose == Pose.FIST) pose else Pose.NONE
        if (hp != holdPose) {
            holdPose = hp
            holdStart = now
            holdFired = false
        } else if (!stationary) {
            holdStart = now
        }
        if (!holdFired && hp != Pose.NONE) {
            val need = if (hp == Pose.OPEN) 1100 else 900
            if (now - holdStart >= need) {
                if (hp == Pose.OPEN && Prefs.palmHoldEnabled) return fire(Gesture.PALM_HOLD, pose, now)
                if (hp == Pose.FIST && Prefs.fistEnabled) return fire(Gesture.FIST_HOLD, pose, now)
                holdFired = true
            }
        }
        return Out(pose, null)
    }

    private fun cooldown(): Int = Prefs.cooldownMs.coerceAtMost(MAX_COOLDOWN_MS)

    private fun fire(g: Gesture, pose: Pose, now: Long): Out {
        lastFire = now
        lastDir = g
        history.clear()
        holdFired = true // must change pose or lower the hand before another hold fires
        holdStart = now
        return Out(pose, g)
    }

    private companion object {
        const val PINCH_HOLD_MS = 90L
        const val PINCH_ON = 0.34f
        const val PINCH_OFF = 0.50f
        const val WINDOW_MS = 380L
        const val V_TH = 0.11f      // vertical travel (fraction of frame height) for a swipe
        const val H_TH = 0.15f      // horizontal travel (fraction of frame width)
        const val EXIT_TH = 0.09f   // travel needed when the hand leaves the frame
        const val LOST_GRACE_MS = 350L
        const val RETURN_LOCK_MS = 750L
        const val MAX_COOLDOWN_MS = 650
    }

    private fun d(lm: List<PointF>, a: Int, b: Int, asp: Float): Float =
        hypot((lm[a].x - lm[b].x) * asp, lm[a].y - lm[b].y)

    private fun ext(lm: List<PointF>, tip: Int, pip: Int, asp: Float): Boolean =
        d(lm, 0, tip, asp) > d(lm, 0, pip, asp) * 1.08f

    private fun classify(lm: List<PointF>, asp: Float): Pose {
        val idx = ext(lm, 8, 6, asp)
        val mid = ext(lm, 12, 10, asp)
        val ring = ext(lm, 16, 14, asp)
        val pinky = ext(lm, 20, 18, asp)
        val size = max(d(lm, 0, 9, asp), 0.001f)
        val pinchRatio = d(lm, 4, 8, asp) / size
        val others = listOf(mid, ring, pinky).count { it }
        val limit = if (pinching) PINCH_OFF else PINCH_ON
        if (pinchRatio < limit && others >= 1) {
            pinching = true
            return Pose.PINCH
        }
        pinching = false
        val count = listOf(idx, mid, ring, pinky).count { it }
        return when (count) {
            4 -> Pose.OPEN
            0 -> Pose.FIST
            else -> Pose.OTHER
        }
    }
}
