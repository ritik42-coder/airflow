package com.airflow.app

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.exp
import kotlin.math.max
import kotlin.math.pow
import kotlin.math.sin

/**
 * Air Music instrument voices. Each one is a small FM / additive model, so the whole "Casio" lives in
 * code: no samples, no assets, no download, a few kilobytes of APK.
 */
enum class Instrument(val label: String, val about: String) {
    CASIO_PIANO("Piano", "Casio grand, bright hammers"),
    ELECTRIC_PIANO("E.Piano", "bell tines, soft and warm"),
    VIBES("Vibes", "vibraphone, slow shimmer"),
    ORGAN("Organ", "drawbar organ, holds forever"),
    SYNTH("Synth", "air lead, wide and glassy"),
    MARIMBA("Marimba", "wooden bars, short and round")
}

/** Envelope and timbre of one instrument. Times are in seconds. */
private class Tone(
    val attack: Float,
    val decay: Float,
    val sustain: Float,
    val release: Float,
    val modRatio: Float,
    val modIndex: Float,
    val h2: Float,
    val h3: Float,
    val lfoHz: Float,
    val lfoDepth: Float
)

private fun toneOf(i: Instrument): Tone = when (i) {
    Instrument.CASIO_PIANO -> Tone(0.004f, 1.9f, 0.09f, 0.30f, 1f, 1.9f, 0.34f, 0.10f, 0f, 0f)
    Instrument.ELECTRIC_PIANO -> Tone(0.006f, 2.6f, 0.16f, 0.34f, 14f, 0.85f, 0.16f, 0.05f, 5.2f, 0.008f)
    Instrument.VIBES -> Tone(0.003f, 1.5f, 0.05f, 0.55f, 4f, 0.55f, 0.10f, 0f, 4.6f, 0.012f)
    Instrument.ORGAN -> Tone(0.020f, 0.9f, 0.85f, 0.12f, 0f, 0f, 0.30f, 0.18f, 6.2f, 0.005f)
    Instrument.SYNTH -> Tone(0.010f, 1.2f, 0.60f, 0.22f, 2f, 1.05f, 0.45f, 0.26f, 5.5f, 0.010f)
    Instrument.MARIMBA -> Tone(0.002f, 0.55f, 0.02f, 0.16f, 3f, 0.75f, 0.22f, 0.08f, 0f, 0f)
}

/** Sine lookup: 4096 points with linear interpolation. Fast enough for 20 voices at 44.1 kHz. */
private val SINE = FloatArray(4096) { sin(2.0 * PI * it / 4096.0).toFloat() }

private fun sine(p: Float): Float {
    val fl = Math.floor(p.toDouble()).toFloat()
    val f = (p - fl) * 4096f
    val i0 = f.toInt()
    val fr = f - i0
    val a = SINE[i0 and 4095]
    val b = SINE[(i0 + 1) and 4095]
    return a + (b - a) * fr
}

/** One sounding note. Everything is plain floats so the audio thread never allocates. */
private class Voice {
    var on = false
    var midi = 0
    var pan = 0f
    var amp = 0f
    var inc = 0f
    var minc = 0f
    var ph = 0f
    var mph = 0f
    var env = 0f
    var stage = 0
    var attackInc = 0f
    var decayCoef = 0f
    var sustain = 0f
    var releaseCoef = 0f
    var lfoPh = 0f
    var lfoInc = 0f
    var lfoDepth = 0f
    var pendingOff = false
    var tone: Tone = toneOf(Instrument.CASIO_PIANO)
}

/** Feedback comb with damping: one of the reverb building blocks. */
private class VerbLine(size: Int, private val feedback: Float, private val damp: Float) {
    private val buf = FloatArray(size)
    private var i = 0
    private var lp = 0f

    fun process(x: Float): Float {
        val y = buf[i]
        lp = y * (1f - damp) + lp * damp
        buf[i] = x + lp * feedback
        i++
        if (i >= buf.size) i = 0
        return y
    }
}

private class AllPass(size: Int, private val g: Float) {
    private val buf = FloatArray(size)
    private var i = 0

    fun process(x: Float): Float {
        val b = buf[i]
        val y = b - x
        buf[i] = x + b * g
        i++
        if (i >= buf.size) i = 0
        return y
    }
}

private class Ev(val type: Int, val midi: Int, val vel: Float, val pan: Float)

/**
 * Polyphonic real-time synthesizer: 20 voices, stereo, plate-ish reverb, soft limiting.
 * The UI only calls [noteOn] / [noteOff]; a single audio thread renders and feeds an AudioTrack.
 */
class AirSynth {

    companion object {
        const val SR = 44100
        private const val BLOCK = 512
        private const val VOICES = 20
        private const val EV_ON = 0
        private const val EV_OFF = 1
        private const val EV_ALL_OFF = 2
        private const val EV_SUSTAIN_OFF = 3
    }

    @Volatile private var instrument: Instrument = Instrument.CASIO_PIANO
    @Volatile private var volume: Float = 0.85f
    @Volatile private var reverb: Float = 0.35f
    @Volatile private var sustain: Boolean = false

    /** 0..1 loudness of the last block, used by the visuals. */
    @Volatile var level: Float = 0f
        private set

    @Volatile var running: Boolean = false
        private set

    private val voices = Array(VOICES) { Voice() }
    private val lock = Any()
    private val events = ArrayList<Ev>()
    private val buf = ShortArray(BLOCK * 2)
    private var track: AudioTrack? = null
    private var thread: Thread? = null

    private val verbsL = arrayOf(
        VerbLine(1557, 0.79f, 0.26f), VerbLine(1491, 0.77f, 0.30f), VerbLine(1422, 0.75f, 0.34f)
    )
    private val verbsR = arrayOf(
        VerbLine(1601, 0.79f, 0.26f), VerbLine(1531, 0.77f, 0.30f), VerbLine(1459, 0.75f, 0.34f)
    )
    private val apL = AllPass(225, 0.5f)
    private val apR = AllPass(241, 0.5f)

    // ---------------------------------------------------------------------------------- public

    fun setInstrument(i: Instrument) { instrument = i }
    fun setVolume(v: Float) { volume = v.coerceIn(0f, 1f) }
    fun setReverb(v: Float) { reverb = v.coerceIn(0f, 1f) }

    fun setSustain(on: Boolean) {
        sustain = on
        if (!on) synchronized(lock) { events.add(Ev(EV_SUSTAIN_OFF, 0, 0f, 0f)) }
    }

    fun noteOn(midi: Int, velocity: Float = 0.8f, pan: Float = 0f) {
        if (midi < 12 || midi > 120) return
        synchronized(lock) { events.add(Ev(EV_ON, midi, velocity.coerceIn(0.05f, 1f), pan)) }
    }

    fun noteOff(midi: Int) {
        synchronized(lock) { events.add(Ev(EV_OFF, midi, 0f, 0f)) }
    }

    fun allNotesOff() {
        synchronized(lock) { events.add(Ev(EV_ALL_OFF, 0, 0f, 0f)) }
    }

    fun start() {
        if (running) return
        running = true
        val t = Thread {
            android.os.Process.setThreadPriority(android.os.Process.THREAD_PRIORITY_AUDIO)
            var at: AudioTrack? = null
            try {
                val minBytes = AudioTrack.getMinBufferSize(
                    SR, AudioFormat.CHANNEL_OUT_STEREO, AudioFormat.ENCODING_PCM_16BIT
                )
                val bytes = max(minBytes, 2048 * 4)
                val made = AudioTrack.Builder()
                    .setAudioAttributes(
                        AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_MEDIA)
                            .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                            .build()
                    )
                    .setAudioFormat(
                        AudioFormat.Builder()
                            .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                            .setSampleRate(SR)
                            .setChannelMask(AudioFormat.CHANNEL_OUT_STEREO)
                            .build()
                    )
                    .setBufferSizeInBytes(bytes)
                    .setTransferMode(AudioTrack.MODE_STREAM)
                    .build()
                if (made.state != AudioTrack.STATE_INITIALIZED) {
                    made.release()
                    running = false
                    return@Thread
                }
                at = made
                track = made
                made.play()
                while (running) {
                    drain()
                    render()
                    made.write(buf, 0, buf.size)
                }
            } catch (e: Exception) {
                // Audio is best effort: a busy device must never take the screen down with it.
                running = false
            } finally {
                try { at?.pause() } catch (_: Exception) {}
                try { at?.flush() } catch (_: Exception) {}
                try { at?.release() } catch (_: Exception) {}
                track = null
                level = 0f
            }
        }
        thread = t
        t.isDaemon = true
        t.start()
    }

    fun stop() {
        running = false
        try { thread?.join(400) } catch (_: InterruptedException) {}
        thread = null
    }

    // ---------------------------------------------------------------------------------- audio thread

    private fun drain() {
        val pending = synchronized(lock) {
            if (events.isEmpty()) null else ArrayList(events).also { events.clear() }
        } ?: return
        for (e in pending) {
            when (e.type) {
                EV_ON -> startVoice(e.midi, e.vel, e.pan)
                EV_OFF -> stopVoice(e.midi)
                EV_ALL_OFF -> for (v in voices) if (v.on) v.stage = 2
                EV_SUSTAIN_OFF -> for (v in voices) if (v.pendingOff) { v.pendingOff = false; v.stage = 2 }
            }
        }
    }

    private fun startVoice(midi: Int, vel: Float, pan: Float) {
        val t = toneOf(instrument)
        var slot: Voice? = null
        for (v in voices) if (!v.on) { slot = v; break }
        if (slot == null) {
            // steal the quietest voice so a fast run never drops a note silently
            var quiet = voices[0]
            for (v in voices) if (v.env < quiet.env) quiet = v
            slot = quiet
        }
        val v: Voice = slot ?: voices[0]
        val f = 440f * 2f.pow((midi - 69) / 12f)
        v.on = true
        v.midi = midi
        v.pan = pan.coerceIn(-1f, 1f)
        v.ph = 0f
        v.mph = 0f
        v.lfoPh = 0f
        v.inc = f / SR
        v.minc = f * t.modRatio / SR
        v.amp = 0.15f * (0.35f + 0.65f * vel)
        v.env = 0f
        v.stage = 0
        v.pendingOff = false
        v.sustain = t.sustain
        v.attackInc = 1f / max(1f, t.attack * SR)
        v.decayCoef = exp(-1f / (t.decay * SR))
        v.releaseCoef = exp(-1f / (t.release * SR))
        v.lfoInc = if (t.lfoHz > 0f) t.lfoHz / SR else 0f
        v.lfoDepth = t.lfoDepth
        v.tone = t
    }

    private fun stopVoice(midi: Int) {
        for (v in voices) {
            if (v.on && v.midi == midi && v.stage != 2) {
                if (sustain) v.pendingOff = true else v.stage = 2
            }
        }
    }

    private fun step(v: Voice): Float {
        val t = v.tone
        var pitch = 1f
        if (v.lfoInc > 0f) {
            v.lfoPh += v.lfoInc
            if (v.lfoPh >= 1f) v.lfoPh -= 1f
            pitch = 1f + v.lfoDepth * sine(v.lfoPh)
        }
        v.ph += v.inc * pitch
        if (v.ph >= 1f) v.ph -= 1f
        var s: Float
        if (t.modIndex > 0f) {
            v.mph += v.minc * pitch
            if (v.mph >= 1f) v.mph -= 1f
            s = sine(v.ph + sine(v.mph) * t.modIndex * (0.30f + 0.70f * v.env))
        } else {
            s = sine(v.ph)
        }
        if (t.h2 > 0f) s += t.h2 * sine(v.ph * 2f)
        if (t.h3 > 0f) s += t.h3 * sine(v.ph * 3f)
        s *= v.amp * v.env

        if (v.stage == 0) {
            v.env += v.attackInc
            if (v.env >= 1f) { v.env = 1f; v.stage = 1 }
        } else if (v.stage == 1) {
            v.env = v.sustain + (v.env - v.sustain) * v.decayCoef
        } else {
            v.env *= v.releaseCoef
            if (v.env < 0.0008f) { v.env = 0f; v.on = false }
        }
        return s
    }

    private fun render() {
        val gain = volume * 0.9f
        val rv = reverb
        val t = toneOf(instrument)
        for (v in voices) if (v.on) v.tone = t
        var peak = 0f

        for (i in 0 until BLOCK) {
            var l = 0f
            var r = 0f
            for (v in voices) {
                if (!v.on) continue
                val s = step(v)
                val pl = if (v.pan > 0f) 1f - v.pan * 0.55f else 1f
                val pr = if (v.pan < 0f) 1f + v.pan * 0.55f else 1f
                l += s * pl
                r += s * pr
            }
            l *= gain
            r *= gain
            if (rv > 0.001f) {
                val sl = (verbsL[0].process(l) + verbsL[1].process(l) + verbsL[2].process(l)) * 0.33f
                val sr = (verbsR[0].process(r) + verbsR[1].process(r) + verbsR[2].process(r)) * 0.33f
                l += apL.process(sl) * rv * 0.9f
                r += apR.process(sr) * rv * 0.9f
            }
            l = softClip(l)
            r = softClip(r)
            val al = abs(l)
            val ar = abs(r)
            if (al > peak) peak = al
            if (ar > peak) peak = ar
            buf[i * 2] = toPcm(l)
            buf[i * 2 + 1] = toPcm(r)
        }
        level = level * 0.72f + (peak.coerceIn(0f, 1f)) * 0.28f
    }

    /** Gentle limiter: quiet playing stays untouched, a ten finger chord compresses instead of clipping. */
    private fun softClip(x: Float): Float {
        val a = abs(x)
        if (a <= 0.7f) return x
        val over = (a - 0.7f) / 0.3f
        val y = 0.7f + 0.3f * (over / (1f + over))
        return if (x < 0f) -y else y
    }

    private fun toPcm(x: Float): Short {
        val v = x.coerceIn(-1f, 1f) * 32767f
        return v.toInt().toShort()
    }
}
