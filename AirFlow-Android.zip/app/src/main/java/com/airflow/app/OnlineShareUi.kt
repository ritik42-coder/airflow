package com.airflow.app

import android.Manifest
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateOffsetAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.max
import kotlin.math.roundToInt

/**
 * The nearby map: you in the middle, every phone at its real direction and distance, rings for the range,
 * a radar sweep. Dots are pushed apart so none ever overlap; tap a dot to pick who gets the drop.
 */
@Composable
fun NearbyMap(
    nodes: List<OnlineNode>,
    radiusM: Float,
    selected: Set<String>,
    onToggle: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val c = Air.c
    val density = LocalDensity.current
    var sizePx by remember { mutableFloatStateOf(0f) }
    val dotPx = with(density) { 34.dp.toPx() }
    val inRange = remember(nodes, radiusM) { nodes.filter { it.dist <= radiusM } }

    // real position -> screen position, then spread so no two dots touch
    val laid = remember(inRange, radiusM, sizePx) {
        if (sizePx <= 0f || inRange.isEmpty()) emptyList()
        else {
            val maxR = sizePx / 2f - dotPx * 0.75f
            val k = maxR / radiusM
            val xs = FloatArray(inRange.size) { inRange[it].dx * k }
            val ys = FloatArray(inRange.size) { -inRange[it].dy * k }
            MapLayout.spread(xs, ys, dotPx * 1.25f, maxR, dotPx * 1.1f)
            inRange.mapIndexed { i, n -> Triple(n, xs[i], ys[i]) }
        }
    }

    val sweep by rememberInfiniteTransition(label = "sweep").animateFloat(
        0f, 360f, infiniteRepeatable(tween(4200, easing = LinearEasing), RepeatMode.Restart), label = "a"
    )
    val pulse by rememberInfiniteTransition(label = "pulse").animateFloat(
        0f, 1f, infiniteRepeatable(tween(1800, easing = LinearEasing), RepeatMode.Restart), label = "p"
    )

    Box(
        modifier
            .fillMaxWidth()
            .aspectRatio(1f)
            .clip(CircleShape)
            .background(Brush.radialGradient(listOf(c.glassHi, c.glassHi.copy(alpha = 0.35f))))
            .border(1.dp, c.stroke, CircleShape)
            .onSizeChanged { sizePx = it.width.toFloat() },
        contentAlignment = Alignment.Center
    ) {
        Canvas(Modifier.fillMaxWidth().aspectRatio(1f)) {
            val ctr = Offset(size.width / 2f, size.height / 2f)
            val maxR = size.minDimension / 2f - dotPx * 0.75f
            for (f in listOf(1f / 3f, 2f / 3f, 1f)) {
                drawCircle(c.stroke, radius = maxR * f, center = ctr, style = Stroke(width = 1.2f))
            }
            drawLine(c.stroke.copy(alpha = 0.5f), Offset(ctr.x, ctr.y - maxR), Offset(ctr.x, ctr.y + maxR), 1f)
            drawLine(c.stroke.copy(alpha = 0.5f), Offset(ctr.x - maxR, ctr.y), Offset(ctr.x + maxR, ctr.y), 1f)
            rotate(sweep, ctr) {
                drawCircle(
                    Brush.sweepGradient(listOf(Color.Transparent, Color.Transparent, c.a2.copy(alpha = 0.28f)), ctr),
                    radius = maxR, center = ctr
                )
            }
            // you: a soft pulse and a solid dot
            drawCircle(c.a2.copy(alpha = 0.35f * (1f - pulse)), radius = dotPx * (0.5f + pulse * 0.9f), center = ctr)
            drawCircle(c.a2, radius = dotPx * 0.3f, center = ctr)
            drawCircle(Color.White, radius = dotPx * 0.12f, center = ctr)
        }
        Text("N", color = c.dim, fontSize = 10.sp, fontWeight = FontWeight.Black, modifier = Modifier.align(Alignment.TopCenter).offset(y = 6.dp))
        val ringLabel = { m: Float -> if (m >= 1000f) "${(m / 100f).roundToInt() / 10f} km" else "${m.roundToInt()} m" }
        Text(ringLabel(radiusM), color = c.dim, fontSize = 10.sp, modifier = Modifier.align(Alignment.BottomCenter).offset(y = (-6).dp))

        for ((n, x, y) in laid) {
            key(n.uid) {
                val pos by animateOffsetAsState(Offset(x, y), tween(700), label = "dot")
                val on = n.uid in selected
                Box(
                    Modifier
                        .offset { IntOffset(pos.x.roundToInt(), pos.y.roundToInt()) }
                        .size(34.dp)
                        .clip(CircleShape)
                        .background(Color(n.color))
                        .border(if (on) 3.dp else 1.dp, if (on) Color.White else Color.White.copy(alpha = 0.55f), CircleShape)
                        .clickable { onToggle(n.uid) },
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        n.name.trim().take(1).uppercase().ifEmpty { "?" },
                        color = Color.White, fontWeight = FontWeight.Black, fontSize = 14.sp, textAlign = TextAlign.Center
                    )
                }
            }
        }
        if (nodes.size > inRange.size) {
            Text(
                "+${nodes.size - inRange.size} farther",
                color = c.dim, fontSize = 10.sp,
                modifier = Modifier.align(Alignment.BottomEnd).offset(x = (-18).dp, y = (-28).dp)
            )
        }
    }
}

/** Online Air Share: turn it on, see who is nearby, pick photos, text or a link, then release by hand gesture. */
@Composable
fun OnlineCard() {
    val ctx = LocalContext.current
    val c = Air.c
    val shareOn by AirShareHub.active.collectAsState()
    val nodes by OnlineShare.nearby.collectAsState()
    val selected by OnlineShare.selected.collectAsState()
    val status by OnlineShare.status.collectAsState()
    val acc by OnlineShare.accuracy.collectAsState()
    var on by remember { mutableStateOf(Prefs.onlineOn) }
    var visible by remember { mutableStateOf(Prefs.onlineVisible) }
    var name by remember { mutableStateOf(Prefs.onlineName) }
    var radius by remember { mutableStateOf(Prefs.onlineRadius) }
    var ttl by remember { mutableStateOf(Prefs.onlineTtl) }
    var msg by remember { mutableStateOf("") }

    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        if (on) AirShareHub.setOnline(ctx, true)
    }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris: List<Uri> ->
        if (uris.isEmpty()) return@rememberLauncherForActivityResult
        val app = ctx.applicationContext
        msg = "Getting your photos ready..."
        Thread {
            val files = ArrayList<QueuedFile>()
            for (u in uris.take(4)) {
                val info = TapFiles.describe(app, u)
                if (!(info.mime.startsWith("image/") || FileStore.isImage(info.name))) continue
                val f = TapFiles.materialise(app, info) ?: continue
                files.add(QueuedFile(f, info.name, true))
            }
            android.os.Handler(android.os.Looper.getMainLooper()).post {
                if (files.isEmpty()) msg = "Online drops carry photos, text and links. Pick a photo."
                else { AirShareHub.armOnline(app, files); msg = "Armed. Flick your open hand upward, or palm, fist, open." }
            }
        }.start()
    }

    val inRange = nodes.count { it.dist <= radius }
    SectionCard("Online Air Share: drop to phones nearby") {
        Text(
            "Works anywhere there is internet, no Bluetooth needed. Phones within range show on the map; release a photo, link or text with the " +
                "same hand gesture and it appears on each of them with the Air Share animation (they tap Accept first). Drops are deleted from the " +
                "server after a few minutes. Needs Air Share (hand + touch) ON to release by gesture.",
            style = MaterialTheme.typography.bodySmall, color = c.dim
        )
        AirButton(
            if (on) "Online Air Share: ON" else "Online Air Share: OFF",
            {
                on = !on
                if (on && !Perms.locationOk(ctx)) {
                    permLauncher.launch(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION))
                    Prefs.onlineOn = true
                } else AirShareHub.setOnline(ctx, on)
            },
            Modifier.fillMaxWidth(), filled = on, icon = IconKind.BOLT
        )
        if (on) {
            Text(
                status.ifEmpty { "Connecting..." } + if (acc > 0f) "  (location ±${acc.toInt()} m)" else "",
                style = MaterialTheme.typography.bodySmall,
                color = if (status.startsWith("Online")) c.ok else c.a2
            )
            NearbyMap(nodes, radius.toFloat(), selected, { OnlineShare.toggle(it) }, Modifier.fillMaxWidth())
            Text(
                if (selected.isEmpty()) "$inRange phone${if (inRange == 1) "" else "s"} in range. Tap dots to pick who gets it; none picked = everyone in range."
                else "${selected.size} picked.",
                style = MaterialTheme.typography.bodySmall, color = c.dim
            )
            for (n in nodes.filter { it.dist <= radius }.take(8)) {
                Text(
                    (if (n.uid in selected) "✓ " else "") + n.name + "  ·  " + (if (n.dist < 1000f) "${n.dist.toInt()} m" else "${"%.1f".format(n.dist / 1000f)} km"),
                    color = c.text, fontSize = 12.sp
                )
            }
            if (selected.isNotEmpty()) AirButton("Everyone in range", { OnlineShare.selected.value = emptySet() }, Modifier.fillMaxWidth(), filled = false)

            Text("RANGE", color = c.a2, fontWeight = FontWeight.Black, fontSize = 11.sp, letterSpacing = 2.sp)
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                for (r in listOf(50, 150, 500, 2000)) {
                    AirButton(if (r >= 1000) "${r / 1000} km" else "$r m", { radius = r; Prefs.onlineRadius = r }, Modifier.weight(1f), filled = radius == r)
                }
            }
            Text("DELETE FROM SERVER AFTER", color = c.a2, fontWeight = FontWeight.Black, fontSize = 11.sp, letterSpacing = 2.sp)
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                for (t in listOf(2, 10, 60)) {
                    AirButton(if (t >= 60) "1 hour" else "$t min", { ttl = t; Prefs.onlineTtl = t }, Modifier.weight(1f), filled = ttl == t)
                }
            }

            AirButton(
                "Pick photos to drop",
                { if (!shareOn) msg = "Turn on Air Share (hand + touch) first." else picker.launch(arrayOf("image/*")) },
                Modifier.fillMaxWidth(), icon = IconKind.SHARE
            )
            AirButton(
                "Drop the link or text I copied",
                {
                    if (!shareOn) msg = "Turn on Air Share (hand + touch) first." else {
                        val text = try {
                            val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                            cm.primaryClip?.takeIf { it.itemCount > 0 }?.getItemAt(0)?.coerceToText(ctx)?.toString()
                        } catch (e: Exception) { null }
                        val item = QuickParser.parse(text)
                        if (item == null) msg = "The clipboard is empty. Copy a link or some text first."
                        else { AirShareHub.armOnline(ctx.applicationContext, emptyList(), item); msg = "Armed. Flick your open hand upward, or palm, fist, open." }
                    }
                },
                Modifier.fillMaxWidth(), filled = false, icon = IconKind.SHARE
            )
            AirButton("Cancel the armed drop", { AirShareHub.closeBlast(); msg = "Cancelled." }, Modifier.fillMaxWidth(), filled = false)
            if (msg.isNotEmpty()) Text(msg, style = MaterialTheme.typography.bodySmall, color = c.a2)

            AirButton(
                if (visible) "Visible on others' maps: ON" else "Visible on others' maps: OFF (you can still receive)",
                { visible = !visible; Prefs.onlineVisible = visible },
                Modifier.fillMaxWidth(), filled = visible
            )
            OutlinedTextField(
                value = name,
                onValueChange = { v -> name = v.take(20); Prefs.onlineName = name },
                label = { Text("Name others see (empty = phone model)") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
            if (android.os.Build.VERSION.SDK_INT >= 29) {
                AirButton(
                    "Location: allow all the time (so drops reach you in other apps)",
                    {
                        try {
                            ctx.startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + ctx.packageName)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                        } catch (_: Exception) {}
                    },
                    Modifier.fillMaxWidth(), filled = false
                )
            }
            Text(
                "Your location is shared only while this is ON and Visible is ON, and only with phones in the same area. Receiving works even when hidden.",
                style = MaterialTheme.typography.bodySmall, color = c.dim
            )
        }
    }
}
