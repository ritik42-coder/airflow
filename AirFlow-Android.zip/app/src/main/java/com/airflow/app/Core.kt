package com.airflow.app

import android.app.Application
import android.content.Context
import android.content.SharedPreferences
import kotlinx.coroutines.flow.MutableStateFlow

class AirFlowApp : Application() {
    override fun onCreate() {
        super.onCreate()
        Prefs.init(this)
    }
}

enum class Gesture(val title: String, val defaultAction: Action, val emoji: String, val how: String) {
    // Open-hand swipes (Auto = smart per app)
    SWIPE_UP("Swipe up", Action.AUTO, "🖐️",
        "Move your open hand UP in front of the camera. Shorts/Reels: next. Browser/other apps: scroll. Music/players: volume up. YouTube video: fullscreen."),
    SWIPE_DOWN("Swipe down", Action.AUTO, "🖐️",
        "Move your hand DOWN. Shorts/Reels: previous. Other apps: scroll back. Music/players: volume down. YouTube video: exit fullscreen."),
    SWIPE_LEFT("Swipe left", Action.AUTO, "🖐️",
        "Sweep your open hand LEFT. YouTube/players: rewind 10 s. Music: previous track. Other apps: swipe left."),
    SWIPE_RIGHT("Swipe right", Action.AUTO, "🖐️",
        "Sweep your open hand RIGHT. YouTube/players: forward 10 s. Music: next track. Other apps: swipe right."),

    // Holds (keep the pose still)
    PALM_HOLD("Open palm hold", Action.AUTO, "🖐️",
        "Keep an open palm completely still for about 1 second. Play / pause in any video or music app."),
    PINCH("Pinch", Action.AUTO, "🤏",
        "Touch your thumb tip to your index fingertip. Shorts, Reels, TikTok: next video (fast and easy). Music: next track. On a YouTube video: Like. In cursor mode a pinch is a mouse click."),
    FIST_HOLD("Fist hold", Action.BACK, "✊",
        "Make a fist and hold it still for about 1 second. Goes Back."),
    THUMB_UP_HOLD("Thumb up", Action.AUTO, "👍",
        "Thumb straight up, other fingers curled, hold still. Shorts, Reels, YouTube: Like. Everywhere else: volume up (keep holding to keep raising it)."),
    THUMB_DOWN_HOLD("Thumb down", Action.VOLUME_DOWN, "👎",
        "Thumb straight down, other fingers curled, hold still. Volume down. Keep holding to keep lowering it."),
    PEACE_HOLD("Peace sign hold", Action.SCREENSHOT, "✌️",
        "Index and middle finger up, others curled, hold still. Takes a screenshot."),
    POINT_HOLD("Point hold", Action.MUTE, "☝️",
        "Only your index finger up, hold still. Mutes / unmutes."),
    THREE_HOLD("Three fingers hold", Action.OPEN_CAMERA, "3️⃣",
        "Index, middle and ring finger up, hold still. Opens the camera."),
    ROCK_HOLD("Rock sign hold", Action.TOGGLE_CURSOR, "🤘",
        "Index and little finger up, middle and ring curled, hold still. Turns cursor mode (hand mouse) on or off."),
    CALL_HOLD("Call-me sign hold", Action.OPEN_YOUTUBE, "🤙",
        "Thumb and little finger out, other fingers curled, hold still. Opens YouTube. Change it to any app in Settings."),

    // Fist swipes = whole-phone navigation
    FIST_SWIPE_UP("Fist swipe up", Action.HOME, "✊",
        "Make a fist and flick it UP. Goes Home."),
    FIST_SWIPE_DOWN("Fist swipe down", Action.NOTIFICATIONS, "✊",
        "Make a fist and flick it DOWN. Pulls down the notifications."),
    FIST_SWIPE_LEFT("Fist swipe left", Action.BACK, "✊",
        "Make a fist and flick it LEFT. Goes Back."),
    FIST_SWIPE_RIGHT("Fist swipe right", Action.RECENTS, "✊",
        "Make a fist and flick it RIGHT. Opens recent apps.");

    val isSwipe: Boolean get() = name.contains("SWIPE")
}

/** What this gesture currently does (the user's choice, or the default). */
val Gesture.action: String get() = Prefs.actionFor(this).label

object AirFlowState {
    val running = MutableStateFlow(false)
    val handVisible = MutableStateFlow(false)
    val lastGesture = MutableStateFlow("")
    val error = MutableStateFlow<String?>(null)
    /** True while the on-screen hand cursor (mouse mode) is active. */
    val cursorMode = MutableStateFlow(false)
    /** App theme: 0 = follow system, 1 = light, 2 = dark. */
    val themeMode = MutableStateFlow(0)
}

object Prefs {
    private lateinit var sp: SharedPreferences

    fun init(ctx: Context) {
        if (!::sp.isInitialized) {
            sp = ctx.applicationContext.getSharedPreferences("airflow", Context.MODE_PRIVATE)
        }
    }

    /** Use the GPU hand model when the phone allows it. */
    var gpuHands: Boolean
        get() = sp.getBoolean("gpuHands", true)
        set(v) = sp.edit().putBoolean("gpuHands", v).apply()

    /** 0 = not tried, 1 = being tried right now (still 1 after a restart means it crashed), 2 = works, 3 = do not use. */
    var gpuState: Int
        get() = sp.getInt("gpuState", 0)
        set(v) { sp.edit().putInt("gpuState", v).commit() }

    /** The live "dynamic island" that shows the detected hand and gesture over other apps. */
    var island: Boolean
        get() = sp.getBoolean("island", true)
        set(v) = sp.edit().putBoolean("island", v).apply()

    /** The last Quick Drops received, as a JSON array. */
    var quickHistory: String
        get() = sp.getString("quickHistory", "[]") ?: "[]"
        set(v) = sp.edit().putString("quickHistory", v).apply()

    /** Put a received Quick Drop on this phone's clipboard automatically. */
    var quickAutoCopy: Boolean
        get() = sp.getBoolean("quickAutoCopy", false)
        set(v) = sp.edit().putBoolean("quickAutoCopy", v).apply()

    /** Air Blast: this phone listens for blasts from a nearby sender (it still asks before taking anything). */
    var blastReceive: Boolean
        get() = sp.getBoolean("blastReceive", false)
        set(v) = sp.edit().putBoolean("blastReceive", v).apply()

    /** Air Blast class code. Sender and listeners must match; empty means an open room. */
    var blastCode: String
        get() = sp.getString("blastCode", "") ?: ""
        set(v) = sp.edit().putString("blastCode", v.trim().take(8)).apply()

    /** Air Grab: a held fist over any app captures the screen. */
    var airGrab: Boolean
        get() = sp.getBoolean("airGrab", false)
        set(v) = sp.edit().putBoolean("airGrab", v).apply()

    /** What Air Grab captures: "shot" (a screenshot) or "text" (the text on screen). */
    var grabMode: String
        get() = sp.getString("grabMode", "shot") ?: "shot"
        set(v) = sp.edit().putString("grabMode", v).apply()

    /** How Tap Share looks when sending: "classic" (the chip slides across by itself) or "drag" (Samsung style, you drag it). */
    var tapStyle: String
        get() = sp.getString("tapStyle", "classic") ?: "classic"
        set(v) = sp.edit().putString("tapStyle", v).apply()

    /** How light a touch counts as "two phones tapped": 8 normal, 11 high, 13 maximum. */
    var tapSens: Int
        get() = sp.getInt("tapSens", 11)
        set(v) = sp.edit().putInt("tapSens", v).apply()
    var sensitivity: Float
        get() = sp.getFloat("sens", 1.0f)
        set(v) = sp.edit().putFloat("sens", v).apply()
    var cooldownMs: Int
        get() = sp.getInt("cooldown", 450)
        set(v) = sp.edit().putInt("cooldown", v).apply()
    var fps: Int
        get() = sp.getInt("fps", 20)
        set(v) = sp.edit().putInt("fps", v).apply()
    var autoStopMin: Int
        get() = sp.getInt("autostop", 0)
        set(v) = sp.edit().putInt("autostop", v).apply()
    var invertSwipe: Boolean
        get() = sp.getBoolean("invert", false)
        set(v) = sp.edit().putBoolean("invert", v).apply()
    var swipeEnabled: Boolean
        get() = sp.getBoolean("swipe", true)
        set(v) = sp.edit().putBoolean("swipe", v).apply()
    var onlyVideoApps: Boolean
        get() = sp.getBoolean("videoOnly", false)
        set(v) = sp.edit().putBoolean("videoOnly", v).apply()

    var haptic: Boolean
        get() = sp.getBoolean("haptic", true)
        set(v) = sp.edit().putBoolean("haptic", v).apply()
    /** Multiplier for how long a pose must be held: lower = faster. */
    var holdScale: Float
        get() = sp.getFloat("holdScale", 1.0f)
        set(v) = sp.edit().putFloat("holdScale", v).apply()

    /** How much of the camera view maps to the whole screen in cursor mode (smaller = more sensitive). */
    var cursorRange: Float
        get() = sp.getFloat("cursorRange", 0.7f)
        set(v) = sp.edit().putFloat("cursorRange", v).apply()

    /** Cursor smoothness 0..1 (1 = ultra smooth). */
    var cursorSmooth: Float
        get() = sp.getFloat("cursorSmooth", 0.65f)
        set(v) = sp.edit().putFloat("cursorSmooth", v).apply()
    /** Hover-to-tap: keep the cursor still and it taps by itself. */
    var dwellClick: Boolean
        get() = sp.getBoolean("dwell", false)
        set(v) = sp.edit().putBoolean("dwell", v).apply()

    var themeMode: Int
        get() = sp.getInt("theme", 0)
        set(v) = sp.edit().putInt("theme", v).apply()

    var fbUrl: String
        get() = sp.getString("fbUrl", "") ?: ""
        set(v) = sp.edit().putString("fbUrl", v).apply()
    var sbUrl: String
        get() = sp.getString("sbUrl", "") ?: ""
        set(v) = sp.edit().putString("sbUrl", v).apply()
    var sbKey: String
        get() = sp.getString("sbKey", "") ?: ""
        set(v) = sp.edit().putString("sbKey", v).apply()
    var sbBucket: String
        get() = sp.getString("sbBucket", "airflow") ?: "airflow"
        set(v) = sp.edit().putString("sbBucket", v).apply()

    // ---- Air Music ------------------------------------------------------------------
    var musicInstrument: Int
        get() = sp.getInt("musicInst", 0)
        set(v) = sp.edit().putInt("musicInst", v).apply()
    var musicVolume: Float
        get() = sp.getFloat("musicVol", 0.85f)
        set(v) = sp.edit().putFloat("musicVol", v).apply()
    var musicReverb: Float
        get() = sp.getFloat("musicRev", 0.35f)
        set(v) = sp.edit().putFloat("musicRev", v).apply()
    var musicOctave: Int
        get() = sp.getInt("musicOct", 4)
        set(v) = sp.edit().putInt("musicOct", v).apply()

    // ---- Air Typing: where the floating keyboard sits and how big it is ---------------
    var kbScale: Float
        get() = sp.getFloat("kbScale", 1f)
        set(v) = sp.edit().putFloat("kbScale", v).apply()
    var kbShiftX: Float
        get() = sp.getFloat("kbShiftX", 0f)
        set(v) = sp.edit().putFloat("kbShiftX", v).apply()
    var kbShiftY: Float
        get() = sp.getFloat("kbShiftY", 0f)
        set(v) = sp.edit().putFloat("kbShiftY", v).apply()

    fun fav(slot: Int): String? = sp.getString("fav$slot", null)
    fun setFav(slot: Int, pkg: String?) = sp.edit().putString("fav$slot", pkg).apply()

    fun actionFor(g: Gesture): Action {
        val s = sp.getString("act_${g.name}", null) ?: return g.defaultAction
        return try { Action.valueOf(s) } catch (_: Exception) { g.defaultAction }
    }
    fun setAction(g: Gesture, a: Action) = sp.edit().putString("act_${g.name}", a.name).apply()

    fun reset() = sp.edit().clear().apply()
}
