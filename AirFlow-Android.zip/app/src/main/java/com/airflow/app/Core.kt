package com.airflow.app

import android.app.Application
import android.content.Context
import android.content.SharedPreferences
import kotlinx.coroutines.flow.MutableStateFlow

class AirFlowApp : Application() {
    override fun onCreate() {
        super.onCreate()
        Prefs.init(this)
    }
}

enum class Gesture(val title: String, val action: String, val emoji: String, val how: String) {
    SWIPE_UP("Swipe up", "Next video / reel", "🖐️",
        "Move your hand UP in front of the camera (any hand shape). Then lower it slowly."),
    SWIPE_DOWN("Swipe down", "Previous video / reel", "🖐️",
        "Move your hand DOWN, or sweep it down out of view. Easy and quick."),
    SWIPE_LEFT("Swipe left", "Swipe left (stories, tabs)", "🖐️",
        "Open palm, sweep your hand LEFT in one quick motion."),
    SWIPE_RIGHT("Swipe right", "Swipe right (stories, tabs)", "🖐️",
        "Open palm, sweep your hand RIGHT in one quick motion."),
    PALM_HOLD("Open palm hold", "Play / pause", "🖐️",
        "Keep an open palm completely still for about 1 second."),
    PINCH("Pinch", "Like (double tap)", "🤏",
        "Touch your thumb tip to your index fingertip and keep the other fingers open."),
    FIST_HOLD("Fist hold", "Back", "✊",
        "Make a fist and hold it still for about 1 second.")
}

object AirFlowState {
    val running = MutableStateFlow(false)
    val handVisible = MutableStateFlow(false)
    val lastGesture = MutableStateFlow("")
    val error = MutableStateFlow<String?>(null)
}

object Prefs {
    private lateinit var sp: SharedPreferences

    fun init(ctx: Context) {
        if (!::sp.isInitialized) {
            sp = ctx.applicationContext.getSharedPreferences("airflow", Context.MODE_PRIVATE)
        }
    }

    var sensitivity: Float
        get() = sp.getFloat("sens", 1.0f)
        set(v) = sp.edit().putFloat("sens", v).apply()
    var cooldownMs: Int
        get() = sp.getInt("cooldown", 600)
        set(v) = sp.edit().putInt("cooldown", v).apply()
    var fps: Int
        get() = sp.getInt("fps", 20)
        set(v) = sp.edit().putInt("fps", v).apply()
    var autoStopMin: Int
        get() = sp.getInt("autostop", 0)
        set(v) = sp.edit().putInt("autostop", v).apply()
    var invertSwipe: Boolean
        get() = sp.getBoolean("invert", false)
        set(v) = sp.edit().putBoolean("invert", v).apply()
    var swipeEnabled: Boolean
        get() = sp.getBoolean("swipe", true)
        set(v) = sp.edit().putBoolean("swipe", v).apply()
    var palmHoldEnabled: Boolean
        get() = sp.getBoolean("palm", true)
        set(v) = sp.edit().putBoolean("palm", v).apply()
    var pinchEnabled: Boolean
        get() = sp.getBoolean("pinch", true)
        set(v) = sp.edit().putBoolean("pinch", v).apply()
    var fistEnabled: Boolean
        get() = sp.getBoolean("fist", true)
        set(v) = sp.edit().putBoolean("fist", v).apply()
    var onlyVideoApps: Boolean
        get() = sp.getBoolean("videoOnly", true)
        set(v) = sp.edit().putBoolean("videoOnly", v).apply()

    fun reset() = sp.edit().clear().apply()
}
