package com.airflow.app

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.PointF
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.inputmethod.InputMethodManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver

// ---------------------------------------------------------------------------------------------
// Air Typing: turn the system keyboard on, then practise right here.
// ---------------------------------------------------------------------------------------------

private fun imeEnabled(ctx: Context): Boolean {
    val imm = ctx.getSystemService(Context.INPUT_METHOD_SERVICE) as? InputMethodManager ?: return false
    return try {
        imm.enabledInputMethodList.any { it.packageName == ctx.packageName }
    } catch (e: Exception) {
        false
    }
}

private fun imeSelected(ctx: Context): Boolean {
    val imm = ctx.getSystemService(Context.INPUT_METHOD_SERVICE) as? InputMethodManager ?: return false
    return try {
        val current = Settings.Secure.getString(ctx.contentResolver, Settings.Secure.DEFAULT_INPUT_METHOD) ?: ""
        current.startsWith(ctx.packageName)
    } catch (e: Exception) {
        false
    }
}

@Composable
fun AirTypeScreen() {
    val ctx = LocalContext.current
    val owner = LocalLifecycleOwner.current
    val c = Air.c

    var text by remember { mutableStateOf("") }
    var tick by remember { mutableIntStateOf(0) }
    var camOk by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED
        )
    }
    val camLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {
        camOk = it
        tick++
    }
    val viewRef = remember { mutableStateOf<AirKeyboardView?>(null) }

    val sink = remember {
        object : TypeSink {
            override fun text(s: String) {
                text = text + s
            }

            override fun del() {
                if (text.isNotEmpty()) text = text.dropLast(1)
            }

            override fun enter() {
                text = "$text\n"
            }
        }
    }

    DisposableEffect(owner) {
        val obs = LifecycleEventObserver { _, e -> if (e == Lifecycle.Event.ON_RESUME) tick++ }
        owner.lifecycle.addObserver(obs)
        onDispose { owner.lifecycle.removeObserver(obs) }
    }

    // the practice keyboard uses the camera, so the background scroll service steps aside
    DisposableEffect(owner, camOk) {
        ctx.stopService(Intent(ctx, AirFlowService::class.java))
        if (!camOk) {
            onDispose { }
        } else {
            val main = Handler(Looper.getMainLooper())
            val controller = HandController(ctx, owner, needBitmap = true, maxHands = 2, minFps = 30) { r ->
                main.post {
                    viewRef.value?.onFrame(r.bitmap)
                    viewRef.value?.onHands(r.hands)
                }
            }
            controller.start()
            onDispose { controller.stop() }
        }
    }

    val enabled = remember(tick) { imeEnabled(ctx) }
    val selected = remember(tick) { imeSelected(ctx) }

    AirScroll {
        ScreenHeader("Air Typing", "Type in any app, with your hand")

        GlassCard(Modifier.fillMaxWidth()) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(
                        when {
                            selected -> "Air Keyboard is your keyboard"
                            enabled -> "Air Keyboard is on, but not selected"
                            else -> "Turn on the Air Keyboard"
                        },
                        style = MaterialTheme.typography.titleMedium, color = c.text
                    )
                    Text(
                        when {
                            selected -> "Open any app, tap a text field, and type in the air."
                            enabled -> "Pick \"Air Flow\" in the keyboard list."
                            else -> "Android settings › System › Languages & input › On-screen keyboard."
                        },
                        style = MaterialTheme.typography.bodySmall, color = c.dim
                    )
                }
                Spacer(Modifier.width(10.dp))
                PulseDot(if (selected) c.ok else if (enabled) c.warn else c.dim, selected)
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                AirButton(
                    "Enable", { ctx.startActivity(Intent(Settings.ACTION_INPUT_METHOD_SETTINGS)) },
                    Modifier.weight(1f), filled = !enabled
                )
                AirButton(
                    "Choose keyboard",
                    {
                        val imm = ctx.getSystemService(Context.INPUT_METHOD_SERVICE) as? InputMethodManager
                        imm?.showInputMethodPicker()
                    },
                    Modifier.weight(1f), filled = false
                )
            }
            if (!enabled) {
                Text(
                    "Enable it once, then switch to it with the keyboard icon that appears at the bottom of the screen.",
                    style = MaterialTheme.typography.bodySmall, color = c.warn
                )
            }
        }

        SectionCard("Practice") {
            Text(
                "This is the same keyboard you get in every app. Touch it, or hold your hand in front of the camera: " +
                    "the glowing dot is your fingertip and a pinch presses the key under it.",
                style = MaterialTheme.typography.bodySmall, color = c.dim
            )
            Box(
                Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(16.dp))
                    .background(c.glassHi)
                    .border(1.dp, c.stroke, RoundedCornerShape(16.dp))
                    .padding(14.dp)
            ) {
                Text(
                    if (text.isEmpty()) "Tap or pinch a key to type here…" else text,
                    color = if (text.isEmpty()) c.dim else c.text,
                    style = MaterialTheme.typography.titleMedium
                )
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                if (!camOk) {
                    AirButton("Allow camera", { camLauncher.launch(Manifest.permission.CAMERA) }, Modifier.weight(1f), icon = IconKind.SCAN)
                } else {
                    AirButton("Clear", { text = "" }, Modifier.weight(1f), filled = false)
                }
            }
            Box(
                Modifier
                    .fillMaxWidth()
                    .height(306.dp)
                    .clip(RoundedCornerShape(20.dp))
            ) {
                AndroidView(
                    factory = { ctx2 ->
                        AirKeyboardView(ctx2, sink).also { viewRef.value = it }
                    },
                    modifier = Modifier.fillMaxWidth().height(306.dp)
                )
            }
        }

        SectionCard("How it works") {
            Text(
                "The keyboard runs inside the app you are typing in, so nothing is sent anywhere. " +
                    "It needs the camera: if you deny it, the keyboard still types normally by touch.",
                style = MaterialTheme.typography.bodySmall, color = c.dim
            )
            Text(
                "Tip: some apps show their own keyboard first. Tap the small keyboard icon in the navigation bar " +
                    "to switch to Air Flow, or set it as the default keyboard in Android settings.",
                style = MaterialTheme.typography.bodySmall, color = c.dim
            )
        }
    }
}
