package com.airflow.app

import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Color as AColor
import android.graphics.pdf.PdfRenderer
import android.os.Build
import android.os.Environment
import android.os.ParcelFileDescriptor
import android.provider.MediaStore
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.io.File
import java.io.InputStream

// ---------------------------------------------------------------------------------------------
// Saving any file, with a fallback, and drawing a card for whatever it is
// ---------------------------------------------------------------------------------------------

object FileStore {

    /** Removes anything that would upset a file name or a MediaStore insert. */
    fun safeName(raw: String): String {
        val base = raw.substringAfterLast('/').substringAfterLast('\\')
        val cleaned = base.replace(Regex("[^A-Za-z0-9._ -]"), "_").trim()
        val name = cleaned.ifEmpty { "airflow_${System.currentTimeMillis()}" }
        return if (name.length > 96) name.takeLast(96) else name
    }

    fun isImage(name: String): Boolean {
        val n = name.lowercase()
        return n.endsWith(".jpg") || n.endsWith(".jpeg") || n.endsWith(".png") || n.endsWith(".webp") ||
            n.endsWith(".gif") || n.endsWith(".heic") || n.endsWith(".bmp")
    }

    fun mimeOf(name: String): String {
        val n = name.lowercase()
        return when {
            n.endsWith(".jpg") || n.endsWith(".jpeg") -> "image/jpeg"
            n.endsWith(".png") -> "image/png"
            n.endsWith(".webp") -> "image/webp"
            n.endsWith(".gif") -> "image/gif"
            n.endsWith(".heic") -> "image/heic"
            n.endsWith(".mp4") -> "video/mp4"
            n.endsWith(".mkv") -> "video/x-matroska"
            n.endsWith(".mp3") -> "audio/mpeg"
            n.endsWith(".m4a") -> "audio/mp4"
            n.endsWith(".wav") -> "audio/wav"
            n.endsWith(".pdf") -> "application/pdf"
            n.endsWith(".apk") -> "application/vnd.android.package-archive"
            n.endsWith(".zip") -> "application/zip"
            n.endsWith(".doc") || n.endsWith(".docx") -> "application/msword"
            n.endsWith(".xls") || n.endsWith(".xlsx") -> "application/vnd.ms-excel"
            n.endsWith(".ppt") || n.endsWith(".pptx") -> "application/vnd.ms-powerpoint"
            n.endsWith(".txt") -> "text/plain"
            n.endsWith(".html") || n.endsWith(".htm") -> "text/html"
            n.endsWith(".json") -> "application/json"
            n.endsWith(".vcf") -> "text/x-vcard"
            else -> "application/octet-stream"
        }
    }

    /**
     * Saves into the public gallery or Downloads. If MediaStore refuses for any reason, it falls
     * back to the app's own folder, so a received file is never lost.
     * Returns the place it landed, or null if even the fallback failed.
     */
    fun save(ctx: Context, rawName: String, input: InputStream, image: Boolean): String? {
        val name = safeName(rawName)
        val mime = mimeOf(name)
        // 1. public collection
        if (Build.VERSION.SDK_INT >= 29) {
            try {
                val collection = if (image) MediaStore.Images.Media.EXTERNAL_CONTENT_URI
                else MediaStore.Downloads.EXTERNAL_CONTENT_URI
                val v = ContentValues().apply {
                    put(MediaStore.MediaColumns.DISPLAY_NAME, name)
                    put(MediaStore.MediaColumns.MIME_TYPE, mime)
                    put(MediaStore.MediaColumns.RELATIVE_PATH, if (image) "Pictures/AirFlow" else "Downloads/AirFlow")
                    put(MediaStore.MediaColumns.IS_PENDING, 1)
                }
                val uri = ctx.contentResolver.insert(collection, v)
                if (uri != null) {
                    ctx.contentResolver.openOutputStream(uri)?.use { o -> input.copyTo(o) }
                    v.clear()
                    v.put(MediaStore.MediaColumns.IS_PENDING, 0)
                    ctx.contentResolver.update(uri, v, null, null)
                    return if (image) "Pictures/AirFlow" else "Downloads/AirFlow"
                }
            } catch (_: Exception) {
            }
        }
        // 2. the app's own external folder: always writable, no permission needed
        return try {
            val dir = File(
                ctx.getExternalFilesDir(if (image) Environment.DIRECTORY_PICTURES else Environment.DIRECTORY_DOWNLOADS),
                "AirFlow"
            )
            dir.mkdirs()
            val out = File(dir, name)
            out.outputStream().use { o -> input.copyTo(o) }
            if (out.length() > 0) "Android/data/${ctx.packageName}/files/${dir.name}/$name" else null
        } catch (_: Exception) {
            null
        }
    }
}

/** The first page of a PDF, drawn small, for the preview box. */
object PdfPreview {

    fun firstPage(file: File, maxWidth: Int = 1000): Bitmap? = try {
        if (!file.exists() || file.length() == 0L) null
        else {
            ParcelFileDescriptor.open(file, ParcelFileDescriptor.MODE_READ_ONLY).use { fd ->
                PdfRenderer(fd).use { renderer ->
                    if (renderer.pageCount <= 0) null
                    else {
                        renderer.openPage(0).use { page ->
                            val w = page.width.coerceAtLeast(1)
                            val h = page.height.coerceAtLeast(1)
                            val scale = maxWidth.toFloat() / w
                            val bmp = Bitmap.createBitmap(maxWidth, (h * scale).toInt().coerceAtLeast(1), Bitmap.Config.ARGB_8888)
                            bmp.eraseColor(AColor.WHITE)
                            page.render(bmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                            bmp
                        }
                    }
                }
            }
        }
    } catch (e: Exception) {
        null
    }
}

/** The three-letter badge for a file, and the colour that goes with it. */
fun fileBadge(name: String): String {
    val n = name.lowercase()
    val dot = n.lastIndexOf('.')
    if (dot < 0 || dot == n.length - 1) return "FILE"
    return n.substring(dot + 1).take(4).uppercase()
}

fun badgeColor(badge: String): Color = when (badge) {
    "PDF" -> Color(0xFFFF5A5A)
    "APK" -> Color(0xFF34F5A5)
    "ZIP", "RAR", "7Z" -> Color(0xFFFFA24A)
    "MP4", "MKV", "MOV", "AVI" -> Color(0xFF8B5CFF)
    "MP3", "M4A", "WAV" -> Color(0xFFFF4FD8)
    "JPG", "JPEG", "PNG", "WEBP", "GIF", "HEIC" -> Color(0xFF22D3EE)
    "DOC", "DOCX" -> Color(0xFF4F8BFF)
    "XLS", "XLSX" -> Color(0xFF0FB77E)
    "PPT", "PPTX" -> Color(0xFFFF8A4A)
    "HTML", "HTM", "JSON", "TXT" -> Color(0xFF9AA7CB)
    else -> Color(0xFF8B93A8)
}

/**
 * A file drawn as itself: a coloured badge with the extension, the name, and a bar for the size.
 * Used wherever a photo would normally be.
 */
@Composable
fun FileCard(
    name: String,
    bytes: Long,
    modifier: Modifier = Modifier,
    dark: Boolean = true,
    label: String? = null
) {
    val badge = fileBadge(name)
    val tint = badgeColor(badge)
    Column(
        modifier
            .clip(RoundedCornerShape(20.dp))
            .background(if (dark) Color(0xFF10182B) else Color(0xFFF3F6FF))
            .border(1.dp, tint.copy(alpha = 0.45f), RoundedCornerShape(20.dp))
            .padding(18.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        if (label != null) {
            Text(label, color = tint, fontSize = 10.sp, fontWeight = FontWeight.Black, letterSpacing = 2.sp)
            Spacer(Modifier.height(10.dp))
        }
        Box(
            Modifier
                .fillMaxWidth(0.62f)
                .height(96.dp)
                .clip(RoundedCornerShape(14.dp))
                .background(Brush.linearGradient(listOf(tint.copy(alpha = 0.28f), tint.copy(alpha = 0.08f))))
                .border(1.dp, tint.copy(alpha = 0.5f), RoundedCornerShape(14.dp)),
            contentAlignment = Alignment.Center
        ) {
            // a little sheet with a folded corner, drawn as paths
            Canvas(Modifier.fillMaxWidth().height(70.dp)) {
                val w = size.minDimension * 0.62f
                val h = w * 1.24f
                val left = (size.width - w) / 2f
                val top = (size.height - h) / 2f
                val fold = w * 0.30f
                val sheet = androidx.compose.ui.graphics.Path().apply {
                    moveTo(left, top)
                    lineTo(left + w - fold, top)
                    lineTo(left + w, top + fold)
                    lineTo(left + w, top + h)
                    lineTo(left, top + h)
                    close()
                }
                drawPath(sheet, Color.White.copy(alpha = 0.10f))
                drawPath(sheet, tint.copy(alpha = 0.85f), style = androidx.compose.ui.graphics.drawscope.Stroke(2f))
                val corner = androidx.compose.ui.graphics.Path().apply {
                    moveTo(left + w - fold, top)
                    lineTo(left + w - fold, top + fold)
                    lineTo(left + w, top + fold)
                }
                drawPath(corner, tint.copy(alpha = 0.85f), style = androidx.compose.ui.graphics.drawscope.Stroke(2f))
            }
            Text(
                badge,
                color = tint, fontSize = if (badge.length > 3) 20.sp else 26.sp,
                fontWeight = FontWeight.Black, letterSpacing = 1.sp
            )
        }
        Spacer(Modifier.height(12.dp))
        Text(
            name,
            color = if (dark) Color.White else Color(0xFF14172B),
            fontSize = 13.sp, fontWeight = FontWeight.Bold, maxLines = 2, textAlign = TextAlign.Center
        )
        if (bytes > 0) {
            Spacer(Modifier.height(4.dp))
            Text(TapFiles.human(bytes), color = Color(0xFF9AA7CB), fontSize = 11.sp)
        }
    }
}
