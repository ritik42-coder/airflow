package com.airflow.app

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.PointF
import android.os.Handler
import android.os.Looper
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.State
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush as BrushG
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke as DStroke
import androidx.compose.ui.graphics.drawscope.clipPath
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.layout.positionInRoot
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.sin
import kotlinx.coroutines.delay

// ---------------------------------------------------------------------------------------------
// Air Board: the teaching board. Draw, laser, erase and rotate a molecule, all with your hand.
// ---------------------------------------------------------------------------------------------

private class LPoint(val x: Float, val y: Float, var life: Float)

private class BoardState(private val ink: AirInk) {

    var brush: Brush = Brush.NEON
    var color: Int = InkPalette.colors[0]
    var width: Float = 16f
    var eraserWidth: Float = 90f
    var reg: AirReg? = null
    var shapeMode = false

    var fieldW = 0f
    var fieldH = 0f
    var colX = 0f
    var colY = 0f
    var boardRootX = 0f
    var boardRootY = 0f
    var boardW = 0f
    var boardH = 0f

    var cursorX = 0f
    var cursorY = 0f
    var visible = false
    var inBoard = false

    /** 0 draw, 1 laser, 2 erase, 3 grab, 4 paused */
    var mode = 0
    var penDown = false
    var penBrush: Brush = Brush.NEON
    private var suppressed = false
    private var sx = 0f
    private var sy = 0f
    private var palmStartX = 0f
    private var palmAt = 0L
    private var swiped = false

    val laser = ArrayList<LPoint>()
    var time = 0f
    var rotateX = 0f
    var rotateY = 0f
    var lastGrabX = 0f
    var lastGrabY = 0f
    var onSwipe: ((Int) -> Unit)? = null

    fun resetPen() {
        finishStroke()
        suppressed = false
        visible = false
    }

    /** Lifts the pen. With Shapes on, a wobbly stroke becomes a clean line, circle or box. */
    fun finishStroke() {
        if (!penDown) return
        ink.end()
        penDown = false
        if (!shapeMode || penBrush == Brush.ERASER) return
        val last = ink.snapshot().lastOrNull() ?: return
        val snapped = Shapes.snap(last.pts) ?: return
        ink.undo()
        val clean = Stroke(penBrush, last.color, last.width, last.seed)
        clean.pts.addAll(snapped)
        ink.addStroke(clean)
    }

    private fun fingers(lms: List<PointF>): Int {
        var n = 0
        // index, middle, ring, little: tip above its middle joint means extended
        for (tip in intArrayOf(8, 12, 16, 20)) {
            if (lms[tip].y < lms[tip - 2].y - 0.012f) n++
        }
        return n
    }

    fun onHands(lms: List<PointF>?) {
        if (lms == null || lms.size < 21 || fieldW < 8f) {
            resetPen()
            return
        }
        val tip = lms[8]
        val thumb = lms[4]
        val pinch = hypot(tip.x - thumb.x, tip.y - thumb.y) < 0.055f
        val count = fingers(lms)

        val nx = ((tip.x - 0.10f) / 0.80f).coerceIn(0f, 1f)
        val ny = ((tip.y - 0.10f) / 0.80f).coerceIn(0f, 1f)
        val left = boardRootX - colX
        val top = boardRootY - colY
        val tx = nx * fieldW
        val ty = if (ny <= 0.80f) {
            top + (ny / 0.80f).coerceIn(0f, 1f) * boardH
        } else {
            top + boardH + ((ny - 0.80f) / 0.20f).coerceIn(0f, 1f) * (fieldH - top - boardH).coerceAtLeast(0f)
        }
        if (!visible) {
            sx = tx
            sy = ty
            visible = true
        }
        sx += (tx - sx) * 0.45f
        sy += (ty - sy) * 0.45f
        cursorX = sx
        cursorY = sy
        inBoard = sx >= left && sx <= left + boardW && sy >= top && sy <= top + boardH

        mode = when {
            pinch -> 3
            count >= 4 -> 2
            count == 2 -> 1
            count == 1 -> 0
            else -> 4
        }

        // open palm swipe turns the page
        if (mode == 2) {
            if (palmAt == 0L) {
                palmStartX = nx
                palmAt = System.currentTimeMillis()
                swiped = false
            } else if (!swiped && System.currentTimeMillis() - palmAt < 900) {
                val dx = nx - palmStartX
                if (abs(dx) > 0.28f) {
                    swiped = true
                    onSwipe?.invoke(if (dx > 0) 1 else -1)
                }
            }
        } else {
            palmAt = 0L
            swiped = false
        }

        when (mode) {
            0 -> {
                if (!inBoard) {
                    finishStroke()
                    return
                }
                if (!penDown) {
                    ink.begin(sx - left, sy - top, brush, color, width)
                    penBrush = brush
                    penDown = true
                } else {
                    ink.extend(sx - left, sy - top)
                }
            }
            2 -> {
                if (inBoard && !penDown) {
                    ink.begin(sx - left, sy - top, Brush.ERASER, color, eraserWidth)
                    penBrush = Brush.ERASER
                    penDown = true
                } else if (penDown) {
                    ink.extend(sx - left, sy - top)
                }
            }
            1 -> {
                finishStroke()
                laser.add(LPoint(sx - left, sy - top, 1f))
                if (laser.size > 70) laser.removeAt(0)
            }
            3 -> {
                finishStroke()
                if (!suppressed && (lastGrabX != 0f || lastGrabY != 0f)) {
                    rotateY += (sx - lastGrabX) * 0.012f
                    rotateX += (sy - lastGrabY) * 0.012f
                    rotateX = rotateX.coerceIn(-1.4f, 1.4f)
                }
                lastGrabX = sx
                lastGrabY = sy
            }
            else -> finishStroke()
        }

        if (mode != 3) {
            lastGrabX = 0f
            lastGrabY = 0f
        }

        // in-air press of the dock
        if (pinch && !suppressed && !inBoard) {
            val hit = reg?.hit(colX + sx, colY + sy)
            if (hit != null) {
                reg?.actions?.get(hit)?.invoke()
                suppressed = true
            }
        }
        if (!pinch) suppressed = false
    }

    fun frame(dt: Float) {
        time += dt
        var i = 0
        while (i < laser.size) {
            val p = laser[i]
            p.life -= dt * 1.5f
            if (p.life <= 0f) laser.removeAt(i) else i++
        }
    }
}

@Composable
fun AirBoardScreen() {
    val ctx = LocalContext.current
    var camOk by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED
        )
    }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { camOk = it }
    if (camOk) {
        BoardStudio()
    } else {
        AirScroll {
            ScreenHeader("Air Board", "Teach, draw and rotate molecules in the air")
            SectionCard("Camera needed") {
                Text(
                    "The board follows your hand. Nothing is recorded and the video never leaves your phone.",
                    color = Air.c.dim
                )
                AirButton(
                    "Allow camera", { launcher.launch(Manifest.permission.CAMERA) },
                    Modifier.fillMaxWidth(), icon = IconKind.SCAN
                )
            }
        }
    }
}

@Composable
private fun BoardStudio() {
    val ctx = LocalContext.current
    val owner = LocalLifecycleOwner.current
    val c = Air.c
    val density = LocalDensity.current.density
    val topInset = WindowInsets.statusBars.asPaddingValues().calculateTopPadding()
    val bottomInset = WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding()

    val ink = remember { AirInk() }
    val reg = remember { AirReg() }
    val st = remember { BoardState(ink) }

    val pages = remember { ArrayList<ArrayList<Stroke>>() }
    if (pages.isEmpty()) pages.add(ArrayList())

    var pageIdx by remember { mutableIntStateOf(0) }
    var pageCount by remember { mutableIntStateOf(1) }
    var scene by remember { mutableStateOf(BoardScene.CAMERA) }
    var penStyle by remember { mutableIntStateOf(0) }
    var colorIdx by remember { mutableIntStateOf(0) }
    var shapeMode by remember { mutableStateOf(false) }
    var objIdx by remember { mutableIntStateOf(-1) }
    var objMode by remember { mutableStateOf(ObjMode.BALL) }
    var spin by remember { mutableStateOf(true) }
    var explode by remember { mutableFloatStateOf(0f) }
    var objScale by remember { mutableFloatStateOf(1f) }
    var sheet by remember { mutableStateOf(false) }
    var toast by remember { mutableStateOf<String?>(null) }
    var layerVersion by remember { mutableIntStateOf(0) }
    var canvasPx by remember { mutableStateOf(IntSize.Zero) }
    var modeLabel by remember { mutableIntStateOf(0) }
    var timerOn by remember { mutableStateOf(false) }
    var timerStart by remember { mutableFloatStateOf(0f) }
    var timerNow by remember { mutableFloatStateOf(0f) }
    var spot by remember { mutableStateOf(false) }
    val clock = remember { mutableFloatStateOf(0f) }
    val frameState = remember { mutableStateOf<Bitmap?>(null) }
    val lmsState = remember { mutableStateOf<List<PointF>?>(null) }

    val pens = listOf(Brush.NEON, Brush.MARKER, Brush.CHALK, Brush.RAINBOW)
    val pen = pens[penStyle.coerceIn(0, pens.size - 1)]

    val sceneColor = when (scene) {
        BoardScene.DARK -> Color(0xFF0A0D18)
        BoardScene.WHITE -> Color(0xFFFDFCFF)
        BoardScene.GRAPH -> Color(0xFFF7F9FF)
        BoardScene.CHALK -> Color(0xFF12241D)
        BoardScene.CAMERA -> Color(0xFF06070E)
    }
    val sceneArgb = when (scene) {
        BoardScene.DARK -> 0xFF0A0D18.toInt()
        BoardScene.WHITE -> 0xFFFDFCFF.toInt()
        BoardScene.GRAPH -> 0xFFF7F9FF.toInt()
        BoardScene.CHALK -> 0xFF12241D.toInt()
        BoardScene.CAMERA -> 0xFF06070E.toInt()
    }
    val onDark = scene == BoardScene.DARK || scene == BoardScene.CHALK || scene == BoardScene.CAMERA

    // ---- restore the last session -----------------------------------------------------------
    LaunchedEffect(Unit) {
        val saved = BoardStore.load(ctx)
        if (saved != null) {
            pages.clear()
            pages.addAll(saved.pages)
            pageIdx = saved.cur
            scene = BoardScene.values()[saved.scene.coerceIn(0, BoardScene.values().size - 1)]
            objIdx = if (saved.obj in Molecules.all.indices) saved.obj else -1
            pageCount = pages.size
            ink.adopt(pages[pageIdx])
            toast = "Last board restored"
        }
    }

    SideEffect {
        st.brush = pen
        st.color = InkPalette.colors[colorIdx.coerceIn(0, InkPalette.colors.size - 1)]
        st.width = floatArrayOf(10f, 18f, 30f)[1] * density * 0.8f
        st.shapeMode = shapeMode
        st.reg = reg
        st.onSwipe = { dir ->
            val next = (pageIdx + dir).coerceIn(0, pages.size - 1)
            if (next != pageIdx) {
                pages[pageIdx] = ink.snapshot()
                pageIdx = next
                ink.adopt(pages[next])
                toast = "Page ${next + 1}"
            }
        }
    }
    LaunchedEffect(Unit) {
        while (true) {
            delay(5000)
            pages[pageIdx] = ink.snapshot()
            BoardStore.save(ctx, pages, pageIdx, scene.ordinal, objIdx)
        }
    }
    DisposableEffect(Unit) {
        onDispose {
            pages[pageIdx] = ink.snapshot()
            BoardStore.save(ctx, pages, pageIdx, scene.ordinal, objIdx)
        }
    }
    LaunchedEffect(toast) {
        if (toast != null) {
            delay(1700)
            toast = null
        }
    }

    // ---- camera -----------------------------------------------------------------------------
    DisposableEffect(owner) {
        ctx.stopService(Intent(ctx, AirFlowService::class.java))
        val main = Handler(Looper.getMainLooper())
        val controller = HandController(ctx, owner, needBitmap = true, maxHands = 1, minFps = 30) { r ->
            main.post {
                frameState.value = r.bitmap
                lmsState.value = r.landmarks
                st.onHands(r.landmarks)
                if (st.mode != modeLabel) modeLabel = st.mode
            }
        }
        controller.start()
        onDispose {
            controller.stop()
            st.resetPen()
        }
    }
    DisposableEffect(owner) {
        val obs = LifecycleEventObserver { _, e -> if (e == Lifecycle.Event.ON_PAUSE) st.resetPen() }
        owner.lifecycle.addObserver(obs)
        onDispose { owner.lifecycle.removeObserver(obs) }
    }

    // ---- clock ------------------------------------------------------------------------------
    LaunchedEffect(Unit) {
        var last = 0L
        while (true) {
            withFrameNanos { now ->
                val dt = if (last == 0L) 0.016f else ((now - last) / 1000000000.0).toFloat().coerceIn(0.001f, 0.05f)
                last = now
                st.frame(dt)
                if (timerOn) timerNow += dt
                clock.floatValue += dt
            }
        }
    }

    val layerImg = remember(layerVersion) { ink.layer?.asImageBitmap() }
    val grid = remember(canvasPx) { boardGrid(canvasPx.width, canvasPx.height, scene) }

    // ---- layout -----------------------------------------------------------------------------
    Box(Modifier.fillMaxSize()) {
        Column(Modifier.fillMaxSize().padding(top = 52.dp + topInset, bottom = 78.dp + bottomInset)) {

            // top strip --------------------------------------------------------------------
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                LazyRow(horizontalArrangement = Arrangement.spacedBy(5.dp), modifier = Modifier.weight(1f)) {
                    items(BoardScene.values().toList()) { s ->
                        val sel = s == scene
                        Box(
                            Modifier
                                .clip(RoundedCornerShape(50))
                                .background(if (sel) BrushG.horizontalGradient(listOf(c.a1, c.a2)) else SolidColor(c.glass))
                                .border(1.dp, if (sel) Color.Transparent else c.stroke, RoundedCornerShape(50))
                                .airTarget(reg, "scene_${s.name}") { scene = s }
                                .pressClick(scaleTo = 0.94f) { scene = s }
                                .padding(horizontal = 10.dp, vertical = 5.dp)
                        ) {
                            Text(
                                s.label, color = if (sel) Color.White else c.dim, fontSize = 11.sp,
                                fontWeight = if (sel) FontWeight.Bold else FontWeight.Medium
                            )
                        }
                    }
                }
                Spacer(Modifier.width(6.dp))
                Box(
                    Modifier
                        .clip(RoundedCornerShape(50))
                        .background(c.glass)
                        .border(1.dp, c.stroke, RoundedCornerShape(50))
                        .airTarget(reg, "timer") {
                            timerOn = !timerOn
                            if (timerOn) timerNow = 0f
                        }
                        .pressClick { timerOn = !timerOn; if (timerOn) timerNow = 0f }
                        .padding(horizontal = 9.dp, vertical = 5.dp)
                ) {
                    Text(
                        if (timerOn) clockText(timerNow) else "Timer",
                        color = if (timerOn) c.ok else c.dim, fontSize = 11.sp, fontWeight = FontWeight.Bold
                    )
                }
            }

            // the board ----------------------------------------------------------------------
            Box(
                Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .padding(horizontal = 10.dp)
                    .clip(RoundedCornerShape(22.dp))
                    .background(sceneColor)
                    .border(
                        1.dp,
                        BrushG.linearGradient(
                            listOf(c.a2.copy(alpha = 0.40f), c.a1.copy(alpha = 0.15f), c.a3.copy(alpha = 0.40f))
                        ),
                        RoundedCornerShape(22.dp)
                    )
            ) {
                // live camera behind the board
                if (scene == BoardScene.CAMERA) {
                    CameraLayer(frameState, Modifier.fillMaxSize())
                    Box(
                        Modifier.fillMaxSize().background(
                            BrushG.verticalGradient(listOf(Color(0xB304050D), Color(0x9904050D), Color(0xE604050D)))
                        )
                    )
                }
                Canvas(
                    Modifier
                        .fillMaxSize()
                        .onSizeChanged { sz ->
                            canvasPx = sz
                            if (ink.resize(sz.width, sz.height)) layerVersion++
                        }
                        .onGloballyPositioned { co ->
                            st.boardRootX = co.positionInRoot().x
                            st.boardRootY = co.positionInRoot().y
                            st.boardW = co.size.width.toFloat()
                            st.boardH = co.size.height.toFloat()
                        }
                ) {
                    if (grid.isNotEmpty()) drawBoardGrid(grid, scene, c)
                    layerImg?.let { drawImage(it, Offset.Zero) }
                    if (objIdx >= 0) {
                        val m = Molecules.all[objIdx]
                        drawMolecule(
                            m, st.rotateX, st.rotateY + (if (spin) clock.floatValue * 0.5f else 0f),
                            size.minDimension * 0.16f * objScale, size.width * 0.62f, size.height * 0.42f,
                            objMode, explode, c
                        )
                    }
                    if (spot && st.visible) drawSpotlight(frameState.value, st.cursorX - (st.boardRootX - st.colX), st.cursorY - (st.boardRootY - st.colY), c)
                    drawLaser(st, c)
                }

                // status chips
                Row(Modifier.padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
                    Chip(modeName(modeLabel), when (modeLabel) {
                        0 -> c.a2
                        1 -> c.a3
                        2 -> c.warn
                        3 -> c.a1
                        else -> c.dim
                    })
                    Spacer(Modifier.width(6.dp))
                    if (objIdx >= 0) Chip(Molecules.all[objIdx].name, c.ok)
                }

                // page control
                Row(
                    Modifier.align(Alignment.BottomEnd).padding(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    MiniBtn("‹", c) { if (pageIdx > 0) { pages[pageIdx] = ink.snapshot(); pageIdx--; ink.adopt(pages[pageIdx]) } }
                    Text(
                        " ${pageIdx + 1}/${pages.size} ",
                        color = if (onDark) Color.White.copy(alpha = 0.85f) else c.text,
                        fontSize = 11.sp, fontWeight = FontWeight.Bold
                    )
                    MiniBtn("›", c) {
                        if (pageIdx < pages.size - 1) {
                            pages[pageIdx] = ink.snapshot()
                            pageIdx++
                            ink.adopt(pages[pageIdx])
                        }
                    }
                    Spacer(Modifier.width(6.dp))
                    MiniBtn("+", c) {
                        pages[pageIdx] = ink.snapshot()
                        pages.add(ArrayList())
                        pageIdx = pages.size - 1
                        pageCount = pages.size
                        ink.adopt(pages[pageIdx])
                        toast = "New page"
                    }
                }

                toast?.let {
                    Box(
                        Modifier
                            .align(Alignment.TopCenter)
                            .padding(top = 8.dp)
                            .clip(RoundedCornerShape(50))
                            .background(BrushG.horizontalGradient(listOf(c.a1, c.a2)))
                            .padding(horizontal = 16.dp, vertical = 7.dp)
                    ) { Text(it, color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold) }
                }
            }

            // dock ---------------------------------------------------------------------------
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 5.dp),
                horizontalArrangement = Arrangement.SpaceEvenly,
                verticalAlignment = Alignment.CenterVertically
            ) {
                BoardBtn("Pen", IconKind.DRAW, reg, "pen", pen.label) {
                    penStyle = (penStyle + 1) % pens.size
                    toast = pens[penStyle].label
                }
                BoardBtn("Colour", IconKind.SUN, reg, "col", "") {
                    colorIdx = (colorIdx + 1) % InkPalette.colors.size
                    toast = InkPalette.names[colorIdx]
                }
                BoardBtn("Shape", IconKind.BOLT, reg, "shape", if (shapeMode) "on" else "") {
                    shapeMode = !shapeMode
                    toast = if (shapeMode) "Shapes on: lines, circles, boxes" else "Shapes off"
                }
                BoardBtn("Spot", IconKind.SCAN, reg, "spot", if (spot) "on" else "") { spot = !spot }
                BoardBtn("Undo", IconKind.REPLAY, reg, "undo", "") { ink.undo() }
                BoardBtn("Redo", IconKind.PLAY, reg, "redo", "") { ink.redo() }
                BoardBtn("3D", IconKind.CUBE, reg, "obj", "") { sheet = !sheet }
                BoardBtn("Save", IconKind.SHARE, reg, "save", "") {
                    pages[pageIdx] = ink.snapshot()
                    BoardStore.save(ctx, pages, pageIdx, scene.ordinal, objIdx)
                    toast = if (ink.export(ctx, sceneArgb)) "Saved to Pictures/AirFlow" else "Could not save"
                }
            }
        }

        // cursor layer over everything ------------------------------------------------------
        Box(Modifier.fillMaxSize().padding(top = 52.dp + topInset, bottom = 78.dp + bottomInset)) {
            Canvas(
                Modifier
                    .fillMaxSize()
                    .onGloballyPositioned { co ->
                        st.colX = co.positionInRoot().x
                        st.colY = co.positionInRoot().y
                        st.fieldW = co.size.width.toFloat()
                        st.fieldH = co.size.height.toFloat()
                    }
            ) {
                drawBoardCursor(st, c, clock.floatValue)
            }
        }

        // 3D sheet --------------------------------------------------------------------------
        AnimatedVisibility(
            visible = sheet,
            enter = fadeIn(tween(180)),
            exit = fadeOut(tween(160)),
            modifier = Modifier.align(Alignment.BottomCenter).padding(horizontal = 12.dp, vertical = 150.dp)
        ) {
            GlassCard(Modifier.fillMaxWidth(), reveal = false) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Science objects", style = MaterialTheme.typography.titleMedium, color = c.text)
                    Spacer(Modifier.weight(1f))
                    Text(
                        "Close", color = c.a2, fontSize = 12.sp, fontWeight = FontWeight.Bold,
                        modifier = Modifier.pressClick { sheet = false }
                    )
                }
                Column(Modifier.fillMaxWidth().heightIn(max = 220.dp).verticalScroll(rememberScrollState())) {
                    Row(
                        Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp))
                            .pressClick { objIdx = -1; sheet = false }
                            .padding(vertical = 7.dp, horizontal = 6.dp)
                    ) {
                        Text("No object", color = if (objIdx < 0) c.a2 else c.text, fontWeight = FontWeight.Bold)
                    }
                    Molecules.all.forEachIndexed { i, m ->
                        Row(
                            Modifier.fillMaxWidth()
                                .clip(RoundedCornerShape(12.dp))
                                .background(if (i == objIdx) c.glassHi else Color.Transparent)
                                .pressClick {
                                    objIdx = i
                                    sheet = false
                                    toast = m.name
                                }
                                .padding(vertical = 7.dp, horizontal = 6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(m.name, color = if (i == objIdx) c.a2 else c.text, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                            Spacer(Modifier.width(8.dp))
                            Text(m.about, color = c.dim, fontSize = 10.sp)
                        }
                    }
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    ObjMode.values().forEach { m ->
                        val sel = m == objMode
                        Box(
                            Modifier
                                .clip(RoundedCornerShape(50))
                                .background(if (sel) BrushG.horizontalGradient(listOf(c.a1, c.a2)) else SolidColor(c.glass))
                                .pressClick { objMode = m }
                                .padding(horizontal = 8.dp, vertical = 5.dp)
                        ) {
                            Text(m.label, color = if (sel) Color.White else c.dim, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                        }
                        Spacer(Modifier.width(5.dp))
                    }
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Spin", color = c.dim, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.width(8.dp))
                    AirSwitch(checked = spin, onChange = { spin = it })
                    Spacer(Modifier.weight(1f))
                    Text("Explode", color = c.dim, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
                AirSlider(explode, { explode = it }, 0f..1f)
                Text("Size", color = c.dim, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                AirSlider(objScale, { objScale = it }, 0.5f..2f)
            }
        }
    }
}

private fun modeName(m: Int): String = when (m) {
    0 -> "DRAW"
    1 -> "LASER"
    2 -> "ERASE"
    3 -> "GRAB 3D"
    else -> "PAUSE"
}

private fun clockText(t: Float): String {
    val total = t.toInt()
    val m = total / 60
    val s = total % 60
    return "%d:%02d".format(m, s)
}

@Composable
private fun Chip(text: String, color: Color) {
    Box(
        Modifier
            .clip(RoundedCornerShape(50))
            .background(Color(0x66000000))
            .border(1.dp, color.copy(alpha = 0.5f), RoundedCornerShape(50))
            .padding(horizontal = 10.dp, vertical = 4.dp)
    ) {
        Text(text, color = color, fontSize = 10.sp, fontWeight = FontWeight.Black, letterSpacing = 1.sp)
    }
}

@Composable
private fun MiniBtn(label: String, c: AirColors, onClick: () -> Unit) {
    Box(
        Modifier
            .size(30.dp)
            .clip(CircleShape)
            .background(Color(0x66000000))
            .border(1.dp, c.stroke, CircleShape)
            .pressClick(scaleTo = 0.9f) { onClick() },
        contentAlignment = Alignment.Center
    ) { Text(label, color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.Black) }
}

@Composable
private fun BoardBtn(label: String, icon: IconKind, reg: AirReg, id: String, badge: String, onClick: () -> Unit) {
    val c = Air.c
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier
            .airTarget(reg, id, onClick)
            .pressClick(scaleTo = 0.9f) { onClick() }
            .padding(horizontal = 1.dp)
    ) {
        Box(
            Modifier
                .size(38.dp)
                .clip(CircleShape)
                .background(if (badge.isNotEmpty()) BrushG.linearGradient(listOf(c.a1, c.a2)) else SolidColor(c.glass))
                .border(1.dp, c.stroke, CircleShape),
            contentAlignment = Alignment.Center
        ) { AirIcon(icon, if (badge.isNotEmpty()) Color.White else c.text, Modifier.size(17.dp)) }
        Spacer(Modifier.height(2.dp))
        Text(
            if (badge.isNotEmpty() && badge != "on") badge else label,
            color = c.dim, fontSize = 8.sp, fontWeight = FontWeight.Medium, maxLines = 1
        )
    }
}

@Composable
private fun CameraLayer(frame: State<Bitmap?>, modifier: Modifier) {
    val bmp = frame.value
    if (bmp != null) {
        val img = remember(bmp) { bmp.asImageBitmap() }
        Image(img, null, modifier, contentScale = ContentScale.FillBounds)
    }
}

// ---------------------------------------------------------------------------------------------
// Board painting
// ---------------------------------------------------------------------------------------------

private fun boardGrid(w: Int, h: Int, scene: BoardScene): List<Offset> {
    if (scene != BoardScene.GRAPH || w <= 0 || h <= 0) return emptyList()
    val out = ArrayList<Offset>(400)
    val step = 30f
    var y = step
    while (y < h) {
        var x = step
        while (x < w) {
            out.add(Offset(x, y))
            x += step
        }
        y += step
    }
    return out
}

private fun DrawScope.drawBoardGrid(grid: List<Offset>, scene: BoardScene, c: AirColors) {
    if (grid.isEmpty()) return
    val col = Color(0xFF14172B).copy(alpha = 0.14f)
    drawPoints(grid, androidx.compose.ui.graphics.PointMode.Points, col, strokeWidth = 2.4f, cap = StrokeCap.Round)
    // axis lines for the graph paper
    drawLine(col.copy(alpha = 0.35f), Offset(0f, size.height / 2f), Offset(size.width, size.height / 2f), 1.5f)
    drawLine(col.copy(alpha = 0.35f), Offset(size.width / 2f, 0f), Offset(size.width / 2f, size.height), 1.5f)
}

private fun DrawScope.drawLaser(st: BoardState, c: AirColors) {
    if (st.laser.isEmpty()) return
    var i = 0
    while (i < st.laser.size) {
        val p = st.laser[i]
        val a = p.life.coerceIn(0f, 1f)
        drawCircle(c.a3.copy(alpha = 0.35f * a), 9f * a + 2f, Offset(p.x, p.y))
        drawCircle(Color.White.copy(alpha = 0.85f * a), 2.6f * a + 0.8f, Offset(p.x, p.y))
        i++
    }
}

private fun DrawScope.drawBoardCursor(st: BoardState, c: AirColors, time: Float) {
    if (!st.visible) return
    val o = Offset(st.cursorX, st.cursorY)
    val pulse = 0.5f + 0.5f * sin(time * 4.2f)
    val col = when (st.mode) {
        1 -> c.a3
        2 -> c.warn
        3 -> c.a1
        else -> c.a2
    }
    if (st.inBoard) {
        val r = if (st.mode == 2) st.eraserWidth / 2f else st.width / 2f
        drawCircle(col.copy(alpha = 0.10f + 0.08f * pulse), r, o)
        drawCircle(col.copy(alpha = 0.55f), r, o, style = DStroke(1.5f))
    }
    drawCircle(col.copy(alpha = 0.25f), 13f + 3f * pulse, o)
    drawCircle(Color.White.copy(alpha = 0.9f), 3.4f, o)
}

/** A magnifier that follows the fingertip, using the live camera picture. */
private fun DrawScope.drawSpotlight(frame: Bitmap?, x: Float, y: Float, c: AirColors) {
    if (frame == null) return
    val r = 84f
    val o = Offset(x, y)
    val path = Path().apply { addOval(androidx.compose.ui.geometry.Rect(o, r)) }
    clipPath(path) {
        val zoom = 2.2f
        val srcW = size.width / zoom
        val srcH = size.height / zoom
        drawImage(
            image = frame.asImageBitmap(),
            srcOffset = androidx.compose.ui.unit.IntOffset((x * zoom - srcW / 2f).toInt().coerceAtLeast(0), (y * zoom - srcH / 2f).toInt().coerceAtLeast(0)),
            srcSize = androidx.compose.ui.unit.IntSize(srcW.toInt().coerceAtLeast(1), srcH.toInt().coerceAtLeast(1)),
            dstOffset = androidx.compose.ui.unit.IntOffset((x - r).toInt(), (y - r).toInt()),
            dstSize = androidx.compose.ui.unit.IntSize((r * 2).toInt(), (r * 2).toInt())
        )
    }
    drawCircle(c.a2.copy(alpha = 0.9f), r, o, style = DStroke(3f))
    drawCircle(Color.White.copy(alpha = 0.35f), r - 4f, o, style = DStroke(1f))
}

/** Ball-and-stick, wireframe or space-fill, projected by hand — no 3D library needed. */
private fun DrawScope.drawMolecule(
    m: Molecule,
    ax: Float,
    ay: Float,
    scale: Float,
    cx: Float,
    cy: Float,
    mode: ObjMode,
    explode: Float,
    c: AirColors
) {
    val pts = m.project(ax, ay, explode)
    val n = pts.size
    if (n == 0) return
    val sx = FloatArray(n)
    val sy = FloatArray(n)
    val sr = FloatArray(n)
    val sz = FloatArray(n)
    for (i in 0 until n) {
        val p = pts[i]
        val persp = 8f / (8f + p.z * 0.8f)
        sx[i] = cx + p.x * scale * persp
        sy[i] = cy + p.y * scale * persp
        sr[i] = Elements.radius(p.el) * scale * persp
        sz[i] = p.z
    }

    if (mode != ObjMode.SPACE) {
        for (b in m.bonds) {
            if (b.a >= n || b.b >= n) continue
            val a1 = Offset(sx[b.a], sy[b.a])
            val a2 = Offset(sx[b.b], sy[b.b])
            val w = if (mode == ObjMode.WIRE) 1.4f else (scale * 0.09f).coerceIn(2f, 10f)
            drawLine(Color(0xFFC6D0EC).copy(alpha = 0.85f), a1, a2, strokeWidth = w, cap = StrokeCap.Round)
            if (b.order == 2) {
                val dx = a2.x - a1.x
                val dy = a2.y - a1.y
                val len = hypot(dx, dy).coerceAtLeast(0.001f)
                val ox = -dy / len * w * 1.5f
                val oy = dx / len * w * 1.5f
                drawLine(
                    Color(0xFFC6D0EC).copy(alpha = 0.7f),
                    Offset(a1.x + ox, a1.y + oy), Offset(a2.x + ox, a2.y + oy),
                    strokeWidth = w * 0.8f, cap = StrokeCap.Round
                )
            }
        }
    }

    val order = (0 until n).sortedBy { sz[it] }
    for (i in order) {
        val el = pts[i].el
        val col = Color(Elements.color(el))
        val r = if (mode == ObjMode.SPACE) {
            Elements.space(el) * scale * (8f / (8f + sz[i] * 0.8f))
        } else {
            sr[i]
        }
        val o = Offset(sx[i], sy[i])
        drawCircle(
            BrushG.radialGradient(
                listOf(col.copy(alpha = 1f), col.copy(alpha = 0.55f)),
                Offset(o.x - r * 0.35f, o.y - r * 0.4f), r * 1.5f
            ),
            r, o
        )
        drawCircle(Color.White.copy(alpha = 0.30f), r * 0.32f, Offset(o.x - r * 0.32f, o.y - r * 0.36f))
        drawCircle(col.copy(alpha = 0.22f), r, o, style = DStroke(1.4f))
    }
}
