# Air Flow

Native Android app (Kotlin + Jetpack Compose, no WebView). Scroll YouTube Shorts / Reels with hand gestures in the air.
Hand tracking: MediaPipe Hand Landmarker (on-device). Scrolling: Accessibility Service.

## Build the APK on GitHub
1. Create a new GitHub repo and upload ALL files from this ZIP (keep the `.github` folder).
   If `.github/workflows/build.yml` did not upload, use "Add file > Create new file", name it
   `.github/workflows/build.yml`, and paste the contents of `BUILD_WORKFLOW_COPY.yml`.
2. Open the **Actions** tab > **Build APK** > **Run workflow** (it also runs on every push).
3. When it finishes, open the run and download the **AirFlow-debug-apk** artifact (zip containing the APK).
4. Install the APK on your phone (allow "install unknown apps").

The workflow downloads the MediaPipe hand model automatically, so no model file is needed in the repo.

## First run on the phone
1. Open Air Flow, allow Camera and Notifications.
2. Accessibility: if the switch is greyed out (Android 13+), open App info > ⋮ > **Allow restricted settings**, then enable Air Flow.
3. Use the **Demo** tab to learn the gestures and the **Test** tab to practise with the live camera and a fake Shorts feed.
4. Press **Start** on Home, then open YouTube Shorts.

## Gestures (v1.2)
Works in **every app**. Every gesture can be remapped or switched off in Settings.
"Auto" actions are smart and change with the app that is open.

| Gesture | Auto / default action |
|---|---|
| Pinch | Shorts, Reels, TikTok: **next video**. Music: next track. YouTube video: Like. Cursor mode: click |
| Swipe up / down (open hand) | Shorts/Reels: next / previous. YouTube video: fullscreen / exit. Players & music: volume. Browser & others: scroll page |
| Swipe left / right (open hand) | YouTube video & players: rewind / forward 10 s. Music: previous / next track. Others: sideways swipe |
| Open palm hold | Play / pause |
| Thumb up hold | Like in Shorts/Reels/YouTube, otherwise volume up (repeats while held) |
| Thumb down hold | Volume down (repeats while held) |
| Fist hold | Back |
| Peace sign hold | Screenshot |
| Point hold | Mute / unmute |
| Three fingers hold | Open camera |
| Call-me sign (thumb + little finger) hold | Open YouTube |
| Rock sign hold | **Cursor mode** on / off |
| Fist swipe up / down / left / right | Home / Notifications / Back / Recent apps |

## Cursor mode (hand mouse)
v1.3: runs the camera at 30+ FPS in cursor mode, uses a One-Euro filter plus display-rate interpolation for a very smooth
cursor (Settings > Cursor smoothness), a much more forgiving pinch, a generous tap tolerance, and an optional
"Hover to tap" mode (hold the cursor still ~1 s to tap).
Turn it on with the rock sign, the Cursor button on Home, or the "Cursor mode" button in the notification.
- Point with your index finger: an on-screen cursor follows your fingertip over any app.
- Quick pinch = tap. This opens apps from the home screen or app drawer, presses keyboard keys, etc.
- Pinch and hold still 0.6 s (cursor turns orange) then release = long-press.
- Pinch and move straight away, then release = scroll / swipe / drag.
- Orange hold, then move, then release = press-hold-drag (move icons, reorder lists).
- Fist hold or rock sign = exit. Fist swipes (Home, Back, Recents, Notifications) keep working inside cursor mode.

Open apps by gesture: choose favorite apps in Settings and give any gesture "Open favorite app 1/2/3".

Limits: Android blocks accessibility taps on secure screens (lock-screen PIN, some banking/payment screens, password
fields in some apps). Opening the camera app can stop the front camera that Air Flow uses on some phones.
Pose thresholds (thumb, peace, call-me ...) can be tuned in `GestureEngine.kt`.

## v2.0 — complete UI overhaul
- Cinematic 6 s intro (hand draws itself, pinches, swipes, morphs into the logo), tap to skip.
- New premium logo + adaptive launcher icon.
- Two distinct themes: **Aurora Night** (dark) and **Pearl Silk** (light), each with its own live animated background; toggle in the top bar or Settings → Appearance (System/Light/Dark).
- Glass UI, scroll-linked reveal animations, floating animated nav bar, power orb, gesture carousel.
- Interactive Tour: 18 animated lessons (9 gestures + 9 cursor-mode) with phone + camera view, step-by-step highlights, scrubber, play/pause.
- Live Test restyled with neon skeleton overlay and progress bar.

## v3.0 — Air Share (gesture photo transfer)
New **Share** tab. Grab a photo in the air on one phone and release it to another.

**Two gestures, one on each phone** (v8.1):
- **Sending phone:** ✋ open palm (hold 0.5 s = READY) → ✊ close fist = **CAPTURE and send**. The photo shrinks into a glowing orb and goes into the air.
- **Receiving phone:** ✊ make a fist → ✋ open your palm = **catch it**. Only then does the orb descend, land, turn back into the photo and save to Gallery > Pictures > AirFlow.

Nothing appears on the receiving phone until that catch gesture is made: a photo that arrives sits in the air as a
glowing orb at the top of the stage, and the screen says "A photo is in the air. Fist, then palm, to bring it down."
Both phones can send and receive once connected.

**The screen shows, live:** the camera with the hand skeleton, the pose it sees ("Open palm", "Fist"…), a 3-step tracker with hold progress bars,
and plain-language corrections ("Move closer", "Spread all 5 fingers", "Now close your fist"). "Watch animated demo" plays every step.

**Connect (two ways, same on both phones):**
1. Phone A: *Show my QR and code*. Phone B: *Scan the other phone's QR* (or type the 6-digit code).
2. Pick the same mode on both phones:
   * **Nearby (offline)**: Google Nearby Connections (Bluetooth + Wi-Fi Direct). No internet. Needs Google Play services and the Nearby permissions.
   * **Online**: Firebase Realtime Database carries the live signal, Supabase Storage carries the full-quality photo.

### Online setup (once, ~3 minutes)
Open Share > *Online setup* and paste the values. Nothing is hard-coded, and no `google-services.json` is needed (plain REST).

**Firebase** (required): Realtime Database > copy the URL (looks like `https://NAME-default-rtdb.firebaseio.com`). Rules:
```json
{ "rules": { "airflow": { "$room": { ".read": true, ".write": true } } } }
```
**Supabase** (optional, full quality): run in the SQL editor, then paste the project URL and anon key into the app.
```sql
insert into storage.buckets (id, name, public) values ('airflow','airflow',true) on conflict do nothing;
create policy "airflow read"   on storage.objects for select to anon using (bucket_id = 'airflow');
create policy "airflow insert" on storage.objects for insert to anon with check (bucket_id = 'airflow');
create policy "airflow update" on storage.objects for update to anon using (bucket_id = 'airflow');
```
Without Supabase the photo is sent as a 1280 px copy through Firebase. The pairing code is the private room name, so use a new code each session. These open rules are for personal use; add auth before sharing the app widely.

Note: while Share is open it uses the front camera, so the background scroll service is paused (same as the Test tab).

## v4.0 — Air Music (a Casio in the air, played with both hands)
New **Music** tab. Nothing is touched: your fingertips are the keys.

- **Both hands at once.** MediaPipe now tracks two hands in this tab, so ten fingertips can play ten notes together.
- **The touch plane.** A glowing line sits across the camera view. When a fingertip drops below it, the key under that finger sounds. The deeper you press past the line, the louder the note, and sliding sideways while below the line glides across the keys. Hovering above the line highlights the key you are about to play.
- **Six instruments, synthesised on the phone** — no samples, no assets, a few kilobytes of code: Casio Piano, E.Piano, Vibes, Organ, Synth, Marimba. 20-voice polyphony, FM/additive models with per-instrument envelopes, left hand panned slightly left and right hand slightly right, a hall reverb, and a soft limiter so a ten-finger chord compresses instead of clipping.
- **Premium visuals.** Neon skeleton for both hands, a beam of light from every playing fingertip down to its key, keys that light up with rings and sparks, note names floating up from your fingers, a light bloom that follows the music, and an equaliser driven by the real audio level.
- **Demo songs** — Air Flow theme, Für Elise, Ode to Joy, Twinkle Twinkle, Jingle Bells, Sargam — played automatically with both hands, with the keys lighting up in time.
- **Learn mode**: the next key glows and every correct hit is scored. **Sustain**, **octave shift** (±2 octaves), **volume** and **hall** sliders, all remembered between sessions.
- Audio: 44.1 kHz stereo, ~46 ms buffer. The camera runs at 30 FPS while this tab is open, and the background scroll service steps aside (the same as the Test and Share tabs).

## v5.0 — Air Draw (paint in the air)
New **Draw** tab. Pinch your thumb and index finger to put the pen down, move to draw, open your fingers to lift it. You can also run the whole toolbar in the air, so you never have to touch the phone.

- **Smooth ink.** The fingertip is smoothed with a weighted follow and every stroke is painted as quadratic curves, segment by segment, straight into one offscreen layer. A long drawing therefore stays silky, keeps undo/redo cheap, and never slows the 30 FPS camera down.
- **Five brushes**: **Neon** (coloured halo plus a white core), **Marker** (soft and wide, made for colouring in), **Rainbow** (hue cycles along the stroke), **Spray** (particles) and **Eraser**. Three brush sizes, ten premium colours, and two papers — deep night or bright white.
- **13 sample outlines to trace**: heart, star, house, cat, flower, butterfly, tree, rocket, apple, cloud, sun, fish and umbrella. They show as animated dashed guides with a live coverage meter, and finishing one celebrates.
- **In-air toolbar.** Pinch over a colour, a brush, undo, redo, sample, paper, save or clear. The fingertip cursor is drawn above the toolbar, so it can reach the buttons; touching them with a finger works too.
- **Save** flattens the drawing onto the paper colour and writes a PNG into Gallery › Pictures › AirFlow.
- Undo and redo replay the stroke list, so nothing is ever lost to a fast finger.

## v6.0 — Studio (music, drawing and a teaching board in one place)
The bottom bar stays short: the old **Music** and **Draw** tabs are now inside one premium **Studio** tab,
together with a brand new **Air Board**. Tap Studio to open the hub, tap a card to open a tool, tap Studio
again (or press Back, or the "‹ STUDIO" chip in the top bar) to come back.

### Air Board — the teaching board
Built natively from the AirBoard brief, on the same on-device hand tracking:

- **Scenes**: live camera, dark board, white board, graph paper and chalkboard. The graph paper is cached,
  so it costs one draw call per frame.
- **Gestures**: one finger draws, two fingers give a laser pointer with a fading trail, an open palm erases,
  a pinch grabs and rotates the 3D object, a pinch over the dock presses a button in the air, and an open
  palm swiped left or right turns the page.
- **Pens**: neon, highlighter, chalk and rainbow, with an adjustable eraser.
- **Shapes**: with Shapes on, a wobbly stroke becomes a clean line, circle or rectangle when you lift your hand.
- **Pages**: add, browse and keep several boards; each page keeps its own strokes.
- **Science objects**: methane, water, CO2, ammonia, benzene, ethanol, cyclohexane, a NaCl lattice, diamond,
  graphite and a DNA double helix. Ball-and-stick, wireframe and space-fill modes, auto-spin, an explode
  slider and a size slider. The 3D is projected by hand in Kotlin — no Three.js, no model files.
- **Classroom extras**: a timer overlay and a spotlight magnifier that follows your fingertip.
- **Nothing is lost**: every page, stroke, scene and object is written to a project file every five seconds
  and restored on the next launch. **Save** also exports the current page as a PNG into Gallery › Pictures › AirFlow.

### Not included (the brief was written for a browser)
Recording (MediaRecorder), PDF import, PWA offline caching, IndexedDB project manager, cloud sync,
voice-to-text and Hindi localisation are not part of this build. Everything above runs on the phone with
no internet, no accounts and no downloads.

## v7.0 — Air Typing (a keyboard for the whole phone)
New **Air Typing** card in Studio. This is a real Android keyboard (an InputMethodService), not an in-app
toy: once it is switched on, **every text field in every app** — WhatsApp, Chrome, YouTube search, your
notes — gets the air keyboard.

### Turn it on once
1. Studio › Air Typing › **Enable** → Android settings › System › Languages & input › On-screen keyboards →
   turn **Air Flow** on.
2. Tap **Choose keyboard** and pick **Air Flow**, or use the small keyboard icon that appears in the
   navigation bar whenever a text field is focused.

### Typing
- The keyboard shows a live camera preview in its top strip, with the hand skeleton and the fingertip dot.
- Move your hand: the glowing cursor travels over the keys and the key under it lights up.
- **Pinch** your thumb and index finger to press the highlighted key. One press per pinch, so holding the
  pinch never repeats a letter.
- Touch typing works at the same time, so you can switch between hand and thumb whenever you like.
- Letters, numbers and symbols, shift, backspace, enter (it respects the app's "search"/"send" action),
  a wide space bar and automatic capitals at the start of a sentence.

### Feel
Springy keys that lift and fill with the Aurora gradient, a haptic tick per key, a glowing cursor ring that
turns pink while pinched, and a status line that tells you when the hand is visible. The keyboard draws
itself on the platform canvas and repaints only while something is animating, so it stays smooth on a
mid-range phone.

### If the camera is off
The keyboard still works completely by touch. Grant the camera in Air Flow to type in the air.

Note: the keyboard and the background scroll service both want the camera. While a text field is open with
the air keyboard, stop the scroll service (the orb on Home) if the preview stays black.

## v8.0 — the floating keyboard (a slab of glass in the air)
The Air Keyboard is no longer a flat strip at the bottom of the screen. It is now a keyboard **floating in
the air in front of the camera**, and you type on it with your hand.

- **It looks like it is in space.** The camera fills the keyboard area, so you see your own hand behind the
  keys, and the whole keyboard is drawn through a perspective matrix: the top edge is narrower than the
  bottom, which is what your eye reads as depth. A soft edge light runs around the slab.
- **It moves with the world.** The accelerometer tilts the slab a few degrees as you tilt the phone, and
  skews it left and right, so it feels anchored in front of you instead of painted on the glass. No ARCore,
  no extra permissions, no cost — it works on every phone that runs the app.
- **Two hands resize and move it.** Hold both hands up and pinch them apart or together to scale the slab
  (62% to 112%), and move both hands to slide it around. The size and position are remembered for next time.
- **A magnified key follows your fingertip.** Your hand covers the key it is pressing, so the hovered key
  lifts into a bubble above your finger, exactly like a phone's pop-up key.
- **Typing.** The glowing cursor is your fingertip; the key under it lights up; a pinch presses it. Touch
  typing still works, and every hit is tested through the inverse of the perspective matrix, so what you
  point at is exactly what you press.
- **Status line** shows whether the hand is seen, whether you are in letters or numbers, and the current
  size, so you always know what the keyboard thinks is happening.

Turn it on once: Studio › Air Typing › Enable, then choose Air Flow as the keyboard. After that it is the
keyboard in every app.

## v9.0 — Tap Share (touch the two phones, everything flows across)
The Share tab now opens on **Tap share**; the old code-and-QR flow is still there behind the "Code & QR" switch.

**How it links.** Both phones advertise and discover at the same time. When you touch their top edges together,
each phone feels the same sharp acceleration spike along its long axis — that shared knock *is* the handshake.
The phone with the smaller device id dials, so the two never dial each other at once. No code, no QR, no menu.
If a tap does not take, "link manually" is one tap away.

**What it moves.** Anything: photos, video, audio, PDFs, APKs, zips, documents — the picker is `*/*` and the
transfer is a plain file stream, so size is not a problem. **Contacts** go as name plus number; the receiving
phone offers "Add … to contacts" and opens the phone's own new-contact screen prefilled. Images land in
Pictures/AirFlow, everything else in Downloads/AirFlow.

**The animation.** While the files move, both phones show the same full-screen scene: two phone outlines with a
beam between them, packets travelling along it, a big percentage, the live file name, the real byte count and
the real speed in MB/s — all driven by `PayloadTransferUpdate`, so what you see is the actual transfer, not a
timer. On the receiving phone the beam runs the other way. The waiting screen has breathing rings, a live bump
meter so you can see the sensor is awake, and a spark at the contact point when the tap lands.

Notes:
- Both phones need Air Flow open on the Share tab: the sensor and Nearby both live there.
- Android needs Bluetooth and Wi-Fi (or a hotspot) available; no internet, no account, nothing uploaded.
- Reading a contact needs the Contacts permission, asked for the first time you pick one.

## v9.1 — Tap Share actually transfers (and any file type)
This release fixes three real bugs that made Tap Share look broken on a phone.

**1. It never started.** The screenshot from the device said it plainly: `8034: MISSING_PERMISSION_ACCESS_COARSE_LOCATION`.
Nearby Connections refuses to advertise or discover without coarse location on every Android version, but the manifest
capped that permission at `maxSdkVersion="30"`, so on Android 12 the permission did not exist at all. The manifest now
declares coarse and fine location for every version, the permission list always asks for coarse, and the Tap Share
screen asks for the whole set the first time it opens, with an "Allow" card and a readable explanation if you say no.

**2. Files never arrived.** The old build sent files as Nearby "file payloads" and then tried to guess the name and
read the payload back on the other side; when that guess failed, nothing was written and the sender still said "sent".
The pipe is rewritten: the sender reads its own file in 128 KB chunks and pushes them as BYTES payloads with a 7-byte
header (type, file index, chunk index), three chunks in flight at a time, the next one sent on each ack. The receiver
writes each chunk straight to a temp file and, at the end, copies it into **Pictures/AirFlow** (images, so the gallery
shows them) or **Downloads/AirFlow** (everything else) under the exact name the sender used. Progress on both phones is
the real byte count, so the beam moves at the real speed.

**3. Air Share was photo-only.** The code-and-QR tab now picks `*/*`: photos, video, audio, PDF, zip, APK. Photos keep
the old preview and the Firebase path; other files travel over Nearby and land in Downloads/AirFlow. The online
(Firebase) mode still carries photos only and says so instead of failing silently.

Also fixed: the Tap share / Code & QR switch no longer sits on top of the app title, and copying a large file to the
cache happens off the main thread so the animation stays smooth.

## v9.2 — the orb belongs to the hand that made it
Air Share no longer sends the photo the moment you close your fist. The photo becomes an orb that stays
**in the hand that captured it**, and only that hand can put it down.

**How it works.** Close your fist (capture) → the orb forms and starts a 20 second countdown, shown on the
status line ("In your hand · 14s") → open your hand to put it down on the other phone. The other phone
catches it with its own fist-then-palm gesture, as before.

**Who can put it down.** The orb is bound to the hand at the moment of capture: its position and its palm
size. Every camera frame after that is checked, and the orb is destroyed the moment any of these happen:

- the hand leaves the frame for more than 0.35 s — you put your hand down, so the orb is gone;
- a different hand takes over — the palm suddenly measures more than 28% different, or the hand jumps
  further across the frame than a hand can move in one frame;
- 20 seconds pass.

When that happens the screen says exactly why ("The orb left your hand", "Another hand took it", "You held
it too long") and you capture again. Nobody else can pick it up, because picking it up means the original
hand had already left. No face model, no fingerprint, no internet — just the hand tracking that was already
running, plus a timer.

Slow movement and fast sweeps are deliberately allowed: the guard follows the hand rather than pinning it,
so normal air gestures never void the orb.

## v9.3 — the hold timer reads correctly
The 20 seconds in Air Share is a **deadline, not a wait**: open your hand whenever you like and the orb goes
immediately (the release fires after about 0.2 s of an open palm). The countdown is only how long the orb
survives in your hand before it fades. The status line now says so — "Holding it. Open your hand any time —
it fades in 20s" — instead of the old wording that made it look like you had to wait.

## v9.4 — a hand leaving the frame no longer sends the photo
Real bug, found from a screen recording: as the hand slid out of the picture, the pose classifier read it as an
open palm, and the third step fired — so taking your hand away *released* the orb instead of destroying it,
which is the opposite of what the hold guard is for.

Fix: a gesture only counts when **all 21 hand points are comfortably inside the picture** (4% margin on every
edge). While the hand is half out of frame the pose is fed to the tracker as "no pose", so it cannot start a
palm hold, cannot complete a fist, and cannot release. The hand leaving now does what it should: after 0.35 s
the orb is void and the screen says "The orb left your hand."

Also fixed: the Code & QR screen now starts below the Tap share / Code & QR switch instead of under it.

## v9.5 — any picked file now works with the gestures
Picking a PDF or a video in Air Share and then doing the palm → fist gesture answered "Pick a photo first". The
whole gesture flow was still gated on "is there a photo bitmap", and a non-image file has no bitmap, so the
capture was refused and the coaching text kept telling you to pick a photo.

Now the flow is gated on "is a file ready", whatever its type. The stage shows a FILE card with the name instead
of an empty photo box, the coaching says "pick a photo or a file", and the section is titled "1 · Choose photo or
file". On the receiving phone a non-image lands as a "RECEIVED FILE" card and is saved to Downloads/AirFlow.

## v9.6 — saving always works, real previews, and the permission trap
Three fixes.

**1. "Received, but could not save".** Every save now goes through one place that tries the public gallery
(Pictures/AirFlow) or Downloads/AirFlow first, and if MediaStore refuses for any reason — bad name, odd OEM
behaviour, a pending row — it falls back to the app's own folder instead of giving up. File names are sanitised
(path separators and odd characters stripped) before they reach MediaStore. Photos use the same fallback, so a
received photo can no longer be lost.

**2. The stage shows what you actually picked.** A photo shows the photo. A **PDF shows its first page**, rendered
with Android's own `PdfRenderer` — no library, no permission. Anything else shows a designed card: a coloured
badge with the extension (APK green, ZIP orange, MP4 violet, DOC blue…), a little document icon with a folded
corner, the file name and its size. The same card appears on the receiving phone as "RECEIVED FILE".

**3. The location permission trap.** Nearby refuses to start without Location (error 8034), and Android stops
showing the permission dialog after two denials — which is why Android 12 asked once and Android 13+ never asked
again while both kept failing. Both the Tap Share and Code & QR screens now name exactly what is missing
("Missing: Location, Nearby devices"), offer **Allow** and **App settings** side by side, and re-check the
permission when you come back from settings so the screen recovers instead of staying stuck.

## v10.0 — Air Games: three hand-controlled games
A new **Air Games** card in Studio, with three different games inside. No controller, no internet, no ads.

**1 · Air Slash — one player.** Fruit arcs up from the bottom and your fingertip is the blade. Move fast
through a fruit to slice it: +10 and a combo multiplier. Bombs come up too, and slicing one costs a life, so
you have to look before you swing. Three lives, the spawn rate climbs the longer you survive, and the trail
behind your fingertip is drawn as neon. Both hands work, so you can play with two blades.

**2 · Air Pong — 1 vs 1 on one phone.** Two players share the camera: your hand's height steers your paddle,
the left hand plays the left side, the right hand the right side. First to 5. The ball speeds up on every
return and picks up spin from where it hits the paddle.

**3 · Air Tug — 1 vs 1 on two phones, offline.** Touch the two phones together (the same bump handshake as Tap
Share) and they link over Nearby — no internet, no hotspot, no account. The rope sits between you: reach your
hand out to your side to pull it your way. The phone with the smaller id is the host and owns the rope, so the
two screens can never disagree; it sends the knot position twelve times a second and the guest sends its pull.
First to drag the knot to their end wins.

All three run on the hand tracking that is already in the app, draw on a single Canvas at the frame rate, and
use no bitmaps — so they stay smooth on a mid-range phone.


## v10.1 — Share fixes
- **Location:** "Approximate" location now counts (Android 12+ often grants only that), the permission card clears as soon as
  you allow it, and a separate card appears when the phone-wide Location switch is OFF (Nearby needs both).
- **Files not arriving / not saving:** Tap Share sent 128 KB chunks but Nearby refuses BYTES payloads over 32 KB, so the sender
  said "sent" and nothing arrived. Chunks are now 30 KB and are written at their own offset on the receiver. Air Share (code/QR)
  never sent the file name, so photos were saved as `.bin`; the name now travels first. Non-photo files were also rejected by
  Android 10+ because the folder was `Downloads/AirFlow` (must be `Download/AirFlow`).
- **Receiver box:** every received photo, PDF page and file shows as a tile you can tap to open. Pick several files at once and
  one palm → fist → open gesture sends them all.

## v11.0 — Air Share anywhere
Send and receive from any app, not just inside Air Flow.
- **Send:** in Gallery, WhatsApp or Files tap Share > **Air Flow**. Show an open palm, close a fist (the photo becomes a glowing
  orb in your hand), open your hand (the orb launches to the other phone). Many photos at once work too.
- **Receive:** on the **Share > Anywhere** tab turn Air Share ON. The orb drops in over whatever app is open; make a fist, then
  open your hand and the photo blooms out of it. Files are already saved in Gallery > AirFlow.
- **Setup** (Anywhere tab shows a checklist): camera, Nearby + Location (and the Location switch), and either the Accessibility
  service or "Display over other apps" so the animation can draw above other apps. "Preview the animation" plays the whole story
  on a sample picture without a second phone.
- Code: `AirShareHub` (flow + link), `AirShareOverlay` (all animation), `ShareTargetActivity` (share sheet), `AirShareScreen` (UI).
  The camera frames come from `AirFlowService`, so there is still one camera user; while Air Share is busy the normal gestures pause.

## v11.1 — Tap Share, premium
- **More sensitive touch:** default sensitivity is now High (Normal / High / Max on the Anywhere tab), the accelerometer is sampled at
  the fastest rate Android allows, and a sharp jump counts as well as a big spike. A light touch of two phones is enough.
  Safety: a "touch" connection is only accepted by the other phone if it felt a knock of its own at the same moment.
- **iOS-style connect:** ripples roll down from the touch point at the top edge, two orbs slide together and merge into one link,
  a ring spins while linking and turns into a check mark.
- **The photo chip crosses between the phones:** at 50% half the chip is off the top of the sender while the other half is in from
  the top of the receiver (the photo preview travels with the offer, so the receiver shows the real picture from the first byte).
  Progress counts bytes the receiver has really got, so both screens show the same percentage. When it lands, the chip blooms into the photo.
- **From anywhere:** Quick Settings tiles **Air Share** (hands + touch) and **Tap Share** (touch only, no camera) switch it on and off
  without opening the app; the Anywhere tab has "Add to Quick Settings" buttons. Share a photo to Air Flow from any app, then touch the phones.
- Same animation runs in the Tap tab (inside the app) and as an overlay over other apps.

## v11.2 — Samsung-style Tap Share
Choose **Default** or **Samsung style** (Tap tab, and Anywhere tab for sharing from any app).
- After the phones touch, your photo waits on screen over a frosted, animated blur (real background blur on Android 12+) with
  drifting light and dust particles. **Drag it up and off the top edge.** Your finger drives the other phone live: the part that left
  your screen appears on theirs, with different particle streams (cool upward streaks when sending, warm sparks raining down when receiving).
- Let go past halfway (or flick fast) and it is sent: the other phone's chip drops to the centre with a bounce, particles converge, a ring
  fills with the real percentage, then it blooms into the photo. Let go early and it slides back on both phones.
- The receiver can **pull it down** to take it, or **push it back up** to give it back. A fast flick lands it instantly.
- Nothing is sent until the drop; the receiver sees a small preview first. Works inside the app and over other apps (Quick Settings tiles).
- Code: `AirShareOverlay.sceneDrag`, drag messages in `TapLink` (peek / pos / commit / cancel), `AirShareHub.startDragSend`.

## v12.0 — Quick Drop
Links, text, YouTube videos and the clipboard, sent in one tiny message (no offer, no chunks), so it lands almost instantly.
- **Send:** share any link or text to **Air Flow** from any app (YouTube, Chrome, Notes, WhatsApp...), or use the **Send clipboard**
  Quick Settings tile, or the "Send what I copied" button on the Anywhere tab. Then touch the tops of the phones together.
- **YouTube:** the sender fetches the title and thumbnail and sends them along, so the receiver gets a ready video card even offline.
  Links keep their timestamp. Buttons: Play (opens the YouTube app), Copy, Close. Links: Open, Copy, Close. Text: Copy, Close.
- **The magic:** sending = a rune circle unfurls under the card, a wand of light sweeps across it and every letter lifts off and ribbons
  up through the top edge in a trail of stardust. Receiving = stardust spirals down into a vortex, the letters swirl in and re-form,
  the card materialises with a shockwave, rings and a burst of light, over a slowly turning magic circle with twinkling stars.
  Link / text / YouTube each have their own colours.
- **Safe:** nothing opens by itself; the receiver taps Open. Last 10 drops are kept under Recent drops (Anywhere tab). Optional auto-copy.
- Code: `QuickDrop.kt`, `AirShareOverlay.sceneQd*`, `TapLink.sendQuick`, `AirShareHub.startQuickSend / receiveQuick`.

## v12.1 — builds that update in place
The APK is now signed with one fixed key (`app/airflow-debug.keystore`) and the version number rises with every GitHub run.
After ONE last uninstall (the old APKs were signed with random keys) every later build installs straight over the previous one:
no "package conflict", and permissions (Accessibility, overlay, camera, Nearby) and settings are kept.
Keep `app/airflow-debug.keystore` in the zip. Never change it, or you will have to uninstall again.

## v12.2 — realistic chips, faster gestures outside the app, live island
- **Chips that look real:** videos show a real frame with film edges, a glowing play button and the length; APKs show the app's own icon,
  name, version and size on a store-style card; songs show cover art (or a record) with title and length; PDFs show the first page; zip,
  doc, sheet, slides and other files become a paper sheet with a folded corner and a coloured type band. A glint of light crosses every chip.
  The receiver gets the same chip before the file arrives (a small preview rides with the offer).
- **Gestures outside the app:** the camera thread now has display priority (it was being starved in the background), the hand model tries the
  GPU (with a safety latch back to CPU), the service runs at 30 fps instead of 20, the screen of the other app is no longer read for every
  gesture, holds are a little shorter (palm 0.85 s, others 0.68 s, thumbs 0.52 s) and the default cooldown is 450 ms.
- **Gesture island:** a dynamic-island pill at the top of the screen over any app. It tucks into a dot, swells when a hand appears (emoji, pose
  name, a ring that fills while you hold, a live mini skeleton), and springs open with the gesture name and action when it fires. During
  Air Share it shows the step (show palm / fist / open). Switch it in the Anywhere tab.

## v13.0 — Air Blast and Air Grab
Both live on **Share > Anywhere**, in the new **Air Blast** and **Air Grab** cards. Code: `AirBlast.kt` (group link, flick detector),
`AirBlastUi.kt` (the cards), plus Blast/Grab sections in `AirShareHub.kt`.

### Air Blast: one flick to the whole room
- **Sender:** turn on Air Share (hand + touch), tap *Pick files to blast* (or *Blast the link I copied*). The room opens. **Flick your open hand
  upward**, or use palm, fist, open. Every phone in the room is asked first.
- **Receivers:** turn on Air Share or Tap Share, then **Receive blasts**. An offer shows as a notification with **Accept / Decline** (and in the
  card). Only after Accept does the data move; then the normal receive animation plays and the file saves to Gallery/Downloads > AirFlow. A link
  arrives as the Quick Drop card. An unanswered offer counts as a no after 45 s.
- **Class code:** optional, up to 8 letters/digits, must match on every phone (empty = open room).
- **How it works:** Nearby `P2P_STAR`: the sender advertises, listeners join. Room cap constant `BlastLink.MAX_ROOM = 30`. Each 30 KB chunk is
  sent once to all accepting phones, with a small window, so a big file costs roughly the same time as one phone, not 30x.
- **Limits:** Nearby star mode shares one radio; the real number of phones and the speed depend on the handsets. Test with your class size and
  keep files small (a question sheet is fine). While a blast room is open, **Tap Share (touch) is paused** because Nearby allows one advertise
  and one discover at a time; it resumes when the room closes (10 min idle, or *Close the room*).
- Tuning: `FlickDetector` (0.26 of frame height in about 0.1 to 0.38 s) in `AirBlast.kt`.

### Air Grab: pick up anything on your screen
- Turn **Air Grab** on and choose *Screenshot* or *Text on screen*. With Air Share (hand + touch) running, hold a still fist over any app for
  about 0.45 s. The capture becomes the orb in your hand; open your hand toward the other phone. A screenshot lands as a picture (receiver's
  normal catch gesture); text lands as a Quick Drop text card.
- Needs the Accessibility service and **Android 11+ for screenshots** (Text mode works on older phones). The accessibility config now declares
  `canTakeScreenshot`, so after updating, switch the Air Flow Accessibility service off and on once.
- Banking and other protected screens refuse capture; the app says so. Password fields are skipped in Text mode.
- While Air Grab is on, a still fist grabs instead of pressing Back; fist swipes (Home, Notifications, Back, Recents) still work. Without the
  Accessibility service the fist keeps its old job.

## v14.0 — Hands-free (Studio > Hands-free)
Head, face and hand control of the whole phone from the one camera frame the hand tracker already reads.
Code: `FaceTracker.kt` (MediaPipe FaceLandmarker, blendshapes), `HandsFree.kt` (engine, blink classifier, zoom), `HandsFreeScreen.kt`
(panel + practice area). The workflow now also downloads `face_landmarker.task` into assets.

- **Pointer:** the head moves the cursor (nose position, One-Euro filtered, glides at display rate). *Recenter* or smile 0.7 s sets the middle.
  *Reach* slider = sensitivity. Rest the cursor at the top/bottom edge to scroll.
- **Click** (a normal blink never clicks): **Wink** (one eye 250-800 ms), **Firm blink** (both eyes longer than your own natural blinks,
  learned automatically, never under 350 ms), **Double blink**, **Hold still** (1 s dwell ring) or **Smile**. The click lands where the cursor
  was just before the eye closed; the cursor holds still while an eye is closed.
- **Easy start presets:** Easiest (head + hold still), Fast (head + wink), Hands only.
- **Zoom:** open hand, spread thumb and index = zoom in, close = zoom out; ratio is distance-free (thumb-index / palm size), a fast flick
  gives a bigger step. Sent as two continuous strokes (`willContinue`) at the cursor. Off in Cursor mode and during Air Share.
- **Face gestures:** eyebrows up = Back, head tilt = previous/next, mouth open 0.7 s = pause/resume, smile = recenter, nod scrolls when the
  head cursor is off. The island shows each action, click and zoom %, plus warnings (face not found, move closer).
- **Performance:** Quality / Balanced / Battery. The face model drops to every 2nd frame in Battery or when it takes over 40 ms.
- **Tests:** `app/src/test/.../HandsFreeTest.kt` (blink classifier: 20 normal blinks = 0 clicks, 20 winks = 20 clicks; One-Euro; zoom maths).
  The pure logic was compiled and run with kotlinc here; the Android parts were not.

Not in this version: eye-gaze pointing with 9-point calibration, the six animated cursor styles, the full guided tour and
the emulator simulation mode. Left-vs-right tilt direction and all thresholds need tuning on a real phone.

### v14.1
If `face_landmarker.task` is not in the build's assets (for example the GitHub workflow was not updated), Hands-free now downloads it once (about 4 MB) into the app's private storage and loads it from there. Needs internet only the first time.
