# Air Flow

Native Android app (Kotlin + Jetpack Compose, no WebView). Scroll YouTube Shorts / Reels with hand gestures in the air.
Hand tracking: MediaPipe Hand Landmarker (on-device). Scrolling: Accessibility Service.

## Build the APK on GitHub
1. Create a new GitHub repo and upload ALL files from this ZIP (keep the `.github` folder).
   If `.github/workflows/build.yml` did not upload, use "Add file > Create new file", name it
   `.github/workflows/build.yml`, and paste the contents of `BUILD_WORKFLOW_COPY.yml`.
2. Open the **Actions** tab > **Build APK** > **Run workflow** (it also runs on every push).
3. When it finishes, open the run and download the **AirFlow-debug-apk** artifact (zip containing the APK).
4. Install the APK on your phone (allow "install unknown apps").

The workflow downloads the MediaPipe hand model automatically, so no model file is needed in the repo.

## First run on the phone
1. Open Air Flow, allow Camera and Notifications.
2. Accessibility: if the switch is greyed out (Android 13+), open App info > ⋮ > **Allow restricted settings**, then enable Air Flow.
3. Use the **Demo** tab to learn the gestures and the **Test** tab to practise with the live camera and a fake Shorts feed.
4. Press **Start** on Home, then open YouTube Shorts.

## Gestures (v1.2)
Works in **every app**. Every gesture can be remapped or switched off in Settings.
"Auto" actions are smart and change with the app that is open.

| Gesture | Auto / default action |
|---|---|
| Pinch | Shorts, Reels, TikTok: **next video**. Music: next track. YouTube video: Like. Cursor mode: click |
| Swipe up / down (open hand) | Shorts/Reels: next / previous. YouTube video: fullscreen / exit. Players & music: volume. Browser & others: scroll page |
| Swipe left / right (open hand) | YouTube video & players: rewind / forward 10 s. Music: previous / next track. Others: sideways swipe |
| Open palm hold | Play / pause |
| Thumb up hold | Like in Shorts/Reels/YouTube, otherwise volume up (repeats while held) |
| Thumb down hold | Volume down (repeats while held) |
| Fist hold | Back |
| Peace sign hold | Screenshot |
| Point hold | Mute / unmute |
| Three fingers hold | Open camera |
| Call-me sign (thumb + little finger) hold | Open YouTube |
| Rock sign hold | **Cursor mode** on / off |
| Fist swipe up / down / left / right | Home / Notifications / Back / Recent apps |

## Cursor mode (hand mouse)
Turn it on with the rock sign, the Cursor button on Home, or the "Cursor mode" button in the notification.
- Point with your index finger: an on-screen cursor follows your fingertip over any app.
- Quick pinch = tap. This opens apps from the home screen or app drawer, presses keyboard keys, etc.
- Pinch and hold still 0.6 s (cursor turns orange) then release = long-press.
- Pinch and move straight away, then release = scroll / swipe / drag.
- Orange hold, then move, then release = press-hold-drag (move icons, reorder lists).
- Fist hold or rock sign = exit. Fist swipes (Home, Back, Recents, Notifications) keep working inside cursor mode.

Open apps by gesture: choose favorite apps in Settings and give any gesture "Open favorite app 1/2/3".

Limits: Android blocks accessibility taps on secure screens (lock-screen PIN, some banking/payment screens, password
fields in some apps). Opening the camera app can stop the front camera that Air Flow uses on some phones.
Pose thresholds (thumb, peace, call-me ...) can be tuned in `GestureEngine.kt`.
