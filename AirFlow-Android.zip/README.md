# Air Flow

Native Android app (Kotlin + Jetpack Compose, no WebView). Scroll YouTube Shorts / Reels with hand gestures in the air.
Hand tracking: MediaPipe Hand Landmarker (on-device). Scrolling: Accessibility Service.

## Build the APK on GitHub
1. Create a new GitHub repo and upload ALL files from this ZIP (keep the `.github` folder).
   If `.github/workflows/build.yml` did not upload, use "Add file > Create new file", name it
   `.github/workflows/build.yml`, and paste the contents of `BUILD_WORKFLOW_COPY.yml`.
2. Open the **Actions** tab > **Build APK** > **Run workflow** (it also runs on every push).
3. When it finishes, open the run and download the **AirFlow-debug-apk** artifact (zip containing the APK).
4. Install the APK on your phone (allow "install unknown apps").

The workflow downloads the MediaPipe hand model automatically, so no model file is needed in the repo.

## First run on the phone
1. Open Air Flow, allow Camera and Notifications.
2. Accessibility: if the switch is greyed out (Android 13+), open App info > ⋮ > **Allow restricted settings**, then enable Air Flow.
3. Use the **Demo** tab to learn the gestures and the **Test** tab to practise with the live camera and a fake Shorts feed.
4. Press **Start** on Home, then open YouTube Shorts.

## Gestures
Swipe up/down = next/previous, open palm hold = play/pause, pinch = like (double tap), fist hold = back, swipe left/right = sideways swipe.
Tune everything in Settings.
