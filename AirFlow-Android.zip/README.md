# Air Flow

Native Android app (Kotlin + Jetpack Compose, no WebView). Scroll YouTube Shorts / Reels with hand gestures in the air.
Hand tracking: MediaPipe Hand Landmarker (on-device). Scrolling: Accessibility Service.

## Build the APK on GitHub
1. Create a new GitHub repo and upload ALL files from this ZIP (keep the `.github` folder).
   If `.github/workflows/build.yml` did not upload, use "Add file > Create new file", name it
   `.github/workflows/build.yml`, and paste the contents of `BUILD_WORKFLOW_COPY.yml`.
2. Open the **Actions** tab > **Build APK** > **Run workflow** (it also runs on every push).
3. When it finishes, open the run and download the **AirFlow-debug-apk** artifact (zip containing the APK).
4. Install the APK on your phone (allow "install unknown apps").

The workflow downloads the MediaPipe hand model automatically, so no model file is needed in the repo.

## First run on the phone
1. Open Air Flow, allow Camera and Notifications.
2. Accessibility: if the switch is greyed out (Android 13+), open App info > ⋮ > **Allow restricted settings**, then enable Air Flow.
3. Use the **Demo** tab to learn the gestures and the **Test** tab to practise with the live camera and a fake Shorts feed.
4. Press **Start** on Home, then open YouTube Shorts.

## Gestures (v1.2)
Works in **every app**. Every gesture can be remapped or switched off in Settings.
"Auto" actions are smart and change with the app that is open.

| Gesture | Auto / default action |
|---|---|
| Pinch | Shorts, Reels, TikTok: **next video**. Music: next track. YouTube video: Like. Cursor mode: click |
| Swipe up / down (open hand) | Shorts/Reels: next / previous. YouTube video: fullscreen / exit. Players & music: volume. Browser & others: scroll page |
| Swipe left / right (open hand) | YouTube video & players: rewind / forward 10 s. Music: previous / next track. Others: sideways swipe |
| Open palm hold | Play / pause |
| Thumb up hold | Like in Shorts/Reels/YouTube, otherwise volume up (repeats while held) |
| Thumb down hold | Volume down (repeats while held) |
| Fist hold | Back |
| Peace sign hold | Screenshot |
| Point hold | Mute / unmute |
| Three fingers hold | Open camera |
| Call-me sign (thumb + little finger) hold | Open YouTube |
| Rock sign hold | **Cursor mode** on / off |
| Fist swipe up / down / left / right | Home / Notifications / Back / Recent apps |

## Cursor mode (hand mouse)
v1.3: runs the camera at 30+ FPS in cursor mode, uses a One-Euro filter plus display-rate interpolation for a very smooth
cursor (Settings > Cursor smoothness), a much more forgiving pinch, a generous tap tolerance, and an optional
"Hover to tap" mode (hold the cursor still ~1 s to tap).
Turn it on with the rock sign, the Cursor button on Home, or the "Cursor mode" button in the notification.
- Point with your index finger: an on-screen cursor follows your fingertip over any app.
- Quick pinch = tap. This opens apps from the home screen or app drawer, presses keyboard keys, etc.
- Pinch and hold still 0.6 s (cursor turns orange) then release = long-press.
- Pinch and move straight away, then release = scroll / swipe / drag.
- Orange hold, then move, then release = press-hold-drag (move icons, reorder lists).
- Fist hold or rock sign = exit. Fist swipes (Home, Back, Recents, Notifications) keep working inside cursor mode.

Open apps by gesture: choose favorite apps in Settings and give any gesture "Open favorite app 1/2/3".

Limits: Android blocks accessibility taps on secure screens (lock-screen PIN, some banking/payment screens, password
fields in some apps). Opening the camera app can stop the front camera that Air Flow uses on some phones.
Pose thresholds (thumb, peace, call-me ...) can be tuned in `GestureEngine.kt`.

## v2.0 — complete UI overhaul
- Cinematic 6 s intro (hand draws itself, pinches, swipes, morphs into the logo), tap to skip.
- New premium logo + adaptive launcher icon.
- Two distinct themes: **Aurora Night** (dark) and **Pearl Silk** (light), each with its own live animated background; toggle in the top bar or Settings → Appearance (System/Light/Dark).
- Glass UI, scroll-linked reveal animations, floating animated nav bar, power orb, gesture carousel.
- Interactive Tour: 18 animated lessons (9 gestures + 9 cursor-mode) with phone + camera view, step-by-step highlights, scrubber, play/pause.
- Live Test restyled with neon skeleton overlay and progress bar.

## v3.0 — Air Share (gesture photo transfer)
New **Share** tab. Grab a photo in the air on one phone and release it to another.

**Gesture (sender):** ✋ open palm (hold 0.5 s = READY) → ✊ close fist (= CAPTURE, photo shrinks into a glowing orb) → ✋ open hand (= RELEASE, orb flies to the other phone).
The receiving phone needs nothing: the orb descends, lands, turns back into the photo and is saved to Gallery > Pictures > AirFlow.
Both phones can send and receive once connected.

**The screen shows, live:** the camera with the hand skeleton, the pose it sees ("Open palm", "Fist"…), a 3-step tracker with hold progress bars,
and plain-language corrections ("Move closer", "Spread all 5 fingers", "Now close your fist"). "Watch animated demo" plays every step.

**Connect (two ways, same on both phones):**
1. Phone A: *Show my QR and code*. Phone B: *Scan the other phone's QR* (or type the 6-digit code).
2. Pick the same mode on both phones:
   * **Nearby (offline)**: Google Nearby Connections (Bluetooth + Wi-Fi Direct). No internet. Needs Google Play services and the Nearby permissions.
   * **Online**: Firebase Realtime Database carries the live signal, Supabase Storage carries the full-quality photo.

### Online setup (once, ~3 minutes)
Open Share > *Online setup* and paste the values. Nothing is hard-coded, and no `google-services.json` is needed (plain REST).

**Firebase** (required): Realtime Database > copy the URL (looks like `https://NAME-default-rtdb.firebaseio.com`). Rules:
```json
{ "rules": { "airflow": { "$room": { ".read": true, ".write": true } } } }
```
**Supabase** (optional, full quality): run in the SQL editor, then paste the project URL and anon key into the app.
```sql
insert into storage.buckets (id, name, public) values ('airflow','airflow',true) on conflict do nothing;
create policy "airflow read"   on storage.objects for select to anon using (bucket_id = 'airflow');
create policy "airflow insert" on storage.objects for insert to anon with check (bucket_id = 'airflow');
create policy "airflow update" on storage.objects for update to anon using (bucket_id = 'airflow');
```
Without Supabase the photo is sent as a 1280 px copy through Firebase. The pairing code is the private room name, so use a new code each session. These open rules are for personal use; add auth before sharing the app widely.

Note: while Share is open it uses the front camera, so the background scroll service is paused (same as the Test tab).

## v4.0 — Air Music (a Casio in the air, played with both hands)
New **Music** tab. Nothing is touched: your fingertips are the keys.

- **Both hands at once.** MediaPipe now tracks two hands in this tab, so ten fingertips can play ten notes together.
- **The touch plane.** A glowing line sits across the camera view. When a fingertip drops below it, the key under that finger sounds. The deeper you press past the line, the louder the note, and sliding sideways while below the line glides across the keys. Hovering above the line highlights the key you are about to play.
- **Six instruments, synthesised on the phone** — no samples, no assets, a few kilobytes of code: Casio Piano, E.Piano, Vibes, Organ, Synth, Marimba. 20-voice polyphony, FM/additive models with per-instrument envelopes, left hand panned slightly left and right hand slightly right, a hall reverb, and a soft limiter so a ten-finger chord compresses instead of clipping.
- **Premium visuals.** Neon skeleton for both hands, a beam of light from every playing fingertip down to its key, keys that light up with rings and sparks, note names floating up from your fingers, a light bloom that follows the music, and an equaliser driven by the real audio level.
- **Demo songs** — Air Flow theme, Für Elise, Ode to Joy, Twinkle Twinkle, Jingle Bells, Sargam — played automatically with both hands, with the keys lighting up in time.
- **Learn mode**: the next key glows and every correct hit is scored. **Sustain**, **octave shift** (±2 octaves), **volume** and **hall** sliders, all remembered between sessions.
- Audio: 44.1 kHz stereo, ~46 ms buffer. The camera runs at 30 FPS while this tab is open, and the background scroll service steps aside (the same as the Test and Share tabs).

## v5.0 — Air Draw (paint in the air)
New **Draw** tab. Pinch your thumb and index finger to put the pen down, move to draw, open your fingers to lift it. You can also run the whole toolbar in the air, so you never have to touch the phone.

- **Smooth ink.** The fingertip is smoothed with a weighted follow and every stroke is painted as quadratic curves, segment by segment, straight into one offscreen layer. A long drawing therefore stays silky, keeps undo/redo cheap, and never slows the 30 FPS camera down.
- **Five brushes**: **Neon** (coloured halo plus a white core), **Marker** (soft and wide, made for colouring in), **Rainbow** (hue cycles along the stroke), **Spray** (particles) and **Eraser**. Three brush sizes, ten premium colours, and two papers — deep night or bright white.
- **13 sample outlines to trace**: heart, star, house, cat, flower, butterfly, tree, rocket, apple, cloud, sun, fish and umbrella. They show as animated dashed guides with a live coverage meter, and finishing one celebrates.
- **In-air toolbar.** Pinch over a colour, a brush, undo, redo, sample, paper, save or clear. The fingertip cursor is drawn above the toolbar, so it can reach the buttons; touching them with a finger works too.
- **Save** flattens the drawing onto the paper colour and writes a PNG into Gallery › Pictures › AirFlow.
- Undo and redo replay the stroke list, so nothing is ever lost to a fast finger.
