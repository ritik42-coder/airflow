package com.raja.tubevault.core

import android.Manifest
import android.app.Application
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.SystemClock
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import com.raja.tubevault.App
import com.raja.tubevault.MainActivity
import com.raja.tubevault.R
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicLong

/** App-wide download queue. UI observes [items]; the work runs here (kept alive by DownloadService). */
object Downloads {
    private lateinit var app: Application
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val _items = MutableStateFlow<List<DownloadItem>>(emptyList())
    val items: StateFlow<List<DownloadItem>> = _items.asStateFlow()

    private val jobs = ConcurrentHashMap<String, Job>()
    private val requests = ConcurrentHashMap<String, Pair<MediaInfo, FormatOption>>()
    private val gate = Semaphore(2)

    val ACTIVE = setOf(Status.QUEUED, Status.DOWNLOADING, Status.MERGING, Status.SAVING)

    fun init(application: Application) {
        if (::app.isInitialized) return
        app = application
        _items.value = loadHistory()
    }

    // ---------------------------------------------------------------- public API

    fun enqueue(info: MediaInfo, opt: FormatOption) {
        val id = UUID.randomUUID().toString()
        val item = DownloadItem(
            id = id,
            title = info.title,
            uploader = info.uploader,
            thumbnail = info.thumbnail,
            label = if (opt.isAudio) "Audio M4A" else opt.label,
            isAudio = opt.isAudio,
            status = Status.QUEUED,
            progress = 0f,
            speed = 0L,
            doneBytes = 0L,
            totalBytes = opt.sizeBytes,
            uri = null,
            error = null,
            createdAt = System.currentTimeMillis()
        )
        requests[id] = info to opt
        _items.update { listOf(item) + it }
        DownloadService.start(app)
        launchJob(id)
    }

    fun retry(id: String) {
        val it = _items.value.firstOrNull { x -> x.id == id } ?: return
        if (it.status != Status.FAILED || !requests.containsKey(id)) return
        patch(id) { x -> x.copy(status = Status.QUEUED, progress = 0f, speed = 0L, doneBytes = 0L, error = null) }
        DownloadService.start(app)
        launchJob(id)
    }

    fun cancel(id: String) {
        jobs[id]?.cancel()
        requests.remove(id)
        _items.update { list -> list.filterNot { x -> x.id == id } }
    }

    fun remove(id: String, deleteFile: Boolean) {
        val item = _items.value.firstOrNull { it.id == id } ?: return
        if (item.status in ACTIVE) {
            cancel(id)
            return
        }
        if (deleteFile && item.uri != null) {
            try {
                app.contentResolver.delete(Uri.parse(item.uri), null, null)
            } catch (_: Exception) {
            }
        }
        requests.remove(id)
        _items.update { list -> list.filterNot { x -> x.id == id } }
        saveHistory()
    }

    // ---------------------------------------------------------------- engine

    private fun launchJob(id: String) {
        jobs[id] = scope.launch {
            try {
                gate.withPermit { process(id) }
            } finally {
                jobs.remove(id)
            }
        }
    }

    private fun patch(id: String, f: (DownloadItem) -> DownloadItem) {
        _items.update { list -> list.map { if (it.id == id) f(it) else it } }
    }

    private suspend fun process(id: String) {
        val (info, opt) = requests[id] ?: return
        val dir = File(app.cacheDir, "dl/$id").apply { mkdirs() }
        try {
            patch(id) { it.copy(status = Status.DOWNLOADING, progress = if (opt.sizeBytes > 0) 0f else -1f) }

            val total = opt.sizeBytes
            val done = AtomicLong(0)
            var lastT = SystemClock.elapsedRealtime()
            var lastD = 0L
            var speed = 0L
            val onBytes: (Long) -> Unit = { n ->
                val d = done.addAndGet(n)
                val now = SystemClock.elapsedRealtime()
                if (now - lastT >= 300) {
                    val inst = ((d - lastD) * 1000.0 / (now - lastT)).toLong()
                    speed = if (speed == 0L) inst else (speed * 0.6 + inst * 0.4).toLong()
                    lastT = now
                    lastD = d
                    val p = if (total > 0) (d.toFloat() / total).coerceIn(0f, 0.99f) else -1f
                    patch(id) { it.copy(progress = p, speed = speed, doneBytes = d) }
                }
            }

            val out: File
            if (opt.hlsUrl != null) {
                val v = File(dir, "hls_v.bin")
                Hls.download(opt.hlsUrl, v, onBytes)
                var aFile: File? = null
                if (opt.hlsAudioUrl != null && !opt.hlsAudioOnly) {
                    aFile = File(dir, "hls_a.bin")
                    Hls.download(opt.hlsAudioUrl, aFile, onBytes)
                }
                patch(id) { it.copy(status = Status.MERGING, progress = -1f, speed = 0L) }
                out = File(dir, if (opt.isAudio) "out.m4a" else "out.mp4")
                if (aFile != null) Muxer.merge(v, aFile, out) else Muxer.remux(v, out, opt.isAudio)
            } else if (opt.needsMerge) {
                val v = File(dir, "v.mp4")
                val a = File(dir, "a.m4a")
                Net.download(opt.video!!.content, v, onBytes)
                Net.download(opt.audio!!.content, a, onBytes)
                patch(id) { it.copy(status = Status.MERGING, progress = -1f, speed = 0L) }
                out = File(dir, "out.mp4")
                Muxer.merge(v, a, out)
                v.delete()
                a.delete()
            } else if (opt.isAudio) {
                val a = File(dir, "a.m4a")
                Net.download(opt.audio!!.content, a, onBytes)
                patch(id) { it.copy(status = Status.MERGING, progress = -1f, speed = 0L) }
                val remuxed = File(dir, "out.m4a")
                out = try {
                    Muxer.remux(a, remuxed)
                    remuxed
                } catch (e: CancellationException) {
                    throw e
                } catch (e: Throwable) {
                    a // fall back to the raw file – still plays fine
                }
            } else {
                out = File(dir, "out.mp4")
                Net.download(opt.video!!.content, out, onBytes)
            }

            patch(id) { it.copy(status = Status.SAVING, progress = -1f, speed = 0L) }
            val ext = if (opt.isAudio) "m4a" else "mp4"
            val name = MediaSaver.sanitize(info.title) +
                (if (opt.isAudio) "" else " (${opt.label.replace(" ", "")})") + "." + ext
            val mime = if (opt.isAudio) "audio/mp4" else "video/mp4"
            val size = out.length()
            val uri = MediaSaver.save(app, out, name, mime, opt.isAudio)

            patch(id) {
                it.copy(
                    status = Status.DONE, progress = 1f, speed = 0L, doneBytes = size,
                    totalBytes = size, uri = uri.toString(), error = null
                )
            }
            requests.remove(id)
            saveHistory()
            notifyDone(info.title, uri, opt.isAudio, true)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Throwable) {
            patch(id) { it.copy(status = Status.FAILED, speed = 0L, progress = 0f, error = Errors.friendly(e)) }
            notifyDone(info.title, null, opt.isAudio, false)
        } finally {
            dir.deleteRecursively()
        }
    }

    // ---------------------------------------------------------------- notifications

    private fun notifyDone(title: String, uri: Uri?, audio: Boolean, ok: Boolean) {
        try {
            if (Build.VERSION.SDK_INT >= 33 &&
                ContextCompat.checkSelfPermission(app, Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED
            ) return

            val pi: PendingIntent = if (ok && uri != null) {
                val view = Intent(Intent.ACTION_VIEW)
                    .setDataAndType(uri, if (audio) "audio/mp4" else "video/mp4")
                    .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                PendingIntent.getActivity(
                    app, uri.hashCode(), view, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
                )
            } else {
                PendingIntent.getActivity(
                    app, 0, Intent(app, MainActivity::class.java),
                    PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
                )
            }
            val n = NotificationCompat.Builder(app, App.CH_DONE)
                .setSmallIcon(R.drawable.ic_stat_download)
                .setContentTitle(if (ok) "Download complete" else "Download failed")
                .setContentText(title)
                .setContentIntent(pi)
                .setAutoCancel(true)
                .build()
            NotificationManagerCompat.from(app).notify((System.nanoTime() % 100000).toInt() + 100, n)
        } catch (_: Throwable) {
        }
    }

    // ---------------------------------------------------------------- history

    private fun saveHistory() {
        val arr = JSONArray()
        for (i in _items.value) {
            if (i.status != Status.DONE || i.uri == null) continue
            arr.put(
                JSONObject()
                    .put("id", i.id).put("title", i.title).put("uploader", i.uploader)
                    .put("thumb", i.thumbnail ?: "").put("label", i.label).put("audio", i.isAudio)
                    .put("uri", i.uri).put("size", i.totalBytes).put("time", i.createdAt)
            )
        }
        app.getSharedPreferences("tubevault", Context.MODE_PRIVATE)
            .edit().putString("history", arr.toString()).apply()
    }

    private fun loadHistory(): List<DownloadItem> {
        return try {
            val raw = app.getSharedPreferences("tubevault", Context.MODE_PRIVATE)
                .getString("history", null) ?: return emptyList()
            val arr = JSONArray(raw)
            (0 until arr.length()).map { idx ->
                val o = arr.getJSONObject(idx)
                DownloadItem(
                    id = o.getString("id"),
                    title = o.getString("title"),
                    uploader = o.optString("uploader"),
                    thumbnail = o.optString("thumb").ifEmpty { null },
                    label = o.optString("label"),
                    isAudio = o.optBoolean("audio"),
                    status = Status.DONE,
                    progress = 1f,
                    speed = 0L,
                    doneBytes = o.optLong("size"),
                    totalBytes = o.optLong("size"),
                    uri = o.getString("uri"),
                    error = null,
                    createdAt = o.optLong("time")
                )
            }
        } catch (_: Throwable) {
            emptyList()
        }
    }
}
