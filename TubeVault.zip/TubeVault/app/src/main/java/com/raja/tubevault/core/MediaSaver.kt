package com.raja.tubevault.core

import android.content.ContentValues
import android.content.Context
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import java.io.File
import java.io.IOException

/** Puts the finished file into the public Movies/TubeVault or Music/TubeVault folder. */
object MediaSaver {
    private const val FOLDER = "TubeVault"

    @Suppress("DEPRECATION")
    fun save(ctx: Context, file: File, name: String, mime: String, audio: Boolean): Uri {
        val cr = ctx.contentResolver
        if (Build.VERSION.SDK_INT >= 29) {
            val values = ContentValues().apply {
                put(MediaStore.MediaColumns.DISPLAY_NAME, name)
                put(MediaStore.MediaColumns.MIME_TYPE, mime)
                put(
                    MediaStore.MediaColumns.RELATIVE_PATH,
                    (if (audio) Environment.DIRECTORY_MUSIC else Environment.DIRECTORY_MOVIES) + "/" + FOLDER
                )
                put(MediaStore.MediaColumns.IS_PENDING, 1)
            }
            val collection = if (audio)
                MediaStore.Audio.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
            else
                MediaStore.Video.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
            val uri = cr.insert(collection, values) ?: throw IOException("Couldn't create the file in storage")
            try {
                val os = cr.openOutputStream(uri) ?: throw IOException("Couldn't open the output file")
                os.use { o -> file.inputStream().use { it.copyTo(o, 256 * 1024) } }
                val done = ContentValues().apply { put(MediaStore.MediaColumns.IS_PENDING, 0) }
                cr.update(uri, done, null, null)
                return uri
            } catch (e: Exception) {
                try {
                    cr.delete(uri, null, null)
                } catch (_: Exception) {
                }
                throw e
            }
        } else {
            val base = Environment.getExternalStoragePublicDirectory(
                if (audio) Environment.DIRECTORY_MUSIC else Environment.DIRECTORY_MOVIES
            )
            val dir = File(base, FOLDER)
            if (!dir.exists() && !dir.mkdirs()) throw IOException("Couldn't create the TubeVault folder")
            val stem = name.substringBeforeLast('.')
            val ext = name.substringAfterLast('.', "")
            var target = File(dir, name)
            var i = 1
            while (target.exists()) {
                target = File(dir, "$stem ($i).$ext")
                i++
            }
            file.copyTo(target)
            val values = ContentValues().apply {
                put(MediaStore.MediaColumns.DATA, target.absolutePath)
                put(MediaStore.MediaColumns.DISPLAY_NAME, target.name)
                put(MediaStore.MediaColumns.MIME_TYPE, mime)
            }
            val collection = if (audio) MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
            else MediaStore.Video.Media.EXTERNAL_CONTENT_URI
            return cr.insert(collection, values) ?: Uri.fromFile(target)
        }
    }

    fun sanitize(title: String): String {
        val cleaned = title.replace(Regex("[\\\\/:*?\"<>|\\p{Cntrl}]"), " ")
            .replace(Regex("\\s+"), " ")
            .trim()
            .trim('.')
        return (if (cleaned.isEmpty()) "video" else cleaned).take(80).trim()
    }
}
