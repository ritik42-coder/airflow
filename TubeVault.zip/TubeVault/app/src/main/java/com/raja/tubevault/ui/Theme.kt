package com.raja.tubevault.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color

val Bg = Color(0xFF07070D)
val SurfaceDark = Color(0xFF12121C)
val Pink = Color(0xFFFF2E63)
val Orange = Color(0xFFFF8A3D)
val Violet = Color(0xFF8B5CF6)
val Cyan = Color(0xFF22D3EE)
val Green = Color(0xFF34D399)
val TextHi = Color(0xFFF5F5FA)
val TextLo = Color(0xFF9A9AB2)
val Glass = Color(0x14FFFFFF)
val GlassBorder = Color(0x22FFFFFF)

val AccentBrush: Brush = Brush.horizontalGradient(listOf(Pink, Orange))
val AccentBrush2: Brush = Brush.linearGradient(listOf(Violet, Pink, Orange))

@Composable
fun TubeTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Pink,
            secondary = Violet,
            background = Bg,
            surface = SurfaceDark,
            onSurface = TextHi,
            onBackground = TextHi,
            onPrimary = Color.White
        ),
        typography = Typography(),
        content = content
    )
}
